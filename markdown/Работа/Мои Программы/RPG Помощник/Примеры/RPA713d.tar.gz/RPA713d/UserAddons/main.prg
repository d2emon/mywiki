
DO FORM main	&& calls the main UserAddon demo form


RETURN




** you can add your functions in the section below  ***
** 
** any function you add to this section will be recognized by RPA and can be called in a report
** or any "advanced" labeled button of rpa (like in the skills/feats section)


****
**** sample function to change the name of a pc  ****
****
FUNCTION MyCoolNameFunction

SELECT pc	&& select the pc table

* replace the current pc name with a new cooler one, current pc index is in the variable "joueur"
replace pc.nom WITH ALLTRIM(pc.nom) + " -Cool Name" FOR no_pc = joueur

LOCATE FOR no_pc = joueur

MESSAGEBOX("Name changed to: "+ALLTRIM(pc.nom),48,"Name change")

RETURN



