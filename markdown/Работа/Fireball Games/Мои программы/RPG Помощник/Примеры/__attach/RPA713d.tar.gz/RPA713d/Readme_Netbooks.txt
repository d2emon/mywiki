
                                     The
                                    Great
                                     Net
                                  Spellbook

                                Sixth Edition
                            Compiled and edited by
                               Boudewijn Wayers

Prologue

As I promised over a year ago, I am now - finally! - posting the
Great Net Spellbook, currently at its sixth edition. This version has a
lot of new spells, compared to the fifth edition of the Spellbook.
Almost all spells were edited by me to make them somewhat more legible
(for example: SOME OF THEM WERE COMPLETELY CAPITALISED, some of the
spells contained lines that did not fit on one line, while others
contianed much speeling missteaks). Please, read this prologue
completely before continuing to read on. It contains an introduction to
the Great Net Spellbook.

Copyrights and Other Legal Stuff

Note that a lot of the spells contained in the Great Net Spellbook have
been copyrighted by their respective authors. Starting this edition,
these authors - when known - have been mentioned along with the spells
they contributed. Permission has been granted by these authors to copy
the spells for your personal use. Also, you may freely distribute copies
of their work, so long as you do not prevent others from doing the same,
and no commercial or barter considerations are obtained in exchange for
such copies.

When you distribute these spells, you must distribute them in whole,
unchanged. Specifially, this file containing the copyright conditions,
and the names of the editors must be included. Make sure that you
distribute the entire package the way you have received it yourself. You
may not claim these spells as having originated from yourself.

Once in a while, the Great Net Spellbook will be updated. Because of the
large amount of work this involves, and the few spare time we all have,
this will normally take quite a while. For example, it took me about two
years to finish the sixth edition after I published the fifth edition.
Note, however, that since the fifth edition, the entire layout has been
changed, so these two years of work have not been in vain. I have never
committed myself to a publishing date, and my successor (see the
epilogue for more information) will not likely commit himself to a date
either. Please, be gentle with him: don't rush him. Only the fact that
he has taken much of the attention off ny back over the last half year
or so has provided me with the time needed to finish this sixth edition.
Whenever he thinks he has accumulated enough new spells to warrant a
next edition, there will be a subsequent one, and it will be posted, and
most probably put on various ftp and www sites.

Another remark about copyrights: the spellbook has been checked as
thoroughly as possible not to contain any spells that have been
published in any official TSR publication before. The fifth edition of
the Great Net Spellbook appeared to contain no less than six of these
copyrighted spells, which have been duly removed. If we want to retain
our own copyrights, we must respect those of others.

D&D, Dungeons & Dragons, AD&D, Advanced Dungeons & Dragons, TSR,
Dragonlance, Greyhawk and probably lots of other words used here are
either registered or non-registered trademarks owned by TSR, Inc. They
are used in this work without permission, but this should not be
regarded as an attempt to challenge their rights.

Note that this work can and should not be used without TSR's excellent
Player's Handbook and Dungeon Master's Guide, which have inspired a
whole generation of roleplayers. Let me quote a passage from the
Player's Handbook, which says:

      "The AD&D game is continually evolving - each player and each DM
      adds his own touch to the whole. No list of special thanks can
      be complete without recognizing the most important comtributors
      of all - the millions of players who, over the years, have made
      the AD&D game what it is today."

Let's all cooperate to make the game even greater! See below, under
contributors, for an attempt to thank at least a few of the millions
mentioned above.Other Net Resources

This edition of the Great Net Spellbook now includes all spells from the
Net Carnal Knowledge Guide and the Net Guide to Alcohol, both edited by
Reid Bluebaugh <c2mxblue@fre.fsu.umd.edu>, and all spells from the first
edition of the Net Dark Sun Resource Book, edited by John Martz
<john_martz@unc.edu>. Note that this means that you will sometimes have
to refer to these sources to look up terms. Some spells that were
written for the Dark Sun world might have to be adjusted when used on
another world. This is, of course, up to individual DMs.

Note further that spells from the Tome of Mighty Magic (another Internet
resource, not the TSR book) have not been included in this edition. One
reason for this is that all these spells were lacking most second-
edition terms and were often too high or low level, the other reason was
that its copyright status is uncertain. Anyway, the Tome of Mighty Magic
can easily be used on its own, if necessary.

Contributors

Many thanks to Jim Lewallen <cscon113@uoft02.utoledo.edu> and Michael
Lerner <cl115826@ulkuvx.bitnet>, who respectively accumulated and posted
the starting lot of these spells. When they started out, they were going
to put each author's name next to each spell. Then they started getting
two or more copies of the same spell, and decided to just put their
names in one big list. Unfortunately, this meant that when I took over,
I was unable to trace most of the spells back to their original authors.
The following people have contributed to the Great Net Spellbook, but I
have been unable to link them to any specific spell. Still, I would like
to thank them for posting or e-mailing their spells (there must probably
be some people whose names are missing even here: my apologies to them
all):

Name Unknown                              <gcwynne@ecuvm1.bitnet>
Name Unknown                              <jaydee%maple.decnet@
                                           pine.circa.ufl.edu>
Name Unknown                              <mrm4730@ritvax.isc.rit.edu>
Name Unknown                              <nhoj@hicom.hitachi.com>
Howard Abrams                             <habrams%pale@cs.utah.edu>
Per Beremark                              <beaver@logm.se>
Gregory R. Block                          <gblock@csd4.csd.uwm.edu>
Gary Brewerton                            <g.p.brewerton@lut.ac.uk>
John Deachman                             NO net access any more
Ted Dreibelbis                            Address unknown
Geoffrey Edward Fagan                     <gefagan@uokmax.ecn.uoknor.edu>
Jamie Ford                                <ford@athena.cs.uga.edu>
Matthew Goldman                           <goldman@ferris.cray.com>
Richard Griffith                          <rjg@doe.carleton.ca>
Rob Holden                                <pyr530@oz.plymouth.edu>
Geoffrey Hopcraft                         <hopcraft@mailer.swarthmore.edu>
Charles K. Hughes                         <ordania-dm@cup.portal.com>
Craig A. Jensen                           <slfxx@cc.usu.edu>
Paul D. Jones (Illithid)                  <pdj7631@venus.tamu.edu>
Matt King (Archmage)                      <mck1@ra.msstate.edu>
Christopher M. Knuth                      <cmk113@psuvm.psu.edu>
David Krikorian                           <dkk@mit.edu>
Jim Lewallen                              <cscon113@uoft02.utoledo.edu>
Chua Hak Lien                             <c9e-al@danube.berkeley.edu>
Allan Longley                             <longley@theochem.uwaterloo.ca>
John Murray                               <murray@fsu.scri.fsu.edu>
Rob McNeur                                <rob@ccc.govt.nz>
Doug Newcomb (Grimbor)                    <kjenks@gothamcity.jsc.nasa.gov>
Bill Noland                               <pyr563@oz.plymouth.edu>
Louis Norton                              <lnorton@acsu.buffalo.edu>
Michael Owen                              <mwo@beach.cis.ufl.edu>
The Jade Piper                            <schmidea@clutx.clarkson.edu>
Stephen P. Potter (Sh'r'ldana)
                                          <anagram@desire.wright.edu>
Matt Presley                              <matt@sapphire.jpl.nasa.gov>
Liam Russell Eric Quin                    <lee@sq.sq.com>
Sean A. Reith                             <sean@mullet.gu.uwa.edu.au>
Rincewind                                 <tkelly@unix2.tcd.ie>
Daniel L. Rouk                            <gt6940a@prism.gatech.edu>
Allen S. Rout                             <asr@beach.cis.ufl.edu>
Ronald P. Sater                           <sater@cis.ohio-state.edu>
Donald A. Shaffer                         <dshaffer@andromeda.rutgers.edu>
Mark Steiglitz                            <steig@cs.stanford.edu>
Elf Sternberg                             <halcyon!elf@sumax.seattleu.edu>
Nathaniel Tagg                            <tagg@hg.uleth.ca>
Marcus M. Trevino                         <thedm@leland.stanford.edu>
Jim Valdesalice                           <cmk113@psuvm.psu.edu>
Jim Vilandre                              NO net access any more
Russell Wallace                           <rwallace@vax1.tcd.ie>
Lei Wang                                  <l2wang@napier.uwaterloo.ca>
Jamye Worthington                         <dmccart@modl01.intel.com>
Ed Zeamba                                 <rogue@ucrmath.ucr.edu>

Special thanks should go to Glen Barnett <barnett@agsm.unsw.edu.au>, who
didn't contribute any spells, but instead sent me some 60 kByte of
constructive criticism, which has proven very helpful in my editing
work.

On some ftp-sites, you might find some of these spells as they have
originally appeared, including the name of the one who posted them
first. Lots of spells have been e-mailed to me directly, and won't be
found on the ftp-sites, except for in this or another edition of the
Great Net Spellbook. Note that where you found this collection of
spells, you should also find a file containing all spells in their
original form, if I could trace it back.

Editor's Notes

After receiving these spells, I read them all, edited them to get a
uniform format, and to make them more legible. Also, note that, starting
the fifth edition, I did a lot of editing, and not only in a lot of
obvious cases of spelling errors.

Especially, from the fifth edition on, I have tried to remove all traces
that were left over from first edition AD&D, and to change everything to
second edition terms and format. Should you find any remains of or
references to the first edition, please send the editor e-mail saying
so, so it can be corrected in a subsequent edition.

Note that - even though they aren't in the second edition - I did retain
the cantrips. There are also some 10th-level spells, which have been
introduced into second edition AD&D in the Dragon Kings book (Dark Sun
setting).

Where no level was indicated, I just guessed what level the spell was to
be in. Furthermore, in those many cases where either school, range, area
of effect, or anything the like were missing, I just used my own
brilliant mind and made them up.



Disclaimers

   *  All references to gender have been
      generalized, where the text allowed for this
      (I have removed all references to "her" and
      "she" for uniformity reasons, since "he"
      can, in English, refer to both men and
      women).
   *  Hopefully, all first-edition notations, most
      notably the "segments" and the infamous
      "yards"-notation have been removed.
   *  The use of capitals is as uniform as I could
      manage in the little time I have (if you
      notice, for example, any capitalized names
      of spells, or spells that have not been
      italicized, please drop me a line).
   *  All spelling has been and will be changed to
      British English, not American English (at
      least, according to my speller).
   *  Talking about spelling: everything should
      have been spell-checked. If you still notice
      any errors, again, please don't hesitate to
      write the editor.
   *  The use of abbrevations has been made more
      uniform; have a look at the standards I try
      to keep to get an impression how exactly.
   *  I've tried to uniformise the references to
      foot/feet etc.

Terminology Used, often Confused

Note that the Player's Handbook clearly mentions that if a spell does
not mention otherwise, its range is always limited to the wizard's
sight, next to any other restrictions. Furthermore, when there is a
reference to a person, what is meant is any bipedal human, demihuman, or
humanoid of man-size or smaller, such as dwarves, elves, gnolls,
halflings, and kobolds. Only intelligent undead should be considered
persons.

I have used the following two notations when naming spells: II and [2].
Let me explain why I make this distinction. When a spell is named, for
example, magic bolt [2], the [2] indicates that this is a spell of about
the same strength of an already existing spell of the same name. The
corresponding [1] spell can be found in either the Great Net Spellbook
or in an official TSR publication. In the latter case, the original
spell obviously has no [1] to its name. Spells that were almost exact
copies of existing spells have not been included. When a spell is
labeled magic bolt II, the II indicates that this is greater-strength
version of an alreadly existing spell. Again, if the original spell was
from an official publication, the original won't have a I attached. Note
that most of these spells just increase the range, damage, or something
like that, and thus aren't very interesting. Sometimes, however, one of
these spells is really original. Since I don't want to be a judge on
which spells to include and which to exclude, I have decided not to
remove any spells at all.

A Final Remark

Dungeon Masters, you should be sure to check these spells before
introducing them into your campaign (preferrably before even showing
them to your players), and make sure they are right for the way you run
your campaign. Some are awfully powerful (if not munchkin-like) but
others could use a little more kick, that is for you to decide. If you
find that some spells seem far too powerful as given, but you don't have
time to adjust the range, duration, area of effect, material components
and the spell effects as carefully as you would like, you might consider
just increasing the level of the spell, to be more in accord with spells
of similar power. Similarly, you may want to reduce the level of other
spells. Don't let your players talk you into introducing a spell at too
low a level.


Boudewijn Wayers, Keeper of the Great Net Spellbook and the Great Net
Prayerbook.
March, 1995.
