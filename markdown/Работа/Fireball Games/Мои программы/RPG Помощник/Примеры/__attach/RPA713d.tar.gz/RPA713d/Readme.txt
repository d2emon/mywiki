

****************************************************
* Welcome to the world of role playing games!      *
*                                                  *
* This is the Roleplaying assistant                *
****************************************************

The Roleplaying assistant is:

The Roleplaying assistant(RPA) includes the following features:

 - Compatible with Star wars, Cyberpunk, Advanced Dungeons and Dragons, Rolemaster and Alternity gaming systems. 
 - complete character generator;
 - name generator with many name styles(SF, Tolkien, Japanese, etc.) ;
 - spellbook generator (with spell descriptions) ;
 - monster and encounter generator ;
 - weather generator ;
 - party generator ;
 - dice roller ;
 - fractal world generator ;
 - dungeon mapper ;
 - generic randomizer(inn names, plot ideas, fantasy background, etc.) ;
 - and much more...


This is the most complete generator available. Ideal for Email campaigns. 

 - RPA uses a database engine, you can store an enormous number of PC, spells,
   races, classes, etc. 
 - You can import the Great NET SPELLBOOKS, over 2200 spells, spell
   description included. 
 - A whole party of NPC can be generated in less than 5 minutes, spellbook
   included!
 - Automatic Spellbook generation, with range, area of effect, components,
   duration,... 
 - Almost everything is generated, Characteristics, Spells, Saving throws,
   Equipment sheet, Turning undead, Character sheet, Thief abilities. 
 - The character sheet includes a graphic bitmat image of your PC when you print
   it 
 - If the level of your PC goes up, just select the new level, and your saving
   throws, turning undead, spell/level, etc. will adjust automaticaly. Reprint the
   PC sheet and it's done! 


This software is shareware. See the file REGISTER.TXT for more information on registering.
See the file README.RTF for information on the drawings included in this package.

*** LEGAL STUFF ***

Beyond a fee for the reproduction and media cost, no fee may be charged 
for distribution of this software.

This software claims no warranty, implied or otherwise.  This software 
is provided "AS IS".  The author claims no responsibility for any damages 
that might be caused by the use or abuse of this software.  This software 
remains the property of the author.  This software may not be modified in 
any way.


*** Notes

Thank you to John Olsson for providing "C" source code in the Fractal world generator,
John can be reached at http://www.lysator.liu.se/~johol/

The source code of Worldgen and the GNU license can be found in the worldgen subdirectory.


Thank you also to Igor Pavlov for providing the free 7-zip software.

Igor's site is at http://compress.da.ru/  and the 7-zip files can be found in the 7-zip subdirectory of this package.


***********************  Enjoy!  ******************************


RPA Home page: http://www.rpgweb.com


