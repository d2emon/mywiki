Settings
========

For now, look in
`wiki/conf/settings.py <https://github.com/django-wiki/django-wiki/blob/master/wiki/conf/settings.py>`_
to see a list of available settings.
