from __future__ import unicode_literals
default_app_config = 'wiki.apps.AttachmentsConfig'
