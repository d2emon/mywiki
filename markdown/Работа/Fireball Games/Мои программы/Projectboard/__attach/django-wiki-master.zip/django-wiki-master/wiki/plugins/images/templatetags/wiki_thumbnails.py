from __future__ import absolute_import
from sorl.thumbnail.templatetags.thumbnail import register
