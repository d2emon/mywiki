 * Create signal for new articles and automatically subscribe users creating the article to notifications?
