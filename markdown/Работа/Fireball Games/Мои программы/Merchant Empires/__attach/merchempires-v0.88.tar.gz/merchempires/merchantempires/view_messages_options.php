<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: View Messages Options</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "viewmessages");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;
$db->add_parameter("current_screen", "view_messages_options");
echo $db->get_transform("./xslt/menu_top_view_messages.xslt", "");
?>
<br>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td valign=top>
									<font  color=#cccccc face=arial,helvetica,swiss size=3>
									<form action=<?php
echo $sess->url(URL . "messages_update.php");
?>
									method=post>
									<font color=#ccccc face=arial,helvetica,swiss size=2>Ignore messages sent to all merchants:</font>			
									<input type=radio name=ignore_global <?php

if ( $player->f("ignore_global") == 't' ) { echo " checked "; }
?>
						value=Yes>Yes
						<input type=radio name=ignore_global <?php

if ( $player->f("ignore_global") == 'f' ) { echo " checked "; }
?>
									value=No>No
									<br>
                  <font color=#ccccc face=arial,helvetica,swiss size=2>Automatically quote original message when replying:</font>			
									<input type=radio name=quote_original <?php

if ( $player->f("quote_original") == 't' ) { echo " checked "; }
?>
						value=Yes>Yes
						<input type=radio name=quote_original <?php

if ( $player->f("quote_original") == 'f' ) { echo " checked "; }
?>
									value=No>No
									<br>
                  <font color=#ccccc face=arial,helvetica,swiss size=2>Scout reports trigger alert:</font>			
									<input type=radio name=ignore_scout <?php

if ( $player->f("ignore_scout") == 'f' ) { echo " checked "; }
?>
						value=No>Yes
						<input type=radio name=ignore_scout <?php

if ( $player->f("ignore_scout") == 't' ) { echo " checked "; }
?>
									value=Yes>No
									<br>
                  <font color=#ccccc face=arial,helvetica,swiss size=2>Planetary reports trigger alert:</font>			
									<input type=radio name=ignore_planetary <?php

if ( $player->f("ignore_planetary") == 'f' ) { echo " checked "; }
?>
						value=No>Yes
						<input type=radio name=ignore_planetary <?php

if ( $player->f("ignore_planetary") == 't' ) { echo " checked "; }
?>
									value=Yes>No
									<br>
									<br><INPUT name=update_options value=Update type=submit>
									<br><br><font color=#3333FF face=arial,helvetica,swiss size=3>Hot List</font><br>
									<?php

$player_config = new ME_Player_config;
$player_config->get_player_config($player_id);

$hot_list = explode(",", $player_config->f("hot_list"));

echo "&nbsp;&nbsp;<select size='" . (count($hot_list) + 1) . "' name=list_member>";

for ($i = 0; $i <= count($hot_list) - 1; $i++) {
	echo "<option>" . stripslashes($hot_list[$i]) . "</option>";	
}		
echo "<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>";

echo "</select><br>";
echo "&nbsp;&nbsp;<input type=textbox name=merchant_name size=10>&nbsp;<input type=submit name=add_list value=Add>";
echo "<br>&nbsp;&nbsp;<input type=submit name=delete_list value=Delete>";

?>
									</select>
									</form>
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
