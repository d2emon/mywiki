<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./lib/player.php");
include("./lib/player_alliance.php");
include("./lib/player_map.php");
include("./lib/sector.php");
include("./lib/player_redirect.php");

$error = 0;

if ( $player_id > 0 )  {
	$db = new ME_DB;

	# update player turns
	$player = new ME_Player;
	$player->get_player($player_id);
	$ship = new ME_Ship;
	$ship->get_ship($player_id);
	$turns = $player->f("turns");
	$newturns = $player->f("newturnsleft");

	$turns_per_sector = $ship->f("turns_per_sector");	
		
	# only move if the player has a turn
	if ( ($player->f("turns") - $turns_per_sector) >= 0 )  {
		if ( $newturns > 0 ) {
			if ( ceil($newturns - $turns_per_sector) < 0 ) {
				$player->set_new_turns_left(0);
			} else {
				$player->set_new_turns_left(ceil($newturns - $turns_per_sector));
			}
		}

		# process forces in the current sector
		$db_f = new ME_DB;
		$query = sprintf("select * from forces where sector_id = '%s' and forces.player_id <> '%s' and mine > 0", $ship->f("sector_id"), $player->f("player_id"));
		$db_f->query($query);
		
		if ( $move <> $ship->f("last_move_sector_id") ) {
			if ( $db_f->nf() > 0 ) {
				# fill treaties
				$treaties = get_treaties($player->f("alliance_id"), 'Free Movement');
				$tactical_defense = get_tactical_defense($ship, $player->f("level"));

				while ( $db_f->next_record() ) {
					if ( $player->f("newturnsleft") == 0 ) {
						if ( $db_f->f("alliance_id") <> $player->f("alliance_id") or $db_f->f("alliance_id") == 0 ) {
							if ( $db_f->f("focused_alliance_id") <> 0 and $db_f->f("focused_alliance_id") <> $player->f("alliance_id") ) {
								# nothing
							} elseif ( $db_f->f("focused_player_id") <> 0 and $db_f->f("focused_player_id") <> $player->f("player_id") ) {
								# nothing
							} elseif ( in_array($db_f->f("alliance_id"), $treaties) ) {
								# nothing
							} else {
								if ( $db_f->f("repulsion") == 'f' ) {
									if ( $db_f->f("mine") <= 10 ) {
										$percent_escape = 25;
									} elseif ( $db_f->f("mine") > 10 and $db_f->f("mine") <= 20 ) {
										$percent_escape = 20;
									} elseif ( $db_f->f("mine") > 20 and $db_f->f("mine") <= 30 ) {
										$percent_escape = 15;
									} elseif ( $db_f->f("mine") > 30 and $db_f->f("mine") <= 40 ) {
										$percent_escape = 10;
									} elseif ( $db_f->f("mine") > 40 ) {
										$percent_escape = 5;
									}

									if ( $ship->f("cloak") and $ship->f("cloak_active") == 't' ) {
										$percent_escape = $percent_escape + 10;
									}

									$num = rand(1,100);

									if ( $num > $percent_escape + $tactical_defense ) {										
										$returnto = "attack";
										$id = $db_f->f("forces_id");
										$type = "m";
										$refer = "moveto";											
									}
								}
							}
						}
					}
				}
			}
		}

		#determine if its possible to move to the target sector
		$s1 = new ME_Sector;
		$s1->get_sector($player_id);
	
		$move = (int) $move;		
		$query = sprintf("select * from sectors where sector_id = '%s'", $move);
		$db->query($query);
		$db->next_record();

		if ( $s1->f("map_id") == $db->f("map_id") and $returnto <> "attack" ) {
			$exits = $db->f("exits");
			$str = $s1->f("xpos") . ":" . $s1->f("ypos");
			$move_public = $db->f("public_sector_id");
	
			# move to the target sector
			if ((strpos ("." . $exits, $str))) {
				if( !isset($repulsion_check) ) {
					$repulsion_check = 1;
				};

				# check for repulsion fields
				if ( $repulsion_check ) {
					$query = sprintf("select * from forces where sector_id = '%s' and player_id <> '%s' and mine > 19 and repulsion = 't'", $move, $player->f("player_id"));
					$db_f->query($query);
		
					if ( $db_f->nf() > 0 ) {
						$date = date("H:i m/d/y");
						$date_integer = time();

						if ( !isset($treaties) ) {
							# fill treaties										
							$treaties = get_treaties($player->f("alliance_id"), 'Free Movement');
						}						

						while ( $db_f->next_record() ) {
							if ( $player->f("newturnsleft") == 0 and $db_f->f("mine") > 0 ) {
								if ( $db_f->f("alliance_id") <> $player->f("alliance_id") or $db_f->f("alliance_id") == 0 ) {
									if ( $db_f->f("focused_alliance_id") <> 0 and $db_f->f("focused_alliance_id") <> $player->f("alliance_id") ) {
										# nothing
									} elseif ( $db_f->f("focused_player_id") <> 0 and $db_f->f("focused_player_id") <> $player->f("player_id") ) {
										# nothing
									} elseif ( in_array($db_f->f("alliance_id"), $treaties) ) {
										# nothing
									} else {
										for ($i = 1; $i <= $db_f->f("mine"); $i++) {
											$returnto = "repulsion";
											$id = $db_f->f("forces_id");
										}
									}
								}
							}
						}
					}
		    }

				if ( $returnto <> "repulsion" ) {
		  		$ship->set_sector_id($move);
					$ship->set_planet_id(0);
					$ship->set_last_move_sector_id($ship->f("sector_id"));
					$ship->set_public_sector_id($move_public);
					$ship->set_last_move_date(time());
  				$ship->save();

					$experience_gain = save_player_map($s1->f("map_id"), $player, $move);

					$num = rand(1,20);
					if ( $num == 20 ) {
						$experience_gain = 1;
					}

					if ( $experience_gain > 0 ) {
						$experience = $player->f("experience") + $experience_gain;
						$player->set_experience($experience);				
					}

					# process forces in the new sector				
					$db_m = new ME_DB;				

					$query = sprintf("select * from forces where sector_id = '%s' and player_id <> '%s'", $move, $player->f("player_id"));
					$db_f->query($query);
		
					if ( $db_f->nf() > 0 ) {
						$date = date("H:i m/d/y");
						$date_integer = time();

						# fill treaties
						if ( !isset($treaties) ) {								
							$treaties = get_treaties($player->f("alliance_id"), 'Free Movement');
						}
	
						if ( !isset($tactical_defense) ) {
							$tactical_defense = get_tactical_defense($ship, $player->f("level"));
						}

						while ( $db_f->next_record() ) {
							if ( $ship->f("cloak_active") == 't' and $ship->f("cloak") ) {
								# nothing
							} else {
								if ( $db_f->f("alliance_id") <> $player->f("alliance_id") or $db_f->f("alliance_id") == 0 ) {
									if ( $db_f->f("focused_alliance_id") <> 0 and $db_f->f("focused_alliance_id") <> $player->f("alliance_id") ) {
										# nothing
									} elseif ( $db_f->f("focused_player_id") <> 0 and $db_f->f("focused_player_id") <> $player->f("player_id") ) {
										# nothing
									} elseif ( $db_f->f("scout") > 0 ) {
										$scout_player_id = $db_f->f("player_id");

										$query = "select player_id, message_id from messages where player_id = '$scout_player_id' and scout = 't' order by message_id";
										$db_m->query($query);
										$db_m->next_record();
										if ( $db_m->nf() > 50 ) {
					          	$message_id = $db_m->f("message_id");

											$query = "delete from messages where message_id = '$message_id'";
											$db_m->query($query);
										}

										$message = "Movement detected in sector " . $move_public;
										$message = $message . "<br>Merchant: " . addslashes($player->f("name"));
										$message = $message . "<br>Alliance: " . addslashes($player->f("alliance_name"));
										$message = $message . "<br>Ship type: " . $ship->f("type");
										$message = $message . "<br>Entered via sector: " . $ship->f("public_sector_id");
										$query = "insert into messages (player_id, message, date, toplayer, scout, date_integer)
										values ('$scout_player_id', '$message', '$date', 'Drone Comm Link', 't', '$date_integer')";
										$db_m->query($query);
									}
								}
							}        	
				
							if ( $player->f("newturnsleft") == 0 and $db_f->f("mine") > 0 ) {								
								if ( $db_f->f("alliance_id") <> $player->f("alliance_id") or $db_f->f("alliance_id") == 0 ) {
									if ( $db_f->f("focused_alliance_id") <> 0 and $db_f->f("focused_alliance_id") <> $player->f("alliance_id") ) {
										# nothing
									} elseif ( $db_f->f("focused_player_id") <> 0 and $db_f->f("focused_player_id") <> $player->f("player_id") ) {
										# nothing
									} elseif ( in_array($db_f->f("alliance_id"), $treaties) ) {
										# nothing
									} else {										
										if ( $db->f("mine") <= 5 ) {
											$percent_escape = 35;
										} elseif ( $db->f("mine") > 5 and $db->f("mine") <= 10 ) {
											$percent_escape = 25;
										} elseif ( $db_f->f("mine") > 10 and $db_f->f("mine") <= 20 ) {
											$percent_escape = 20;
										} elseif ( $db_f->f("mine") > 20 and $db_f->f("mine") <= 30 ) {
											$percent_escape = 15;
										} elseif ( $db_f->f("mine") > 30 and $db_f->f("mine") <= 40 ) {
											$percent_escape = 10;
										} elseif ( $db_f->f("mine") > 40 ) {
											$percent_escape = 5;
										}

										if ( $ship->f("cloak") and $ship->f("cloak_active") == 't' ) {
											$percent_escape = $percent_escape + 10;
										}

										$num = rand(1,100);
        		
										if ( $num > $percent_escape + $tactical_defense ) {
											$returnto = "attack";
											$id = $db_f->f("forces_id");
											$type = "m";
											$refer = "moveto";																						
										}
									}
								}
							}
						}
					}				

					if ( $follow_course == 1 ) {
						$query = "select player_id, course from ships where player_id = '$player_id'";
						$db->query($query);
						$db->next_record();

						$course = array();
						$course = explode(",", $db->f("course"));
        	  array_splice($course, 0, 1);
						$str_course = implode (",", $course);				
						$ship_id = $ship->f("ship_id");
						$query = "update ships set course = '$str_course' where ship_id = '$ship_id'";
						$db->query($query);	
					
						if ( count($course) == 1 ) {
							$follow_course = 0;
						}			
					}

					if ( $ship->f("tractor_beam") and $ship->f("tractor_beam_locked") == 't' and $ship->f("tractor_beam_time") < time() and $ship->f("tractor_beam_time") <> 0 ) {
						$tractor_beam_player_id = $ship->f("tractor_beam_player_id");
						$db->query("update ships set sector_id = '$move' where player_id = '$tractor_beam_player_id'");

						$player->set_turns($turns - $turns_per_sector * 2.5);
						$player->save();
					} else {
						$player->set_turns($turns - $turns_per_sector);
						$player->save();
					}
				}
			}
		}
	} else {
		$error = 4;
		# no turns
	}

	if ( $error ) {
		if ($returnto == "currentsector")  {
			$newurl = $sess->url(URL . "current_sector.php?error=$error");
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "local_map.php?error=$error");
	  	header("Location: $newurl");
		}
	} else {
		if ($returnto == "currentsector")  {
			if ( $follow_course == 1 ) {
				$newurl = $sess->url(URL . "current_sector.php?follow_course=1");
				header("Location: $newurl");
			} else {
				$newurl = $sess->url(URL . "current_sector.php");
				header("Location: $newurl");
			}
		} elseif ($returnto == "attack") {
			$newurl = $sess->url(URL . "attack.php" . "?refer=" . $refer . "&id=" . $id . "&type=" . $type );
			header("Location: $newurl");	
		} elseif ($returnto == "repulsion") {
			$newurl = $sess->url(URL . "move_to_sector_repulsion.php" . "?move=" . $move . "&id=" . $id );
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "local_map.php");
	  	header("Location: $newurl");
		}
	}
}

page_close();
?>