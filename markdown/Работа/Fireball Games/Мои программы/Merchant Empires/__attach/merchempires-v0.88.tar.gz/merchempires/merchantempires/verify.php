<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

include("./merchantempiresdefines.php");
?>

<html><head><title>Merchant Empires: Validation</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top>

</td><td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0 width=350>
	<tr>
  	<td bgColor=#993300>
    	<table border=0 cellPadding=5 cellSpacing=1 width=100%>
      	<tr>
        	<td bgColor=#330000><FONT color=#ffffff  face=arial,helvetica,swiss size=4><B>Validate Your User
          	</B></FONT><BR clear=all>
         </td>
	    	</tr>
        <tr>
        	<td bgColor=#000000><FONT  color=#cccccc face=arial,helvetica,swiss size=2>
						<form METHOD="POST" ACTION=<?php printf("%s", URL); ?>validate_user.php>
						<table>
 		  				<tr>
  		  				<td>Code:</td>
  		  				<td ><input TYPE="textbox" NAME="code" size=20></td>
		  				</tr>
		 	 				<tr>
		  					<td></td>
 		  					<td><input TYPE="submit" NAME="validate" VALUE="Validate"></td>
		  				</tr>
		   			</table>
		   			</form>
	       	</td>
		  	</tr>
			</table>
	  </td>
	</tr>
</table>
</td>

<td>

</td></tr></table>
</body></html>