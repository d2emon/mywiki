<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./lib/weapons.php");
include("./lib/technology.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

function delete_weapon($id, $ship_id) {
	switch ($id) {
		case "1":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_1_id = 0, weapon_1_name = '', weapon_1_shield_damage = 0, weapon_1_armor_damage = 0
				where ship_id = '$ship_id'");			
			break;
   	case "2":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_2_id = 0, weapon_2_name = '', weapon_2_shield_damage = 0, weapon_2_armor_damage = 0
				where ship_id = '$ship_id'");
			break;
		case "3":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_3_id = 0, weapon_3_name = '', weapon_3_shield_damage = 0, weapon_3_armor_damage = 0
				where ship_id = '$ship_id'");
			break;
		case "4":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_4_id = 0, weapon_4_name = '',  weapon_4_shield_damage = 0, weapon_4_armor_damage = 0
				where ship_id = '$ship_id'");			
			break;
		case "5":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_5_id = 0, weapon_5_name = '',  weapon_5_shield_damage = 0, weapon_5_armor_damage = 0
				where ship_id = '$ship_id'");			
			break;
		case "6":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_6_id = 0, weapon_6_name = '',  weapon_6_shield_damage = 0, weapon_6_armor_damage = 0
				where ship_id = '$ship_id'");			
			break;
		case "7":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_7_id = 0, weapon_7_name = '',  weapon_7_shield_damage = 0, weapon_7_armor_damage = 0
				where ship_id = '$ship_id'");			
			break;
		case "8":
			$db = new ME_DB;
			$db->query("update ship_weapons set weapon_8_id = 0, weapon_8_name = '',  weapon_8_shield_damage = 0, weapon_8_armor_damage = 0
				where ship_id = '$ship_id'");		
			break;
	}
}

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$s1 = new ME_Sector;
$s1->get_sector($player_id);
$sector_id = $s1->f("sector_id");

$db = new ME_DB;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Shipdealer'");
$db->next_record();
$options = $db->f("options");	
$ships = explode(",", $options);

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "trade_ship":
			$returnto = "ship_dealer";

			if ( $db->nf() == 0 ) {
				$returnto = "current_sector";
				break;
			}

	    $db = new ME_DB;
		
			$current_id = $ship->f("type_id");		
			$db->query("select * from ship_types where ship_type_id = '$current_id'");
			$db->next_record();
			$resale = (int) ($db->f("cost") / 2);			

			$id = (int) $id;
			$db->query("SELECT * from ship_types where ship_type_id = '$id'");
			$db->next_record();

			if ( $player->f("level") < $db->f("experience_level") ) {
				$returnto = "ship_dealer_examine";
				$error = 8;
				break;
			}

			if ( $db->nf() == 0 ) {
				$returnto = "ship_dealer_examine";
				$error = 5;
				break;
			}

			if ( $player->f("race_number") <> $db->f("race") and $db->f("race") <> 0 ) {
				$returnto = "ship_dealer_examine";
				$error = 3;
				break;
			}

			if ( $db->f("cost") - $resale > $player->f("credits") ) {
				$returnto = "ship_dealer_examine";
				$error = 1;
				break;
			}

			if ( $db->f("restrictions") == 1 and $player->f("alignment") < 300 ) {
				$returnto = "ship_dealer_examine";
				$error = 9;
				break;
			}

			if ( $db->f("restrictions") == 2 and $player->f("alignment") > -300 ) {
				$returnto = "ship_dealer_examine";
				$error = 9;
				break;
			}

			$ship_found = 0;
			while (list($key, $val) = each($ships)) {
      	if ( $val == $id ) { $ship_found = 1; }
			}

			if ( !$ship_found ) {
				$returnto = "ship_dealer_examine";
				$error = 2;
				break;
			}
			
			$ship->set_type_id($db->f("ship_type_id"));
			$ship->set_type($db->f("name"));
	
			$ship->set_shieldmax($db->f("shieldmax"));

			if ( $ship->f("shieldcurrent") > $db->f("shieldmax") and $db->f("shieldmax") <> 0 ) {
				$ship->set_shieldcurrent($db->f("shieldmax"));
			} elseif ( $db->f("shieldmax") == 0 ) {
				$ship->set_shieldcurrent(0);
			}

			$ship->set_armormax($db->f("armormax"));

			if ( $ship->f("armorcurrent") > $db->f("armormax") and $db->f("armormax") <> 0 ) {
				$ship->set_armorcurrent($db->f("armormax"));
			} elseif ( $db->f("armormax") == 0 ) {
				$ship->set_armorcurrent(0);
			}

			$ship->set_powermax($db->f("powermax"));

			if ( $ship->f("powercurrent") > $db->f("powermax") and $db->f("powermax") <> 0 ) {
				$ship->set_powercurrent($db->f("powermax"));
			} elseif ( $db->f("powermax") == 0 ) {
				$ship->set_powercurrent(0);
			}

			$ship->set_minesmax($db->f("minesmax"));

			if ( $ship->f("minescurrent") > $db->f("minesmax") and  $db->f("minesmax") <> 0 ) {
				$ship->set_minescurrent($db->f("minesmax"));
			} elseif (  $db->f("minesmax") == 0 ) {
				$ship->set_minescurrent(0);
			}

			$ship->set_combatmax($db->f("combatmax"));

			if ( $ship->f("combatcurrent") > $db->f("combatmax") and $db->f("combatmax") <> 0 ) {
				$ship->set_combatcurrent($db->f("combatmax"));
			} elseif ( $db->f("combatmax") == 0 ) {
				$ship->set_combatcurrent(0);
			}

			$ship->set_scoutmax($db->f("scoutmax"));

			if ( $ship->f("scoutcurrent") > $db->f("scoutmax") and $db->f("scoutmax") <> 0 ) {
				$ship->set_scoutcurrent($db->f("scoutmax"));
			} elseif ( $db->f("scoutmax") == 0 ) {
  			$ship->set_scoutcurrent(0);
			}
	
			$ship->set_cargomax($db->f("cargomax"));

			if ( $ship->f("cargocurrent") > $db->f("cargomax") and $db->f("cargomax") <> 0 ) {
				$ship->set_cargocurrent($db->f("cargomax"));
			} elseif ( $db->f("cargomax") == 0 ) {
				$ship->set_cargocurrent(0);
			}

			$ship->set_hardpoints($db->f("hardpoints"));				
			$ship->set_turns_per_sector($db->f("turns_per_sector"));

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));						

			if ( $db->f("scanner") == 'f' ) {
				$technology->set_scanner(0);
			}

			if ( $db->f("illusion") == 'f' ) {
				$technology->set_illusion(0);
			}

			if ( $db->f("jump") == 'f' ) {
				$technology->set_jump(0);
			}

			if ( $db->f("galaxy_jump") == 'f' ) {
				$technology->set_galaxy_jump('f');
			} else {
				$technology->set_galaxy_jump('t');
			}

			if ( $db->f("cloak") == 'f' ) {
				$technology->set_cloak(0);
			}

			$technology->save();

			# delete extra weapons
			if ( $db->f("hardpoints") < $ship->f("hardpoints") ) {
				$weapons = new ME_Weapons;
				$weapons->get_weapons($ship->f("ship_id"));
				$hardpoints = 0;

		    while (list($key, $val) = each($weapons->Current_weapons)) {
					if ( $hardpoints >= $db->f("hardpoints") ) {
							delete_weapon($key, $ship->f("ship_id"));
					}
					
					$hardpoints = $hardpoints + 1;
				}
			}

			$current_id = $ship->f("type_id");
			$db_2 = new ME_DB;
			$db_2->query("select * from ship_types where ship_type_id = '$current_id'");
			$db_2->next_record();

			$resale = (int) ($db_2->f("cost") / 2);

			$new_credits = ($player->f("credits") - $db->f("cost")) + $resale;

			if ( $player->f("newturnsleft") > 100 ) {
				$player->set_new_turns_left(0);
			}

			$player->set_credits($new_credits);
			$player->save();

			$ship->save();

			break;

		case "deliver_ship":
			$returnto = "ship_dealer";
			$delivery_time = 0;

			if ( $db->nf() == 0 ) {
				$returnto = "current_sector";
				break;
			}
			
	    $db = new ME_DB;
		
			$id = (int) $id;
			$db->query("SELECT * from ship_types where ship_type_id = '$id'");
			$db->next_record();

			if ( $db->f("restrictions") == 1 and $player->f("alignment") < 300 ) {
				$returnto = "ship_dealer_examine";
				$error = 9;
				break;
			}

			if ( $db->f("restrictions") == 2 and $player->f("alignment") > -300 ) {
				$returnto = "ship_dealer_examine";
				$error = 9;
				break;
			}

			if ( $player->f("level") < $db->f("experience_level") ) {
				$returnto = "ship_dealer_examine";
				$error = 8;
				break;
			}
		
			if ( $db->nf() == 0 ) {
				$returnto = "ship_dealer_examine";
				$error = 5;
				break;
			}

			$cost = $db->f("cost");

			if ( $player->f("race_number") <> $db->f("race") and $db->f("race") <> 0 ) {
				$returnto = "ship_dealer_examine";
				$error = 3;
				break;
			}

			if ( $cost + 250000 > $player->f("credits") ) {
				$returnto = "ship_dealer_examine";
				$error = 1;
				break;
			}

			$ship_found = 0;
			while (list($key, $val) = each($ships)) {
      	if ( $val == $id ) { $ship_found = 1; }
			}

			if ( !$ship_found ) {
				$returnto = "ship_dealer_examine";
				$error = 2;
				break;
			}
			
			$stored_ship_type_id = $db->f("ship_type_id");
			$stored_ship_type = $db->f("name");

			$stored_ship_shieldmax = $db->f("shieldmax");			
			$stored_ship_shieldcurrent = 0;

			$stored_ship_armormax = $db->f("armormax");			
			$stored_ship_armorcurrent = 0;

			$stored_ship_powermax = $db->f("powermax");			
			$stored_ship_powercurrent = 15;

			$stored_ship_minesmax = $db->f("minesmax");			
			$stored_ship_minescurrent = 0;

			$stored_ship_combatmax = $db->f("combatmax");			
			$stored_ship_combatcurrent = 0;	

			$stored_ship_scoutmax = $db->f("scoutmax");
 			$stored_ship_scoutcurrent = 0;	

			$stored_ship_cargomax = $db->f("cargomax");			
			$stored_ship_cargocurrent = 0;
		
			$stored_ship_hardpoints = $db->f("hardpoints");				
			$stored_ship_turns_per_sector = $db->f("turns_per_sector");

			$stored_ship_galaxy_jump = $db->f("galaxy_jump");

			$stored_ship_scanner = 0;		
			$stored_ship_illusion = 0;
			$stored_ship_jump = 0;			
			$stored_ship_cloak = 0;
			
			$delivery_sector_id = (int) $delivery_sector_id;				
			$query = sprintf("select * from sectors where public_sector_id = '%s'", $delivery_sector_id);
			$db_2 = new ME_DB;
			$db_2->query($query);								

			$valid_sector = 0;

			$db_m = new ME_DB;

			while (	$db_2->next_record() and !($valid_sector) ) {								
				$query = sprintf("select * from maps where map_id = '%s'", $db_2->f("map_id"));
				$db_m->query($query);
        $db_m->next_record();

				if ( $game_id == $db_m->f("game_id") ) {
					$map_id = $db_m->f("map_id");			
					$planet_sector_id = $db_2->f("sector_id");
					$valid_sector = 1;					
				}
			}			
						
			$db->query("select * from planets where sector_id = '$planet_sector_id'");
			$db->next_record();			

			if ( $db->nf() == 0 or !($valid_sector) ) {
				$returnto = "ship_dealer_examine";
				$error = 4;
				break;
			}

			$alliance_id = $db->f("alliance_id");
			$owner_id = $db->f("owner_id");
			$planet_id = $db->f("planet_id");
			
			if ( $owner_id == $player->f("player_id") ) {
				$db->query("select * from ships_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				if ( $db->nf() >= 3 ) {
					$returnto = "ship_dealer_examine";
					$error = 7;
					break;
				}
			} elseif ( $alliance_id == $player->f("alliance_id") and $alliance_id <> 0 ) {
				$db->query("select * from ships_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				if ( $db->nf() >= 1 ) {
					$returnto = "ship_dealer_examine";
					$error = 7;
					break;
				}
			} else {
				$returnto = "ship_dealer_examine";
				$error = 6;
				break;
			}

			$new_credits = ($player->f("credits") - $cost) - 250000;
			$player->set_credits($new_credits);

			if ( $player->f("newturnsleft") > 100 ) {
				$player->set_new_turns_left(0);
			}

			$player->save();
			
			$delivery_time = time() + 1800;
			$query = "insert into ships_storage (player_id, planet_id, type_id, type, shieldmax, shieldcurrent, armormax, armorcurrent,
				minesmax, minescurrent, combatmax, combatcurrent, scoutmax, scoutcurrent,
				cargomax, cargocurrent, hardpoints, scanner, illusion, cloak,
				jump, galaxy_jump, turns_per_sector, delivery_time, powermax, powercurrent)

				values($player_id, $planet_id, $stored_ship_type_id, '$stored_ship_type', $stored_ship_shieldmax, $stored_ship_shieldcurrent, $stored_ship_armormax, $stored_ship_armorcurrent,
				$stored_ship_minesmax, $stored_ship_minescurrent, $stored_ship_combatmax, $stored_ship_combatcurrent, $stored_ship_scoutmax, $stored_ship_scoutcurrent,
				$stored_ship_cargomax, $stored_ship_cargocurrent, $stored_ship_hardpoints, '$stored_ship_scanner', '$stored_ship_illusion', '$stored_ship_cloak',
				'$stored_ship_jump', '$stored_ship_galaxy_jump', $stored_ship_turns_per_sector, $delivery_time, '$stored_ship_powermax', '$stored_ship_powercurrent')";
			$db->query($query);

			$db->query("select * from ship_storage_id");
			$db->next_record();
			$ship_stored_id = $db->f("last_value");
	
			$query = "insert into ship_weapons_stored (player_id, ship_stored_id) values
				('$player_id', '$ship_stored_id')";
			$db->query($query);

			break;
	}
}

if ( $error ) {
	if ($returnto == "ship_dealer_examine")  {
		$newurl = $sess->url(URL . "ship_dealer_examine.php?id=$id&error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "ship_dealer_examine")  {
		$newurl = $sess->url(URL . "ship_dealer_examine.php?id=$id");
		header("Location: $newurl");	
	} elseif ($returnto == "ship_dealer")  {
		if ( $delivery_time <> 0 ) {
			$newurl = $sess->url(URL . "ship_dealer.php?dt=$delivery_time");
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "ship_dealer.php");
			header("Location: $newurl");	
		}
	} elseif ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php");
		header("Location: $newurl");	
	}
}

page_close();
?>