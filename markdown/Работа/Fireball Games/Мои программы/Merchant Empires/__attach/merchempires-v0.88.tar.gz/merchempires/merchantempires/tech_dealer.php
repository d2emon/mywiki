<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/sector.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$s1 = new ME_Sector;
$s1->get_sector($player_id);
$sector_id = $s1->f("sector_id");
?>

<html><head><title>Merchant Empires: Technology Dealer</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left>
									<font color=#3333FF face=arial,helvetica,swiss size=5><?php
$db = new ME_DB;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Technology'");
$db->next_record();

if ( $db->nf() == 0 ) {
	echo "The current sector does not contain a technology dealer.";
} else {
	echo $db->f("name");
}
?>
								</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$options = $db->f("options");	
$techs = array();
$techs = explode(",", $options);

?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=4 class=clsHedTxt id=blu1><center>
					<br>Available Technology<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Item</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Cost</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Amount</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Action</center>
					</td>
				</tr><?php

while (list($key, $val) = each($techs)) {
	$val = (int) $val;
	$db = new ME_DB;
	$db->query("select technology_type_id, name, cost from technology_types where technology_type_id = '$val'");
	$db->next_record();	

	echo "<tr>";
	echo "<form action=";
	echo $sess->url(URL . "tech_dealer_update.php");
	echo " method=post  onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";
	echo "<td class=clsNrmTxt><center>";
	echo $db->f("name");
	echo "</center></td>";
	
	echo "<td class=clsNrmTxt><center>";
	echo $db->f("cost");
	echo "</center></td>";
	
	echo "<td class=clsNrmTxt><center>";

	switch ($db->f("technology_type_id")) {
		case "1":
			echo "<input type=textbox name=amount size=5>";
			break;
		case "2":
			echo "<input type=textbox name=amount size=5>";
			break;
		case "3":
			echo "<input type=textbox name=amount size=5>";
			break;
		case "8":
			echo "<input type=textbox name=amount size=5>";
			break;
		case "9":
			echo "<input type=textbox name=amount size=5>";
			break;
		case "10":
			echo "<input type=textbox name=amount size=5>";
			break;
		case "17":
			echo "<input type=textbox name=amount size=5>";
			break;
		default:
			echo "&nbsp;";
	}
	echo "</center></font></td>";

	echo "<input type=hidden name=tech_type value=" . $db->f("technology_type_id") . " size=5>";
	echo "<td class=clsNrmTxt><center>";
	echo "<input type=submit name=purchase_tech_" . $db->f("technology_type_id") . " value=Buy>";
	echo "<input type=submit name=store_tech value=Store>";
	echo "</center></td>";

	echo "</form></tr>";
}
?>							
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=blu1><center>
					<br>Installed Technology<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Item</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Offer</center>
					</td>					
					<td class=clsHedTxt id=blu1>
					<center>Action</center>
					</td>
				</tr>
				<form action=<?php

$current_techs = array();

if ( $ship->f("cloak") ) {
	array_push($current_techs, 7);	
}

if ( $ship->f("illusion") ) {
	array_push($current_techs, 4);		
}

if ( $ship->f("jump") ) {
	array_push($current_techs, 6);		
}

if ( $ship->f("scanner") ) {
	array_push($current_techs, 5);		
}

if ( $ship->f("tracking") ) {
	array_push($current_techs, 11);		
}

if ( $ship->f("deep_scanner") ) {
	array_push($current_techs, 12);		
}

if ( $ship->f("targeting_computer") ) {
	array_push($current_techs, 13);		
}

if ( $ship->f("plasma_booster") ) {
	array_push($current_techs, 14);		
}

if ( $ship->f("active_screens") ) {
	array_push($current_techs, 16);		
}

if ( $ship->f("trifocus_plasma") ) {
	array_push($current_techs, 18);		
}

if ( $ship->f("tractor_beam") ) {
	array_push($current_techs, 15);		
}

echo $sess->url(URL . "tech_dealer_update.php");
?>
					method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'><?php

while (list($key, $val) = each($current_techs)) {
	$val = (int) $val;
	$db = new ME_DB;
	$db->query("select technology_type_id, name, cost from technology_types where technology_type_id = '$val'");
	$db->next_record();

	echo "<tr>";
	echo "<td class=clsNrmTxt><center>";
	echo $db->f("name");
	echo "</center></td>";
	
	echo "<td class=clsNrmTxt><center>";
	echo ($db->f("cost") / 2);
	echo "</center></td>";
		
	echo "<td class=clsNrmTxt><center>";
	echo "<input type=submit name=sell_tech_" . $db->f("technology_type_id") . " value=Sell>";
	echo "</center></td>";

	echo "</tr>";
}
?>
				</form>				
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=4 class=clsHedTxt id=blu1><center>
					<br>Stored Technology<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Item</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Offer</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Amount on Ship</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Action</center>
					</td>
				</tr><?php

$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

$db = new ME_DB;

while (list($key, $val) = each($cargo->Current_cargo)) {
	if ( $val['type'] == 2 ) {
		$db->query("select technology_type_id, name, cost from technology_types where name = '$key'");
		$db->next_record();

		$stored_techs[$db->f("technology_type_id")] = $val['amount'];

		echo "<tr>";
		echo "<form action=";
		echo $sess->url(URL . "tech_dealer_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td class=clsNrmTxt><center>";
		echo $key;
		echo "</center></td>";
	
		echo "<td class=clsNrmTxt><center>";
		echo ($db->f("cost") / 2);
		echo "</center></td>";

		echo "<td class=clsNrmTxt><center>";
		echo "<input type=textbox name=amount value=" . $val['amount'] . " size=5>";
		echo "</center></td>";
		
		echo "<td class=clsNrmTxt><center>";
		echo "<input type=hidden name=tech_type value=" . $db->f("technology_type_id") . ">";
		echo "<input type=submit name=sell_stored_tech value=Sell>";
		echo "</center></td>";
		echo "</form></tr>";
	}
}

?>					
				<tr>
					<td colspan=4 bgColor=#000000>
          	<br><center><a href=<?php

echo $sess->url(URL . "local_map.php");
echo ">Leave Technology Dealer</a></center><br>";
?>

					</td>
				</tr>
			</table>
		<td>
  </tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");		
		
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to insufficient shield capacity.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient armor capacity.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "Command not processed due to insufficient cargo capacity.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "Ship type " . $ship->f("type") . " does not support that technology.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "Command not processed due to insufficient credits.");
	} elseif ($error == 6) {
		$db->add_parameter("message", "Current sector does not contain a technology dealer.");
	} elseif ($error == 8) {
		$db->add_parameter("message", "Command not processed due to insufficient mine capacity.");
	} elseif ($error == 9) {
		$db->add_parameter("message", "Command not processed due to insufficient combat drone capacity.");
	} elseif ($error == 10) {
		$db->add_parameter("message", "Command not processed due to insufficient scout drone capacity.");
	} elseif ($error == 11) {
		$db->add_parameter("message", "Command not processed due to invalid amount entered.");
	} elseif ($error == 12) {
		$db->add_parameter("message", "Your ship already has that technology installed.");
	} elseif ($error == 13) {
		$db->add_parameter("message", "Your ship does not have that technology installed.");
	} elseif ($error == 14) {
		$db->add_parameter("message", "Command not processed due to insufficient quantity on ship.");
	} elseif ($error == 15) {
		$db->add_parameter("message", "Only four modules of that technology type can be installed.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>