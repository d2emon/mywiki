<?php

#phplib doesn't like me putting in the standard ME define file here
$URL = "http://www.merchantempires.net/";
?>

<html>
<head>
<meta name="keywords" content="merchant empires, games, strategy, trade wars, free, open source, play, galaxy, rpg, game, merchants, empire, war">
<title>Merchant Empires: Login</title>
<link rel=stylesheet href="merchantempires.css" type=text/css>

</head>

<?php

$num = rand(1,3);

echo "<body text=white background='./images/loginback_" . $num . ".jpg'>";
?>

<table cellPadding=0 cellSpacing=0 border=0 width=100%>
  <tr>
    <td background="./images/headerleft.png" width=180>
      <img src="./images/spacer.gif">
    </td>
    <td background="./images/headback.png" width=100%>
      &nbsp;
    </td>
  </tr>
</table>

<br>
<table border=0 width=100%>
	<tr>
  	<td width=20% vAlign=top>
   	</td>
		<td width=30% align=left vAlign=top>
  	  <table border=0 cellPadding=0 cellSpacing=0 width=100%>
    	  <tr>
      	  <td bgColor=#993300>
        	  <table border=0 cellPadding=5 cellSpacing=1 width=100%>
          	  <tr>
								<td class=clsHedTxt id=red1>									
									Create a New User
          	       <br>
								</td>
	    				</tr>
    	        <tr>
  	            <td class=clsNrmTxt>
									If you are new to Merchant Empires you may create a user and
									join the fun.<br><br><a href=<?php printf("%s", $URL); ?>get_new_user.php>
									Create User</a>&nbsp;&nbsp;									
                  <a href=<?php printf("%s", $URL); ?>verify.php>Validate User</a>									
	      				</td>
	    				</tr>
	  				</table>
					</td>
    	  </tr>
  	  </table><br>
	  </td>
		<td width=30% align=left vAlign=top>
			<table border=0 cellPadding=0 cellSpacing=0 width=100%>
      	<tr>
        	<td bgColor=#993300>
          	<table border=0 cellPadding=5 cellSpacing=1 width=100%>
            	<tr>
              	<td class=clsHedTxt id=red1>
									Log in<br>
								</td>
							</tr>
							<tr>
              	<td class=clsNrmTxt>									
									<form METHOD="POST" ACTION="<?php printf("%s", $URL); ?>index.php3">
										<table>
								 		 <tr>
							  		  <td class=clsNrmTxt>Username:</td>
										  <td><input type="text" NAME="username" value=""></td>
										 </tr>
									 	 <tr>
								  	  <td class=clsNrmTxt>Password:</td>
								  	  <td><input type="password" NAME="password"></td>
									 	 </tr>
										 <tr>
										  <td></td>
										  <td>
												<input type="submit" NAME="Default_Name" VALUE="Login">	
											</td>
											</tr>											
								        <script language="JavaScript1.2">

													document.cookie = "test=cookiesEnabled";
													var pos = document.cookie.indexOf( "test=" );
													
													if( pos == -1 )
													{
														document.writeln('<tr><td class=clsNrmTxt colspan=2>');
														document.writeln('To play Merchant Empires, your web browser must have cookies enabled.');
														document.writeln('</td></tr>');
													}													
												</script>																						
										</table>
									</form>
					      </td>
					    </tr>
					  </table>
					</td>
				</tr>
			</table>
		</td>
		<td width=20% vAlign=top>
   	</td>		
	</tr>	
</table>

</body>
</html>
