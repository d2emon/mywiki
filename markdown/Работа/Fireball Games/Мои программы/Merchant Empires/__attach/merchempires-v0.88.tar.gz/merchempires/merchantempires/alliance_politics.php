<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Alliance Politics</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
} else {
	$alliance_id = -1;
}

$alliance_id = (int) $alliance_id;

if ( $alliance_id <> -1 )  {
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "alliance_politics");
$db->add_parameter("alliance_id", $alliance_id);
echo $db->get_transform("./xslt/menu_top_alliance.xslt", "");
}

if ( $player->f("alliance_id") <> 0 ) {
	$db = new ME_DB;
	$db_2 = new ME_DB;

	$query = sprintf("select * from alliances where alliance_id = '%s'", $player->f("alliance_id"));
	$db->query($query);
	$db->next_record();
	$alliance_leader = 0;

	if ( $db->f("leader_id") == $player->f("player_id") and $player->f("experience") > 700 ) {
		$alliance_leader = 1;
	}

	$query = sprintf("select * from treaties where primary_alliance_id = '%s' or secondary_alliance_id = '%s'", $player->f("alliance_id"), $player->f("alliance_id"));
	$db->query($query);

	if ( $db->nf() > 0 ){
		echo "<table border=0 cellPadding=0 cellSpacing=0 width=500><tr><td bgColor=#003399>";
		echo "<table border=0 cellpadding=5 cellspacing=1 width=100%><tr>";
		echo "<td width=150 class=clsHedTxt id=blu1><center>Alliance Name</center></td>";
		echo "<td class=clsHedTxt id=blu1><center>Leader</center></td>";
		echo "<td class=clsHedTxt id=blu1><center>Type</center></td>";
		echo "<td class=clsHedTxt id=blu1><center>Date</center></td>";		

		if ( $alliance_leader ) {
			echo "<td class=clsHedTxt id=blu1><center>Action</center></td>";
		} else {
			echo "</tr>";
		}

		while ( $db->next_record() ) {
			if ( $db->f("primary_alliance_id") == $player->f("alliance_id") ) {
				$this_alliance_name = $db->f("secondary_alliance_name");
				$this_leader_name = $db->f("secondary_leader_name");
			} else {
				$this_alliance_name = $db->f("primary_alliance_name");
				$this_leader_name = $db->f("primary_leader_name");
			}

			echo "<tr><td class=clsNrmTxt>";			
			echo stripslashes($this_alliance_name) . "</td>";

			echo "<td class=clsNrmTxt>";
			echo stripslashes($this_leader_name) . "</td>";

			echo "<td class=clsNrmTxt>";
			echo $db->f("type");

			if ( $db->f("accepted") == 't' ) {
				echo "&nbsp;";
			} else {
				echo " (offered) ";
			}

			if ( $db->f("type") == 'War' ) {
				echo "declared by " . $db->f("primary_alliance_name");
			}

			echo "</td>";

			echo "<td class=clsNrmTxt>";

			if ( $db->f("accepted") == 't' ) {
				echo date ("m/d/y H:i:s",  $db->f("date_accepted"));
			} else {
				echo date ("m/d/y H:i:s",  $db->f("date_offered"));
			}

			echo "</td>";

			if ( $alliance_leader ) {
				echo "<td class=clsNrmTxt><center>";
				echo "<form action=";
				echo $sess->url(URL . "alliance_update.php");
				echo " method=post>";

				echo "<input type=hidden name=treaty_id value=" . $db->f("treaty_id") . ">";

				if ( $db->f("accepted") == 't' ) {
					if ( $db->f("primary_alliance_id") == $player->f("alliance_id") or $db->f("secondary_alliance_id") == $player->f("alliance_id") ) {
						echo "<input type=submit name=cancel_treaty value=Cancel>";
					} else {
						echo "&nbsp;";	
					}					
				} elseif ( $db->f("primary_leader_id") == $player->f("player_id") ) {
					echo "<input type=submit name=withdraw_treaty value=Withdraw>";
				} elseif ( $db->f("secondary_leader_id") == $player->f("player_id") ) {
					echo "<input type=submit name=accept_treaty value=Accept>";
				}

				echo "</form></center></td>";
			} else {
				echo "</tr>";
			}
		}		
		
		echo "</td></tr></table></td></tr></table>";

	} else {
		echo "<table border=0 cellPadding=0 cellSpacing=0 width=500><tr><td bgColor=#003399>";
		echo "<table border=0 cellpadding=5 cellspacing=1 width=100%><tr><td class=clsNrmTxt>";
		echo "Your alliance has formed no treaties.<br><br>";
		echo "</td></tr></table></td></tr></table>";
	}

	if ( $alliance_leader ) {
		echo "<br><table border=0 cellPadding=0 cellSpacing=0 width=500><tr><td bgColor=#003399>";
		echo "<table border=0 cellpadding=5 cellspacing=1 width=100%><tr><td class=clsNrmTxt>";
		echo "<font color=#3333FF face=arial,helvetica,swiss size=3>Offer Treaty</font><br><br>";

		echo "<form action=";
		echo $sess->url(URL . "alliance_update.php");
		echo " method=post>";

		echo "<table cellpadding=2 cellspacing=2><tr><td class=clsNrmTxt>";
		echo "Alliance Name</td><td>";
		echo "<input type=textbox name=alliance_name></td></tr><tr><td class=clsNrmTxt>";
		echo "Treaty Type:</td><td>";
		echo "<select name=treaty_type>";

		$db_2->query("select * from treaty_types order by name");

		while ( $db_2->next_record() ) {		
			echo "<option value='" . $db_2->f("name") . "'>" . $db_2->f("name") . "</option>";
		}

		echo "</select>";
		echo "</td></tr></table>";
		echo "<br>&nbsp;&nbsp;<input type=submit name=offer_treaty value=Offer>";
		echo "</form>";				

		echo "</table><td></tr></table><br>";
	}

} else {
	echo "<table border=0 cellPadding=0 cellSpacing=0 width=500><tr><td bgColor=#003399>";
	echo "<table border=0 cellpadding=5 cellspacing=1 width=100%><tr><td class=clsNrmTxt>";
	echo "You have not joined an alliance.<br><br>";
	echo "</td></tr></table></td></tr></table><br>";
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	
	$db->add_parameter("message", $error);
		
	if ($error == 1) {
		$db->add_parameter("message", "Your alliance is not member to the terms of that treaty.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "That treaty was not offered to your alliance.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "An alliance with that name could not be found.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "A treaty cannot be offered to your own alliance.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "Treaty type not found.");
	} elseif ($error == 6) {
		$db->add_parameter("message", "Your alliance has an existing treaty or treaty offer with that alliance.");
	} elseif ($error == 7) {
		$db->add_parameter("message", "Treaty type not found.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");					
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
