<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Ship extends ME_DB_Xml {
  var $id = 0;
	var $dirty_fields = array();
	var $combined_damage = 0;
	var $weapons_mounted = 0;

  function get_ship($id) {
		$this->connect();
		$query = sprintf("select ships.*, ship_weapons.*, ship_technology.* from ships, ship_weapons, ship_technology where ships.player_id = '%s' and ship_weapons.player_id = ships.player_id and ship_technology.player_id = ships.player_id", $id);

		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row = 0;
    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
    }

    $this->next_record();	
    $this->id = $this->f("ship_id");

		$this->combined_damage = 0;
		$this->weapons_mounted = 0;

		if ( $this->f("weapon_1_id") > 0 ) {
			if ( $this->f("weapon_1_shield_damage") < $this->f("weapon_1_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_1_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_1_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}	
		}

		if ( $this->f("weapon_2_id") > 0 ) {
			if ( $this->f("weapon_2_shield_damage") < $this->f("weapon_2_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_2_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_2_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}
		}

		if ( $this->f("weapon_3_id") > 0 ) {
			if ( $this->f("weapon_3_shield_damage") < $this->f("weapon_3_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_3_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_3_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}
		}

		if ( $this->f("weapon_4_id") > 0 ) {
			if ( $this->f("weapon_4_shield_damage") < $this->f("weapon_4_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_4_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_4_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}
		}

		if ( $this->f("weapon_5_id") > 0 ) {
			if ( $this->f("weapon_5_shield_damage") < $this->f("weapon_5_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_5_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_5_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}
		}

		if ( $this->f("weapon_6_id") > 0 ) {
			if ( $this->f("weapon_6_shield_damage") < $this->f("weapon_6_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_6_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_6_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}
		}

		if ( $this->f("weapon_7_id") > 0 ) {
			if ( $this->f("weapon_7_shield_damage") < $this->f("weapon_7_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_7_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_7_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}
		}

		if ( $this->f("weapon_8_id") > 0 ) {
			if ( $this->f("weapon_8_shield_damage") < $this->f("weapon_8_armor_damage") ) {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_8_armor_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			} else {
				$this->combined_damage = $this->combined_damage + $this->f("weapon_8_shield_damage");
				$this->weapons_mounted = $this->weapons_mounted + 1;
			}		
		}
	
  	return $this->Query_ID;
  }	
	
  function get_new_ship($player_id, $sector_id) {
    $this->connect();
  	$query = "insert into ships (player_id, sector_id) values($player_id, $sector_id)";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   	
   	$db = new ME_DB;
		$db->query("select * from ship_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;
	  $this->set_sector_id($sector_id);
		$this->set_planet_id(0);
					
	  $query = sprintf("select * from ships where ship_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();
    return $this->Query_ID;
  }
		
  function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update ships set ";
			$i = 1;

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}
			
				$i++;
			}
					
			$str = $str . " where ship_id = '$this->id'";		
			$db->query($str);
		
			$this->dirty_fields = array();
		}
	}

	function set_type($n) {
		$this->dirty_fields["type"] = $n;
  }

	function set_shieldmax($n) {
		$this->dirty_fields["shieldmax"] = $n;
  }

	function set_shieldcurrent($n) {
		$this->dirty_fields["shieldcurrent"] = $n;
  }

  function set_armormax($n) {
		$this->dirty_fields["armormax"] = $n;
  }

  function set_armorcurrent($n) {
		$this->dirty_fields["armorcurrent"] = $n;
  }

  function set_minesmax($n) {
		$this->dirty_fields["minesmax"] = $n;
  }

  function set_minescurrent($n) {
		$this->dirty_fields["minescurrent"] = $n;
  }

  function set_combatmax($n) {
		$this->dirty_fields["combatmax"] = $n;
  }

  function set_combatcurrent($n) {
		$this->dirty_fields["combatcurrent"] = $n;
  }

  function set_scoutmax($n) {
		$this->dirty_fields["scoutmax"] = $n;
  }

  function set_scoutcurrent($n) {
		$this->dirty_fields["scoutcurrent"] = $n;
  }

  function set_cargomax($n) {
		$this->dirty_fields["cargomax"] = $n;
  }

  function set_cargocurrent($n) {
		$this->dirty_fields["cargocurrent"] = $n;
  }

  function set_hardpoints($n) {
		$this->dirty_fields["hardpoints"] = $n;
  }

  function set_sector_id($n) {
		$this->dirty_fields["sector_id"] = $n;
  }

  function set_type_id($n) {
		$this->dirty_fields["type_id"] = $n;
  }

	function set_turns_per_sector($n) {
		$this->dirty_fields["turns_per_sector"] = $n;	 			
  }	
	
	function set_planet_id($n) {
		$this->dirty_fields["planet_id"] = $n;	 			
  }
	
	function set_public_sector_id($n) {
		$this->dirty_fields["public_sector_id"] = $n;	 			
  }	

	function set_last_move_date($n) {
		$this->dirty_fields["last_move_date"] = $n;	 			
  }

	function set_starbase_id($n) {
		$this->dirty_fields["starbase_id"] = $n;	 			
  }

	function set_last_move_sector_id($n) {
		$this->dirty_fields["last_move_sector_id"] = $n; 			
  }

	function set_powermax($n) {
		$this->dirty_fields["powermax"] = $n;
  }

  function set_powercurrent($n) {
		$this->dirty_fields["powercurrent"] = $n;
  }

	function set_cargo($n) {
		$this->dirty_fields["cargo"] = $n;
  }	

	function get_technology() {
		$technology = array();

		for ($i = 1; $i <= $this->f("cloak"); $i++) {	
			if ( $i == 1 ) {
				$technology['CD'] = 10;	
			} else {
				$technology['CD'] = $technology['CD'] + 0;	
			}
		}

		for ($i = 1; $i <= $this->f("illusion"); $i++) {	
			if ( $i == 1 ) {
				$technology['IG'] = 10;	
			} else {
				$technology['IG'] = $technology['IG'] + 0;	
			}
		}

		for ($i = 1; $i <= $this->f("jump"); $i++) {	
			if ( $i == 1 ) {
				$technology['JD'] = 10;	
			} else {
				$technology['JD'] = $technology['JD'] + 0;	
			}
		}

		for ($i = 1; $i <= $this->f("scanner"); $i++) {	
			if ( $i == 1 ) {
				$technology['SC'] = 5;	
			} else {
				$technology['SC'] = $technology['SC'] + 0;	
			}
		}

		for ($i = 1; $i <= $this->f("tractor_beam"); $i++) {	
			if ( $i == 1 ) {
				$technology['TB'] = 25;	
			} else {
				$technology['TB'] = $technology['TB'] + 15;
			}
		}

		for ($i = 1; $i <= $this->f("tracking"); $i++) {	
			if ( $i == 1 ) {
				$technology['TD'] = 15;	
			} else {
				$technology['TD'] = $technology['TD'] + 5;
			}
		}

		for ($i = 1; $i <= $this->f("deep_scanner"); $i++) {	
			if ( $i == 1 ) {
				$technology['DS'] = 25;	
			} else {
				$technology['DS'] = $technology['DS'] + 15;	
			}
		}

		for ($i = 1; $i <= $this->f("targeting_computer"); $i++) {	
			if ( $i == 1 ) {
				$technology['TC'] = 25;	
			} else {
				$technology['TC'] = $technology['TC'] + 15;	
			}
		}

		for ($i = 1; $i <= $this->f("plasma_booster"); $i++) {	
			if ( $i == 1 ) {
				$technology['PB'] = 25;	
			} else {
				$technology['PB'] = $technology['PB'] + 15;	
			}
		}

		for ($i = 1; $i <= $this->f("trifocus_plasma"); $i++) {	
			if ( $i == 1 ) {
				$technology['TP'] = 25;	
			} else {
				$technology['TP'] = $technology['TP'] + 15;	
			}
		}

		for ($i = 1; $i <= $this->f("active_screens"); $i++) {	
			if ( $i == 1 ) {
				$technology['AS'] = 25;	
			} else {
				$technology['AS'] = $technology['AS'] + 15;	
			}
		}

		for ($i = 1; $i <= $this->f("battle_systems_computer"); $i++) {	
			if ( $i == 1 ) {
				$technology['BC'] = 40;	
			} else {
				$technology['BC'] = $technology['BC'] + 15;	
			}
		}

		return $technology;
	}

	function alter_dom() {		
		$this->xml = $this->xml . '<combined_damage>' . $this->combined_damage . '</combined_damage>';
		$this->xml = $this->xml . '<weapons_mounted>' . $this->weapons_mounted . '</weapons_mounted>';
		$this->xml = $this->xml . '<technology>';

		$technology = $this->get_technology();

		for ($i = 1; $i <= 5; $i++) {
			list($key, $val) = each($technology);

			if ( $key ) {
				$this->xml = $this->xml . '<' . $key . '>' . $val . '</' . $key. '>';																						
			} else {
				$this->xml = $this->xml . '<n>00</n>';					
			}		
		}
						
		$this->xml = $this->xml . '</technology>';
		
		$this->xml = $this->xml . '<cargo>';

		$cargo_temp = explode(",", $this->f("cargo"));		
		$str = "";
		
		for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 3) {
			$str = $str . '<item_' . $i . ' type="' . $cargo_temp[$i + 1] . '" name="' . $cargo_temp[$i] . '" ';
						
			if ( $cargo_temp[$i + 1] == 1 ) {
				$str = $str . ' image_name="' . strtolower( str_replace(" ", "_", $cargo_temp[$i]) . ".png") . '"';								
			} elseif ( $cargo_temp[$i + 1] == 2 ) {				
				$str = $str . ' image_name="' . "technology.png" . '"';									
			} elseif ( $cargo_temp[$i + 1] == 3 ) {		
				$str = $str . ' image_name="' . "weapons.png" . '"';
			}

			$str = $str . '>' . $cargo_temp[$i + 2] . '</item_' . $i . '>';
			 
			$t_amt = $t_amt + $cargo_temp[$i + 2];
		}

		$this->xml = $this->xml . $str;
								
		$this->xml = $this->xml . '</cargo>';
		
		$this->xml = $this->xml . '<open_holds>' . (string) ($this->f("cargocurrent") - $t_amt) . '</open_holds>';

		if ( $this->f("tracking_player_id") <> 0 and $this->f("tracking") ) {
			$trackable = 1;

			$db = new ME_DB;
			$tracked_player_id = $this->f("tracking_player_id");
			$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id, players.player_id, players.name from ships, sectors, players where ships.player_id = '$tracked_player_id' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id");
			$db->next_record();

			$this_player_id = $this->f("player_id");
			$tracked_sector_id = $db->f("public_sector_id");
			$tracked_map_id = $db->f("map_id");
			$tracked_player_name = stripslashes($db->f("name"));

			if ( $this->f("tracking_locked") == 'f' or $this->f("sector_id") == 0 ) {
				$trackable = 0;
			} else {
				$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id from ships, sectors where ships.player_id = '$this_player_id' and ships.sector_id = sectors.sector_id");
				$db->next_record();

				$player_xpos = $db->f("xpos");
				$player_ypos = $db->f("ypos");
				$player_map_id = $db->f("map_id");	
			}

			if ( $tracked_map_id <> $player_map_id ) {
				$trackable = 0;
			}
	
			$this->xml = $this->xml . '<tracked_player_name>' . $tracked_player_name . '</tracked_player_name>';						

			if ( $trackable and $this->f("tracking_locked") == 't' ) {
				$player_map_id = $db->f("map_id");					

				$map_sql = "select * from sectors where ";
    	
				$counter = 1;
		
				if ( $this->f("tracking") == 1 ) {
					$y_bound = 2;
					$x_bound = -2;
					$search_width = 5;
					$sector_limit = 26;
				} elseif ( $this->f("tracking") == 2 ) {
					$y_bound = 3;
					$x_bound = -3;
					$search_width = 7;
					$sector_limit = 50;
				} elseif ( $this->f("tracking") == 3 ) {
					$y_bound = 4;
					$x_bound = -4;
					$search_width = 9;
					$sector_limit = 82;
				} elseif ( $this->f("tracking") == 4 ) {
					$y_bound = 5;
					$x_bound = -5;
					$search_width = 11;
					$sector_limit = 122;
				}		
	
				$y = $y_bound;
				for ($i = 1; $i <= $search_width; $i++) {
					$x = $x_bound;
					for ($j = 1; $j <= $search_width; $j++) {
						$map_sql = $map_sql . "( map_id = " . $player_map_id . " and xpos = " . ($player_xpos + $x) . " and ypos = " . ($player_ypos + $y) . " )";
						$counter++;
		
						if ( $counter <> $sector_limit ) {
							$map_sql = $map_sql . " or ";
						}
		
						$x = $x + 1;
					}
			
					$y = $y - 1;
				}				
											
				$query = $map_sql;
				$db->query($query);

				$surrounding_sectors = array();

				while ( $db->next_record() ) {
					array_push($surrounding_sectors, $db->f("public_sector_id"));
				}

				if ( !in_array($tracked_sector_id, $surrounding_sectors) ) {
					$db->query("update ship_technology set tracking_locked = 'f' where player_id = '$this_player_id'");
					$this->xml = $this->xml . '<tracked_location>---</tracked_location>';
				} else {
					$this->xml = $this->xml . '<tracked_location>' . $tracked_sector_id . '</tracked_location>';
				}
			} else {
				$db->query("update ship_technology set tracking_locked = 'f' where player_id = '$this_player_id'");
				$this->xml = $this->xml . '<tracked_location>---</tracked_location>';
			}			
		}

		if ( $this->f("tractor_beam_player_id") <> 0 and $this->f("tractor_beam") ) {
			$this_player_id = $this->f("player_id");

			$db = new ME_DB;
			$tractor_beam_player_id = $this->f("tractor_beam_player_id");
			$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, players.player_id, players.name from ships, sectors, players where ships.player_id = '$tractor_beam_player_id' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id");
			$db->next_record();
			
			$tractor_beam_player_name = stripslashes($db->f("name"));
			$towable = 1;

			if ( $this->f("tractor_beam_locked") == 'f' or $this->f("sector_id") == 0 ) {
				$towable = 0;
			}

			if ( $this->f("sector_id") <> $db->f("sector_id") ) {
				$towable = 0;
			}				

			if ( $towable and $this->f("tractor_beam_locked") == 't' ) {
				$this->xml = $this->xml . '<tractor_beam_player_name>' . $tractor_beam_player_name . '</tractor_beam_player_name>';
			} else {
				$db->query("update ship_technology set tractor_beam_locked = 'f', tractor_beam_time = 0 where player_id = '$this_player_id'");
			}
		}
	}		
}
?>