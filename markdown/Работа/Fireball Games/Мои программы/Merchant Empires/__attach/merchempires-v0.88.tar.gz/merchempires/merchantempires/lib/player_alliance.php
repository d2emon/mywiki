<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

function get_treaties($alliance_id, $treaty_type) {
	$db = new ME_DB;
	
	$treaties = array();
	
	if ( $treaty_type == 'Free Movement' ) {
		$type_id = 1;	
	} elseif ( $treaty_type == 'War' ) {
		$type_id = 2;	
	} elseif ( $treaty_type == 'Mutual Assistance' ) {
		$type_id = 3;
	}

	$query = sprintf("select * from treaties where (primary_alliance_id = '%s' or secondary_alliance_id = '%s') and accepted = 't' and type_id = '%s'", $alliance_id, $alliance_id, $type_id);
	$db->query($query);

	while ( $db->next_record() ) {
		if ( $db->f("primary_alliance_id") <> $alliance_id ) {
			array_push($treaties, $db->f("primary_alliance_id"));
		} else {
			array_push($treaties, $db->f("secondary_alliance_id"));
		}
	}

	return $treaties;
}

function get_alliance_sql($alliance_id, $treaties) {
	$alliance_sql = "players.alliance_id = '" . $alliance_id . "'";
	
	while (list($key, $val) = each($treaties)) {		
		$alliance_sql = $alliance_sql . " or players.alliance_id = '" . $val . "'";		
	}
	
	return $alliance_sql;	
}
?>