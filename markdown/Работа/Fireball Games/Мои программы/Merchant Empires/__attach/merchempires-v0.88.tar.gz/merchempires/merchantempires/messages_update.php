<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");
include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/player_redirect.php");

$error = 0;

$db = new ME_DB;

if ( $player_id > 0 )  {
	// Check if there was a submission
	while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {	
		switch ($key) {
			case "delete_messages":
				$returnto = "view_messages";

				if ( $deletescope == "deletemarked" )  {
					for ($i = 0; $i <= $total_messages; $i++) {
						if ( !empty($delete[$i]) )  {
							$query = sprintf("delete from messages where message_id = '%s'", $delete[$i]);
							$db->query($query);
						}
					}
				} elseif ( $deletescope == "deleteall" )  {
					$query = sprintf("delete from messages where player_id = '%s' and planetary = 'f' and scout = 'f' and battle = 'f'", $player_id);
					$db->query($query);	
				} elseif ( $deletescope == "deleteunmarked" )  {
					$str = "delete from messages where player_id = '$player_id' and (planetary = 'f' and scout = 'f' and battle = 'f')";
					
					for ($i = 0; $i <= $total_messages; $i++) {					
						if ( !empty($delete[$i]) )  {
							$str = $str . " and message_id <> '$delete[$i]'";							
						}
					}
														
					$db->query($str);	
				}
				
				break;

			case "delete_messages_planetary":
				$returnto = "view_messages_planet";

				if ( $deletescope == "deletemarked" )  {
					for ($i = 0; $i <= $total_messages; $i++) {
						if ( !empty($delete[$i]) )  {
							$query = sprintf("delete from messages where message_id = '%s'", $delete[$i]);
							$db->query($query);
						}
					}
				} elseif ( $deletescope == "deleteall" )  {
					$query = sprintf("delete from messages where player_id = '%s' and planetary = 't'", $player_id);
					$db->query($query);	
				} elseif ( $deletescope == "deleteunmarked" )  {
					$str = "delete from messages where player_id = '$player_id' and (planetary = 't' and scout = 'f' and battle = 'f')";
					
					for ($i = 0; $i <= $total_messages; $i++) {					
						if ( !empty($delete[$i]) )  {
							$str = $str . " and message_id <> '$delete[$i]'";							
						}
					}
														
					$db->query($str);	
				}
				
				break;

			case "delete_messages_scout":
				$returnto = "view_messages_scout";

				if ( $deletescope == "deletemarked" )  {
					for ($i = 0; $i <= $total_messages; $i++) {
						if ( !empty($delete[$i]) )  {
							$query = sprintf("delete from messages where message_id = '%s'", $delete[$i]);
							$db->query($query);
						}
					}
				} elseif ( $deletescope == "deleteall" )  {
					$query = sprintf("delete from messages where player_id = '%s' and scout = 't'", $player_id);
					$db->query($query);	
				} elseif ( $deletescope == "deleteunmarked" )  {
					$str = "delete from messages where player_id = '$player_id' and (planetary = 'f' and scout = 't' and battle = 'f')";
					
					for ($i = 0; $i <= $total_messages; $i++) {					
						if ( !empty($delete[$i]) )  {
							$str = $str . " and message_id <> '$delete[$i]'";							
						}
					}
														
					$db->query($str);	
				}
				
				break;			

			case "delete_messages_battle":
				$returnto = "view_messages_battle";

				if ( $deletescope == "deletemarked" )  {
					for ($i = 0; $i <= $total_messages; $i++) {
						if ( !empty($delete[$i]) )  {
							$query = sprintf("delete from messages where message_id = '%s'", $delete[$i]);
							$db->query($query);
						}
					}
				} elseif ( $deletescope == "deleteall" )  {
					$query = sprintf("delete from messages where player_id = '%s' and battle = 't'", $player_id);
					$db->query($query);	
				} elseif ( $deletescope == "deleteunmarked" )  {
					$str = "delete from messages where player_id = '$player_id' and (planetary = 'f' and scout = 'f' and battle = 't')";
					
					for ($i = 0; $i <= $total_messages; $i++) {					
						if ( !empty($delete[$i]) )  {
							$str = $str . " and message_id <> '$delete[$i]'";							
						}
					}
														
					$db->query($str);	
				}
				
				break;	

			case "delete_messages_sent":
				$returnto = "view_messages_sent";

				if ( $deletescope == "deletemarked" )  {
					for ($i = 0; $i <= $total_messages; $i++) {
						if ( !empty($delete[$i]) )  {
							$query = sprintf("delete from sent_messages where sent_message_id = '%s'", $delete[$i]);
							$db->query($query);
						}
					}
				} elseif ( $deletescope == "deleteall" )  {
					$query = sprintf("delete from sent_messages where player_id = '%s'", $player_id);
					$db->query($query);	
				} elseif ( $deletescope == "deleteunmarked" )  {
					$str = "delete from sent_messages where player_id = '$player_id'";
					
					for ($i = 0; $i <= $total_messages; $i++) {					
						if ( !empty($delete[$i]) )  {
							$str = $str . " and sent_message_id <> '$delete[$i]'";							
						}
					}
														
					$db->query($str);	
				}
				
				break;	

			case "update_options":
				$returnto = "view_messages_options";

				if ( $ignore_global == 'Yes' ) {
					$query = sprintf("update players set ignore_global = 't' where player_id = '%s'", $player_id);
				} else {
					$query = sprintf("update players set ignore_global = 'f' where player_id = '%s'", $player_id);
				}

        $db->query($query);	

				if ( $ignore_scout == 'Yes' ) {
					$query = sprintf("update players set ignore_scout = 't' where player_id = '%s'", $player_id);
				} else {
					$query = sprintf("update players set ignore_scout = 'f' where player_id = '%s'", $player_id);
				}

        $db->query($query);	

				if ( $ignore_planetary == 'Yes' ) {
					$query = sprintf("update players set ignore_planetary = 't' where player_id = '%s'", $player_id);
				} else {
					$query = sprintf("update players set ignore_planetary = 'f' where player_id = '%s'", $player_id);
				}

				$db->query($query);	

				if ( $quote_original == 'Yes' ) {
					$query = sprintf("update players set quote_original = 't' where player_id = '%s'", $player_id);
				} else {
					$query = sprintf("update players set quote_original = 'f' where player_id = '%s'", $player_id);
				}

				$db->query($query);	

				break;

			case "delete_list":
				$returnto = "view_messages_options";

				$player_config = new ME_Player_config;
				$player_config->get_player_config($player_id);

				$hot_list = explode(",", $player_config->f("hot_list"));

				$new_hot_list = array();

				for ($i = 0; $i <= count($hot_list) - 1; $i++) {
					if ( $hot_list[$i] <> $list_member ) {
  	      	array_push($new_hot_list, $hot_list[$i]);
					}
      	}

				$str_hot_list = implode(",", $new_hot_list);
				$player_config->set_hot_list($str_hot_list);

				$player_config->save();

				break;

			case "add_list":
				$returnto = "view_messages_options";

				$player_config = new ME_Player_config;
				$player_config->get_player_config($player_id);

				$hot_list = array();

				if ( strlen($player_config->f("hot_list")) > 0 ) {
					$hot_list = explode(",", $player_config->f("hot_list"));
				}

				array_push($hot_list, $merchant_name);

				$str_hot_list = implode(",", $hot_list);
				$player_config->set_hot_list($str_hot_list);
				$player_config->save();

				break;
		}
	}
}

if ( $error ) {
	if ($returnto == "view_messages")  {
		$newurl = $sess->url(URL . "planet_defenses.php?error=$error");
 		header("Location: $newurl");	
	}

	if ($returnto == "view_messages_battle")  {
		$newurl = $sess->url(URL . "view_messages_battle.php?error=$error");
 		header("Location: $newurl");	
	}

  if ($returnto == "view_messages_scout")  {
		$newurl = $sess->url(URL . "view_messages_scout.php?error=$error");
 		header("Location: $newurl");	
	}

	if ($returnto == "view_messages_planet")  {
		$newurl = $sess->url(URL . "view_messages_planet.php?error=$error");
 		header("Location: $newurl");	
	}
	
	if ($returnto == "view_messages_options")  {
		$newurl = $sess->url(URL . "view_messages_options.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "view_messages")  {
		$newurl = $sess->url(URL . "view_messages.php");
		header("Location: $newurl");	
	} elseif ($returnto == "view_messages_battle")  {
		$newurl = $sess->url(URL . "view_messages_battle.php");
		header("Location: $newurl");	
	} elseif ($returnto == "view_messages_scout")  {
		$newurl = $sess->url(URL . "view_messages_scout.php");
		header("Location: $newurl");	
	} elseif ($returnto == "view_messages_planet")  {
		$newurl = $sess->url(URL . "view_messages_planet.php");
		header("Location: $newurl");	
	} elseif ($returnto == "view_messages_options")  {
		$newurl = $sess->url(URL . "view_messages_options.php");
		header("Location: $newurl");	
	} elseif ($returnto == "view_messages_sent")  {
		$newurl = $sess->url(URL . "view_messages_sent.php");
		header("Location: $newurl");	
	}
}
page_close();
?>
