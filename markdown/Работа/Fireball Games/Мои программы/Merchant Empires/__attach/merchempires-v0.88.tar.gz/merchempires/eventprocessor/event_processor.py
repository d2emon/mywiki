
""" This file is part of Merchant Empires
    Copyright (C) 2000 Bryan Brunton (bryan@dunsinane.net)

    This is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this library; see the file COPYING If not, write to
    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
    Boston, MA 02111-1307, USA.
"""

import string

import socket
import asyncore
import asynchat
import signal, os, time

class telnet_channel (asynchat.async_chat):

	def __init__ (self, server, sock, addr):
		asynchat.async_chat.__init__ (self, sock)
		self.server = server
		self.addr = addr
		self.set_terminator ('\r\n')
		self.data = ''
		self.nick = None
		self.push ('password: ')

	def collect_incoming_data (self, data):
		self.data = self.data + data

	def found_terminator (self):
		line = self.data
		self.data = ''
		if self.nick is None:
			if len(line) > 0:
				self.nick = string.split (line)[0]
				self.greet()
			else:
				self.nick = None
				self.push ('password: ')
		else:
			if not line:
				pass
			elif line[0] != '/':
				self.server.push_line (self, line)
			else:
				self.handle_command (line)

	def greet (self):
		num_channels = len(self.server.channels)-1

		if self.nick <> self.server.password:
			self.close_when_done()
		else:
			self.push ('Commands\n')
			self.push ('status: (/status),(/s)\n')
			self.push ('quit: (/quit),(/q)\n')

	def handle_command (self, command):
		import types
		command_line = string.split(command)
		name = 'cmd_%s' % command_line[0][1:]
		if hasattr (self, name):
			# make sure it's a method...
			method = getattr (self, name)
			if type(method) == type(self.handle_command):
				#print method
				method (command_line[1:])
			else:
				self.push ('unknown command: %s' % command_line[0])

	def cmd_quit (self, args):
		self.server.push_line (self, '[left]')
		self.push ('Goodbye!\r\n')
		self.close_when_done()

	# alias for '/quit' - '/q'
	cmd_q = cmd_quit

	def cmd_status (self, args):
		self.push (self.server.report())

	# alias for '/status' - '/s'
	cmd_s = cmd_status

	def push_line (self, nick, line):
		self.push ('%s: %s\r\n' % (nick, line))

	def handle_close (self):
		self.close()

	def close (self):
		del self.server.channels[self]
		asynchat.async_chat.close (self)

	def get_nick (self):
		if self.nick is not None:
			return self.nick
		else:
			return 'Unknown'

class event_server (asyncore.dispatcher):

	SERVER_IDENT = 'Merchant Empires Event Processor'

	channel_class = telnet_channel

	spy = 1

	def __init__ (self, ip='', port=8518, password=''):
		self.port = port
		self.create_socket (socket.AF_INET, socket.SOCK_STREAM)
		self.bind ((ip, port))
		print '%s started on port %d' % (self.SERVER_IDENT, port)
		self.listen (5)
		self.channels = {}
		self.count = 0
		self.password = password

	def handle_accept (self):
		conn, addr = self.accept()
		self.count = self.count + 1
		self.channels[self.channel_class (self, conn, addr)] = 1

	def push_line (self, from_channel, line):
		nick = from_channel.get_nick()
		if self.spy:
			print '%s: %s' % (nick, line)
		for c in self.channels.keys():
			if c is not from_channel:
				c.push ('%s: %s\r\n' % (nick, line))

	def writable (self):
		return 0

if __name__ == '__main__':
	import sys

	if len(sys.argv) < 3:
		print 'usage: %s <port> <password>' % (sys.argv[0])
	else:	
		if len(sys.argv) > 1:
			port = string.atoi (sys.argv[1])

		if len(sys.argv) > 2:
			password = sys.argv[2]

		s = event_server ('', port, password)
		asyncore.loop()
		
