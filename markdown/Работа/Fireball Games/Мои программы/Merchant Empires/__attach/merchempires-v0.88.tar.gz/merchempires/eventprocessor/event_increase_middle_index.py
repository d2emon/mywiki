
def increase_middle_index():
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT good_id, supplydemand, type from goods where supplydemand <> 6000 and (type = 'Machinery' or	\
		type = 'Textiles' or type = 'Circuitry' or type = 'Weapons')"
	q = pgcnx.query(qrystr)
	res = q.getresult()

	for value in range(len(res)):
		index = res[value][q.fieldnum('supplydemand')]

		if index + 60 > 6000:
			index = 6000
		else:
			index = index + 60

		qrystr = "update goods set supplydemand = '%d' where good_id = '%d'" % (index, res[value][q.fieldnum('good_id')])
		pgcnx.query(qrystr)
 
