<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/ship.php");
include("./lib/player.php");
include("./lib/player_redirect.php");

if ( $player_id > 0 )  {
	# update player turns
	$player = new ME_Player;
	$player->get_player($player_id);
	$alignment = $player->f("alignment");
	$turns = $player->f("turns");
	$newturns = $player->f("newturnsleft");
	$ship = new ME_Ship;
	$ship->get_ship($player_id);	

	if ( (int) (($ship->combined_damage / 40) + ($ship->f("combatcurrent") / 50)) < 1 ) {
		$offense = 1;
	} else {
		$offense = (int) (($ship->combined_damage / 40) + ($ship->f("combatcurrent") / 50));
	}

	$error = 0;
	$protected = 3;
				
	if ( $alignment >= 150 and $alignment < 300 ) {
		$protected = 4;
	} elseif( $alignment >= 300 ) {
		$protected = 5;
	} elseif( $alignment <= -150 and $alignment > -300 ) {
		$protected = 2;
	} elseif( $alignment < -300 ) {
		$protected = 1;
	}

	# only land if the player has a turn
	if ( ($player->f("turns") - 1) >= 0 )  {
		if ( $newturns > 0 ) {
			$player->set_new_turns_left($newturns - 1);
		}

		if ( $ship->f("starbase_id") == 0 ) {
			$db = new ME_DB;
			$query = sprintf("select * from starbases where sector_id = '%s'", $ship->f("sector_id"));
			$db->query($query);
			$db->next_record();
		
			if ( $db->f("sector_id") > 0 ) {
				if ( $offense <= $protected ) {	
					if ( $player->f("alignment") > -100 ) {
						if ( $player->f("credits") - 3000 >= 0 ) {
							$ship->set_sector_id(0);
							$ship->set_planet_id(0);
							$ship->set_starbase_id($db->f("starbase_id"));
				  		$ship->save();

							$new_credits = $player->f("credits") - 3000;
							$player->set_credits($new_credits);
							$player->set_turns($turns - 2);
							$player->save();
						} else {
							$error = 6;								
						}				
					} else {
						$error = 7;
					}
        } else {
					$error = 8;
				}

				if ( $error == 0) {
					$newurl = $sess->url(URL . "starbase.php");
					header("Location: $newurl");
				} else {
					$newurl = $sess->url(URL . "current_sector.php?error=$error");
				  header("Location: $newurl");
				}
			} else {
				$newurl = $sess->url(URL . "starbase_dock.php");
			  header("Location: $newurl");
			}
		}
	} else {
		$newurl = $sess->url(URL . "starbase_dock.php.php");
	  header("Location: $newurl");
	}
}

page_close();
?>