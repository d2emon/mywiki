
def forces_expire():
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	current_time = int(time.time())
	qrystr = "delete from forces where expiration <= '%s'" % (current_time)
	pgcnx.query(qrystr)
 
