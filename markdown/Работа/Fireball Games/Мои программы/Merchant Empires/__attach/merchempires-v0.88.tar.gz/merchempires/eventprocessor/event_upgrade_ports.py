
def check_slot_open(good_level, sector_id):
	from pg import DB
	from Defines import *

	if good_level == 1:
		qrystr = "select * from goods where type = 'Biochemicals' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Food' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Ore' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Precious Metals' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Slaves' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			return 0
		else:
			return 1

	elif good_level == 2:
		qrystr = "select * from goods where type = 'Textiles' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Machinery' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Circuitry' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Weapons' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			return 0
		else:
			return 1

	elif good_level == 3:
		qrystr = "select * from goods where type = 'Computers' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Luxury Items' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			pass
		else:
			return 1

		qrystr = "select * from goods where type = 'Narcotics' and sector_id = '%d'" % (sector_id)
		q = pgcnx.query(qrystr)
		res = q.getresult()

		if len(res) > 0:
			return 0
		else:
			return 1

def select_new_good_type(new_good_level, sector_id):
	import whrandom
	from pg import DB
	from Defines import *	

	good_found = 0
	good_slot_open = 1

	if new_good_level == 1:
		good_slot_open = check_slot_open(1, sector_id)

		if good_slot_open:
			while good_found <> 1:
				num = whrandom.randint(1,5)

				if num == 1:
					qrystr = "select * from goods where type = 'Biochemicals' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Biochemicals'
				elif num == 2:
					qrystr = "select * from goods where type = 'Food' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Food'

				elif num == 3:
					qrystr = "select * from goods where type = 'Ore' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Ore'

				elif num == 4:
					qrystr = "select * from goods where type = 'Precious Metals' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Precious Metals'

				elif num == 5:
					qrystr = "select * from goods where type = 'Slaves' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Slaves'

		else:
			return 'No Slots Open'

	elif new_good_level == 2:
		good_slot_open = check_slot_open(2, sector_id)

		if good_slot_open:
			while good_found <> 1:
				num = whrandom.randint(1,4)

				if num == 1:
					qrystr = "select * from goods where type = 'Textiles' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Textiles'
				elif num == 2:
					qrystr = "select * from goods where type = 'Machinery' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Machinery'

				elif num == 3:
					qrystr = "select * from goods where type = 'Circuitry' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Circuitry'

				elif num == 4:
					qrystr = "select * from goods where type = 'Weapons' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Weapons'

		else:
			return 'No Slots Open'

	elif new_good_level == 3:
		good_slot_open = check_slot_open(3, sector_id)

		if good_slot_open:
			while good_found <> 1:
				num = whrandom.randint(1,3)

				if num == 1:
					qrystr = "select * from goods where type = 'Computers' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Computers'
				elif num == 2:
					qrystr = "select * from goods where type = 'Luxury Items' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Luxury Items'

				elif num == 3:
					qrystr = "select * from goods where type = 'Narcotics' and sector_id = '%d'" % (sector_id)
					q = pgcnx.query(qrystr)
					res = q.getresult()

					if len(res) > 0:
						pass
					else:
						return 'Narcotics'

		else:
			return 'No Slots Open'

def upgrade_ports():
	import whrandom, os
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT * from ports where level < 9 and goods_traded > 15000"
	q = pgcnx.query(qrystr)
	res = q.getresult()

	for value in range(len(res)):
	 	goods_traded = res[value][q.fieldnum('goods_traded')]
		level = res[value][q.fieldnum('level')]
		port_id = res[value][q.fieldnum('port_id')]
		sector_id = res[value][q.fieldnum('sector_id')]
		public_sector_id = res[value][q.fieldnum('public_sector_id')]

		upgrade = 0
		chance_new_good = 0
		new_good_level = 0

		#print str(port_id)

		if level == 1:
			if goods_traded > 15000:
				num = 1
				if num == 1:
					chance_new_good = whrandom.randint(1,2)
					new_good_level = 1
					upgrade = 1

		elif level == 2:
			if goods_traded > 20000:
				num = whrandom.randint(1,5)
				if num == 1:
					chance_new_good = whrandom.randint(1,3)
					new_good_level = 1
					upgrade = 1

		elif level == 3:
			if goods_traded > 35000:
				num = whrandom.randint(1,5)
				if num == 1:
					chance_new_good = whrandom.randint(1,6)
					new_good_level = 1
					upgrade = 1

		elif level == 4:
			if goods_traded > 50000:
				num = 1
				if num == 1:
					chance_new_good = 1
					new_good_level = 2
					upgrade = 1

		elif level == 5:
			if goods_traded > 60000:
				num = whrandom.randint(1,5)
				if num == 1:
					chance_new_good = 1
					new_good_level = 2
					upgrade = 1

		elif level == 6:
			if goods_traded > 70000:
				num = whrandom.randint(1,5)
				if num == 1:
					chance_new_good = whrandom.randint(1,2)
					new_good_level = 3
					upgrade = 1

		elif level == 7:
			if goods_traded > 90000:
				num = whrandom.randint(1,3)
				if num == 1:
					chance_new_good = 1
					new_good_level = 3
					upgrade = 1

		elif level == 8:
			if goods_traded > 100000:
				num = whrandom.randint(1,5)
				if num == 1:
					chance_new_good = 1
					new_good_level = 3
					upgrade = 1

		if upgrade:
			new_level = level + 1
		  	qrystr = "update ports set level = '%d', goods_traded = 0 where port_id = '%d'" % (new_level, port_id)
			pgcnx.query(qrystr)

		if upgrade:
			num = whrandom.randint(1,2)

			if num == 1:
				buyorsell = 'buy'
			else:
				buyorsell = 'sell'

			print 'upgrading ' + str(port_id)

			if chance_new_good == 1:
				new_good_type = select_new_good_type(new_good_level, sector_id)

				if new_good_type <> 'No Slots Open':
					if new_good_type == 'Biochemicals':
						marketvalue = whrandom.randint(10,14)
					elif new_good_type == 'Food':
						marketvalue = whrandom.randint(16,19)
					elif new_good_type == 'Ore':
						marketvalue = whrandom.randint(25,28)
					elif new_good_type == 'Precious Metals':
						marketvalue = whrandom.randint(31,33)
					elif new_good_type == 'Slaves':
						marketvalue = whrandom.randint(60,65)
					elif new_good_type == 'Textiles':
						marketvalue = whrandom.randint(68,72)
					elif new_good_type == 'Machinery':
						marketvalue = whrandom.randint(85,89)
					elif new_good_type == 'Circuitry':
						marketvalue = whrandom.randint(98,104)
					elif new_good_type == 'Weapons':
						marketvalue = whrandom.randint(245,255)
					elif new_good_type == 'Computers':
						marketvalue = whrandom.randint(192,202)
					elif new_good_type == 'Luxury Items':
						marketvalue = whrandom.randint(290,305)
					elif new_good_type == 'Narcotics':
						marketvalue = whrandom.randint(345,355)

					qrystr = "insert into goods (port_id, sector_id, type, marketvalue, supplydemand, buyorsell)	\
						values ('%d', '%d', '%s', '%d', 6000, '%s')" % (port_id, sector_id, new_good_type, marketvalue, buyorsell)
					pgcnx.query(qrystr)

					qrystr = "select * from sectors where sector_id = '%d'" % (sector_id)
					q_2 = pgcnx.query(qrystr)
					res_2 = q_2.getresult()
					map_id = res_2[0][q_2.fieldnum('map_id')]
					image_version = res_2[0][q_2.fieldnum('image_version')] + 1

					qrystr = "update sectors set image_version = '%d' where sector_id = '%d'" % (image_version, sector_id)
					pgcnx.query(qrystr)

					sector = None
					sector = Map_image(sector_id, map_id, web_root)
					sector.recreate_sector()

					os.system('./pathfinder ' + str(map_id) + ' ' + str(sector_id) + ' &')

	print 'finished upgrading'
 
