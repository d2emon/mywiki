<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/player_map.php");
include("./lib/player_alliance.php");
include("./lib/ship.php");
include("./lib/ship_combat.php");
include("./lib/ship_miscellaneous.php");
include("./lib/technology.php");
include("./lib/weapons.php");
include("./lib/sector.php");
include("./lib/relations.php");
include("./lib/player_redirect.php");

function check_module($number, $name, $megawatts, $additional_megawatts, &$megawatts_used) {
	for ($i = 1; $i <= $number; $i++) {	
		if ( $i == 1 ) {			
			$megawatts_used = $megawatts_used + $megawatts[$name];
		} else {			
			$megawatts_used = $megawatts_used + $additional_megawatts[$name];
		}
	}
}

function outside_safe_jump($player_map_id, $player_xpos, $player_ypos, $player_sector, $current_public_sector_id) {
	$map_sql = "select * from sectors where ";

	$counter = 1;
			
	$y_bound = 4;
	$x_bound = -4;
	$search_width = 9;
	$sector_limit = 82;

	$y = $y_bound;
	for ($i = 1; $i <= $search_width; $i++) {
		$x = $x_bound;
		for ($j = 1; $j <= $search_width; $j++) {
			$map_sql = $map_sql . "( map_id = " . $player_map_id . " and xpos = " . ($player_xpos + $x) . " and ypos = " . ($player_ypos + $y) . " )";
			$counter++;

			if ( $counter <> $sector_limit ) {
				$map_sql = $map_sql . " or ";
			}
		
			$x = $x + 1;
		}
			
		$y = $y - 1;
	}				
											
	$query = $map_sql;
	$db = new ME_DB;
	$db->query($query);

	$surrounding_sectors = array();

	while ( $db->next_record() ) {
		if ( $db->f("public_sector_id") <> $current_public_sector_id ) {
			array_push($surrounding_sectors, $db->f("public_sector_id"));
		}
	}

	if ( !in_array($player_sector, $surrounding_sectors) ) {
		return 1;
	} else {
		return 0;
	}
}

function get_miss_jump($map_id, $xpos, $ypos, $sector_id) {
	$map_sql = "select * from sectors where ";

	$counter = 1;
			
	$y_bound = 1;
	$x_bound = -1;
	$search_width = 3;
	$sector_limit = 10;

	$y = $y_bound;
	for ($i = 1; $i <= $search_width; $i++) {
		$x = $x_bound;
		for ($j = 1; $j <= $search_width; $j++) {
			$map_sql = $map_sql . "( map_id = " . $map_id . " and xpos = " . ($xpos + $x) . " and ypos = " . ($ypos + $y) . " )";
			$counter++;

			if ( $counter <> $sector_limit ) {
				$map_sql = $map_sql . " or ";
			}
		
			$x = $x + 1;
		}
			
		$y = $y - 1;
	}
											
	$query = $map_sql;
	$db = new ME_DB;
	$db->query($query);

	$surrounding_sectors = array();
	$miss_jump = array();

	$num = rand(1,$db->nf());
	$i = 1;

	while ( $db->next_record() ) {
		if ( $i == $num ) {
			$miss_jump['sector_id'] = $db->f("sector_id");
			$miss_jump['public_sector_id'] = $db->f("public_sector_id");	
		}

		$i++;
	}

	return $miss_jump;
}

function kill_forces($dead_forces_id, $total_forces_killed) {
	$db = new ME_DB;
	$db->query("select * from forces where forces_id = '$dead_forces_id'");
	$db->next_record();

	$combat = $db->f("combat");
	$mine = $db->f("mine");
	$scout = $db->f("scout");

	if ( $combat > 0 ) {
		if ( $combat - $total_forces_killed < 0 ) {
			$combat = 0;
			$total_forces_killed = $total_forces_killed - $combat;
		} else {
			$combat = $combat - $total_forces_killed;
			$total_forces_killed = 0;
		}
	}

	if ( $scout > 0  and $total_forces_killed > 0 ) {
		if ( $scout - $total_forces_killed < 0 ) {
			$scout = 0;
			$total_forces_killed = $total_forces_killed - $scout;
		} else {
			$scout = $scout - $total_forces_killed;
			$total_forces_killed = 0;
		}
	}

	if ( $mine > 0  and $total_forces_killed > 0 ) {
		if ( $mine - $total_forces_killed < 0 ) {
			$mine = 0;
			$total_forces_killed = $total_forces_killed - $mine;
		} else {
			$mine = $mine - $total_forces_killed;
			$total_forces_killed = 0;
		}
	}

	if ( $scout == 0 and $mine == 0 and $combat == 0 ) {
		$db->query("delete from forces where forces_id = '$dead_forces_id'");
	} else {
		$db->query("update forces set scout = '$scout', mine = '$mine', combat = '$combat' where forces_id = '$dead_forces_id'");
	}
}

function merchant_dead($dead_player_id, $killer_id, $sector_id, $killer_type) {
	$dead_player = new ME_Player;
	$dead_player->get_player($dead_player_id);
	$victor_credits = $dead_player->f("credits");
	$dead_player->set_credits(3000);
	$dead_player->set_new_turns_left(100);	

	$dead_player_alignment = $dead_player->f("alignment");
	$dead_player_experience = $dead_player->f("experience");
	$dead_player_race_id = $dead_player->f("race_number");
	$new_experience = (int) ($dead_player->f("experience") * .85);
	$dead_player->set_experience($new_experience);

	$db = new ME_DB;
	$query = "select * from levels where experience <= '$new_experience' order by experience desc limit 1";
	$db->query($query);
	$db->next_record();

	$dead_player->set_rank($db->f("rank"));
	$dead_player->set_dead("t");
	$dead_player->save();

	$game_id = $dead_player->f("game_id");
	$race = $dead_player->f("race");
	# find the player's starting sector	
	$db->query("select * from games where game_id = '$game_id'");
	$db->next_record();
		
	if ($race == $db->f("namerace_1")) {
		$sector_id = $db->f("startsectrace_1");
	} elseif ($race == $db->f("namerace_2")) {
		$sector_id = $db->f("startsectrace_2");
	} elseif ($race == $db->f("namerace_3")) {
		$sector_id = $db->f("startsectrace_3");
	} elseif ($race == $db->f("namerace_4")) {
		$sector_id = $db->f("startsectrace_4");
	} elseif ($race == $db->f("namerace_5")) {
		$sector_id = $db->f("startsectrace_5");
	} elseif ($race == $db->f("namerace_6")) {
		$sector_id = $db->f("startsectrace_6");
	} elseif ($race == $db->f("namerace_7")) {
		$sector_id = $db->f("startsectrace_7");
	}

	$db->query("select player_id, type_id from ships where player_id = '$dead_player_id'");
	$db->next_record();
	$dead_ship_type_id = $db->f("type_id");
	
	$db_d = new ME_DB_Tran;
	$db_d->begin_transaction();
  $db_d->query("delete from ships where player_id = '$dead_player_id'");

	$delete_success = $db_d->affected_rows();

	if ( $delete_success ) {
	  $db_d->query("delete from ship_weapons where player_id = '$dead_player_id'");
		$db_d->query("delete from ship_technology where player_id = '$dead_player_id'");
	}

	$delete_success = $db_d->affected_rows();
	$db_d->end_transaction();

	if ( $delete_success ) {
		# set some default values
		$ship = new ME_Ship;
		$ship->get_new_ship($dead_player_id, $sector_id);
		$ship->set_type("Light Freighter");
		$ship->set_shieldmax(250);
		$ship->set_shieldcurrent(150);
		$ship->set_armormax(200);
		$ship->set_armorcurrent(75);
		$ship->set_powermax(50);
		$ship->set_powercurrent(15);
		$ship->set_minesmax(0);
		$ship->set_minescurrent(0);
		$ship->set_combatmax(0);
		$ship->set_combatcurrent(0);
		$ship->set_scoutmax(0);
		$ship->set_scoutcurrent(0);
		$ship->set_cargocurrent(40);
		$ship->set_cargomax(100);
		$ship->set_type_id(53);		
		$ship->set_turns_per_sector(2.5);
		$ship->set_hardpoints(1);
		$ship->set_last_move_date(time());	
		$ship->save();		
	
		$weapons = new ME_Weapons;
		$weapons->get_new_weapons($ship->id);
		$weapons->set_player_id($dead_player_id);
		$weapons->save();

		$technology = new ME_Technology;
		$technology->get_new_technology($ship->id);
		$technology->set_player_id($dead_player_id);		
		$technology->save();
	}
	
	$date = time();	

	if ( $killer_type == 's' ) {				
		$db->query("select * from bounties where player_target_id = '$dead_player_id'");
    $db->next_record();

		if ( $db->nf() > 0 ) {
			$new_bounties = $db->f("bounty_id");
		}

		$db->query("select * from underground_bounties where player_target_id = '$dead_player_id'");
		$db->next_record();

		if ( $db->nf() > 0 ) {
			$new_ug_bounties = $db->f("underground_bounty_id");
		}

		$db->query("select players.player_id, players.name, players.alignment, players.race, players.credits, players.race_number,
			players.experience, players.unclaimed_bounties, players.unclaimed_ug_bounties, players.unclaimed_military_bounties, ships.player_id,
			ships.sector_id, ships.public_sector_id from players, ships where players.player_id = '$killer_id'
			and players.player_id = ships.player_id");

		$db->next_record();

		$relations = new ME_Relations;
		$relations->initialize($game_id, $db->f("race_number"));

		if ( $dead_player_race_id == 1 ) {
			$this_relations = $relations->get_relations_1();
		} elseif ( $dead_player_race_id == 2 ) {
			$this_relations = $relations->get_relations_2();
		} elseif ( $dead_player_race_id == 3 ) {
			$this_relations = $relations->get_relations_3();
		} elseif ( $dead_player_race_id == 4 ) {
			$this_relations = $relations->get_relations_4();
		} elseif ( $dead_player_race_id == 5 ) {
			$this_relations = $relations->get_relations_5();
		} elseif ( $dead_player_race_id == 6 ) {
			$this_relations = $relations->get_relations_6();
		} elseif ( $dead_player_race_id == 7 ) {
			$this_relations = $relations->get_relations_7();
		}

		$new_military_bounties = $db->f("unclaimed_military_bounties");

		if ( $dead_player_experience > 100 ) {
			if ( $this_relations <= -300 ) {
				if ( strlen($new_military_bounties) > 0 ) {
					$new_military_bounties = $new_military_bounties . "," . $dead_ship_type_id;
				} else {
					$new_military_bounties = $dead_ship_type_id;
				}
			}
		}

		if ( strlen($new_bounties) > 0 ) {
			if ( strlen($db->f("unclaimed_bounties")) > 0 ) {

				$bounties = array();
				$bounties = explode(",", $db->f("unclaimed_bounties"));	

				$bounty_found = 0;
				while (list($key, $val) = each($bounties)) {
					if ( $val == $new_bounties ) {
						$bounty_found = 1;
					}		
				}	

				if ( !(bounty_found) ) {
					$new_bounties = $db->f("unclaimed_bounties") . "," . $new_bounties;
				} else {
					$new_bounties = $db->f("unclaimed_bounties");
				}
			}
		} else {
			$new_bounties = $db->f("unclaimed_bounties");
		}

		if ( strlen($new_ug_bounties) > 0 ) {
			if ( strlen($db->f("unclaimed_ug_bounties")) > 0 ) {

				$bounties = array();
				$bounties = explode(",", $db->f("unclaimed_ug_bounties"));	

				$bounty_found = 0;
				while (list($key, $val) = each($bounties)) {
					if ( $val == $new_ug_bounties ) {
						$bounty_found = 1;
					}		
				}	

				if ( !(bounty_found) ) {
					$new_ug_bounties = $db->f("unclaimed_ug_bounties") . "," . $new_ug_bounties;					
				} else {
					$new_ug_bounties = $db->f("unclaimed_ug_bounties");
				}				
			}
		} else {
			$new_ug_bounties = $db->f("unclaimed_ug_bounties");
		}
		
		$public_sector_id = $db->f("public_sector_id");
	  $message = addslashes($db->f("name")) . " killed " . addslashes($dead_player->f("name")) . " in sector " . $db->f("public_sector_id") . ".";
		$new_credits = $db->f("credits") + $victor_credits;

		$new_experience = ($dead_player_experience / 1000) * 50;
		if ( $new_experience < 50 ) {
			$new_experience = $db->f("experience") + 50;			
		} else {
			$new_experience = (int) ($db->f("experience") + $new_experience);	
		}

		$new_alignment = $db->f("alignment");

		if ( $dead_player_experience > 300 ) {
			if ( $dead_player_alignment > 200 ) {
				$new_alignment = $new_alignment - 70;
			} elseif ( $dead_player_alignment > 150 ) {
	  		$new_alignment = $new_alignment - 50;
			} elseif ( $dead_player_alignment > 100 ) {
				$new_alignment = $new_alignment - 30;
			} elseif ( $dead_player_alignment > 50 ) {
				$new_alignment = $new_alignment - 10;
			} elseif ( $dead_player_alignment < -200 ) {
				$new_alignment = $new_alignment + 70;
			} elseif ( $dead_player_alignment < -150 ) {
				$new_alignment = $new_alignment + 40;
			} elseif ( $dead_player_alignment < -100 ) {
				$new_alignment = $new_alignment + 20;
			}	elseif ( $dead_player_alignment < -50 ) {
				$new_alignment = $new_alignment + 10;
			}			

			if ( $new_alignment > 500 ) {
				$new_alignment = 500;
			} elseif ( $new_alignment < -500 ) {
				$new_alignment = -500;
			}
		}

		$killer_name = $db->f("name");
		$query = "insert into news (date, item, game_id) values ('$date', '$message', '$game_id')";
		$db->query($query);

		$query = "update players set credits = '$new_credits', experience = '$new_experience', alignment = '$new_alignment', unclaimed_bounties = '$new_bounties', unclaimed_ug_bounties = '$new_ug_bounties', unclaimed_military_bounties = '$new_military_bounties' where player_id = '$killer_id'";
		$db->query($query);
			
		$message = addslashes($killer_name) . " destroyed you in sector " . $public_sector_id;
		$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
			values ('$dead_player_id', '$message', 'Bridge', 't', '$date')";
		$db->query($query);
	}	
}

function attack_merchant_with_merchant($attacker_id, $defender_id, $trifocus_plasma) {	
	$db_ds = new ME_DB;
	$query = sprintf("select players.player_id, players.name, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.shieldmax, ships.armorcurrent, ships.armormax, ships.combatcurrent, ships.type, ships.public_sector_id, ship_technology.player_id, ship_technology.active_screens, ship_technology.screenscurrent from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $defender_id);
	$db_ds->query($query);
	$db_ds->next_record();	

	$db_as = new ME_DB;
	$query = sprintf("select players.player_id, players.name, players.rank, players.level, players.turns, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.combatcurrent, ships.type, ships.public_sector_id, ship_technology.player_id, ship_technology.targeting_computer, ship_technology.plasma_booster from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_as->query($query);
	$db_as->next_record();

	$player_public_sector_id = $db_as->f("public_sector_id");
	$targeting_bonus = 0;
	$damage_bonus = 0;

	if ( $db_as->f("targeting_computer") ) {
		$targeting_bonus = get_targeting_bonus($db_as->f("targeting_computer"));
	}

	if ( $db_as->f("plasma_booster") ) {
		$damage_bonus = 5;
	}	
	
	$attacker_level = $db_as->f("level");
	
	$defender_name = htmlentities($db_ds->f("name"));
	$attacker_name = htmlentities($db_as->f("name"));			

	$merchant_and_forces = array();
	$merchant_and_forces[0] = 0;
	$merchant_and_forces[1] = 0;	

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$target_screens = $db_ds->f("screenscurrent");
	$shield_damage = 0;
	$armor_damage = 0;
	$screens_damage = 0;

	$merchant_killed = 0;		

	$num = rand(1,100);	

	if ( $trifocus_plasma == 1 ) {
		$damage = 75;	
	} elseif ( $trifocus_plasma == 2 ) {
		$damage = 95;			
	} elseif ( $trifocus_plasma == 3 ) {
		$damage = 115;			
	} elseif ( $trifocus_plasma == 4 ) {
		$damage = 135;			
	}
		
	if ( (($num - $attacker_level) - $targeting_bonus) <= 65 ) {
		$num = rand(-5,5);	

		if ( 45 > 0 and $target_shields + $target_screens > 0 ) {			
			$damage = $damage + $num;
			
			if ( $target_screens > 0 and $target_screens - $damage < 0 ) {
				$target_screens = 0;
				$screens_damage = $db_ds->f("screenscurrent");
			} elseif ( $target_screens > 0 ) {
				$target_screens = $target_screens - $damage;
				$screens_damage = $screens_damage + $damage;
			} elseif ( $target_shields > 0 and $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} elseif ( $target_shields > 0 ) {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;				
			}				
		} elseif ( 45 > 0 and $target_shields <= 0 and $target_screens <= 0 ) {
			if ( $total_forces_killed < $total_forces and $num == 1 ) {									
				$damage = $damage + $num;
				$total_forces_killed = $total_forces_killed + 1;
			} else {					
				$damage = $damage + $num;

				if ( $target_armor - $damage < 0 ) {
  				$target_armor = 0;
					$armor_damage = $db_ds->f("armorcurrent");
					
					$merchant_killed = 1;
				} else {
					$target_armor = $target_armor - $damage;
					$armor_damage = $armor_damage + $damage;
				}	
			}
		} elseif ( 45 > 0 and $target_shields + $target_screens <= 0 and 45 == 0 ) {
			# nothing
		} elseif ( 45 > 0 and $target_shields + $target_screens > 0 and 45 == 0 ) {
			# nothing
		}
	} else {
		if ( 45 > 0 and $target_shields + $target_screens <= 0 and 45 == 0 ) {
			# nothing
		} elseif ( 45 > 0 and $target_shields + $target_screens > 0 and 45 == 0 ) {
			# nothing
		} else {
			# nothing
		}
	}
	
	if ( $shield_damage > 0 or $armor_damage > 0 or $screens_damage > 0 ) {
		$total_damage = $shield_damage + $armor_damage + $screens_damage;

		if ( $db_ds->f("screenscurrent") - $screens_damage <= 0 ) {
			$new_screens = 0;			
		} else {
			$new_screens = $db_ds->f("screenscurrent") - $screens_damage;
		}

		if ( $db_ds->f("shieldcurrent") - $shield_damage <= 0 ) {
			$new_shields = 0;			
		} else {
			$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		}

		if ( $db_ds->f("armorcurrent") - $armor_damage <= 0 ) {
			$new_armor = 0;
		} else {
			$new_armor = $db_ds->f("armorcurrent") - $armor_damage;
		}

		$ship_id = $db_ds->f("ship_id");
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";

		if ( $screens_damage > 0 ) {
			$query = "update ship_technology set screenscurrent = '$new_screens' where ship_id = '$ship_id'";
		}

		$db_as->query($query);

		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_as->query($query);

		$date = time();
				
		$message = "Your ship was hit by a long range energy weapon in sector " . $db_ds->f("public_sector_id") . " that was fired from sector " . $player_public_sector_id . ".";
		$message = $message . "<br><br>Ship status:";
		$message = $message . "<br>Shields: " . $new_shields;
		$message = $message . "<br>Armor: " . $new_armor;				
		$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
			values ('$defender_id', '$message', 'Bridge', 't', '$date')";
		$db_as->query($query);
	}	

	$merchant_and_forces[0] = $merchant_killed;
	$merchant_and_forces[1] = $merchant_killed;
	$merchant_and_forces[2] = $damage;

	if ( $shield_damage > 0 or $armor_damage > 0 or $screens_damage > 0 ) {
		$merchant_and_forces[1] = 1;		
	}
	
	return $merchant_and_forces;
}

function attack_forces($attacker_id, $defender_id, $trifocus_plasma) {	
	$db_df = new ME_DB;
	$query = sprintf("SELECT * from forces where forces_id = '%s'", $defender_id);
	$db_df->query($query);
	$db_df->next_record();

	$db_as = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.rank, players.level, players.turns, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.combatcurrent, ships.type, ship_technology.player_id, ship_technology.targeting_computer, ship_technology.plasma_booster from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_as->query($query);
	$db_as->next_record();

	$targeting_bonus = 0;	

	if ( $db_as->f("targeting_computer") ) {
		$targeting_bonus = get_targeting_bonus($db_as->f("targeting_computer"));
	}	

	$attacker_level = $db_as->f("level");
	
	$total_forces = $db_df->f("mine") + $db_df->f("combat") + $db_df->f("scout");
	$total_forces_killed = 0;
	
	$num = rand(1,100);	

	if ( (($num - $attacker_level) - $targeting_bonus) <= 65 ) {
		if ( $trifocus_plasma == 1 ) {
			$num = rand(5, 9);			
		} elseif ( $trifocus_plasma == 2 ) {
			$num = rand(7, 11);			
		} elseif ( $trifocus_plasma == 3 ) {
			$num = rand(9, 13);			
		} elseif ( $trifocus_plasma == 4 ) {
			$num = rand(10, 14);			
		}
						
		$total_forces_killed = $num;

		if ( $total_forces_killed > $total_forces ) {
			$total_forces_killed = $total_forces;
		}
	}
	
	if ( $db_as->f("turns") - 5 < 0 ) {
		$new_turns = 0;
	} else {
		$new_turns = $db_as->f("turns") - 5;
	}

	$query = sprintf("update players set turns = '$new_turns' where player_id = '%s'", $attacker_id);
	$db_as->query($query);	

	return $total_forces_killed;
}

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$public_sector_id = $ship->f("public_sector_id");

$megawatts = array();

$db = new ME_DB;
$db->query("select * from technology_types");

while (	$db->next_record() ) {
	$megawatts[$db->f("name")] = $db->f("megawatts");
	$additional_megawatts[$db->f("name")] = $db->f("additional_megawatts");
}

$megawatts_used = 0;

check_module($ship->f("cloak"), "Cloaking Device", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("illusion"), "Illusion Generator", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("jump"), "Jump Drive", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("scanner"), "Scanners", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("tracking"), "Tracking Device", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("deep_scanner"), "Deep Space Scanner", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("targeting_computer"), "Targeting Computer", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("active_screens"), "Active Screens", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("plasma_booster"), "Plasma Booster", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("tractor_beam"), "Tractor Beam", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("trifocus_plasma"), "Tri-Focus Plasma", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("battle_systems_computer"), "Battle Systems Computer", $megawatts, $additional_megawatts, $megawatts_used);

$power_deficit = 0;

if ( $megawatts_used > $ship->f("powercurrent") ) {
	$power_deficit = 1;
	$error = 16;
}

$completed = 0;
$returnto = "ship_technology";

while ( !$completed ) {
	if ( $merchant_action == "track_merchant" and !$power_deficit ) {
		if ( !$ship->f("tracking") ) {
			$error = 10;
			break;
		}

		if ( $ship->f("planet_id") > 0 ) {
			$returnto = "ship_technology";
			$error = 7;
			break;
		}

		$results_found = 0;
		$tracking_player_id = 0;
		$db = new ME_DB;
			
		if ( $action == "merchantname" )  {
			if ( $track_target == $player->f("name") ) {
				$error = 13;
				break;
			}

			if ( stristr($track_target, ';') ) {
				$error = 10;
				break;
			} else {
				$db->query("select player_id, public_player_id, experience, name, game_id, race, alliance_name from players where name like '%$track_target%' and game_id = '$game_id'");
			}
				
			if ( $db->nf() > 0 ) {
				$db->next_record();
				$results_found = 1;

				$tracking_player_id = $db->f("player_id");
			}
		} else {
			$track_target = (int) $track_target;
   	
			if ( $track_target == $player->f("public_player_id") ) {
				$error = 13;
				break;
			}

 			$db->query("select player_id, public_player_id, experience, name, game_id, race, alliance_name from players where public_player_id = '$track_target' and game_id = '$game_id'");
			if ( $db->nf() > 0 ) {
				$db->next_record();
				$results_found = 1;

				$tracking_player_id = $db->f("player_id");
			}
		}

		if ( $results_found ) {
			$db->query("select player_id, sector_id from ships where player_id = '$tracking_player_id' and sector_id = '$sector_id'");
			if ( $db->nf() > 0 ) {
				$technology = new ME_Technology;
				$technology->get_technology($ship->f("ship_id"));	
				$technology->set_tracking_locked('t');		
				$technology->set_tracking_player_id($tracking_player_id);
				$technology->save();
				$returnto = "current_sector";
			} else {
				$error = 12;
				break;
			}
		} else {
			$error = 11;
			break;
		}		
	}

	if ( $merchant_action == "tow_merchant" and !$power_deficit ) {
		if ( !$ship->f("tractor_beam") ) {
			$error = 10;
			break;
		}

		if ( $ship->f("cloak") and $ship->f("cloak_active") == 't' ) {
			$error = 14;
			break;
		}

		if ( $ship->f("planet_id") > 0 ) {
			$returnto = "ship_technology";
			$error = 7;
			break;
		}

		$results_found = 0;
		$tractor_beam_player_id = 0;
		$db = new ME_DB;
			
		if ( $action == "merchantid" )  {			
			$tow_target = (int) $tow_target;
   	
			if ( $tow_target == $player->f("public_player_id") ) {
				$error = 13;
				break;
			}

			$query = "SELECT sector_id, type from locations where sector_id = '$sector_id' and type = 'Authority'";
			$db->query($query);
			$db->next_record();
					
			if ( $db->nf() > 0 ) {
				$error = 20;
				break;
			}

 			$db->query("select player_id, public_player_id, experience, name, newturnsleft, game_id, race, alliance_name from players where public_player_id = '$tow_target' and game_id = '$game_id'");
			if ( $db->nf() > 0 ) {
				$db->next_record();
				$results_found = 1;

				if ( $db->f("newturnsleft") > 0 ) {
					$error = 20;
					break;
				}				

				$tractor_beam_player_id = $db->f("player_id");
			}
		}

		if ( $results_found ) {
			$db->query("select player_id, sector_id, cargomax, shieldmax, armormax from ships where player_id = '$tractor_beam_player_id' and sector_id = '$sector_id'");
			$db->next_record();

			if ( $db->f("cargomax") <= 250 and $db->f("shieldmax") + $db->f("armormax") < 500 ) {
				// nothing
			} else {
				if ( $ship->f("cargomax") <= 250 and $ship->f("shieldmax") + $ship->f("armormax") < 750 ) {
					$error = 24;
					break;
				}
			}

			if ( $db->nf() > 0 ) {
				$technology = new ME_Technology;
				$technology->get_technology($ship->f("ship_id"));
				$technology->set_tractor_beam_locked('t');
				$technology->set_tractor_beam_player_id($tractor_beam_player_id);
				$technology->set_tractor_beam_time(time() + 45);
				$technology->save();
				$returnto = "current_sector";
			} else {
				$error = 12;
				break;
			}
		} else {
			$error = 11;
			break;
		}
	}

	$completed = 1;
}

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS) ) {

	switch ($key) {
		case "cloak_activate_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
			if ( !$ship->f("cloak") ) {
				$error = 1;
				break;	
			}

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_cloak_active('t');
			$technology->save();

			break;	

		case "cloak_de-activate_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
			if ( !$ship->f("cloak") ) {
				$error = 1;
				break;					
			}
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_cloak_active('f');					
			$technology->save();

			break;		

		case "illusion_activate_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
			if ( !$ship->f("illusion") ) {
				$error = 2;
				break;					
			}

			if ( $attack < 0 or $defense < 0 ) {
				$error = 3;
				break;					
			}

			if ( $attack > 30 or $defense > 30 ) {
				$error = 4;
				break;					
			}

			$db = new ME_DB;
  		
			$ship_type = (int) $ship_type;

			$db->query("SELECT * from ship_types where ship_type_id = '$ship_type'");
			$db->next_record();
			$illusion_type = $db->f("name");

			$attack = (int) $attack;
			$defense = (int) $defense;			

			$query = sprintf("update ship_technology set illusion_active = '%s', illusion_attack = '%s',
				illusion_defense = '%s', illusion_type_id = '%s', illusion_type = '%s' where ship_id = '%s'",
				't', $attack, $defense, $ship_type, $illusion_type, $ship->f("ship_id"));
  		
			$db->query($query);			

			break;	

		case "illusion_de-activate_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
			if ( !$ship->f("illusion") ) {
				$error = 2;
				break;					
			}

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_illusion_active('f');					
			$technology->save();

			break;	
		
		case "untrack_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
			if ( !$ship->f("tracking") ) {
				$error = 10;
				break;					
			}
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_tracking_locked('f');		
			$technology->set_tracking_player_id(0);
			$technology->save();

			break;	

		case "untractor_beam_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
			if ( !$ship->f("tractor_beam") ) {
				$error = 10;
				break;					
			}
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_tractor_beam_locked('f');		
			$technology->set_tractor_beam_player_id(0);
			$technology->save();

			break;	
			
		case "deep_scan_x":
			$returnto = "ship_technology_scan";			
  		
			if ( !$ship->f("deep_scanner") ) {
				$returnto = "ship_technology";
				$error = 10;
				break;
			}

			if ( $ship->f("cloak_active") == 't' ) {
				$returnto = "ship_technology";
				$error = 14;
				break;
			}

			if ( $ship->f("planet_id") > 0 ) {
				$returnto = "ship_technology";
				$error = 7;
				break;
			}

			if ( $power_deficit ) {
				$returnto = "ship_technology";
				$error = 16;
				break;	
			}
		
			$s1 = new ME_Sector;
			$s1->get_sector($player_id);

			$map_sql = "select * from sectors where ";
		
			$merchants = array();
			$sectors = array();

			$counter = 1;

			if ( $ship->f("deep_scanner") == 1 ) {
				$y_bound = 2;
				$x_bound = -2;
				$search_width = 5;
				$sector_limit = 26;
			} elseif ( $ship->f("deep_scanner") == 2 ) {
				$y_bound = 3;
				$x_bound = -3;
				$search_width = 7;
				$sector_limit = 50;
			} elseif ( $ship->f("deep_scanner") == 3 ) {
				$y_bound = 4;
				$x_bound = -4;
				$search_width = 9;
				$sector_limit = 82;
			} elseif ( $ship->f("deep_scanner") == 4 ) {
				$y_bound = 5;
				$x_bound = -5;
				$search_width = 11;
				$sector_limit = 122;
			}

			$y = $y_bound;
			for ($i = 1; $i <= $search_width; $i++) {
				$x = $x_bound;
				for ($j = 1; $j <= $search_width; $j++) {
					$map_sql = $map_sql . "( map_id = " . $s1->f("map_id") . " and xpos = " . ($s1->f("xpos") + $x) . " and ypos = " . ($s1->f("ypos") + $y) . " )";
					$counter++;

					if ( $counter <> $sector_limit ) {
						$map_sql = $map_sql . " or ";
					}

					$x = $x + 1;
				}
		
				$y = $y - 1;
			}				

			$query = $map_sql;
			$db = new ME_DB;
			$db_2 = new ME_DB;
			$db->query($query);
	
			$i = 0;

			while ( $db->next_record() ) {				
				$query = sprintf("select ship_id, sector_id from ships where sector_id = '%s' order by ship_id", $db->f("sector_id"));
				$db_2->query($query);

				if ( $db->f("sector_id") <> $ship->f("sector_id") and $db_2->nf() > 0 ) {
					array_push($sectors, $db->f("sector_id"));
										
					while ( $db_2->next_record() ) {
						if ( $merchants[$i] <> 0 ) {
							$merchants[$i] = $merchants[$i] . "," . $db_2->f("ship_id");
						} else {
							array_push($merchants, $db_2->f("ship_id"));
						}
					}

					$i++;
				}				
			}																				

			for ($i = 0; $i <= count($sectors) - 1; $i++) {
				$str_merchants = $str_merchants . "s" . $sectors[$i] . "(" . $merchants[$i] . ")";
			}

			$sector_id = $s1->f("sector_id");									
			$scan_time = time();
			$query = "insert into scans (player_id, scanned_merchants, sector_id, scan_time) values('$player_id', '$str_merchants', '$sector_id', '$scan_time')";
			$db->query($query);			

			$db->query("select * from scan_id");
			$db->next_record();
			$scan_id = $db->f("last_value");
			
			break;

		case "jump_x":
			$db = new ME_DB;
			$db_2 = new ME_DB;

			$player_config = new ME_Player_config;
			$player_config->get_player_config($player_id);
			
			$returnto = $player_config->f("post_trade_screen");
  		
			if ( !$ship->f("jump") ) {
				$returnto = "ship_technology";
				$error = 5;
				break;					
			}
		
			if ( $ship->f("planet_id") > 0 ) {
				$returnto = "ship_technology";
				$error = 7;
				break;
			}

			if ( $power_deficit ) {
				$returnto = "ship_technology";
				$error = 16;
				break;	
			}
			
			if ( $player->f("alliance_id") == 0 ) {				
				$query = sprintf("select * from forces where sector_id = '%s' and mine > 0 and player_id <> '%s'", $ship->f("sector_id"), $player->f("player_id"));
				$db->query($query);
				$db->next_record();
				
				if ( $db->nf() > 0 ) {
					$returnto = "ship_technology";
					$error = 21;
					break;				
				}											
			} else {				
				$treaties = get_treaties($player->f("alliance_id"), 'Free Movement');

				$query = sprintf("select * from forces where sector_id = '%s' and mine > 0 and alliance_id <> '%s'", $ship->f("sector_id"), $player->f("alliance_id"));
				$db->query($query);				
				
				if ( $db->nf() > 0 ) {
				
					while ( $db->next_record() ) {
						if ( !(in_array($db->f("alliance_id"), $treaties)) ) {
							$returnto = "ship_technology";
							$error = 21;
						}
					}

					if ( $error == 21 ) {
						break;				
					}
				}
			}
						
			# update player turns
			$player = new ME_Player;
			$player->get_player($player_id);
			$turns = $player->f("turns");
			$newturns = $player->f("newturnsleft");
			$game_id = $player->f("game_id");
	
			# only move if the player has 20 turns
			if ( ($player->f("turns") - 20) >= 0 )  {
				if ( $newturns > 0 ) {
					if ( ($player->f("newturnsleft") - 20) >= 0 )  {
						$player->set_new_turns_left($newturns - 20);
					} else {
						$player->set_new_turns_left(0);
					}
				}

				$jump_target = (int) $jump_target;

				$db_2 = new ME_DB;
				$query = sprintf("select * from sectors where sector_id = '%s'", $ship->f("sector_id"));
				$db_2->query($query);	
				$db_2->next_record();
				$current_xpos = $db_2->f("xpos");
				$current_ypos = $db_2->f("ypos");
				$current_map_id = $db_2->f("map_id");
				
				$query = sprintf("select * from sectors where public_sector_id = '%s'", $jump_target);
				$db_2->query($query);
				
				$valid_sector = 0;

				while (	$db_2->next_record() and !$valid_sector ) {
					$db_m = new ME_DB;
					$query = sprintf("select * from maps where map_id = '%s'", $db_2->f("map_id"));
					$db_m->query($query);
	        $db_m->next_record();

					if ( $game_id == $db_m->f("game_id") ) {
						$valid_sector = 1;
						$this_map_id = $db_m->f("map_id");
						$this_sector_id = $db_2->f("sector_id");
						$this_public_sector_id = $db_2->f("public_sector_id");
						$this_xpos = $db_2->f("xpos");
						$this_ypos = $db_2->f("ypos");
					}
				}

				if ( $current_map_id <> $this_map_id and $ship->f("galaxy_jump") == 'f' ) {
					$returnto = "ship_technology";
					$error = 9;
					break;				
				}

				$db_p = new ME_DB;
				$db_p->query("select * from planets where sector_id = '$this_sector_id'");
				$db_p->next_record();

				if ( $db_p->nf() > 0 ) {
					if ( $db_p->f("warp_inhibitor") == 't' ) {
						if ( ( $db_p->f("alliance_id") == 0 and $db_p->f("owner_id") <> $player->f("player_id") ) or $db_p->f("alliance_id") <> $player->f("alliance_id") ) {
							$returnto = "ship_technology";
							$error = 8;
							break;
						}
					}
				}
						
		    if ( $valid_sector ) {
					$ship = new ME_Ship;
					$ship->get_ship($player_id);

					$num = rand(1,100);
					$percent_miss_jump = 0;

					if ( $this_map_id <> $current_map_id ) {
						$percent_miss_jump = 50 - $player->f("level");
					} elseif ( outside_safe_jump($current_map_id, $current_xpos, $current_ypos, $this_public_sector_id, $ship->f("public_sector_id")) ) {
						$percent_miss_jump = 40 - $player->f("level");
					}

					if ( $percent_miss_jump > $num ) {
						$miss_jump = get_miss_jump($this_map_id, $this_xpos, $this_ypos, $this_public_sector_id);

						$ship->set_sector_id($miss_jump['sector_id']);
						$ship->set_public_sector_id($miss_jump['public_sector_id']);
						$this_sector_id = $miss_jump['sector_id'];
						$this_public_sector_id = $miss_jump['public_sector_id'];
					} else {
					  $ship->set_sector_id($this_sector_id);
						$ship->set_public_sector_id($this_public_sector_id);
					}

					$ship->set_last_move_sector_id($ship->f("sector_id"));
			  	$ship->save();
					$player->set_turns($turns - 20);
					$player->save();
				}
					
				$query = sprintf("select * from forces where sector_id = '%s' and player_id <> '%s'", $this_sector_id, $player->f("player_id"));
				$db->query($query);

				if ( $db->nf() > 0 ) {					
					$date = time();					
		
					if ( !isset($treaties) ) {
						# fill treaties										
						$treaties = get_treaties($player->f("alliance_id"), 'Free Movement');
					}					

					$tactical_defense = get_tactical_defense($ship, $player->f("level"));
					
					while ( $db->next_record() ) {							
						if ( $db->f("alliance_id") <> $player->f("alliance_id") or $db->f("alliance_id") == 0 ) {
							if ( $db->f("focused_alliance_id") <> 0 and $db->f("focused_alliance_id") <> $player->f("alliance_id") ) {
								# nothing
							} elseif ( $db->f("focused_player_id") <> 0 and $db->f("focused_player_id") <> $player->f("player_id") ) {
								# nothing
							} elseif ( $db->f("scout") > 0 ) {
								if ( $ship->f("cloak_active") == 't' and $ship->f("cloak") ) {
									# nothing
								} else {
									$scout_player_id = $db->f("player_id");

									$query = "select player_id, message_id from messages where player_id = '$scout_player_id' and scout = 't' order by message_id";
									$db_m->query($query);
									$db_m->next_record();
									if ( $db_m->nf() > 50 ) {
	    	  		    	$message_id = $db_m->f("message_id");

										$query = "delete from messages where message_id = '$message_id'";
										$db_m->query($query);
									}
	
									$message = "Movement detected in sector " . $this_public_sector_id;
									$message = $message . "<br>Merchant: " . addslashes($player->f("name"));
									$message = $message . "<br>Alliance: " . addslashes($player->f("alliance_name"));
									$message = $message . "<br>Ship type: " . $ship->f("type");
									$message = $message . "<br>Entered via: jump drive";

									$query = "insert into messages (player_id, message, toplayer, scout, date_integer)
										values ('$scout_player_id', '$message', 'Drone Comm Link', 't', '$date')";
									$db_m->query($query);									
								}							
							}
						}						

						if ( $player->f("newturnsleft") == 0 and $db->f("mine") > 0 ) {
							if ( $db->f("alliance_id") <> $player->f("alliance_id") or $db->f("alliance_id") == 0 ) {
								if ( $db->f("focused_alliance_id") <> 0 and $db->f("focused_alliance_id") <> $player->f("alliance_id") ) {
									# nothing
								} elseif ( $db->f("focused_player_id") <> 0 and $db->f("focused_player_id") <> $player->f("player_id") ) {
									# nothing
								} elseif ( in_array($db->f("alliance_id"), $treaties) ) {
									# nothing
								} else {									
									if ( $db->f("mine") <= 5 ) {
										$percent_escape = 35;
									} elseif ( $db->f("mine") > 5 and $db->f("mine") <= 10 ) {
										$percent_escape = 25;
									} elseif ( $db->f("mine") > 10 and $db->f("mine") <= 20 ) {
										$percent_escape = 20;
									} elseif ( $db->f("mine") > 20 and $db->f("mine") <= 30 ) {
										$percent_escape = 15;
									} elseif ( $db->f("mine") > 30 and $db->f("mine") <= 40 ) {
										$percent_escape = 10;
									} elseif ( $db->f("mine") > 40 ) {
										$percent_escape = 5;
									}

									if ( $ship->f("cloak") and $ship->f("cloak_active") == 't' ) {
										$percent_escape = $percent_escape + 10;
									}

									$num = rand(1,100);
        		
									if ( $num > $percent_escape + $tactical_defense ) {
										$returnto = "attack";
										$id = $db->f("forces_id");
										$type = "m";
										$refer = "moveto";																		
									}
								}
							}
						}						
					}
				}								

				save_player_map($this_map_id, $player, $this_sector_id);
			} else {
      			$returnto = "ship_technology";
				$error = 6;
				break;	
			}

			break;	

		case "trifocus_fire_x":
			$returnto = "ship_technology";

			if ( $power_deficit ) {
				$error = 16;
				break;	
			}
  		
  		if ( $ship->f("sector_id") == 0 ) {
				$returnto = "ship_technology";
				$error = 7;
				break;
			}
			
			if ( !$ship->f("trifocus_plasma") ) {
				$error = 10;
				break;					
			}			

			if ( stristr($trifocus_target, ';') ) {
				$error = 1;
				break;			
			}					
	
			if ( $ship->f("trifocus_fire_time") >= time() - 30 ) {
				$error = 17;
				break;
			}	

			if ( !($trifocus_sector > 0) ) {
				$error = 3;
				break;
			}	

			if ( $player->f("newturnsleft") > 0 ) {
				$error = 23;
				break;
			}

			if ( $player->f("turns") - 2 < 0 ) {
				$error = 6;
				break;
			}

			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type = 'Authority'");

			if ( $db->nf() > 0 ) {
				$error = 23;
				break;	
			}

			$db->query("select * from sectors where sector_id = '$sector_id'");
			$db->next_record();
			$player_map_id = $db->f("map_id");
			$player_xpos = $db->f("xpos");
			$player_ypos = $db->f("ypos");
			$player_public_sector_id = $db->f("public_sector_id");

			if ( $target_type == 1 ) {				
				$db->query("select player_id, public_player_id, experience, name, game_id, race, alliance_name, newturnsleft from players where name = '$trifocus_target' and game_id = '$game_id'");
				$db->next_record();
				$target_player_id = $db->f("player_id");
				
				if ( $db->f("newturnsleft") > 0 ) {
					$error = 20;
					break;
				}
					
				if ( $db->nf() == 0 ) {
					$error = 11;
					break;
				}													
								
				$db->query("select * from sectors where public_sector_id = '$trifocus_sector' and map_id = '$player_map_id'");
				$db->next_record();

				if ( $db->nf() <> 0 ) {								
					$target_sector_id = $db->f("sector_id");		
					$player_map_id = $db->f("map_id");	

					$map_sql = "select * from sectors where ";

					$counter = 1;
		
					if ( $ship->f("trifocus_plasma") == 1 ) {
						$y_bound = 1;
						$x_bound = -1;
						$search_width = 3;
						$sector_limit = 10;
					} else {
						$y_bound = 2;
						$x_bound = -2;
						$search_width = 5;
						$sector_limit = 26;
					}							

					$y = $y_bound;
					for ($i = 1; $i <= $search_width; $i++) {
						$x = $x_bound;
						for ($j = 1; $j <= $search_width; $j++) {
							$map_sql = $map_sql . "( map_id = " . $player_map_id . " and xpos = " . ($player_xpos + $x) . " and ypos = " . ($player_ypos + $y) . " )";
							$counter++;

							if ( $counter <> $sector_limit ) {
								$map_sql = $map_sql . " or ";
							}
		
							$x = $x + 1;
						}
			
						$y = $y - 1;
					}				
											
					$query = $map_sql;
					$db->query($query);

					$surrounding_sectors = array();

					while ( $db->next_record() ) {
						if ( $db->f("public_sector_id") <> $player_public_sector_id ) {
							array_push($surrounding_sectors, $db->f("public_sector_id"));
						}
					}

					if ( !in_array($trifocus_sector, $surrounding_sectors) ) {
						$error = 19;
						break;						
					}
				}						

				$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id, players.player_id, players.name, players.experience, ship_technology.cloak, ship_technology.cloak_active from ships, sectors, players, ship_technology where ships.player_id = '$target_player_id' and ships.public_sector_id = '$trifocus_sector' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id and ships.player_id = ship_technology.player_id");
				$db->next_record();

				if ( $db->nf() == 0 ) {
					$error = 18;
					break;
				} else {
					if ( $db->f("cloak_active") == 't' and $db->f("cloak") and $db->f("experience") > $player->f("experience") ) {
						$error = 18;
						break;
					}

					$target_sector_id = $db->f("sector_id");				
				
					$target_xpos = $db->f("xpos");
					$target_ypos = $db->f("ypos");
					$target_map_id = $db->f("map_id");
					$target_player_name = $db->f("name");
										
					$query = sprintf("SELECT sector_id, type from locations where sector_id = '%s' and type = 'Authority'", $target_sector_id);
					$db->query($query);
					$db->next_record();
					
					if ( $db->nf() > 0 ) {
						$error = 20;
						break;
					}																

					if ( $target_map_id <> $player_map_id ) {
						$error = 18;
						break;
					}
				
					$merchant_and_forces = array();
					$merchant_and_forces = attack_merchant_with_merchant($player_id, $target_player_id, $ship->f("trifocus_plasma"));
				}

				$merchant_killed = 'f';
				if ( $merchant_and_forces[0] == 1 ) {
					$merchant_killed = 't';
					merchant_dead($target_player_id, $player_id, $sector_id, "s");
				}

				$merchant_hit = 'f';
				if ( $merchant_and_forces[1] == 1 ) {
					$merchant_hit = 't';
				}				

				$query = "insert into trifocus_attacks (player_id, merchant_killed, merchant_hit, forces_killed, forces_hit, trifocus_target, target_type, damage) values('$player_id', '$merchant_killed', '$merchant_hit', 'f', 'f', '$target_player_id', $target_type, $merchant_and_forces[2])";
				$db->record_oid();	
				$db->query($query);
			} elseif ( $target_type == 2 ) {								
				$db->query("select * from sectors where sector_id = '$sector_id'");
				$db->next_record();
				$player_map_id = $db->f("map_id");
				
				$target_player_id = $db->f("player_id");
				$db->query("select * from sectors where public_sector_id = '$trifocus_sector' and map_id = '$player_map_id'");
				$db->next_record();

				if ( $db->nf() <> 0 ) {
					$xpos = $db->f("xpos");
					$ypos = $db->f("ypos");
					$target_sector_id = $db->f("sector_id");
					
					$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id from ships, sectors where ships.player_id = '$player_id' and ships.sector_id = sectors.sector_id");
					$db->next_record();

					$player_xpos = $db->f("xpos");
					$player_ypos = $db->f("ypos");																			
				
					$db->query("select * from forces where sector_id = '$target_sector_id'");

					$total_forces = 0;

					while ( $db->next_record() ) {
						$total_forces = $total_forces + $db->f("mine");
						$total_forces = $total_forces + $db->f("combat");
						$total_forces = $total_forces + $db->f("scout");
						$target_forces_id = $db->f("forces_id");
						$target_player_id = $db->f("player_id");		
					}
					
					if ( $total_forces < 125 ) {
						$error = 22;
						break;			
					}								

					$map_sql = "select * from sectors where ";

					$counter = 1;
		
					if ( $ship->f("trifocus_plasma") == 1 ) {
						$y_bound = 1;
						$x_bound = -1;
						$search_width = 3;
						$sector_limit = 10;
					} else {
						$y_bound = 2;
						$x_bound = -2;
						$search_width = 5;
						$sector_limit = 26;
					}		

					$y = $y_bound;
					for ($i = 1; $i <= $search_width; $i++) {
						$x = $x_bound;
						for ($j = 1; $j <= $search_width; $j++) {
							$map_sql = $map_sql . "( map_id = " . $player_map_id . " and xpos = " . ($player_xpos + $x) . " and ypos = " . ($player_ypos + $y) . " )";
							$counter++;

							if ( $counter <> $sector_limit ) {
								$map_sql = $map_sql . " or ";
							}
		
							$x = $x + 1;
						}
			
						$y = $y - 1;
					}				
											
					$query = $map_sql;
					$db->query($query);

					$surrounding_sectors = array();

					while ( $db->next_record() ) {
						if ( $db->f("public_sector_id") <> $player_public_sector_id ) {
							array_push($surrounding_sectors, $db->f("public_sector_id"));
						}
					}

					if ( !in_array($trifocus_sector, $surrounding_sectors) ) {
						$error = 19;
						break;						
					}

					$total_forces_killed = 0;
					$total_forces_killed = attack_forces($player_id, $target_forces_id, $ship->f("trifocus_plasma"));
					
					$forces_hit = 'f';
					if ( $total_forces_killed > 0 ) {
						$forces_hit = 't';
						kill_forces($target_forces_id, $total_forces_killed);
	
						$num = rand(25,40);	
						$new_experience = $player->f("experience") + $num;
						$player->set_experience($new_experience);
						$player->save();		
					}

					$forces_killed = 'f';
					if ( $total_forces == $total_forces_killed ) {
						$forces_killed = 't';
					}

					if ( $total_forces_killed > 0 ) {						
						$date = time();
						$message = "Your forces in sector " . $trifocus_sector . " were attacked by a long range energy weapon.";
						$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
							values ('$target_player_id', '$message', 'Bridge', 't', '$date')";
						$db->query($query);					
					}
					
					$query = "insert into trifocus_attacks (player_id, merchant_killed, merchant_hit, forces_killed, forces_hit, trifocus_target, target_type, damage) values('$player_id', 'f', 'f', '$forces_killed', '$forces_hit', '$target_player_id', '$target_type', '$total_forces_killed')";
					$db->record_oid();	
					$db->query($query);
			  }
			}			

			$query = sprintf("select trifocus_attack_id from trifocus_attacks where oid = '%s'", $db->Last_OID);
			$db->query($query);
			$db->next_record();
		
			$trifocus_attack_id = $db->f("trifocus_attack_id");

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_trifocus_fire_time(time());		
			$technology->save();

			$player->set_turns($player->f("turns") - 2);
			$player->save();

			break;					
	}
}

if ( $error ) {
	if ($returnto == "ship_technology")  {
		$newurl = $sess->url(URL . "ship_technology.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "local_map")  {
		$newurl = $sess->url(URL . "local_map.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "ship_technology_scan")  {
		$newurl = $sess->url(URL . "ship_technology_scan.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "ship_technology")  {
		if ( $trifocus_attack_id > 0 ) {
			$newurl = $sess->url(URL . "ship_technology.php") . "?trifocus_id=" . $trifocus_attack_id;
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "ship_technology.php");
			header("Location: $newurl");	
		}
	} elseif ($returnto == "local_map")  {
		$newurl = $sess->url(URL . "local_map.php");
		header("Location: $newurl");	
	} elseif ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php");
		header("Location: $newurl");	
	} elseif ($returnto == "attack") {
		$newurl = $sess->url(URL . "attack.php" . "?refer=" . $refer . "&id=" . $id . "&type=" . $type );
		header("Location: $newurl");	
	} elseif ($returnto == "ship_technology_scan") {
		$newurl = $sess->url(URL . "ship_technology_scan.php" . "?id=" . $scan_id);
		header("Location: $newurl");	
	}
}

page_close();
?>
