<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./merchantempiresdefines.php");
include("./lib/player.php");
include("./lib/ship.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Current Players</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ip = (int) $ip;

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "currentplayers");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top width=490><?php

$db = new ME_DB;
$db->query("select active_sessions.player_id, active_sessions.game_id, active_sessions.player_ip, players.player_id, players.name,
	players.race, players.experience, players.alliance_name, players.public_player_id from active_sessions, players
	where active_sessions.player_id > 0 and active_sessions.game_id = '$game_id' and players.player_id = active_sessions.player_id");

?>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=1 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 valign=middle>
						<br>
						<font color=#3333FF face=arial,helvetica,swiss size=5><center>CURRENT PLAYERS</center></font>
						<br>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
    			<td bgColor=#330000><font color=#ffffff  face=arial,helvetica,swiss size=3>
    			Name
					</font><br></td>
					<td bgColor=#330000><font color=#ffffff  face=arial,helvetica,swiss size=3>
    			Race
					</font><br></td>
					<td bgColor=#330000><font color=#ffffff  face=arial,helvetica,swiss size=3>
    			Alliance
					</font><br></td>
					<td bgColor=#330000><font color=#ffffff  face=arial,helvetica,swiss size=3>
    			Experience
					</font><br></td><?php

if ( $ip == 1 ) {
	echo "<td bgColor=#330000><font color=#ffffff  face=arial,helvetica,swiss size=3>";
	echo "IP</font><br></td>";
}
?>
				</tr><?php

# this array holds unique player names; there could be multiple entries for 1 player

while ($db->next_record()) {

	$active_player_id = $db->f("player_id");

  if ( $active_player_id > 0 ) {	
		$str = $active_player_id;

		if ( isset($str) ) {
			echo "<tr>";
			echo "<td width=125 bgColor=#000000 valign=middle bgColor=#330000>";
			echo "<font color=#cccccc face=arial,helvetica,swiss size=3><a href=";
			echo $sess->purl(URL . "merchant_search_results.php?action=merchant_id&criteria=" . $db->f("public_player_id")) . ">";
			echo $db->f("name") . "</a></font>";
			echo "</td>";
			echo "<td width=75 bgColor=#000000 valign=middle bgColor=#330000>";
			echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";
   		echo $db->f("race");
			echo "</font>";
			echo "</td>";
			echo "<td width=150 bgColor=#000000 valign=middle bgColor=#330000>";
			echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";
   		echo $db->f("alliance_name");
			echo "</font>";
			echo "</td>";
			echo "<td width=50 bgColor=#000000 valign=middle bgColor=#330000>";
			echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";
   		echo $db->f("experience");
			echo "</font></td>";

			if ( $ip == 1 ) {
				echo "<td width=50 bgColor=#000000 valign=middle bgColor=#330000>";
				echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";

				if ( $db->f("name") == 'joe1' ) {
  				echo "---";
				} else {
	  	 		echo $db->f("player_ip");
				}
				echo "</font></td>";				
			}

			echo "</tr>";
  	}
	}
}

?>
			</table>
		</td>
	</tr>
</table><?php

if ( $ip <> 1 ) {
?>
<br>
<table width=490 border=0 cellPadding=1 cellSpacing=5>
	<tr>
		<td bgColor=#003399>
			<table width=490 border=0 cellPadding=3 cellSpacing=0>
				<tr>
					<td align=center bgColor=#000000><a href=<?php

echo $sess->url(URL . "current_players.php");
echo "?ip=1";
?>
									><font face=arial,helvetica,swiss size=2>View IP</a>
					</td>					
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}
?>
</td>
<td>

</td></tr></table>
</body></html><?php

page_close();
?>
