<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Planet Ownership</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
	
$db_p = new ME_DB_Xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();
	
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {
	$db_p->add_parameter("current_screen", "planet_ownership");	
	echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());
?>
<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
  	<td bgColor=#003399>
    	<table border=0 cellPadding=5 cellSpacing=1 width=490>
        <tr>
        	<td class=clsNrmTxt>
						&nbsp;Owner: <?php

	$owner_id =  $db_p->f("owner_id");
	$db_a = new ME_DB;
	$db_a->query("select player_id, name, alliance_name from players where player_id = '$owner_id'");
	$db_a->next_record();
	echo $db_a->f("name");
	echo "<br>" . "&nbsp;Alliance: " . $db_a->f("alliance_name");
?>


						<form METHOD="POST" ACTION=<?php $sess->purl(URL . "planet_update.php") ?>>
						<table>
		   				<tr>
		   					<td class=clsNrmTxt>Password</td>
 		   					<td class=clsNrmTxt><input type="password" name="password"></td>
		   				</tr>
							<tr>
		   					<td>&nbsp;</td>
 		   					<td><input border=0 type="image" src="./images/form/claim-off.png" name="change_password" value="Claim"></td>
		   				</tr>
							<tr>
		   					<td>&nbsp;</td>
 		   					<td class=clsNrmTxt>
									Claiming an owned planet will expel all merchants except the claiming merchant into space.<br><br>
									The owner of a planet can abandon a planet by setting the password to 00.</td>
		   				</tr>
							<tr>
		   					<td class=clsNrmTxt>Planet name</td><?php

	echo '<td><input type=textbox name=name value="' . htmlentities($db_p->f("name")) . '"></td>';
?>						
		   				</tr>
							<tr>
		   					<td>&nbsp;</td>
 		   					<td><input border=0 type="image" src="./images/form/update_narrow-off.png" name="change_name" value="Change Name"></td>
		   				</tr>

							<tr>
		   					<td class=clsNrmTxt><br>Alliance access</td>
		   				</tr>
							<tr>
		   					<td>&nbsp;</td>
 		   					<td>

									<table cellpadding=2 cellspacing=2><tr><td class=clsNrmTxt>

Construction
<td></td><td>
<input type=radio name=construction<?php

if ( $db_p->f("alliance_access_construction") == "t" ) {
	echo ' checked ';
}
?>
										value=1>&nbsp;Yes<br>
										<input type=radio name=construction<?php

if ( $db_p->f("alliance_access_construction") == "f" ) {
	echo ' checked ';
}
?>
											value=2>&nbsp;No
</tr><tr>
<td class=clsNrmTxt>
Military
<td></td><td>
<input type=radio name=military<?php

if ( $db_p->f("alliance_access_military") == "t" ) {
	echo ' checked ';
}
?>
										value=1>&nbsp;Yes<br>
										<input type=radio name=military<?php

if ( $db_p->f("alliance_access_military") == "f" ) {
	echo ' checked ';
}
?>
											value=2>&nbsp;No
</tr><tr>
<td class=clsNrmTxt>
Stockpile
<td></td><td>
<input type=radio name=stockpile<?php

if ( $db_p->f("alliance_access_stockpile") == "t" ) {
	echo ' checked ';
}
?>
										value=1>&nbsp;Yes<br>
										<input type=radio name=stockpile<?php

if ( $db_p->f("alliance_access_stockpile") == "f" ) {
	echo ' checked ';
}
?>
											value=2>&nbsp;No

										</td></tr></table>

								</td>
		   				</tr>
							<tr>
		   					<td>&nbsp;</td>
 		   					<td><input border=0 type="image" src="./images/form/update_narrow-off.png" name="alliance_access" value="Update"></td>
		   				</tr>
		   			</table>
		   			</form>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table><?php

} else {
	$error = 4;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Password not entered.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Incorrect password.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "Your merchant's experience level does not allow you to claim additional planets.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "Your alignment prevents you from installing that weapon.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "Your merchant does not have sufficient experience to claim a planet.");			
	} elseif ($error == 7) {
		$db->add_parameter("message", "Your merchant does not own this planet.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
