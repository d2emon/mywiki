<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/ship.php");
include("./lib/player.php");
include("./lib/player_redirect.php");

if ( $player_id > 0 )  {
	# update player turns
	$player = new ME_Player;
	$player->get_player($player_id);
	$turns = $player->f("turns");	
	$ship = new ME_Ship;
	$ship->get_ship($player_id);
	$sector_id = $ship->f("sector_id");

	$db_p = new ME_DB;
	$db_p->query("select * from planets where sector_id = '$sector_id'");
	$db_p->next_record();

	$owner_id =  $db_p->f("owner_id");

	if ( $db_p->f("alliance_id") == $player->f("alliance_id") or $db_p->f("owner_id") == $player->f("player_id") or
				($db_p->f("alliance_id") == 0 and $db_p->f("owner_id") == 0) ) {
		# only land if the player has a turn
		if ( ($player->f("turns") - 2) >= 0 )  {
			if ( $player->f("newturnsleft") - 2 >= 0 ) {
				$player->set_new_turns_left($player->f("newturnsleft") - 2);
			} else {
				$player->set_new_turns_left(0);
			}

			if ( $ship->f("planet_id") == 0 ) {
				$db = new ME_DB;
				$query = sprintf("select planet_id, sector_id from planets where sector_id = '%s'", $ship->f("sector_id"));
				$db->query($query);
				$db->next_record();
		
				if ( $db->f("planet_id") > 0 ) {
		  		$ship->set_sector_id(0);
					$ship->set_public_sector_id(0);
					$ship->set_starbase_id(0);
					$ship->set_planet_id($db->f("planet_id"));
		  		$ship->save();
	
					$player->set_turns($turns - 2);
					$player->save();
	
					$newurl = $sess->url(URL . "planet.php");
				  header("Location: $newurl");
				} else {
					$newurl = $sess->url(URL . "planet_orbit.php");
				  header("Location: $newurl");
				}
			}
		} else {
			$newurl = $sess->url(URL . "planet_orbit.php");
		  header("Location: $newurl");
		}
	} else {
		$newurl = $sess->url(URL . "planet_orbit.php");
	  header("Location: $newurl");
	}
}

page_close();
?>