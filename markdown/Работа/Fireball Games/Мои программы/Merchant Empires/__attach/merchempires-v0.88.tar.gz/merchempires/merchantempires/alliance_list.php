<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Alliance List</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
}

$alliance_id = (int) $alliance_id;
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "alliance_list");	
$db->add_parameter("alliance_id", $alliance_id);
echo $db->get_transform("./xslt/menu_top_alliance.xslt", "");
?>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
    			<td width=150 bgColor=#330000><center><FONT color=#ffffff  face=arial,helvetica,swiss size=3>
    			Name</center>
					</FONT></td>
					<td width=100 bgColor=#330000><center><FONT color=#ffffff  face=arial,helvetica,swiss size=3>
    			Total Experience</center>
					</FONT></td>
					<td width=100 bgColor=#330000><center><FONT color=#ffffff  face=arial,helvetica,swiss size=3>
    			Average Experience</center>
					</FONT></td>
					<td width=80 bgColor=#330000><center><FONT color=#ffffff  face=arial,helvetica,swiss size=3>
    			Merchants</center>
					</FONT></td>
				</tr><?php

$db = new ME_DB;
$db->query("select alliance_id from alliances where game_id = '$game_id'");
$total_alliances = $db->nf();

$limit = 17;
if ( ! ( $offset > 0 ) ) {
	$offset = 0;
}

if ( $direction == "all_up" ) {
	$offset = $total_alliances - 17;
} elseif ( $direction == "all_down" ) {
	$offset = 0;
}

$offset = (int) $offset;
$limit = (int) $limit;
$db->query("select * from alliances where game_id = '$game_id' order by name limit $limit offset $offset");
$db_p = new ME_DB;
$db_2 = new ME_DB;

while ( $db->next_record() ) {
			$all_id = $db->f("alliance_id");

			$db_p->query("select alliance_id from players where alliance_id = '$all_id'");
			$db_2->query("select alliance_id, SUM(experience) as total_experience from players where alliance_id = '$all_id' group by alliance_id");
      $db_2->next_record();

			if ( $db_2->f("total_experience") > 300 ) {
				echo "<tr><td width=150 bgColor=#000000 valign=middle>";
				echo "<font color=#cccccc face=arial,helvetica,swiss size=3><a href=";
				echo $sess->url(URL . "alliance.php") . "?alliance_id=" . $db->f("alliance_id");
				echo ">" . $db->f("name") . "</a></font>";
				echo "</td>";
				echo "<td width=100 bgColor=#000000 valign=middle>";
				echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";

				if ( $db_2->f("total_experience") > 0 ) {
				 	echo $db_2->f("total_experience");
				} else {
					echo "0";
				}

				echo "</font>";
				echo "</td>";
				echo "<td width=100 bgColor=#000000 valign=middle>";
				echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";
   		 	if ( $db_2->f("total_experience") == 0 ) {
  	    	echo "0";
				} else {
      		echo (int) ($db_2->f("total_experience") / $db_p->nf());
				}
				echo "</font>";
				echo "</td>";
				echo "<td width=80 bgColor=#000000 valign=middle>";
				echo "<font color=#cccccc face=arial,helvetica,swiss size=3>";
  	  	echo $db_p->nf();
				echo "</font></td></tr>";
			}
}

			echo "<tr><td bgColor=#000000 colspan=4><center>";

			echo "<a href=";
			echo $sess->url(URL . "alliance_list.php?direction=all_down");
			echo "><img border=0 src=./images/misc/left_double.png>&nbsp;";

			if ( $offset - 17 < 0 ) {
				echo "<img border=0 src=./images/misc/left_single.png>";				
			} else {
				echo "<a href=";
				$this_offset = $offset - 17;
				echo $sess->url(URL . "alliance_list.php?offset=" . $this_offset);
				echo "><img border=0 src=./images/misc/left_single.png></a>";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;";
			}

			if ( $offset + 17 > $total_alliances ) {
				echo "<img border=0 src=./images/misc/right_single.png>&nbsp;";
			} else {
				echo "<a href=";
				$this_offset = $offset + 17;
				echo $sess->url(URL . "alliance_list.php?&offset=" . $this_offset);
				echo "><img border=0 src=./images/misc/right_single.png></a>&nbsp;";
			}

			echo "<a href=";
			echo $sess->url(URL . "alliance_list.php?direction=all_up");
			echo "><img border=0 src=./images/misc/right_double.png></a>";
			echo "</center></td></tr>";
?>
			</table>
		</td>
	</tr>
</table>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
