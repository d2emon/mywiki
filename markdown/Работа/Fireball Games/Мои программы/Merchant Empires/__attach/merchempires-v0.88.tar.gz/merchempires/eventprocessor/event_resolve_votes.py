
def resolve_votes():
	import time, string
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb, postmerchhost, user=postmerchuser, passwd=postmerchpass)

	for race_num in range(7):
		qrystr = "select * from overlord_votes where overlord_has_voted_" + str(race_num + 1) + " = 1"
		q = pgcnx.query(qrystr)
		res = q.getresult()

		for value in range(len(res)):
			str_votes = res[value][q.fieldnum('overlord_council_votes_' + str(race_num + 1))]
			game_id = res[value][q.fieldnum('game_id')]
			race_id = res[value][q.fieldnum('race_id')]
			vote_time = res[value][q.fieldnum('overlord_vote_' + str(race_num + 1) + '_date')]

			if res[value][q.fieldnum('overlord_vote_' + str(race_num + 1))] == 1:
				relations = -300
			else:
				relations = 300

			votes = string.split(str_votes, ',')

			qrystr = "select * from games where game_id = %d" % (game_id)
			q_g = pgcnx.query(qrystr)
			res_g = q_g.getresult()

			list_relations = string.split(str(res_g[0][q_g.fieldnum('relationsrace_' + str(race_id))]), ',')

			if len(votes) >= 9 or vote_time <= time.time():
				support = 0
				against = 0

				for value_2 in range(len(votes)):
					if votes[value_2] == "1":
						support = support + 1
					else:
						against = against + 1

				if support > against:
					list_relations[race_num] = str(relations)
					str_new_relations = string.join(list_relations, ',')

					qrystr = "update games set relationsrace_" + str(race_id) + " = '%s' where game_id = %d" % (str_new_relations, game_id)
					pgcnx.query(qrystr)

				qrystr = "update overlord_votes set overlord_has_voted_" + str(race_num + 1) + " = 0, overlord_vote_" + str(race_num + 1) + " = 0, overlord_council_votes_" + str(race_num + 1) + " = '', overlord_vote_" + str(race_num + 1) + "_date = 0 where game_id = %d and race_id = %d" % (game_id, race_id)
				pgcnx.query(qrystr)

				qrystr = "update council_votes set overlord_has_voted_" + str(race_num + 1) + " = 0 where game_id = %d and race_id = %d" % (game_id, race_id)
				pgcnx.query(qrystr) 
