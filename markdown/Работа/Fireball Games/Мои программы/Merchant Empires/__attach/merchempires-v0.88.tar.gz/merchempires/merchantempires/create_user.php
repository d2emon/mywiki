<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

include("./merchantempiresdefines.php");
?>

<html><head><title>Merchant Empires: New User</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
$error = 0;

## Get a database connection
$db = new ME_DB;

// Check if there was a submission
while (is_array($HTTP_POST_VARS) 
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "create": // Create a new user
			if (empty($username) || empty($password) || empty($verify) || empty($email)) {
				$error = "Please fill out all of the fields.";
				break;
			}
      			
			if (!strcmp($password,$verify) == 0) {
				$error = "Your password was not successfully verified.";
				break;
			}

			if ( stristr($username, ';') ) {
				$error = "Illegal character in name.";
				break;			
			}

			if ( stristr($password, ';') ) {
				$error = "Illegal character in password.";
				break;			
			}

			if ( stristr($email, ';') ) {
				$error = "Illegal character in email.";
				break;			
			}

			$db->query("select * from auth_user where username='$username'");
			if ( $db->nf() > 0 ) {
				$error = "User <B>$username</B> already exists!";
				break;
			}			

			$db->query("select * from auth_user where email='$email'");
			if ( $db->nf() > 0 ) {
				$error = "A user with that email address already exists!";
				break;
			}

			// Create a uid and insert the user...
			$u_id=md5(uniqid($hash_secret));
    	$validation_code = substr($u_id, 0, 6);

			$public_username = stripslashes($username);

			$public_validation_code = $validation_code . "-" . $public_username;
			$validation_code = $validation_code . "-" . $username;
			$query = "insert into auth_user values('$u_id','$username','$password','admin', 0, '$email', 'Newbie', '$validation_code', 0, 0, 0)";
			$db->query($query);
			
			if ( $db->affected_rows() == 0 ) {
			 	$error = "failed";
				break;
			}
			
			mail($email, "New Merchant Empires User", "Your validation code is: " . $public_validation_code . "\n\nThe Merchant Empires server is on the web at http://www.merchantempires.net");
			break;
	}
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	$db->add_parameter("message", $error);
	echo $db->get_transform("./xslt/message_box.xslt", "");		
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Success");

	$msg = "Your Merchant Empires user was successfully created.<br><br>An email containing a validation code has been sent to your address.";
	$msg = $msg . "In order to log into Merchant Empires, you must retrieve that code and enter it at the validation <a href=" .  URL . "verify.php>page</a>.";

	$db->add_parameter("message", $msg);
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td></tr></table>
</body></html>