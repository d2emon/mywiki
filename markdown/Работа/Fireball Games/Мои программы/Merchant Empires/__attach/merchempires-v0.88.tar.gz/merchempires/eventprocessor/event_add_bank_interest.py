
def add_bank_interest():
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT game_id, interestrate from games"
	q = pgcnx.query(qrystr)
	res = q.getresult()

	for value in range(len(res)):
		qrystr = "select player_id, game_id, bank_account from players where game_id = '%d'" % (res[value][q.fieldnum('game_id')])
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		for value_2 in range(len(res_2)):
			interestrate = res[value][q.fieldnum('interestrate')]
			bank_account = res_2[value_2][q_2.fieldnum('bank_account')]

			bank_account = bank_account + (bank_account * interestrate)
		  	#update the player record
			qrystr = "update players set bank_account = '%d' where player_id = '%d'" % (bank_account, res_2[value_2][q_2.fieldnum('player_id')])
			pgcnx.query(qrystr)

		qrystr = "select account_id, game_id, balance from accounts where game_id = '%d'" % (res[value][q.fieldnum('game_id')])
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		for value_2 in range(len(res_2)):
			interestrate = res[value][q.fieldnum('interestrate')]
			balance = res_2[value_2][q_2.fieldnum('balance')]

			balance = balance + (balance * interestrate)
		  	#update the player record
			qrystr = "update accounts set balance = '%d' where account_id = '%d'" % (balance, res_2[value_2][q_2.fieldnum('account_id')])
			pgcnx.query(qrystr) 
