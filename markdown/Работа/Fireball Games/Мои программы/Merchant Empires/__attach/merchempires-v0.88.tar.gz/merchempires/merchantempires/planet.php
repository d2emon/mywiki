<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Planet Status</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
	
$db_p = new ME_DB_xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {

$db_p->add_parameter("current_screen", "planet");	
echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());
?>

<table width=490 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table width=490 border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td bgColor=#000000 align=left valign=middle>
						<table width=470 cols=2 border=0>
            	<tr>
								<td class=clsNrmTxt valign=top>
									<font color=#3333FF face=arial,helvetica,swiss size=3><b>Planet Info</font></b><br>
									&nbsp;Owner: <?php

	$owner_id =  $db_p->f("owner_id");
	$db_a = new ME_DB;
	$db_a->query("select player_id, name, alliance_name from players where player_id = '$owner_id'");
	$db_a->next_record();
  echo $db_a->f("name");
	echo "<br>" . "&nbsp;Alliance: </font>" . $db_a->f("alliance_name");
?>
									<br><br><font color=#3333FF face=arial,helvetica,swiss size=3><b>Defenses</font></b><br></font>
									<table cellPadding=5 cellSpacing=1>
										<tr>
											<td class=clsNrmTxt>Type</td><td class=clsNrmTxt>Max</td><td class=clsNrmTxt>Current</td>
										</tr>
										<tr><?php

	echo "<td class=clsNrmTxt>Drones</td><td class=clsNrmTxt>" . $db_p->f("hangarcurrent") * 20 . "</td><td class=clsNrmTxt>" . $db_p->f("combatcurrent") . "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td class=clsNrmTxt>Shields</td><td class=clsNrmTxt>" . $db_p->f("generatorcurrent") * 100 . "</td><td class=clsNrmTxt>" . $db_p->f("shieldcurrent") . "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td class=clsNrmTxt>Turrets</td><td class=clsNrmTxt>" . $db_p->f("turretsmax") . "</td><td class=clsNrmTxt>" . $db_p->f("turretscurrent") . "</td>";
?>
										</tr>
									</table>
								</td>	
								<td class=clsNrmTxt valign=top>
									<font color=#3333FF face=arial,helvetica,swiss size=3><b>Merchants</font></b><br><?php

	$db_s = new ME_DB;

	$query = sprintf("SELECT ships.*, ship_weapons.* from ships, ship_weapons where ships.planet_id = '%s' and ship_weapons.player_id = ships.player_id", $planet_id);

	$db_s->query($query);

	while ($db_s->next_record())  {
		$ship_player_id = $db_s->f("player_id");

		$db_p = new ME_DB;
		$db_p->query("select player_id, public_player_id, name from players where player_id = '$ship_player_id'");
		$db_p->next_record();

		if ( $db_p->f("name") <> "" ) {
			echo "&nbsp;&nbsp;<a href=";
			echo $sess->purl(URL . "merchant_search_results.php?action=merchant_id&criteria=" . $db_p->f("public_player_id")) . ">";
			echo $db_p->f("name") . "</a><br>";	

			echo "&nbsp;&nbsp;&nbsp;" . $db_s->f("type");

			$combined_damage = get_combined_damage($db_s);

			if ( (int) (($combined_damage / 40) + ($db_s->f("combatcurrent") / 50)) < 1 ) {
				$offense = 1;
			} else {
				$offense = (int) (($combined_damage / 40) + ($db_s->f("combatcurrent") / 50));
			}

			if ( (int) (($db_s->f("shieldcurrent") + $db_s->f("armorcurrent") + ($db_s->f("combatcurrent") * 3)) / 100)  < 1 ) {
				$defense = 1;
			} else {
				$defense = (int) (($db_s->f("shieldcurrent") + $db_s->f("armorcurrent") + ($db_s->f("combatcurrent") * 3)) / 100);
			}
	
			echo  "&nbsp;(" . $offense . "/" . $defense . ")";
			echo "<br>";			
		}
	}

?>
								</td>							
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br>
<table width=490 border=0 cellPadding=1 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table width=490 border=0 cellPadding=6 cellSpacing=0>
				<tr>					
					<form name="takoff" action=<?php

	echo $sess->url(URL . "planet_takeoff.php");
?>
						method=post>
					<td align=center valign=middle bgColor=#000000>												
						<input border=0 type="image" src="./images/form/takeoff-off.png">						
					</td>
					</form>
					<form title="logoff" name="logoff" action=<?php

	echo $sess->url(URL . "logout.php");
?>
						method=post>
					<td align=center valign=middle bgColor=#000000>
						<input border=0 type="image" src="./images/form/logoff-off.png">																		
					</td>						
					</form>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

} else {
	$error = 4;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 4) {
		$db->add_parameter("message", "Your merchant is currently not landed on a planet.");		
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
