<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

#if player dead, send to post-death screen
if ( $player_dead == 't' ) {	
	$newurl = $sess->url(URL . "death.php");
	header("Location: $newurl");
	exit;
}
	
# send player to select a game if no player id
if ( !$player_id > 0 )  {
	$newurl = $sess->url(URL . "select_game.php");
	header("Location: $newurl");
	exit;
}
?>