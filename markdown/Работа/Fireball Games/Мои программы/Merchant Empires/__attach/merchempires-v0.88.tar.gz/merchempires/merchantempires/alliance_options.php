<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Alliance Options</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
} else {
	$alliance_id = -1;
}

$alliance_id = (int) $alliance_id;

if ( $alliance_id <> -1 )  {
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "alliance_options");	
$db->add_parameter("alliance_id", $alliance_id);
echo $db->get_transform("./xslt/menu_top_alliance.xslt", "");
?>

<table border=0 cellPadding=0 cellSpacing=0 width=450>
	<tr>
  	<td bgColor=#003399>
    	<table border=0 cellPadding=5 cellSpacing=1 width=450>
      	<tr>
        	<td bgColor=#000033><FONT color=#ffffff  face=arial,helvetica,swiss size=4><B>Member Options
          	</B></FONT><BR clear=all>
          </td>
	    	</tr>
        <tr>
        	<td bgColor=#000000>
						<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_update.php") ?>>
						<table>
		   				<tr>
		   					<td>Leave the alliance</td>
 		   					<td><input type="submit" name="leave_alliance" value="Leave"></td>
		   				</tr>
							<tr>
		   					<td>Download maps</td>
 		   					<td><input type="submit" name="merge_maps" value="Download"></td>
		   				</tr>
							<tr>
		   						<td></td>
 		   						<td><FONT color=#cccccc face=arial,helvetica,swiss size=2>
									Download the alliance map information.  A copy of your current alliance map information is downloaded into your ship's computer.  This
									map information is used if your merchant leaves the alliance.</font></td>
		   					</tr>
		   			</table>
		   			</form>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

	$db = new ME_DB;
	$query = sprintf("SELECT * from alliances where leader_id = '%s' and alliance_id = '%s'", $player_id, $alliance_id);
	$db->query($query);

	if ( $db->nf() > 0 ) {

?>
<table border=0 cellPadding=0 cellSpacing=0 width=450>
	<tr>
  	<td bgColor=#993300>
    	<table border=0 cellPadding=5 cellSpacing=1 width=450>
      	<tr>
        	<td bgColor=#330000><FONT color=#ffffff  face=arial,helvetica,swiss size=4><B>Leader Options
          	</B></FONT><BR clear=all>
          </td>
	    	</tr>
        <tr>
        	<td bgColor=#000000><FONT  color=#cccccc face=arial,helvetica,swiss size=2>
						<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_update.php") ?>>
						<table>
 		   				<tr>
  		   				<td>New password:</td>
  		   				<td><input type="password" name="password"></td>
		   				</tr>
		   				<tr>
  		   				<td>Verify:</td>
  		   				<td><input type="password" name="verify"></td>
		   				</tr>
		   				<tr>
		   					<td></td>
 		   					<td><input type="submit" name="change_password" value="Change Password"></td>
		   				</tr>
		   				<tr>
		   					</form>
		   					<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_update.php") ?>>
		   					<tr>
  		   					<td>Description:</td>
  		   					<td><textarea rows=4 cols=40 name="description"></textarea></td>
		   					</tr>
		   					<tr>
		   						<td></td>
 		   						<td><input type="submit" name="change_description" value="Change Description"></td>
		   					</tr>
								<tr>
  		   					<td>Log:</td>
  		   					<td><textarea rows=6 cols=40 name="log"></textarea></td>
		   					</tr>
		   					<tr>
		   						<td></td>
 		   						<td><input type="submit" name="change_log" value="Change Log"></td>
		   					</tr>
								<tr>
									<td></td>
									<td><FONT  color=#cccccc face=arial,helvetica,swiss size=2>The alliance log is displayed on the alliance status screen.  It is
									viewable only by alliance members.  It is a place for the leader to display current strategies, events, advice to alliance
									members.</font></td>
								</tr>
								</form>
								<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_update.php") ?>>
		   					<tr>
  		   					<td>Change leadership:</td>
  		   					<td><select name=leader_id><?php

		$db = new ME_DB;
		$query = sprintf("SELECT player_id, alliance_id, name from players where alliance_id = '%s'", $alliance_id);
		$db->query($query);

		while ( $db->next_record() ) {
			echo "<option value=";
			echo $db->f("player_id") . ">";
			echo $db->f("name") . "</option>";
		}	
?>								
										</select>
									</td>
		   					</tr>
		   					<tr>
		   						<td></td>
 		   						<td><input type="submit" name="change_leadership" value="Change Leadership"></td>
		   					</tr>
								</form>
								<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_update.php") ?>>
		   					<tr>
  		   					<td>Remove member:</td>
  		   					<td><select name=member_id><?php
										
		$db = new ME_DB;
		$query = sprintf("SELECT player_id, alliance_id, name from players where alliance_id = '%s'", $alliance_id);
		$db->query($query);

		while ( $db->next_record() ) {
			echo "<option value=";
			echo $db->f("player_id") . ">";
			echo $db->f("name") . "</option>";
		}	
?>								
										</select>
									</td>
		   					</tr>
		   					<tr>
		   						<td></td>
 		   						<td><input type="submit" name="remove_member" value="Remove member"></td>
		   					</tr>
								</form>
								<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_update.php") ?>>
		   					<tr>
  		   					<td>Register account:</td>
  		   					<td><input type="textbox" name="account_id" value=<?php
$db = new ME_DB;
$query = "select * from accounts where alliance_id = '$alliance_id'";
$db->query($query);
$db->next_record();

if ( $db->nf() > 0 )  {
	echo $db->f("public_account_id");
}

?>
								></td>
		   					</tr>
								<tr>
  		   					<td>Account password:</td>
  		   					<td><input type="password" name="password"></td>
		   					</tr>
		   					<tr>
		   						<td></td>
 		   						<td><input type="submit" name="register_account" value="Register"></td>
		   					</tr>
								<tr>
		   						<td></td>
 		   						<td><FONT  color=#cccccc face=arial,helvetica,swiss size=2>Anonymous bank accounts may be registered as your official alliance account.
									This allows alliance members access to this account without providing an account password.  To de-register an alliance bank account (returning
									the account to simple anonymous status), enter an account id of 0 and the account password.
									</font></td>
		   					</tr>
								</form>
		   			</table>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table><br><?php
	}
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	
	$db->add_parameter("message", $error);
		
	if ($error == 1) {
		$db->add_parameter("message", "You are the leader of an alliance with more than one member.  You must first transfer leadership before leaving the alliance.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Password length limit is 10 characters.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "Your new password was not correctly verified.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "The description contains illegal characters.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "The length of the alliance description is limited to 255 characters");
	} elseif ($error == 6) {
		$db->add_parameter("message", "The length of the alliance log is limited to 2000 characters");
	} elseif ($error == 7) {
		$db->add_parameter("message", "No such account on record.");
	} elseif ($error == 8) {
		$db->add_parameter("message", "Incorrect password.");
	} elseif ($error == 9) {
		$db->add_parameter("message", "An account is already registered to this alliance.  You must first clear that account before registering a new account.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");					
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
