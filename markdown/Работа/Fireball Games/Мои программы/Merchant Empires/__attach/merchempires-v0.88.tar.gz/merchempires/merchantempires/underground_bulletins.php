<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Bulletins</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$sector_id = $ship->f("sector_id");
$db = new ME_DB_Xml;
$db->query("select * from locations where sector_id = '$sector_id' and type='Underground'");
$db->next_record();

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

if ( $player->f("alignment") < 100 ) {	
	$db->add_parameter("current_screen", "underground_bulletins");
	echo $db->get_transform("./xslt/menu_top_underground.xslt", $db->get_xml());

	$db = new ME_DB;
	$db->query("select * from bulletins where sector_id = '$sector_id' order by bulletin_id desc");

	$color_3 = "#993300";
	$color_4 = "#330000";
	$color_1 = "#003399";
	$color_2 = "#000033";
	$fcolor_1 = "#3333FF";
	$fcolor_2 = "#993300";
	$toggle = 1;

	if ($db->nf()>0) {
		while($db->next_record()) {
?>

	<table border=0 cellPadding=0 cellSpacing=0>
		<tr>
			<td bgColor=<?php

if ($toggle == 1) {
echo $color_1;
} else {
echo $color_3;
}
?>

				>
				<table border=0 cellPadding=1 cellSpacing=1 width=500>
					<tr>
						<td bgColor=#000000>
							<br>
							<font  color=#cccccc face=arial,helvetica,swiss size=3><?php

echo nl2br(htmlentities($db->f("bulletin")));
?>
							</font>
						</td>
					</tr>
					<tr>
						<td align=right bgColor=<?php
if ($toggle == 1) {
echo $color_2;
} else {
echo $color_4;
}
?>						width=165>
							<font color=<?php

if ($toggle == 1) {
echo $fcolor_1;
} else {
echo $fcolor_2;
}

?>
							face=arial,helvetica,swiss size=3>&nbsp;Posted by:&nbsp;</font>
							<font color=#ccccc face=arial,helvetica,swiss size=3><?php

if ( $db->f("player_id") > 0 ) {
	echo "<a href=" . $sess->url(URL . "send_messages_merchant.php") . "?merchant=" . $db->f("public_player_id") . ">";
	echo stripslashes($db->f("player_name")) . "</a>";
	echo  " (" . $db->f("public_player_id") . ")";
} else {
	echo stripslashes($db->f("player_name")) . "</a>";
}
?>
							</font>
						</td>									
					</tr>					
				</table>
			</td>
		</tr>
	</table><br><?php
	
		if ( $toggle == 1 ) {
			$toggle = 2;
  	} else {
  		$toggle = 1;
		}
	}	
}
?>

<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td bgColor=#000000><form action=<?php

echo $sess->url(URL . "underground_update.php");
?>
					method=post>
						<font color=cccccc face=arial,helvetica,swiss size=3><?php

echo "<center><textarea size=600 NAME=bulletin rows=3 cols=48>";
echo "</textarea></center>";
?>
							<center><input type="submit" NAME="post_bulletin" VALUE="Post Bulletin"></center>
						</form>
					</td>							
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $error ) {
		$db = new ME_DB_Xml;
		$db->add_parameter("title", "Error");			
		
		if ($error == 1) {
			$db->add_parameter("message", "Command not processed due to insufficient alignment.");
		}
			
		echo $db->get_transform("./xslt/message_box.xslt", "");
	}
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Warning");
	$db->add_parameter("message", "Your alignment prevents you from accessing this location.");
	echo $db->get_transform("./xslt/message_box.xslt", "");	
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>