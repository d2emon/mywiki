<?php

if ( strpos($HTTP_USER_AGENT, "zilla/4") and !(strpos($HTTP_USER_AGENT, "MSIE")) ) {
	echo $ship->get_transform("./xslt/ship_ns4.xslt", $ship->get_xml());
} else {
	echo $ship->get_transform("./xslt/ship.xslt", $ship->get_xml());
}

?>