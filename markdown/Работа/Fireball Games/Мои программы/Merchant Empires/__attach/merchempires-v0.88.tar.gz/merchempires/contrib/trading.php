<?php

function compute_sell_offer($good_name, $amount, $relations, $sector_id, $old_offer, $db) {
	# Trying to reduce the number of db calls, so db is being passed from parent
	# $cdb = new ME_DB;
	$query = "select * from goods where sector_id = '$sector_id' and type = '$good_name' and buyorsell = 'sell'";
	$db->query($query);
	$db->next_record();

	if ($old_offer>0) {
		$temp=$old_offer/200;
		settype($temp,"integer");

		return $old_offer+rand(1,$temp);
	}

	$demand=$db->f("supplydemand");
	$demand=$demand/1000;
	if ($demand>5) {
		$demand=5;
	}
	$demand=5-$demand;
	$demand=$demand*10;

	$value=$amount*$db->f("marketvalue")*(20+$demand)/100;

	$temp=$value/100;
	settype($temp,"integer");

	if ($temp > 1) {
	    $value=$value+rand(1,$temp);
	    }

	settype($value,"integer");

	return $value;
}

function compute_buy_offer($good_name, $amount, $relations, $sector_id, $old_offer, $cdb) {
	# db is passed from parent now to reduce postgresql connections
	# $cdb = new ME_DB;
	$query = "select * from goods where sector_id = '$sector_id' and type = '$good_name' and buyorsell = 'buy'";
	$cdb->query($query);
	$cdb->next_record();

	if ($old_offer>0) {
		$temp=$old_offer/200;
		settype($temp,"integer");

		return $old_offer-rand(1,$temp);
	}

	$demand=$cdb->f("supplydemand");
	$demand=$demand/1000;
	if ($demand>5) {
		$demand=5;
	}
	$demand=5-$demand;
	$demand=$demand*10;

	$value=$amount*$cdb->f("marketvalue")*(125-$demand)/100;

	# Increased profit by decreasing denominator from 100 to 66
	$value=$value+(70*$value*($cdb->f("distance_index")-1)/66);

	$temp=$value/100;

	settype($temp,"integer");

	if ($temp > 1 ) {
	    $value=$value+rand(1,$temp);
	    }

	settype($value,"integer");

	return $value;
}

function effect_indexes($amount, $good_name, $sector_id, $cdb) {
	# $cdb = new ME_DB;
	# database is now passed from parent to reduce postgresql connections
	$query = "select * from goods where sector_id = '$sector_id' and type = '$good_name'";
	$cdb->query($query);
	$cdb->next_record();

	$supdem=$cdb->f("supplydemand");
	$supdem-=$amount;

	if ($supdem<0) {
		$supdem=0;
	}

	$query = "update goods set supplydemand = '$supdem' where sector_id = '$sector_id' and type = '$good_name'";
	$cdb->query($query);
}

function verify_buy_offer($counteroffer, $old_offer, $relations, $good_no) {
	$low_value=$old_offer*91/100;
	settype($low_value,"integer");

	if ($counteroffer<$low_value) {
		return 0;
	}
	return 1;
}

function verify_sell_offer($counteroffer, $old_offer, $relations, $good_no) {
	$high_value=($old_offer*109/100)+1;
	settype($high_value,"integer");

	if ($counteroffer>$high_value) {
		return 0;
	}
	return 1;
}

function set_success($credits, $amount, $good_name, $player_id, $db) {
	# $db = new ME_DB;
	# database is now passed from parent to reduce postgresql connections
	$db->query("update players set success_offer = '$credits', success_amount = '$amount', success_type='$good_name' where player_id = '$player_id'");
	return 1;
}

function set_reject($credits, $amount, $good_name, $player_id, $cdb) {
	# $cdb = new ME_DB;
	# database now passed from parent to reduce connections
	$cdb->query("update players set reject_counter = '$credits', reject_amount = '$amount', reject_type = '$good_name' where player_id = '$player_id'");
	
	return 1;
}

function experience_buy($amount, $offer, $counter, $relations, $experience, $good_no, $cdb) {
	$experience=0;

	if ($counter<$offer) {
		$percent=$counter*100/$offer;
		$percent=100-$percent;
		$percent/=3;
		settype($percent,"integer");
		$experience=($amount/20);
		settype($experience,"integer");
		$experience=$experience*$percent;
	}

	if ($experience>0) {
		# db is passed from parent to reduce postgres connections
		# $cdb = new ME_DB;
		$cdb->query("update players set success_experience = '$experience' where player_id = '$player_id'");
	}
	return $experience;
}

function experience_sell($amount, $offer, $counter, $relations, $experience, $good_no, $cdb) {
	$experience=0;

	if ($counter>$offer) {
		$percent=$counter*100/$offer;
		$percent=$percent-100;
		$percent=$percent+1;
		$percent/=3;
		settype($percent,"integer");
		$experience=($amount/20);
		settype($experience,"integer");
		$experience=$experience*$percent;
	}

	if ($experience>0) {
		# db is passed from parent to reduce postgresql connections
		# $cdb = new ME_DB;
		$cdb->query("update players set success_experience = '$experience' where player_id = '$player_id'");
	}
	return $experience;
}

function check_level_gain($experience, $rank, $db) {
	$result= array();
	
	$max_level = 26;
	$loop_done = 0;
	$next_level = 0;
	$loop_count = 0;
	$orig_rank = $rank;

	# $db = new ME_DB;
	# db is passed from parent to reduce postgresql connections
	$db->query("select * from levels where rank = '$rank'");
	$db->next_record();	
	$level = $db->f("level");
	$orig_level = $level;

	if ($level < $max_level) {
	    $loop_done = 0;
	} else {
	    $loop_done = 1;
	    $result['rank'] = $rank;
	    $result['level'] = $level;
	}    

	while ($loop_done == 0) {
	    $next_level = $level + 1;
	    $db->query("select * from levels where level = '$next_level'");
	    $db->next_record();
	    $xp_high_lim = $db->f("experience");

	    $db->query("select * from levels where level = '$level'");
	    $db->next_record();
	    $xp_low_lim = $db->f("experience");

	    if ( $experience < $xp_high_lim && $experience >= $xp_low_lim ) {
		$result['rank'] = $db->f("rank");
		$result['level'] = $db->f("level");
		$loop_done = 1;
	    } else {
		if ($experience >= $xp_high_lim) {
		    $level = $level + 1;
		} else {
		    $level = $level - 1;
		}
	    }
	
	    $loop_count = $loop_count + 1;
	    if ($loop_count > 10) {
	
		if (0 == 1) {
    		    $fp = fopen("/home/apache/html/me-debug", "a+");
		    fwrite($fp, "check_level_gain fn of tradin.php exiting from max iters\r\n");
		    $problem = sprintf("Current Level = %s, experience = %s", $level, $experience);
    		    fwrite($fp, $problem);
		    $problem = sprintf("xp_high_lim = %s, xp_low_lim = %s", $xp_high_lim, $xp_low_lim);
    		    fwrite($fp, $problem);
		    fwrite($fp, "\r\n");
		    fclose($fp);
		}
		$result['rank'] = $orig_rank;
		$result['level'] = $orig_level;
		$loop_done = 1;
	    }

	}
	    
	return $result;
}

function set_relations($player, $government, $new_personal_relations) {
	# ME's relation code is braindead. Forget it for now.
}

function increase_port_goods($amount, $sector_id, $cdb) {
	# $cdb = new ME_DB;
	# db is passed from parent to reduce postgresql calls.
	$query = "select * from ports where sector_id = '$sector_id'";
	$cdb->query($query);
	$cdb->next_record();

	$traded=$cdb->f("goods_traded");
	$traded+=$amount;

	$query = "update ports set goods_traded = '$traded' where sector_id = '$sector_id'";
	$cdb->query($query);
}

?>
