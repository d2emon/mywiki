
def inactive_merchants():
	import time
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb, postmerchhost, user=postmerchuser, passwd=postmerchpass)
	qrystr = "SELECT ships.ship_id, ships.player_id, ships.starbase_id, ships.sector_id, ships.planet_id, players.race, players.player_id, players.game_id	\
		from ships, players where ships.last_move_date < '%d' and ships.last_move_date > 0 and ships.starbase_id = 0 and ships.planet_id = 0 and	\
		players.player_id = ships.player_id" % (time.time() - 604800)
	q = pgcnx.query(qrystr)
	res = q.getresult()

	for value in range(len(res)):
		q_2 = pgcnx.get('games', res[value][q.fieldnum('game_id')], 'game_id')
		race = res[value][q.fieldnum('race')]
		player_id = res[value][q.fieldnum('player_id')]

		if race == q_2['namerace_1']:
			sector_id = q_2['starbasesectrace_1']
		elif race == q_2['namerace_2']:
			sector_id = q_2['starbasesectrace_2']
		elif race == q_2['namerace_3']:
			sector_id = q_2['starbasesectrace_3']
		elif race == q_2['namerace_4']:
			sector_id = q_2['starbasesectrace_4']
		elif race == q_2['namerace_5']:
			sector_id = q_2['starbasesectrace_5']
		elif race == q_2['namerace_6']:
			sector_id = q_2['starbasesectrace_6']
		elif race == q_2['namerace_7']:
			sector_id = q_2['starbasesectrace_7']

		q_2 = pgcnx.get('starbases', sector_id, 'sector_id')
		starbase_id = q_2['starbase_id']

		if starbase_id > 0:
			qrystr = "update ships set starbase_id = '%d', sector_id = 0, planet_id = 0 where player_id = '%d'" % (starbase_id, player_id)
			pgcnx.query(qrystr)
 
