<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/
	
page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/sector.php");
include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Orbit Planet</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=125 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
		
$db_p = new ME_DB;
$db_p->query("select * from planets where sector_id = '$sector_id'");
$db_p->next_record();

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table width=490 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table width=490 border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=490 bgColor=#000000 align=left valign=middle>
						<center><font color=#3333FF face=arial,helvetica,swiss size=5>Planetary Orbit : <?php

echo htmlentities($db_p->f("name"));
?>			
						</center>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br>
<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
  	<td bgColor=#003399>
    	<table border=0 cellPadding=5 cellSpacing=1 width=490>
        <tr>
        	<td bgColor=#000000>
						<table border=0>
							<tr>
								<td width=200>
									<table cellspacing=2 cellpadding=2><?php
										
echo "<tr><td class=clsNrmTxt>Owner:</td><td>";

$owner_id =  $db_p->f("owner_id");

if ( $owner_id <> 0 )  {
	$db_a = new ME_DB;
	$db_a->query("select player_id, name, alliance_name, race from players where player_id = '$owner_id'");
	$db_a->next_record();
	echo $db_a->f("name") . "</td></tr>";
	echo "<tr><td class=clsNrmTxt>Alliance:</td><td>";
	echo $db_a->f("alliance_name") . "</td></tr>";
	echo "<tr><td  class=clsNrmTxt>Race:</td><td>";
	echo $db_a->f("race") . "</td></tr>";
	echo "<tr><td  class=clsNrmTxt>Build level:</td><td>";
	$buildlevel = ($db_p->f("generatorcurrent") + $db_p->f("turretscurrent") + $db_p->f("hangarcurrent")) / 3;
	echo (int) $buildlevel . "</td></tr>";	
	
	if ( $db_p->f("alliance_id") <> $player->f("alliance_id") or $db_p->f("alliance_id") == 0 ) {
		if ( $owner_id <> $player->f("player_id") ) {
			echo "<tr><td colspan=2><br><br><center><form name=form_planet_attack action=";
			echo $sess->purl(URL . "attack.php");
			echo " method=post>";

			echo "<a href='javascript:document.form_planet_attack.submit()'><img border=0 width=100 height=20 src='./images/form/attack-off.png'></a><br>";
			echo "<input type=hidden name=attack value=Attack>";
			echo "<input type=hidden name=id value=" . $db_p->f("planet_id") . ">";
			echo "<input type=hidden name=type value=p>";
			echo "<input type=hidden name=refer value=current>";
			echo "</form></center></td></tr>";
		} else {
			echo "<tr><td colspan=2><br><br><center><form name=form_planet_land action=";
			echo $sess->purl(URL . "planet_land.php");
			echo " method=post>";
			echo "<a href='javascript:document.form_planet_land.submit()'><img border=0 width=100 height=20 src='./images/form/land-off.png'></a><br>";
			echo "<input type=hidden name=land value=Land>";
			echo "</form>";

			if ( $db_p->f("star_gate") == 't' ) {
				echo "<br><form action=";
				echo $sess->purl(URL . "planet_stargate.php");
				echo " method=post>";
				echo "<input type=image border=0 src='./images/form/stargate-off.png' name=stargate><br>";
				echo "<input type=hidden name=land value=Land>";
				echo "</form></center>";
			}

			echo "</td></tr>";
		}
	} else {
		echo "<tr><td colspan=2><br><br><center><form name=form_planet_land action=";
		echo $sess->purl(URL . "planet_land.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_planet_land.submit()'><img border=0 width=100 height=20 src='./images/form/land-off.png'></a><br>";
		echo "<input type=hidden name=land value=Land>";
		echo "</form>";

		if ( $db_p->f("star_gate") == 't' ) {
			echo "<br><form action=";
			echo $sess->purl(URL . "planet_stargate.php");
			echo " method=post>";
			echo "<input type=image border=0 src='./images/form/stargate-off.png' name=stargate><br>";
			echo "<input type=hidden name=land value=Land>";
			echo "</form></center>";
		}

		echo "</td></tr>";
	}
} else {
	echo "&nbsp;None";
  echo "<tr><td colspan=2><br><br><center><form name=form_planet_land action=";
	echo $sess->purl(URL . "planet_land.php");
	echo " method=post>";
	echo "<a href='javascript:document.form_planet_land.submit()'><img border=0 width=100 height=20 src='./images/form/land-off.png'></a><br>";
	echo "<input type=hidden name=land value=Land>";
	echo "</form></center></td></tr>";
}
?>
									</table>
              	</td>
								<td valign=top width=100><?php

if ( $db_p->f("image_id") == 1 )  {
	echo "<img src='./images/planets/planet1-big.png'>";
} elseif ( $db_p->f("image_id") == 2 ) {
	echo "<img src='./images/planets/planet2-big.png'>";	
} elseif ( $db_p->f("image_id") == 3 ) {
	echo "<img src='./images/planets/planet3-big.png'>";	
} elseif ( $db_p->f("image_id") == 4 ) {
	echo "<img src='./images/planets/planet4-big.png'>";	
} elseif ( $db_p->f("image_id") == 5 ) {
	echo "<img src='./images/planets/planet5-big.png'>";	
}
?>
								</td>
							</tr>
						</table>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Your merchant cannot attack planets while under newbie protection.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "The planet that this Star Gate is linked to must also build a Star Gate.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td vAlign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>