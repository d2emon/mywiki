<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Technology extends ME_DB {	
	var $id = 0;	
	var $dirty_fields = array();
	
  function get_technology($id) {
		$this->connect();
		$query = sprintf("select * from ship_technology where ship_id = '%s'", $id);

		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
    }
	
		$this->next_record();	
		$this->id = $this->f("ship_technology_id");  	
		$this->set_ship_id($id);
				
  	return $this->Query_ID;
  }

	function get_new_technology($ship_id) {
    $this->connect();
  	$query = "insert into ship_technology (ship_id) values ($ship_id)";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   	
   	$db = new ME_DB;
		$db->query("select * from ship_technology_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;		
	
	  $query = sprintf("select * from ship_technology where ship_technology_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();
    return $this->Query_ID;
  }

  function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update ship_technology set ";		
			$i = 1;

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}
			
				$i++;
			}
					
			$str = $str . " where ship_technology_id = '$this->id'";
			$db->query($str);
		
			$this->dirty_fields = array();
		}	
	}

	function set_ship_id($n) {
		$this->dirty_fields["ship_id"] = $n;	 			
  }

	function set_player_id($n) {
		$this->dirty_fields["player_id"] = $n;	 			
  }	

	function set_tracking($n) {
		$this->dirty_fields["tracking"] = $n;	 			
  }	

	function set_tracking_locked($n) {
		$this->dirty_fields["tracking_locked"] = $n;	 			
  }	

	function set_tracking_player_id($n) {
		$this->dirty_fields["tracking_player_id"] = $n;	 			
  }

	function set_deep_scanner($n) {
		$this->dirty_fields["deep_scanner"] = $n;	 			
  }

	function set_targeting_computer($n) {
		$this->dirty_fields["targeting_computer"] = $n;	 			
  }

	function set_active_screens($n) {
		$this->dirty_fields["active_screens"] = $n;

		if ( $this->dirty_fields["active_screens"] == 0 ) {
			$this->dirty_fields["screensmax"] = 0;
		} elseif ( $this->dirty_fields["active_screens"] == 1 ) {
			$this->dirty_fields["screensmax"] = 50;
		} elseif ( $this->dirty_fields["active_screens"] == 2 ) {
			$this->dirty_fields["screensmax"] = 75;
		} elseif ( $this->dirty_fields["active_screens"] == 3 ) {
			$this->dirty_fields["screensmax"] = 100;
		} elseif ( $this->dirty_fields["active_screens"] == 4 ) {
			$this->dirty_fields["screensmax"] = 125;
		}
  }

	function set_screenscurrent($n) {
		$this->dirty_fields["screenscurrent"] = $n;
  }

	function set_screensmax($n) {
		$this->dirty_fields["screensmax"] = $n;
  }					

	function set_plasma_booster($n) {
		$this->dirty_fields["plasma_booster"] = $n;
	}				

	function set_trifocus_plasma($n) {
		$this->dirty_fields["trifocus_plasma"] = $n;
	}				

	function set_tractor_beam($n) {
		$this->dirty_fields["tractor_beam"] = $n;
	}		

	function set_tractor_beam_locked($n) {
		$this->dirty_fields["tractor_beam_locked"] = $n;
  }	

	function set_tractor_beam_player_id($n) {
		$this->dirty_fields["tractor_beam_player_id"] = $n;	 			
  }

	function set_tractor_beam_time($n) {
		$this->dirty_fields["tractor_beam_time"] = $n;
  }

	function set_trifocus_fire_time($n) {
		$this->dirty_fields["trifocus_fire_time"] = $n;
	}

	function set_battle_systems_computer($n) {
		$this->dirty_fields["battle_systems_computer"] = $n;
	}		

	function set_scanner($n) {
		$this->dirty_fields["scanner"] = $n;
	}

	function set_illusion($n) {
		$this->dirty_fields["illusion"] = $n;
	}

	function set_jump($n) {
		$this->dirty_fields["jump"] = $n;
	}

	function set_galaxy_jump($n) {
		$this->dirty_fields["galaxy_jump"] = $n;;
	}

	function set_cloak($n) {
		$this->dirty_fields["cloak"] = $n;
	}

	function set_cloak_active($n) {
		$this->dirty_fields["cloak_active"] = $n;
	}

	function set_illusion_active($n) {
		$this->dirty_fields["illusion_active"] = $n;
	}

}
?>
