<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/ship.php");
include("./lib/player.php");
include("./lib/player_map.php");
include("./lib/sector.php");
include("./lib/player_redirect.php");

$returnto == "planet_orbit";

if ( $player_id > 0 )  {
	# update player turns
	$player = new ME_Player;
	$player->get_player($player_id);
	$turns = $player->f("turns");
	$newturns = $player->f("newturnsleft");
	
	# only move if the player has a turn
	if ( ($player->f("turns") - 10) >= 0 )  {
		if ( $newturns > 0 ) {
			$player->set_new_turns_left($newturns - 10);
		}
	
		#determine if its possible to move to the target sector
		$s1 = new ME_Sector;
		$s1->get_sector($player_id);
	
		$db = new ME_DB;
		$db_2 = new ME_DB;

		$query = sprintf("select * from planets where sector_id = '%s'", $s1->f("sector_id"));
		$db->query($query);
		$db->next_record();

		if ( $db->nf() > 0 ) {
			$query = sprintf("select * from planets where sector_id = '%s'", $db->f("star_gate_sector_id"));
			$db_2->query($query);
			$db_2->next_record();

			$ship = new ME_Ship;
			$ship->get_ship($player_id);
		
			if ( $db_2->f("star_gate") == 't' and $db_2->f("star_gate_sector_id") == $ship->f("sector_id") ) {							
		  	$ship->set_sector_id($db_2->f("sector_id"));
				$ship->set_last_move_sector_id($ship->f("sector_id"));
				$ship->set_public_sector_id($db_2->f("public_sector_id"));
	  		$ship->save();

				$query = sprintf("select * from sectors where sector_id = '%s'", $db->f("star_gate_sector_id"));
				$db_2->query($query);
				$db_2->next_record();

				save_player_map($db_2->f("map_id"), $player, $db_2->f("sector_id"));

				$db_m = new ME_DB;
				$query = sprintf("select * from forces where sector_id = '%s' and player_id <> '%s'", $db_2->f("sector_id"), $player->f("player_id"));
				$db->query($query);
		
				if ( $db->nf() > 0 ) {
					$date = date("H:i m/d/y");
					$date_integer = time();

					while ( $db->next_record() ) {
						if ( $db->f("alliance_id") <> $player->f("alliance_id") or $db->f("alliance_id") == 0 ) {
							if ( $ship->f("cloak_active") == 't' and $ship->f("cloak") ) {
								# nothing
							} elseif ( $db->f("focused_alliance_id") <> 0 and $db->f("focused_alliance_id") <> $player->f("alliance_id") ) {
								# nothing
							} elseif ( $db->f("focused_player_id") <> 0 and $db->f("focused_player_id") <> $player->f("player_id") ) {
								# nothing
							} elseif ( $db->f("scout") > 0 ) {						
								$scout_player_id = $db->f("player_id");
      	
								$query = "select player_id, message_id from messages where player_id = '$scout_player_id' and scout = 't' order by message_id";
								$db_m->query($query);
								$db_m->next_record();
								if ( $db_m->nf() > 50 ) {
  	  	  	    					$message_id = $db_m->f("message_id");

									$query = "delete from messages where message_id = '$message_id'";
									$db_m->query($query);
								}

								$message = "Movement detected in sector " . $db_2->f("public_sector_id");
								$message = $message . "<br>Merchant: " . addslashes($player->f("name"));
								$message = $message . "<br>Alliance: " . addslashes($player->f("alliance_name"));
								$message = $message . "<br>Ship type: " . $ship->f("type");
								$message = $message . "<br>Entered via: Star Gate";

								$query = "insert into messages (player_id, message, date, toplayer, scout, date_integer)
									values ('$scout_player_id', '$message', '$date', 'Drone Comm Link', 't', '$date_integer')";
								$db_m->query($query);											
							}
						}					
					}
				}
				
				$player->set_turns($turns - 10);
				$player->save();
			} else {
				$error = 2;				
			}			
    } else {
			// nothing
		}
	}

	if ( $error ) {
		$newurl = $sess->url(URL . "planet_orbit.php?error=$error");
		header("Location: $newurl");
	} else {
		if ($returnto == "currentsector")  {
			$newurl = $sess->url(URL . "current_sector.php");
			header("Location: $newurl");	
		} elseif ($returnto == "attack") {
			$newurl = $sess->url(URL . "attack.php" . "?refer=" . $refer . "&id=" . $id . "&type=" . $type );
			header("Location: $newurl");	
		} elseif ($returnto == "planet_orbit") {
			$newurl = $sess->url(URL . "planet_orbit.php");
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "local_map.php");
  		header("Location: $newurl");
		}
	}
}

page_close();
?>