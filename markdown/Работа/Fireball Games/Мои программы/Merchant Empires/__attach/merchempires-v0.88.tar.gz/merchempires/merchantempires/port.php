<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Trade at Port</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php


$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

$db_p = new ME_DB;
$db_p->query("select * from ports where sector_id = '$sector_id'");
$db_p->next_record();
$port_id = $db_p->f("port_id");
$db_g = new ME_DB;
$db_g->query("select * from goods where port_id = '$port_id' order by marketvalue");
	
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=490>
				<tr>
					<td width=490 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5>Trade at Port : <?php

echo $db_p->f("public_sector_id");
?>				
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

$db = new ME_DB;
$db->query("select player_id, success_offer, success_amount, success_type, success_experience from
	players where player_id = '$player_id'");
$db->next_record();

if ( $db->f("success_offer") <> 0 ) {
?>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=490>
				<tr>
					<td width=490 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#cccccc face=arial,helvetica,swiss size=3> <?php

echo "Your offer of </font>" . $db->f("success_offer") . "<font color=#cccccc face=arial,helvetica,swiss size=3> credits for </font>" . $db->f("success_amount") . "<font color=#cccccc face=arial,helvetica,swiss size=3> unit(s)";
echo " of " . $db->f("success_type") . " was accepted.";

if ( $db->f("success_experience") > 0 ) {
	echo "<br>Your trading skills have earned you </font>" . $db->f("success_experience") . "<font color=#cccccc face=arial,helvetica,swiss size=3> experience points.</font>";
}

?>				
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

$db = new ME_DB;
$db->query("update players set success_offer = '0',	success_amount = '0',
		success_type = '', success_experience = '0' where player_id = '$player_id'");
}
?>

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=490>
				<tr>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Good</center>
	        </font>
					</td>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Supply/Demand</center>
	        </font>
					</td>
					<td width=50 bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Fair Market Value per Unit</center>
	        </font>
					</td>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Amount on Ship</center>
	        </font>
					</td>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Amount to Trade</center>
	        </font>
					</td>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Action</center>
	        </font>
					</td>
				</tr><?php

while ( $db_g->next_record() )  {	
	if ( ($cargo->Open_holds > 0 and $db_g->f("buyorsell") == "sell") || ($cargo->Current_cargo[$db_g->f("type")]['amount'] > 0 and $db_g->f("buyorsell") == "buy") ) {
		if ( $player->f("alignment") > -100 and ( $db_g->f("type") == "Weapons" or $db_g->f("type") == "Slaves" or $db_g->f("type") == "Narcotics" ) ) {
			# nothing
		} else {
			echo "<tr>";
			echo "<form name=form_port_" . $db_g->f("good_id") . " action=";
			echo $sess->url(URL . "port_offer.php");
			echo " method=post  onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";
			echo "<td class=clsNrmTxt align=center>";
			echo $db_g->f("type");
			echo "</td>";
	
			echo "<td class=clsNrmTxt align=center>";
			echo $db_g->f("supplydemand");
			echo "</td>";

			echo "<td class=clsNrmTxt align=center>";
	  	echo $db_g->f("marketvalue");
			echo "</td>";

			echo "<td class=clsNrmTxt align=center>";

			if ( $cargo->Current_cargo[$db_g->f("type")]['amount'] > 0 ) {
				echo $cargo->Current_cargo[$db_g->f("type")]['amount'];
			} else {
				echo "0";
			}

			echo "</td>";

			echo "<td class=clsNrmTxt align=center>";
			echo "<input type=textbox size=5 name=amount_good value=";
				
			if ($cargo->Current_cargo[$db_g->f("type")]['amount'] > 0 and $db_g->f("buyorsell") == "buy") {
				echo $cargo->Current_cargo[$db_g->f("type")]['amount'] . ">";
			} elseif ($db_g->f("buyorsell") == "buy") {
				echo "0>";
			}

			if ($db_g->f("buyorsell") == "sell" and $cargo->Open_holds > 0) {
				echo $cargo->Open_holds . ">";
			} elseif ($db_g->f("buyorsell") == "sell") {
				echo "0>";
			}

			echo "</td>";

			echo "<td class=clsNrmTxt align=center><small>";
			
			if ($cargo->Open_holds > 0 and $db_g->f("buyorsell") == "sell") {
				echo "<a href='javascript:document.form_port_" . $db_g->f("good_id") . ".submit()'><img border=0 width=39 height=20 src='./images/form/buy-off.png'></a><br>";
				echo "<input type=hidden name=buy value='Buy'>";
			} elseif ($cargo->Current_cargo[$db_g->f("type")]['amount'] > 0 and $db_g->f("buyorsell") == "buy") {
				echo "<a href='javascript:document.form_port_" . $db_g->f("good_id") . ".submit()'><img border=0 width=42 height=20 src='./images/form/sell-off.png'></a><br>";
				echo "<input type=hidden name=sell value='Sell'>";
			}

			echo "<input type=hidden name=good_type value='" . $db_g->f("type") . "'>";
			echo "</small></td></form>";
			echo "</tr>";
		}
	}					
}

?>
      	<tr>
					<td colspan=6 bgColor=#000000>
          	<br><center><a href=<?php

echo $sess->url(URL . "local_map.php");
echo ">Leave Port</a></center><br>";
?>

					</td>
				</tr>
			</table>
		<td>
  </tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");		
		
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due incorrect amount offered.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient goods on planet.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "Command not processed due to insufficient drones on planet.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "Command not processed due to insufficient shields on planet.");
	} elseif ($error == 11) {
		$db->add_parameter("message", "A cheat has been detected or an error has occured.");
	} elseif ($error == 12) {
		$db->add_parameter("message", "Command not processed due to insufficient credits.");
	} elseif ($error == 13) {
		$db->add_parameter("message", "Command not processed due to good type not found at this port.");
	} elseif ($error == 14) {
		$db->add_parameter("message", "Command not processed due to insufficient cargo capacity.");
	} elseif ($error == 15) {
		$db->add_parameter("message", "Command not processed due to insufficient cargo capacity.");
	} elseif ($error == 16) {
		$db->add_parameter("message", "You submitted a negative value.");
	} elseif ($error == 17) {
		$db->add_parameter("message", "Error processing transaction.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>