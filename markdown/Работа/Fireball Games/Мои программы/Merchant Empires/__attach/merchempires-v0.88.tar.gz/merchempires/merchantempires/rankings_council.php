<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Rankings</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "rankings");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if ( !(isset($id)) ) {
	$id = $player->f("race_number");
}

$id = (int) $id;

$db = new ME_DB;
$query = sprintf("select * from games where game_id = '%s'", $game_id);
$db->query($query);
$db->next_record();

switch ( $id ) {
	case "1":
		$race = $db->f("namerace_1");
		break;
	case "2":
		$race = $db->f("namerace_2");
		break;
	case "3":
		$race = $db->f("namerace_3");
		break;
	case "4":
		$race = $db->f("namerace_4");
		break;
	case "5":
		$race = $db->f("namerace_5");
		break;
	case "6":
		$race = $db->f("namerace_6");
		break;
	case "7":
		$race = $db->f("namerace_7");
		break;
}

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$player->add_parameter("current_screen", "rankings_council");	
echo $player->get_transform("./xslt/menu_top_rankings.xslt", $player->get_xml());
?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td width=170 bgColor=#000033><font color=#ffffff  face=arial,helvetica,swiss size=3><center>Name</center></td>
					<td bgColor=#000033><font color=#ffffff  face=arial,helvetica,swiss size=3><center>Rank</center></td>					
					<td bgColor=#000033><center><font color=#ffffff  face=arial,helvetica,swiss size=3>Alliance</center></td>
					<td bgColor=#000033><center><font color=#ffffff  face=arial,helvetica,swiss size=3>Experience</center></td>
				</tr><?php

$query = sprintf("SELECT player_id, name, experience, game_id, race, rank, alliance_id, alliance_name from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
$db->query($query);
$x = 1;

while ( $db->next_record() ) {
	echo "<tr>";
	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3>";
	if ( $x == 1 ) {
		echo "Racial Overlord<br>";
	} else {
		echo "Council Member<br>";
	}

	echo $db->f("name") . "</td>";	
	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3>" . $db->f("rank") . "</td>";

	if ( $db->f("alliance_id") <> 0 ) {
  	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3><a href=";
		echo $sess->url(URL . "alliance.php") . "?alliance_id=" . $db->f("alliance_id");
		echo ">" . $db->f("alliance_name") . "</a></td>";	
	} else {
		echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3>" . $db->f("alliance_name") . "</td>";	 		
	}

	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3>" .  $db->f("experience") . "</td>";
	echo "</tr>";
	$x = $x + 1;
}
?>
			</table>
		<td>
  </tr>
</table>

<br>
<table width=490 border=0 cellPadding=1 cellSpacing=5>
	<tr>
		<td bgColor=#003399>
			<table width=490 border=0 cellPadding=3 cellSpacing=0>
				<tr>
					<td align=center bgColor=#000000>
						<table cellPadding=0 cellSpacing=0><tr><td>
						<form action=<?php

echo $sess->url(URL . "rankings_council.php");
?>
					method=post>						
        		<select name=id><?php

$query = sprintf("select * from games where game_id = '%s'", $game_id);
$db->query($query);
$db->next_record();
echo "<option ";
if ( $id == 1 ) { echo "selected"; }
echo " value=1>" . $db->f("namerace_1") . "</option>";

echo "<option ";
if ( $id == 2 ) { echo "selected"; }
echo " value=2>" . $db->f("namerace_2") . "</option>";

echo "<option ";
if ( $id == 3 ) { echo "selected"; }
echo " value=3>" . $db->f("namerace_3") . "</option>";

echo "<option ";
if ( $id == 4 ) { echo "selected"; }
echo " value=4>" . $db->f("namerace_4") . "</option>";

echo "<option ";
if ( $id == 5 ) { echo "selected"; }
echo " value=5>" . $db->f("namerace_5") . "</option>";

echo "<option ";
if ( $id == 6 ) { echo "selected"; }
echo " value=6>" . $db->f("namerace_6") . "</option>";

echo "<option ";
if ( $id == 7 ) { echo "selected"; }
echo " value=7>" . $db->f("namerace_7") . "</option>";
?>						
						</select>
            &nbsp;&nbsp;<input type=submit name=view value=View>
						</form>
						</td><td>	
						<form action=<?php

echo $sess->url(URL . "send_messages_council.php");
?>
					method=post><?php

echo "<input type=hidden name=id value=" . $id . ">";
echo "&nbsp;&nbsp;<input type=submit name=message value=Message>";
?>
							</form>
						</tr></td></table>
					</td>					
				</tr>
			</table>
		</td>
	</tr>
</table>

<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>