<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Planet Defenses</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
	
$db_p = new ME_DB_Xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();
	
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {
	$db_p->add_parameter("current_screen", "planet_defense");	
	echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());
?>
<form action=<?php

echo $sess->url(URL . "planet_update.php");
?>
 method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
		<td bgColor=#003399>
			<table cols=5 border=0 cellpadding=5 cellspacing=1 width=490>
				<tr>
					<td class=clsHedTxt id=blu1>
					Type
					</td>
					<td class=clsHedTxt id=blu1>
					On Ship
					</td>
					<td class=clsHedTxt id=blu1>
					On Planet
					</td>
					<td class=clsHedTxt id=blu1>
					Max
					</td>
					<td class=clsHedTxt id=blu1>
					Amount
					</td>
				</tr>
				<tr>
        	<td class=clsNrmTxt>
					Combat Drones
					</td>
					<td class=clsNrmTxt><?php

	echo $ship->f("combatcurrent");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("combatcurrent");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("hangarcurrent") * 20;
?>
					</td>	
					<td class=clsNrmTxt>
					<input type=textbox size=5 name=combat_amount>
					</td>
				</tr>
				<tr>
        	<td class=clsNrmTxt>					
					Shields
					</td>
					<td class=clsNrmTxt><?php

	echo $ship->f("shieldcurrent");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("shieldcurrent");
?>
					</td>
					<td class=clsNrmTxt>
<?php
	echo $db_p->f("generatorcurrent") * 100;
?>
					</td>
					<td class=clsNrmTxt>
					<input type=textbox size=5 name=shield_amount>
					</td>	
				</tr>
				<tr>
        	<td colspan=5 class=clsNrmTxt>
					Transaction History<br><?php
	$transactions = array();
	$transactions = explode(",", $db_p->f("defense_transactions"));

	while (list($key, $val) = each($transactions)) {		
		echo "&nbsp;" . stripslashes($val) . "<br>";		
	}
?>					
					</td>
				</tr>
				<tr>
        	<td colspan=5 class=clsNrmTxt align=center>
						<input border=0 type=image src='./images/form/planet-off.png' name=deposit_defenses>
						<input border=0 type=image src='./images/form/ship-off.png' name=withdraw_defenses>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table>
</form><br>

<form action=<?php

echo $sess->url(URL . "planet_update.php");
?>
 method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
		<td bgColor=#003399>
			<table cols=5 border=0 cellpadding=5 cellspacing=1 width=490>				
				<tr>
        	<td colspan=5 class=clsNrmTxt><br>
						Number of planetary drone squadrons (1 - 5):<br><br>
						<input type=textbox name=squadrons size=5 value="<?php echo $db_p->f("combat_squadrons") ?>">
						<br><br><input border=0 type=image src='./images/form/update-off.png' name=update_squadrons>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table>

<br><?php

if ( $db_p->f("battle_management_control_unit") == 't' ) {
	$db = new ME_DB;
	$query = sprintf("select * from sectors where sector_id = '%s'", $db_p->f("sector_id"));
	$db->query($query);	
	$db->next_record();
	$map_id = $db->f("map_id");

	$query = sprintf("select * from attack_logs where defender_alliance_id <> 0 and defender_alliance_id = '%s' and map_id = '%s' order by date desc limit 20", $player->f("alliance_id"), $map_id);
	$db->query($query);
?>
<table border=0 cellPadding=0 cellSpacing=0 width=490>	
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=490>
				<tr>
        	<td colspan=3 class=clsHedTxt id=blu1>
					<center>Force Battle Reports</center>
					</td>
				</tr>	
				<tr>
					<td width=20% class=clsHedTxt id=blu1>
					Date
					</td>
					<td width=20% class=clsHedTxt id=blu1>					
					Sector
					</td>
					<td class=clsHedTxt id=blu1>
					Attacker
					</td>					
				</tr><?php

	while ( $db->next_record() ) {
		if ( stristr($db->f("defender_types"), "f") or stristr($db->f("defender_types"), "m") ) {
	
			echo "<tr><td width=30% class=clsNrmTxt>";
			echo date ("H:i:s m/d/y",  $db->f("date"));
			echo "</td>";
	
			echo "<td width=20% class=clsNrmTxt>";
			echo $db->f("public_sector_id");
			echo "</td>";

			echo "<td class=clsNrmTxt>";
			echo $db->f("attacker_name");
			echo "</td></tr>";
		}
	}
?>
			</table>
		<td>
  </tr>
</table><br><?php

$query = sprintf("select * from attack_logs where defender_alliance_id <> 0 and defender_alliance_id = '%s' and map_id = '%s' order by date desc limit 20", $player->f("alliance_id"), $map_id);
$db->query($query);

?>

<table border=0 cellPadding=0 cellSpacing=0 width=490>	
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=490>
				<tr>
        	<td colspan=3 class=clsHedTxt id=blu1>
					<center>Planetary Battle Reports</center>
					</td>
				</tr>	
				<tr>
					<td width=20% class=clsHedTxt id=blu1>
					Date
					</td>
					<td width=20% class=clsHedTxt id=blu1>					
					Sector
					</td>
					<td class=clsHedTxt id=blu1>
					Attacker
					</td>					
				</tr><?php

	while ( $db->next_record() ) {
		if ( stristr($db->f("defender_types"), "p") ) {
	
			echo "<tr><td width=30% class=clsNrmTxt>";
			echo date ("H:i:s m/d/y",  $db->f("date"));
			echo "</td>";
	
			echo "<td width=20% class=clsNrmTxt>";
			echo $db->f("public_sector_id");
			echo "</td>";

			echo "<td class=clsNrmTxt>";
			echo $db->f("attacker_name");
			echo "</td></tr>";
		}
	}
?>
			</table>
		<td>
  </tr>
</table><br><?php
}

} else {
	$error = 8;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to insufficient drones on ship.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient shields on ship.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "Command not processed due to insufficient drones on planet.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "Command not processed due to insufficient shields on planet.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "Command not processed due to insufficient drone capacity.");			
	} elseif ($error == 7) {
		$db->add_parameter("message", "Command not processed due to insufficient shield capacity.");			
	} elseif ($error == 8) {
		$db->add_parameter("message", "Your merchant is currently not landed on a planet.");			
	} elseif ($error == 9) {
		$db->add_parameter("message", "Command not processed due to invalid amount entered.");			
	} elseif ($error == 10) {
		$db->add_parameter("message", "Amount to transfer is greater than ship capacity.");			
	} elseif ($error == 25) {
		$db->add_parameter("message", "Access to that functionality not allowed by planet owner.");			
	} elseif ($error == 26) {
		$db->add_parameter("message", "The number of drones squadrons must be between 1 and 5.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
