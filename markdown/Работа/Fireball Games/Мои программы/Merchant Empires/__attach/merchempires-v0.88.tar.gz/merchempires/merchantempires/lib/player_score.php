<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Player_score extends ME_DB {
  var $id = 0;
	var $dirty_fields = array();
	var $goods_traded = array();
	var $kills_by_level = array();

  function get_player_score($id) {
		$this->connect();
		$query = sprintf("select * from player_score where player_id = '%s'", $id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();				

		$goods_temp = explode(",", $this->f("goods_traded"));

		for ($i = 0; $i <= count($goods_temp) - 1; $i = $i + 2) {
			$this->goods_traded[$goods_temp[$i]] = $goods_temp[$i + 1];
		}

		$kills_temp = explode(",", $this->f("kills_by_level"));

		for ($i = 0; $i <= count($kills_temp) - 1; $i = $i + 2) {
			$this->kills_by_level[$kills_temp[$i]] = $kills_temp[$i + 1];
		}

		$this->id = $this->f("player_score_id");
				
    return $this->Query_ID;
  }

  function get_new_player_score($this_player_id) {
  	$this->connect();
  	$query = "insert into player_score (player_id) values ('$this_player_id')";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   	
   	$db = new ME_DB;
		$db->query("select * from player_score_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;			

	  $query = sprintf("select * from player_score where player_score_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();	
   	return $this->Query_ID;
  }

  function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update player_score set ";
			$i = 1;			

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}

				$i++;
			}
					
			$str = $str . " where player_score_id = '$this->id'";
			$db->query($str);
			
			$this->dirty_fields = array();			
		}
  }
	
	function set_credits_from_sales($n) {
		$this->dirty_fields["credits_from_sales"] = $n;
	}

	function set_credits_from_buys($n) {
		$this->dirty_fields["credits_from_buys"] = $n;
	}

	function set_credits_from_kills($n) {
		$this->dirty_fields["credits_from_kills"] = $n;
	}

	function set_credits_from_bounties($n) {
		$this->dirty_fields["credits_from_bounties"] = $n;
	}

	function set_credits_from_bounties_military($n) {
		$this->dirty_fields["credits_from_bounties_military"] = $n;
	}
	
	function set_total_trades($n) {
		$this->dirty_fields["total_trades"] = $n;
	}

	function set_total_kills($n) {
		$this->dirty_fields["total_kills"] = $n;
	}

	function set_goods_traded($m, $n) {
		$this->goods_traded[$m] = $n;

		$goods_temp = array();

		while (list($key, $val) = each($this->goods_traded)) {
			if ( $val > 0 ) {
				array_push($goods_temp, $key);
				array_push($goods_temp, $val);
			}
		}		
		
		$this->dirty_fields["goods_traded"] = implode(",", $goods_temp);
	}

	function set_kills_by_level($m, $n) {		
		$this->kills_by_level[$m] = $n;

		$kills_temp = array();

		while (list($key, $val) = each($this->kills_by_level)) {
			if ( $val > 0 ) {
				array_push($kills_temp, $key);
				array_push($kills_temp, $val);
			}
		}		
		
		$this->dirty_fields["kills_by_level"] = implode(",", $kills_temp);
	}
 }
?>