<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
include("./merchantempiresdefines.php");
$sess->register("player_id");
$sess->register("user_ignore_newbie");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");

?>

<html><head><title>Merchant Empires: Play Game</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>

<td width=100 align=left vAlign=top><?php

$db = new ME_DB;

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
		  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "play":
			if (empty($game_id)) {
				$error = "Error. No game id posted.";
				break;
			}

			$game_id = (int) $game_id;						

			$qrystr = "SELECT player_id, user_id, game_id from players where user_id = '$user->id' and game_id = '$game_id'";
			$db->query($qrystr);
			$db->next_record();

			if ( $db->nf() > 0 ) {
				if(!isset($player_id)) { $player_id=0; };
				$player_id = $db->f("player_id");

				$qrystr = "update active_sessions set player_id = '$player_id', game_id = '$game_id' where sid = '$sess->id'";
				$db->query($qrystr);

				$qrystr = "delete from active_sessions where player_id = '$player_id' and sid <> '$sess->id'";
				$db->query($qrystr);

				$db_u = new ME_DB;
				$query = sprintf("select * from auth_user where user_id = '%s'", $user->id);
				$db_u->query($query);
				$db_u->next_record();
				$user_ignore_newbie = $db_u->f("ignore_newbie");
				
				$player = new ME_Player;
				$player->get_current_player($player_id);
				$player_dead = $player->f("dead");
				$ship = new ME_Ship;
				$ship->get_current_ship($player_id);

				include("./templates/script.js");
				include("./templates/nav-root.ihtml");				

				echo "</td><td vAlign=top width=650><table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=#993300>";
				echo "<table border=0 cellPadding=5 cellSpacing=1 width=500><tr><td width=200 bgColor=#000000 align=left valign=middle>";

				if (!isset($arg)) {
					$today = "&nbsp;&nbsp;<img alt='Today' border=0 src='./images/submenu/today-on.png'>";
				}

				echo "<table border=0><tr><td colspan=2 align=left><font color=#3333FF face=arial,helvetica,swiss size=5>NEWS</font>";
				echo "</td></tr><tr><td>" . $today . "</td></tr></table></td></tr></table></td></tr></table><br>";
	
				$date = mktime(0,0,0,date("m"),date("d"),date("Y"));
				$query = sprintf("SELECT * from news where date >= $date and game_id = '$game_id' order by date desc");
	
				if ( $arg == 1 ) {
					$date = mktime(0,0,0,date("m"),date("d") - 1,date("Y"));
					$date_2 = mktime(0,0,0,date("m"),date("d"),date("Y"));
					$query = sprintf("SELECT * from news where date >= $date and date <= $date_2 and game_id = '$game_id' order by date desc");
				}

				if ( $arg == 2 ) {
					$date = mktime(0,0,0,date("m"),date("d") - 7,date("Y"));
					$query = sprintf("SELECT * from news where date >= $date and game_id = '$game_id' order by date desc");
				}
	
				echo "<table border=0 cellPadding=0 cellSpacing=0 width=500><tr><td bgColor=#003399>";
				echo "<table border=0 cellpadding=5 cellspacing=1 width=100%><tr>";
				echo "<td width=15% class=clsHedTxt id=blu1><center>Date</center></td><td width=85% class=clsHedTxt id=blu1><center>News</center></td></tr>";

				$db->query($query);

				while ( $db->next_record() ) {
					echo "<tr><td class=clsNrmTxt>";
					echo date ("m/d/y H:i:s",  $db->f("date"));
					echo "</td><td class=clsNrmTxt>";
					echo $db->f("item");
					echo "</td></tr>";
				}

				echo "</table><td></tr></table><br>";

				if ( $player->f("alliance_id") <> 0 ) {
					$query = sprintf("SELECT * from alliances where alliance_id = '%s' and game_id = '%s'", $player->f("alliance_id"), $player->f("game_id"));
					$db->query($query);
					$db->next_record();

					if ( strlen($db->f("log")) > 0 ) {
						echo "<br><table border=0 cellPadding=0 cellSpacing=0 width=500><tr><td bgColor=#003399>";
						echo "<table border=0 cellpadding=5 cellspacing=1 width=100%><tr><td class=clsNrmTxt><b>";
						echo "<br><font color=#3333FF face=helvetica size=3>Alliance Log:</font><br><br></b>";
						echo nl2br(htmlentities($db->f("log")));

						$db_2 = new ME_DB;
						$query = sprintf("select * from accounts where alliance_id = '%s'", $player->f("alliance_id"));
						$db_2->query($query);
						$db_2->next_record();

						if ( $db_2->nf() > 0 ) {			
							echo "<br><br><b><font color=#3333FF face=helvetica size=3>Finances:</font></b><br>";
							echo "<br>&nbsp;Alliance account: ";
							echo $db_2->f("balance") . "<br><br>";
						} else {
							echo "<br>";
						}
		
						echo "</tr></table><td></tr></table><br>";	
					}
				}
			}
	}
}
?>
</td>
<td>

</td></tr></table>
</body></html><?php

page_close();
?>