<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Ship Details</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

if ( !isset($id) ) { $id = $ship->f("type_id"); }

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<center><font color=#3333FF face=arial,helvetica,swiss size=5>SHIP DETAILS</font></center>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$id = (int) $id;

$db = new ME_DB;
$db->query("select * from ship_types where ship_type_id = '$id'");
$db->next_record();

?>

<table border=0 cellPadding=0 cellSpacing=0 width=400>
	<tr>
		<td bgColor=#003399>
			<table BORDER=0 cellpadding=5 cellspacing=1 COLS=2 WIDTH=100%>
				<tr>
					<td colspan= 2 bgColor=#000033>
						<FONT color=#ffffff  face=arial,helvetica,swiss size=3>
						<?php echo $db->f("name"); ?></font>
					</td>
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Turns Per Sector
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("turns_per_sector"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Shields
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("shieldmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Armor
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("armormax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Cargo Holds
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("cargomax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Power Plant
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("powermax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Combat Drones
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("combatmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Scout Drones
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("scoutmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Mines
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("minesmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Hardpoints
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("hardpoints"); ?>
 					</td>	
				</tr>		
				<tr>
					<td class=clsNrmTxt>
						Level
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("experience_level"); ?>
 					</td>	
				</tr>				
				<tr>
					<td class=clsNrmTxt>
						Scanner Capable?
		      </td>
					<td class=clsNrmTxt><?php

if ( $db->f("scanner") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Illusion Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("illusion") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Jump Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("jump") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Galaxy Jump Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("galaxy_jump") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Cloak Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("cloak") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
			</table>
		<td>
  </tr>
</table>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
