<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Military Payment</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$sector_id = $ship->f("sector_id");
$db = new ME_DB_Xml;
$db->query("select * from locations where sector_id = '$sector_id' and type='Government'");
$db->next_record();

$db_2 = new ME_DB;
$db_2->query("select * from games where game_id = '$game_id'");
$db_2->next_record();

switch ($db->f("options")) {
	case "1":
		$race_name = $db_2->f("namerace_1");
		break;
	case "2":
		$race_name = $db_2->f("namerace_2");
		break;
	case "3":
		$race_name = $db_2->f("namerace_3");
		break;
	case "4":
		$race_name = $db_2->f("namerace_4");
		break;
	case "5":
		$race_name = $db_2->f("namerace_5");
		break;
	case "6":
		$race_name = $db_2->f("namerace_6");
		break;
	case "7":
		$race_name = $db_2->f("namerace_7");
		break;
}

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

if ( $player->f("alignment") > -100 ) {	
	$db->add_parameter("current_screen", "government_military");
	echo $db->get_transform("./xslt/menu_top_government.xslt", $db->get_xml());			
?>

<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle><?php

	if ( $player->f("race") <> $race_name ) {
		echo "<br><font  color=#cccccc face=arial,helvetica,swiss size=2>You are not a member of the " . $race_name . " race.";
	} else {
		$bounties = array();
		$bounties = explode(",", $player->f("unclaimed_military_bounties"));

		if ( ! $bounties[0] > 0 ) {
			echo "<br><font  color=#cccccc face=arial,helvetica,swiss size=2>There are no payments that you can claim at this time.</font>";
		} else {
			echo "<table cellspacing=5>";
  	
			while (list($key, $val) = each($bounties)) {
				$val = (int) $val;

				$db = new ME_DB;
				$db->query("select ship_type_id, cost, name from ship_types where ship_type_id = '$val'");
				$db->next_record();
				
				$amount = (int) ($db->f("cost") * .15);
				if ( $amount < 50000 ) {
					$amount = 50000;
				}

				echo "<tr>";
				echo "<td><font  color=#cccccc face=arial,helvetica,swiss size=3>" . $db->f("name") . "</td><td>" . $amount . "</td>";
				echo "</tr>";				
			}

			echo "<tr>";
			echo "<td colspan=2 bgColor=#000000>";
			echo "<br><center><form action=";
			echo $sess->url(URL . "government_update.php");
			echo " method=post>";
			echo "<input type=submit name=claim_military_bounty value='Claim All Bounties'></form>";
	  	echo "</tr>";
			echo "</table></tr>";			
		}
  }

	echo "<tr>";
	echo "<td colspan=2 bgColor=#000000>";
	echo "<center><a href=";
	echo $sess->url(URL . "local_map.php");
	echo ">Leave Capitol</a></center>";
	echo "</tr>";
?>            	
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $error ) {
		$db = new ME_DB_Xml;
		$db->add_parameter("title", "Error");
	
		$db->add_parameter("message", $error);
		
		if ($error == 1) {
			$db->add_parameter("message", "Command not processed due to insufficient alignment.");
		} 
			
		echo $db->get_transform("./xslt/message_box.xslt", "");
	}
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Warning");
	$db->add_parameter("message", "Your alignment prevents you from accessing this location.");
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>