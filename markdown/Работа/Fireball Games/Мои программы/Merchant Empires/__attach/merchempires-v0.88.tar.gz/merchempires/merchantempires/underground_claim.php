<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Claim Bounty</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$sector_id = $ship->f("sector_id");
$db = new ME_DB_Xml;
$db->query("select * from locations where sector_id = '$sector_id' and type='Underground'");
$db->next_record();

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

if ( $player->f("alignment") < 100 ) {	
	$db->add_parameter("current_screen", "underground_claim");
	echo $db->get_transform("./xslt/menu_top_underground.xslt", $db->get_xml());
?>

<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle><?php

	$bounties = array();
	$bounties = explode(",", $player->f("unclaimed_ug_bounties"));
	$arr_bounties = explode(",", $player->f("unclaimed_ug_bounties"));
	asort($bounties);
	asort($arr_bounties);

	$i = 0;
	$db = new ME_DB;

	while (list($key, $val) = each($arr_bounties)) {
		$val = (int) $val;
		$db->query("select * from underground_bounties where underground_bounty_id = '$val'");
		$db->next_record();
				
		if ( $db->nf() == 0 ) {
			array_splice($bounties, $i, 1);
		}

		$i++;
	}	

	reset($bounties);

	if ( count($bounties) == 0 ) {
		echo "<br><font  color=#cccccc face=arial,helvetica,swiss size=2>There are no bounties that you can claim at this time.</font>";
	} else {
		echo "<table cellspacing=5>";

		while (list($key, $val) = each($bounties)) {			
			$val = (int) $val;
			$db->query("select * from underground_bounties where underground_bounty_id = '$val'");
			
			while ( $db->next_record() ) {
				echo "<tr>";
				echo "<td>" . $db->f("player_target_name") . "</td><td>" . $db->f("amount") . "<br></td>";
				echo "</tr>";
			}
		}
		echo "<tr>";
		echo "<td colspan=2 bgColor=#000000>";
		echo "<br><center><form action=";
		echo $sess->url(URL . "underground_update.php");
		echo " method=post>";
		echo "<input type=submit name=claim_bounty value='Claim All Bounties'></form>";
	  echo "</tr>";
		echo "</table>";	
	}

	$str_bounties = implode(",", $bounties);
	$player->set_unclaimed_ug_bounties($str_bounties);
	$player->save();

	echo "<tr>";
	echo "<td colspan=2 bgColor=#000000>";
	echo "<center><a href=";
	echo $sess->url(URL . "local_map.php");
	echo ">Leave Underground</a></center>";
	echo "</tr>";
?>            	
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $error ) {
		$db = new ME_DB_Xml;
		$db->add_parameter("title", "Error");		
		
		if ($error == 1) {
			$db->add_parameter("message", "Command not processed due to insufficient alignment.");
		}
			
		echo $db->get_transform("./xslt/message_box.xslt", "");
	}
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Warning");
	$db->add_parameter("message", "Your alignment prevents you from accessing this location.");
	echo $db->get_transform("./xslt/message_box.xslt", "");		
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>