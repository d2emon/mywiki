
def active_screens():	
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT ship_technology_id, active_screens, screenscurrent, screensmax from ship_technology where active_screens > 0 and screenscurrent < screensmax"
	q = pgcnx.query(qrystr)
	res = q.getresult()

	qrystr = "begin transaction"
	pgcnx.query(qrystr)

	# loop through ship_technology
	for value in range(len(res)):
	 	screenscurrent = res[value][q.fieldnum('screenscurrent')]
		screensmax = res[value][q.fieldnum('screensmax')]

	 	if (screenscurrent + 25) >= screensmax:
 			new_screens = screensmax
 		else:
			new_screens = screenscurrent + 25

		try:
	  		#update the player record
			qrystr = "update ship_technology set screenscurrent = '%d' where ship_technology_id = '%d'" % (new_screens, res[value][q.fieldnum('ship_technology_id')])
			pgcnx.query(qrystr)
		except:
                       	pass

  	qrystr = "commit transaction"
	pgcnx.query(qrystr) 
