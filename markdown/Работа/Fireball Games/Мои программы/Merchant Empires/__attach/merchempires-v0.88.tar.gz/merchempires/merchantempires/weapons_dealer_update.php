<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/ship_weapons.php");
include("./lib/weapons.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$weapons = new ME_Weapons;
$weapons->get_weapons($ship->f("ship_id"));

$hardpoints_allocated = 0;

if ( $weapons->f("weapon_1_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_2_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_3_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_4_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_5_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_6_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_7_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

if ( $weapons->f("weapon_8_id") <> 0 ) {
  $hardpoints_allocated = $hardpoints_allocated + 1;
}

$db_w = new ME_DB;
$db_w->query("SELECT * from locations where sector_id = '$sector_id' and type='Weapons'");
$db_w->next_record();

$options = $db_w->f("options");  
$dealer_weapons = array();
$dealer_weapons = explode(",", $options);

$weapon_found = 0;

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
  
  switch ($key) {
    case "purchase_weapon_4":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 4 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '4'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(4, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_6":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 6 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '6'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(6, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;
    
    case "purchase_weapon_7":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 7 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '7'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(7, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_8":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 8 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '8'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(8, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_9":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 9 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '9'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(9, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_10":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 10 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '10'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(10, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_11":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 11 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '11'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(11, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_12":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 12 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '12'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(12, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_13":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 13 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '13'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(13, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_14":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 14 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '14'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(14, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_15":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 15 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '15'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(15, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_16":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 16 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '16'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(16, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_17":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 17 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '17'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(17, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_18":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 18 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '18'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(18, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_19":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 19 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '19'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(19, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_20":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 20 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '20'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      if ( $db->f("restrictions") == 2 ) {
        if ( $player->f("alignment") > -200 ) {
          $error = 7;
          break;
        }
      }

      add_weapon(20, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_21":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 21 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '21'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      if ( $db->f("restrictions") == 1 ) {
        if ( $player->f("alignment") < 200 ) {
          $error = 6;
          break;
        }
      }

      add_weapon(21, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_22":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 22 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '22'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(22, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_23":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 23 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '23'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(23, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_24":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 24 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '24'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(24, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_25":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 25 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '25'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(25, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_26":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 26 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '26'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(26, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_27":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 27 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '27'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(27, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_28":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 28 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '28'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(28, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_29":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 29 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '29'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(29, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_30":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 30 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '30'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(30, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_31":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 31 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '31'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(31, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_32":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 32 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '32'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(32, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_33":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 33 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '33'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(33, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_34":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 34 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '34'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(34, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_35":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 35 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '35'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(35, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_37":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 37 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '37'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(37, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_38":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 38 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '38'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(38, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_39":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 39 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '39'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(39, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_40":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 40 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '40'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(40, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_41":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 41 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '41'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(41, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_42":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 42 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '42'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(42, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;
    
    case "purchase_weapon_43":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 43 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '43'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(43, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_44":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 44 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '44'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(44, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_45":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 45 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '45'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(45, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_46":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 46 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '46'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(46, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_47":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 47 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '47'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(47, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_48":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 48 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '48'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(48, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;

    case "purchase_weapon_49":
      $returnto = "weapons_dealer";

      if ( $hardpoints_allocated >= $ship->f("hardpoints") ) {
        $error = 2;
        break;
      }

      while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == 49 ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '49'");
      $db->next_record();

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

      add_weapon(49, $db->f("name"), $weapons);

      $new_credits = $player->f("credits") - $db->f("cost");
      $player->set_credits($new_credits);
      $player->save();

      break;    

    case "sell_weapon_4":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 4 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '4'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_6":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 6 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '6'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_7":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 7 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '7'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_8":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 8 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '8'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_9":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 9 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '9'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_10":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 10 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '10'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_11":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 11 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '11'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_12":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 12 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '12'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_13":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 13 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '13'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_14":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 14 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '14'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_15":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 15 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '15'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_16":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 16 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '16'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_17":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 17 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '17'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_18":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 18 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '18'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_19":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 19 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '19'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_20":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 20 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '20'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_21":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 21 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '21'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_22":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 22 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '22'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;
  
    case "sell_weapon_23":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 23 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '23'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_24":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 24 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '24'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_25":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 25 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '25'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_26":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 26 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '26'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_27":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 27 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '27'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_28":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 28 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '28'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_29":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 29 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '29'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_30":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 30 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '30'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_31":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 31 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '31'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_32":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 32 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '32'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_33":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 33 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '33'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_34":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 34 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '34'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_35":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 35 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '35'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_37":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 37 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '37'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_38":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 38 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '38'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_39":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 39 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '39'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_40":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 40 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '40'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_41":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 41 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '41'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_42":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 42 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '42'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_43":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 43 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '43'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_44":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 44 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '44'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_45":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 45 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '45'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_46":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 46 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '46'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_47":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 47 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '47'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_48":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 48 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '48'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

    case "sell_weapon_49":
      $returnto = "weapons_dealer";

      if ( $weapons->Current_weapons[$id] <> 49 ) {
        $error = 3;
        break;
      }

      if ( $db_w->nf() == 0 ) {
        $error = 5;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '49'");
      $db->next_record();

      $new_credits = (int) ($db->f("cost") / 3) + $player->f("credits");
      $player->set_credits($new_credits);
      $player->save();

      set_weapon_id_and_name($id, $weapons);

      break;

		case "store_weapon":			
			$id = (int) $id;
			$returnto = "weapons_dealer";

			while (list($key, $val) = each($dealer_weapons)) {
        if ( $val == $id ) {
          $weapon_found = 1;
        }
      }

      if ( !$weapon_found ) {
        $error = 4;
        break;
      }

      $db = new ME_DB;
      $db->query("SELECT * from weapons where weapon_id = '$id'");
      $db->next_record();

			$weapon_name = $db->f("name");

      if ( $db->f("cost") > $player->f("credits") ) {
        $error = 1;
        break;
      }

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $cargo->Open_holds == 0 ) {
				$error = 8;
				break;    				
			}

			$new_credits = $player->f("credits") - $db->f("cost");
			$new_weapons = $cargo->Current_cargo[$weapon_name]['amount'] + 1;						

			$cargo->set_good($weapon_name, 3, $new_weapons);
			$cargo->save();

			$player->set_credits($new_credits);
			$player->save();
			
			break;
  }
}

if ( $error ) {
  if ($returnto == "weapons_dealer")  {
    $newurl = $sess->url(URL . "weapons_dealer.php?error=$error");
     header("Location: $newurl");  
  }
} else {
  if ($returnto == "weapons_dealer")  {
    $newurl = $sess->url(URL . "weapons_dealer.php");
    header("Location: $newurl");  
  }
}

page_close();
?>