<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Alliance extends ME_DB {
	var $id = 0;	

  function get_alliance($id) {
		$this->connect();
		$query = sprintf("select * from alliances where alliance_id = '%s'", $id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
    }
	
		$this->next_record();				
		$this->id = $this->f("alliance_id");

   	return $this->Query_ID;
  }

	function get_new_alliance($leader_id, $game_id) {
  	$this->connect();
  	$query = "insert into alliances (leader_id, game_id) values ('$leader_id', '$game_id')";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   	
		# get the alliance id so the save method will know what to save to
   	$db = new ME_DB;
		$db->query("select * from alliance_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;
		$this->set_game_id($game_id);	

	  $query = sprintf("select * from alliances where alliance_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}		
	
		$query = sprintf("SELECT * from player_maps where player_id = '%s'", $leader_id);
		$db->query($query);	
		$db->next_record();

		$query = sprintf("insert into alliance_maps (alliance_id,
			map_1, map_2, map_3, map_4, map_5, map_6, map_7, map_8, map_9, map_10,
			map_1_id, map_2_id, map_3_id, map_4_id, map_5_id, map_6_id, map_7_id, map_8_id, map_9_id, map_10_id) values
			('%s',
			'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',
			'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
			$this->id,
			$db->f("map_1"), $db->f("map_2"), $db->f("map_3"), $db->f("map_4"), $db->f("map_5"), $db->f("map_6"), $db->f("map_7"), $db->f("map_8"), $db->f("map_9"), $db->f("map_10"),
			$db->f("map_1_id"), $db->f("map_2_id"), $db->f("map_3_id"), $db->f("map_4_id"), $db->f("map_5_id"), $db->f("map_6_id"), $db->f("map_7_id"), $db->f("map_8_id"), $db->f("map_9_id"), $db->f("map_10_id"));
		$db->query($query);
 		
		$this->next_record();	
   	return $this->Query_ID;
  }

	function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update alliances set ";
			$i = 1;

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}
			
				$i++;
			}
					
			$str = $str . " where alliance_id = '$this->id'";		
			$db->query($str);
		
			$this->dirty_fields = array();
		}
	}

	function set_password($n) {
		$this->dirty_fields["password"] = $n;	
	}

	function set_name($n) {
		$this->dirty_fields["name"] = $n;	
	}

	function set_game_id($n) {
		$this->dirty_fields["game_id"] = $n;
	}

	function set_description($n) {
		$this->dirty_fields["description"] = $n;		
	}
}
?>
