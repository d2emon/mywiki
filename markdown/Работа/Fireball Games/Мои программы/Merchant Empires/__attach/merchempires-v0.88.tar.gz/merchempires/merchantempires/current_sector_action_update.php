<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./lib/technology.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function check_module($number, $name, $megawatts, $additional_megawatts, &$megawatts_used) {
	for ($i = 1; $i <= $number; $i++) {	
		if ( $i == 1 ) {			
			$megawatts_used = $megawatts_used + $megawatts[$name];
		} else {			
			$megawatts_used = $megawatts_used + $additional_megawatts[$name];
		}
	}
}

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$public_sector_id = $ship->f("public_sector_id");

$megawatts = array();

$db = new ME_DB;
$db->query("select * from technology_types");

while (	$db->next_record() ) {
	$megawatts[$db->f("name")] = $db->f("megawatts");
	$additional_megawatts[$db->f("name")] = $db->f("additional_megawatts");
}

$megawatts_used = 0;

check_module($ship->f("cloak"), "Cloaking Device", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("illusion"), "Illusion Generator", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("jump"), "Jump Drive", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("scanner"), "Scanners", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("tracking"), "Tracking Device", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("deep_scanner"), "Deep Space Scanner", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("targeting_computer"), "Targeting Computer", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("active_screens"), "Active Screens", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("plasma_booster"), "Plasma Booster", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("tractor_beam"), "Tractor Beam", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("trifocus_plasma"), "Tri-Focus Plasma", $megawatts, $additional_megawatts, $megawatts_used);
check_module($ship->f("battle_systems_computer"), "Battle Systems Computer", $megawatts, $additional_megawatts, $megawatts_used);

$power_deficit = 0;

if ( $megawatts_used > $ship->f("powercurrent") ) {
	$power_deficit = 1;
	$error = 16;
}
	
switch ($action) {
	case "m_d_a":
		$returnto = "current_sector";

 		$db = new ME_DB;
		$query = sprintf("SELECT location_id from locations where sector_id = '%s'", $ship->f("sector_id"));
		$db->query($query);

		$db_f = new ME_DB;
		$db_f->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
		$db_f->next_record();		

		$amount_mines = $ship->f("minescurrent");		

		if ( $db_f->f("mine") >= 50 ) {
			$error = 9;
			break;	
		}

		$amount_mines_sector = $amount_mines + $db_f->f("mine");
		
		if ( $amount_mines_sector > 50 ) {	
			$amount_mines_sector = 50;
			$amount_mines = 50 - $db_f->f("mine");
		}

		if ( $db->nf() > 0 ) {
			$error = 17;
			break;	
		}

		if ( $amount_mines <= 0 ) {
			$error = 18;
			break;
		}
		
		if ( $amount_mines > 0 ) {
			if ( $amount_mines > $ship->f("minescurrent") ) {										
	     	$error = 1;
				break;	
     	}

			$new_mines = $ship->f("minescurrent") - $amount_mines;
			$ship->set_minescurrent($new_mines);
		}

		$ship->save();

		if ( $player->f("newturnsleft") > 0 ) {
			$player->set_new_turns_left(0);
			$player->save();			
		}
			
		$player_name = addslashes($player->f("name"));
		$public_player_id = $player->f("public_player_id");
		$alliance_id = $player->f("alliance_id");
		$alliance_name = addslashes($player->f("alliance_name"));			

		if ( $db_f->nf() >  0 ) {				
			$query = "update forces set sector_id = '$sector_id', player_id = '$player_id',
				player_name = '$player_name', mine = '$amount_mines_sector' where player_id = '$player_id'
				and sector_id = '$sector_id'";
			$db_f->query($query);

			if ( $amount_mines > 0 ) {
				$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
				$db_f->query($query);
			}
		} else {
   		$expiration = mktime(0,date("i"),0,date("m"),date("d") + 14,date("Y"));
	
			$query = "insert into forces (sector_id, player_id, player_name,
				mine, expiration, alliance_id, alliance_name, public_player_id,
				public_sector_id) values ('$sector_id', '$player_id', '$player_name',
				'$amount_mines_sector', '$expiration', '$alliance_id', '$alliance_name',
				'$public_player_id', '$public_sector_id')";
			$db_f->query($query);

			if ( $amount_mines > 0 ) {
				$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
				$db_f->query($query);
			}
		}

		break;	

	case "m_t_a":
			$returnto = "current_sector";

			if ( $ship->f("minesmax") == $ship->f("minescurrent") ) {
				$error = 1;
				break;
			}
  		
			$db = new ME_DB;
			$db->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
			$db->next_record();

			if ( ! ($db->nf() > 0) ) {
				$error = 2;
				break;
			}

			$amount_mines = $db->f("mine");

			if ( $amount_mines + $ship->f("minescurrent") > $ship->f("minesmax") ) {
				$amount_mines = $ship->f("minesmax") - $ship->f("minescurrent");
			}		

			if ( $amount_mines < 0 ) {
				$error = 5;
				break;
			}

			if ( $amount_mines > 0 ) {
				if ( $amount_mines > $db->f("mine") ) {
	      	$error = 1;
					break;	
      	}

				$new_mines = $ship->f("minescurrent") + $amount_mines;
				$ship->set_minescurrent($new_mines);
			}			

			$ship->save();

			if ( $db->nf() >  0 ) {				
				$amount_mines = $db->f("mine") - $amount_mines;	
				$amount_scout = $db->f("scout");
				$amount_combat = $db->f("combat");
				$forces_id = $db->f("forces_id");

				if ( $amount_scout == 0 and $amount_combat == 0 and $amount_mines == 0 ) {
					$query = "delete from forces where forces_id = '$forces_id'";
					$db->query($query);
				} else {
					$query = "update forces set mine = '$amount_mines' where forces_id = '$forces_id'";
					$db->query($query);
				}
			}

			break;

	case "s_d_a":
		$returnto = "current_sector";

 		$db = new ME_DB;
		$query = sprintf("SELECT location_id from locations where sector_id = '%s'", $ship->f("sector_id"));
		$db->query($query);

		$db_f = new ME_DB;
		$db_f->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
		$db_f->next_record();		

		$amount_scouts = $ship->f("scoutcurrent");

		if ( $db_f->f("scout") >= 10 ) {
			$error = 9;
			break;	
		}

		$amount_scouts_sector = $amount_scouts + $db_f->f("scout");		
		
		if ( $amount_scouts_sector > 10 ) {
			$amount_scouts_sector = 10;
			$amount_scouts = 10 - $db_f->f("scout");
		}

		if ( $db->nf() > 0 ) {
			$error = 17;
			break;	
		}

		if ( $amount_scouts <= 0 ) {
			$error = 18;
			break;
		}
		
		if ( $amount_scouts > 0 ) {
			if ( $amount_scouts > $ship->f("scoutcurrent") ) {										
	     	$error = 1;
				break;	
     	}

			$new_scouts = $ship->f("scoutcurrent") - $amount_scouts;
			$ship->set_scoutcurrent($new_scouts);
		}

		$ship->save();

		if ( $player->f("newturnsleft") > 0 ) {
			$player->set_new_turns_left(0);
			$player->save();			
		}
			
		$player_name = addslashes($player->f("name"));
		$public_player_id = $player->f("public_player_id");
		$alliance_id = $player->f("alliance_id");
		$alliance_name = addslashes($player->f("alliance_name"));			

		if ( $db_f->nf() >  0 ) {				
			$query = "update forces set sector_id = '$sector_id', player_id = '$player_id',
				player_name = '$player_name', scout = '$amount_scouts_sector' where player_id = '$player_id'
				and sector_id = '$sector_id'";
			$db_f->query($query);

			if ( $amount_scouts > 0 ) {
				$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
				$db_f->query($query);
			}
		} else {
   		$expiration = mktime(0,date("i"),0,date("m"),date("d") + 14,date("Y"));
	
			$query = "insert into forces (sector_id, player_id, player_name,
				scout, expiration, alliance_id, alliance_name, public_player_id,
				public_sector_id) values ('$sector_id', '$player_id', '$player_name',
				'$amount_scouts_sector', '$expiration', '$alliance_id', '$alliance_name',
				'$public_player_id', '$public_sector_id')";
			$db_f->query($query);

			if ( $amount_scouts > 0 ) {
				$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
				$db_f->query($query);
			}
		}

		break;	

	case "s_t_a":
		$returnto = "current_sector";

		if ( $ship->f("scoutmax") == $ship->f("scoutcurrent") ) {
			$error = 1;
			break;
		}
  		
		$db = new ME_DB;
		$db->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
		$db->next_record();

		if ( ! ($db->nf() > 0) ) {
			$error = 2;
			break;
		}

		$amount_scouts = $db->f("scout");

		if ( $amount_scouts + $ship->f("scoutcurrent") > $ship->f("scoutmax") ) {
			$amount_scouts = $ship->f("scoutmax") - $ship->f("scoutcurrent");
		}		

		if ( $amount_scouts < 0 ) {
			$error = 10;
			break;
		}

		if ( $amount_scouts > 0 ) {
			if ( $amount_scouts > $db->f("scout") ) {
      	$error = 1;
				break;	
     	}

			$new_scouts = $ship->f("scoutcurrent") + $amount_scouts;
			$ship->set_scoutcurrent($new_scouts);
		}			

		$ship->save();

		if ( $db->nf() >  0 ) {				
			$amount_scouts = $db->f("scout") - $amount_scouts;	
			$amount_mine = $db->f("mine");
			$amount_combat = $db->f("combat");
			$forces_id = $db->f("forces_id");

			if ( $amount_mine == 0 and $amount_combat == 0 and $amount_scouts == 0 ) {
				$query = "delete from forces where forces_id = '$forces_id'";
				$db->query($query);
			} else {
				$query = "update forces set scout = '$amount_scouts' where forces_id = '$forces_id'";
				$db->query($query);
			}
		}

		break;	

	case "c_d_a":
		$returnto = "current_sector";

 		$db = new ME_DB;
		$query = sprintf("SELECT location_id from locations where sector_id = '%s'", $ship->f("sector_id"));
		$db->query($query);

		$db_f = new ME_DB;
		$db_f->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
		$db_f->next_record();		

		$amount_combat = $ship->f("combatcurrent");

		if ( $db_f->f("combat") >= 50 ) {
			$error = 9;
			break;	
		}

		$amount_combat_sector = $amount_combat + $db_f->f("combat");
		
		if ( $amount_combat_sector > 50 ) {	
			$amount_combat_sector = 50;
			$amount_combat = 50 - $db_f->f("combat");
		}

		if ( $db->nf() > 0 ) {
			$error = 17;
			break;	
		}

		if ( $amount_combat <= 0 ) {
			$error = 18;
			break;
		}
		
		if ( $amount_combat > 0 ) {
			if ( $amount_combat > $ship->f("combatcurrent") ) {										
	     	$error = 1;
				break;	
     	}

			$new_combat = $ship->f("combatcurrent") - $amount_combat;
			$ship->set_combatcurrent($new_combat);
		}

		$ship->save();

		if ( $player->f("newturnsleft") > 0 ) {
			$player->set_new_turns_left(0);
			$player->save();			
		}
			
		$player_name = addslashes($player->f("name"));
		$public_player_id = $player->f("public_player_id");
		$alliance_id = $player->f("alliance_id");
		$alliance_name = addslashes($player->f("alliance_name"));			

		if ( $db_f->nf() >  0 ) {				
			$query = "update forces set sector_id = '$sector_id', player_id = '$player_id',
				player_name = '$player_name', combat = '$amount_combat_sector' where player_id = '$player_id'
				and sector_id = '$sector_id'";
			$db_f->query($query);

			if ( $amount_combat > 0 ) {
				$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
				$db_f->query($query);
			}
		} else {
   		$expiration = mktime(0,date("i"),0,date("m"),date("d") + 14,date("Y"));
	
			$query = "insert into forces (sector_id, player_id, player_name,
				combat, expiration, alliance_id, alliance_name, public_player_id,
				public_sector_id) values ('$sector_id', '$player_id', '$player_name',
				'$amount_combat_sector', '$expiration', '$alliance_id', '$alliance_name',
				'$public_player_id', '$public_sector_id')";
			$db_f->query($query);

			if ( $amount_combat > 0 ) {
				$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
				$db_f->query($query);
			}
		}

		break;	

	case "c_t_a":
		$returnto = "current_sector";

		if ( $ship->f("combatmax") == $ship->f("combatcurrent") ) {
			$error = 1;
			break;
		}
  		
		$db = new ME_DB;
		$db->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
		$db->next_record();

		if ( ! ($db->nf() > 0) ) {
			$error = 2;
			break;
		}

		$amount_combat = $db->f("combat");

		if ( $amount_combat + $ship->f("combatcurrent") > $ship->f("combatmax") ) {
			$amount_combat = $ship->f("combatmax") - $ship->f("combatcurrent");
		}		

		if ( $amount_combat < 0 ) {
			$error = 5;
			break;
		}

		if ( $amount_combat > 0 ) {
			if ( $amount_combat > $db->f("combat") ) {
      	$error = 1;
				break;	
     	}

			$new_combat = $ship->f("combatcurrent") + $amount_combat;
			$ship->set_combatcurrent($new_combat);
		}			

		$ship->save();

		if ( $db->nf() >  0 ) {				
			$amount_combat = $db->f("combat") - $amount_combat;	
			$amount_scout = $db->f("scout");
			$amount_mine = $db->f("mine");
			$forces_id = $db->f("forces_id");

			if ( $amount_scout == 0 and $amount_mine == 0 and $amount_combat == 0 ) {
				$query = "delete from forces where forces_id = '$forces_id'";
				$db->query($query);
			} else {
				$query = "update forces set combat = '$amount_combat' where forces_id = '$forces_id'";
				$db->query($query);
			}
		}

		break;

	case "cloak_activate":
		$returnto = "current_sector";

		if ( $power_deficit ) {
			$error = 16;
			break;	
		}
  		
		if ( !$ship->f("cloak") ) {
			$error = 1;
			break;	
		}

		$technology = new ME_Technology;
		$technology->get_technology($ship->f("ship_id"));	
		$technology->set_cloak_active('t');					
		$technology->save();		

		break;	

	case "cloak_de-activate":
		$returnto = "current_sector";

		if ( $power_deficit ) {
			$error = 16;
			break;	
		}
  		
		if ( !$ship->f("cloak") ) {
			$error = 1;
			break;					
		}

		$technology = new ME_Technology;
		$technology->get_technology($ship->f("ship_id"));	
		$technology->set_cloak_active('f');					
		$technology->save();		

		break;	

	case "deep_scan":
		$returnto = "ship_technology_scan";			
  		
		if ( !$ship->f("deep_scanner") ) {
			$returnto = "ship_technology";
			$error = 10;
			break;
		}

		if ( $ship->f("cloak_active") == 't' ) {
			$returnto = "ship_technology";
			$error = 14;
			break;
		}

		if ( $ship->f("planet_id") > 0 ) {
			$returnto = "ship_technology";
			$error = 7;
			break;
		}

		if ( $power_deficit ) {
			$returnto = "ship_technology";
			$error = 16;
			break;	
		}
		
		$s1 = new ME_Sector;
		$s1->get_sector($player_id);

		$map_sql = "select * from sectors where ";
		
		$merchants = array();
		$sectors = array();

		$counter = 1;

		if ( $ship->f("deep_scanner") == 1 ) {
			$y_bound = 2;
			$x_bound = -2;
			$search_width = 5;
			$sector_limit = 26;
		} elseif ( $ship->f("deep_scanner") == 2 ) {
			$y_bound = 3;
			$x_bound = -3;
			$search_width = 7;
			$sector_limit = 50;
		} elseif ( $ship->f("deep_scanner") == 3 ) {
			$y_bound = 4;
			$x_bound = -4;
			$search_width = 9;
			$sector_limit = 82;
		} elseif ( $ship->f("deep_scanner") == 4 ) {
			$y_bound = 5;
			$x_bound = -5;
			$search_width = 11;
			$sector_limit = 122;
		}

		$y = $y_bound;
		for ($i = 1; $i <= $search_width; $i++) {
			$x = $x_bound;
			for ($j = 1; $j <= $search_width; $j++) {
				$map_sql = $map_sql . "( map_id = " . $s1->f("map_id") . " and xpos = " . ($s1->f("xpos") + $x) . " and ypos = " . ($s1->f("ypos") + $y) . " )";
				$counter++;

				if ( $counter <> $sector_limit ) {
					$map_sql = $map_sql . " or ";
				}

				$x = $x + 1;
			}
		
			$y = $y - 1;
		}				
																
		$query = $map_sql;
		$db = new ME_DB;
		$db_2 = new ME_DB;
		$db->query($query);
	
		$i = 0;

		while ( $db->next_record() ) {				
			$query = sprintf("select ship_id, sector_id from ships where sector_id = '%s' order by ship_id", $db->f("sector_id"));
			$db_2->query($query);

			if ( $db->f("sector_id") <> $ship->f("sector_id") and $db_2->nf() > 0 ) {
				array_push($sectors, $db->f("sector_id"));
										
				while ( $db_2->next_record() ) {
					if ( $merchants[$i] <> 0 ) {
						$merchants[$i] = $merchants[$i] . "," . $db_2->f("ship_id");
					} else {
						array_push($merchants, $db_2->f("ship_id"));
					}
				}

				$i++;
			}				
		}																				

		for ($i = 0; $i <= count($sectors) - 1; $i++) {
			$str_merchants = $str_merchants . "s" . $sectors[$i] . "(" . $merchants[$i] . ")";
		}

		$sector_id = $s1->f("sector_id");									
		$scan_time = time();
		$query = "insert into scans (player_id, scanned_merchants, sector_id, scan_time) values('$player_id', '$str_merchants', '$sector_id', '$scan_time')";
		$db->query($query);			

		$db->query("select * from scan_id");
		$db->next_record();
		$scan_id = $db->f("last_value");

		break;

	case "refresh_forces":
		$returnto = "current_sector";

		$db = new ME_DB;
		$query = "select * from forces where forces_id = '$id'";
		$db->query($query);
		$db->next_record();

		if ( $player->f("alliance_id") <> $db->f("alliance_id") or $player->f("player_id") <> $db->f("player_id") ) {
			$error = 19;
			break;
		}

		if ( $ship->f("sector_id") <> $db->f("sector_id") ) {
			$error = 20;
			break;
		}

		$expiration = time() + 1209600;
		$query = "update forces set expiration = '$expiration' where forces_id = '$id'";
		$db->query($query);

		break;	
}

if ( $error ) {
	if ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "ship_technology_scan")  {
		$newurl = $sess->url(URL . "ship_technology_scan.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "ship_technology")  {
		$newurl = $sess->url(URL . "ship_technology.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php");
		header("Location: $newurl");	
	} elseif ($returnto == "ship_technology_scan") {
		$newurl = $sess->url(URL . "ship_technology_scan.php" . "?id=" . $scan_id);
		header("Location: $newurl");	
	} elseif ($returnto == "ship_technology")  {
		$newurl = $sess->url(URL . "ship_technology.php");
		header("Location: $newurl");	
	}
}

page_close();
?>