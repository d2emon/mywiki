<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/
	
include("./merchantempiresdefines.php");
?>

<html><head><title>Merchant Empires: Validation</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
$error = 0;

// Check if there was a submission
while (is_array($HTTP_POST_VARS) 
		  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "validate": 
			if (empty($code)) { 
				$error = "No code submitted.";
				break;
			}

			if ( strlen($code) > 40 ) {
				$error = "The length of the validation code is limited to 40 characters";
				break;
			}

			$db = new ME_DB;
			$query = sprintf("select * from auth_user where validation_code = '%s'", $code);
			$db->query($query);
			$db->next_record();

			if ( $db->nf() > 0 ) {
				if ( $db->f("validated") == 0 ) {
					$db_2 = new ME_DB;
					$query = sprintf("update auth_user set validated = '1' where validation_code = '%s'", $code);
					$db_2->query($query);						
					if ($db_2->affected_rows() == 0) {
					 	$error = "Validation failed.";
						break;
					}
				} else {
					$error = "That user has already been validated.";
					break;
				}
			} else {
				$error = "Incorrect Code.";
				break;
			}

			break;
	}
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	$db->add_parameter("message", $error);
	echo $db->get_transform("./xslt/message_box.xslt", "");	
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Success");

	$msg = "Your Merchant Empires user was successfully validated.<br><br>You may now ";
	$msg = $msg . "<a href=" . URL . "index.php3>log in</a> and join the game of Merchant Empires.";

	$db->add_parameter("message", $msg);
	echo $db->get_transform("./xslt/message_box.xslt", "");	
}
?>

</td></tr></table>
</body></html>