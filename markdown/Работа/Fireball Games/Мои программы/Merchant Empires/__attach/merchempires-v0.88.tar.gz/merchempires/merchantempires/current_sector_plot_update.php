<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function check_player_map($map_id, $player, $sector_id)  {
	$player_id = $player->f("player_id");
	$db = new ME_DB;
	$query = sprintf("SELECT * from maps where map_id = '%s'", $map_id);
	$db->query($query);	
  $db->next_record();
	$map_rank = $db->f("map_rank");

	if ( $player->f("alliance_id") <> 0 ) {	
		$query = sprintf("SELECT * from alliance_maps where alliance_id = '%s'", $player->f("alliance_id"));
	} else {
		$query = sprintf("SELECT * from player_maps where player_id = '%s'", $player_id);
	}
	
	$db->query($query);	
  $db->next_record();

	switch ($map_rank) {
		case "1":
			$sectors = $db->f("map_1");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);			

			break;
		case "2":
			$sectors = $db->f("map_2");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);				

			break;
		case "3":
			$sectors = $db->f("map_3");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);	
			
			break;
		case "4":
			$sectors = $db->f("map_4");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);	
		
			break;
		case "5":
			$sectors = $db->f("map_5");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);			

			break;
		case "6":
			$sectors = $db->f("map_6");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);	
			
			break;
		case "7":
			$sectors = $db->f("map_7");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);			

			break;
		case "8":
			$sectors = $db->f("map_8");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);			

			break;
		case "9":
			$sectors = $db->f("map_9");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);			

			break;
		case "10":
			$sectors = $db->f("map_10");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return in_array($sector_id, $visible_sectors);				

			break;
	}	
}

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$public_sector_id = $ship->f("public_sector_id");

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {			
		switch ($key) {
			case "plot_x":
				$target = (int) $target;

				$returnto = "current_sector_plot";
				
				if (empty($target)) {
					$error = 1;
					#target not entered
					break;
				}

				if ( $target <= 0 ) {
					$error = 2;					
					break;
				}

				if ( $target == $public_sector_id ) {
					$error = 4;					
					break;
				}

				$db = new ME_DB;

				$query = "select * from sectors where sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();
  			$map_id = $db->f("map_id");
				$player_xpos = $db->f("xpos");
				$player_ypos = $db->f("ypos");
					
				$query = "select * from sectors where public_sector_id = '$target' and map_id = '$map_id'";
				$db->query($query);
        $db->next_record();

				$explored = 0;
				$explored = check_player_map($db->f("map_id"), $player, $db->f("sector_id"));

				if ( !($explored) ) {
					$error = 6;
					break;
				}

				if ( $map_id <> $db->f("map_id") ) {
					$error = 3;
					break;
				}

				$target_xpos = $db->f("xpos");
				$target_ypos = $db->f("ypos");

				exec('./courceplot ' . $map_id . ' ' . $player_xpos . ' ' . $player_ypos . ' ' . $target_xpos . ' ' . $target_ypos, $my_array);
				$course = array();
				$course = explode(",", $my_array[0]);
				$course = array_reverse($course);
				$str_course = implode (",", $course);
				
				$ship_id = $ship->f("ship_id");
				$query = "update ships set course = '$str_course' where ship_id = '$ship_id'";
				$db->query($query);

				break;
		}
}

if ( $error ) {
	if ($returnto == "current_sector_plot")  {
		$newurl = $sess->url(URL . "current_sector_plot.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "current_sector_plot")  {
		$newurl = $sess->url(URL . "current_sector_plot.php?action=read_course");
		header("Location: $newurl");	
	}
}

page_close();
?>
