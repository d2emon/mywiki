<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/relations.php");
include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/player_score.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./lib/trading.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function create_transaction($offer, $amount, $this_player_id) {
	$db = new ME_DB;	
	$query = "insert into transactions (offer, amount, player_id)
		values('$offer', '$amount', '$this_player_id')";
	$db->record_oid();	
	$db->query($query);

	$query = sprintf("select * from transactions where oid = '%s'", $db->Last_OID);	
	$db->query($query);
	$db->next_record();
	
	return $db->f("transaction_id");	
}

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$player_config = new ME_Player_config;
$player_config->get_player_config($player_id);

$post_trade_screen = "current_sector";

if ( $player_config->f("post_trade_screen") != "" ) {
	$post_trade_screen = $player_config->f("post_trade_screen");
}

$db = new ME_DB;
$db->query("select * from ports where sector_id = '$sector_id'");
$db->next_record();

$global_relations = new ME_Relations;
$global_relations->initialize($player->f("game_id"), $player->f("race_number"));
$government = $db->f("government");

switch ( $db->f("government") ) {
	case "1":
		$old_personal_relations = $player->f("relationrace_1");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_1();
		break;
	case "2":
		$old_personal_relations = $player->f("relationrace_2");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_2();
		break;
	case "3":
		$old_personal_relations = $player->f("relationrace_3");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_3();
		break;
	case "4":
		$old_personal_relations = $player->f("relationrace_4");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_4();
		break;
	case "5":
		$old_personal_relations = $player->f("relationrace_5");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_5();
		break;
	case "6":
		$old_personal_relations = $player->f("relationrace_6");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_6();
		break;
	case "7":
		$old_personal_relations = $player->f("relationrace_7");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_7();;
		break;
}

$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);
srand((double)microtime()*1000000);

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "accept":
			$returnto = "port";
			$transaction_id = (int) $transaction_id;
			$db->query("SELECT * from transactions where transaction_id = '$transaction_id' and player_id = '$player_id'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = 17;
				break;
			} else {
				$offer = (int) $db->f("offer");
				$amount = (int) $db->f("amount");
				
				$db_d = new ME_DB_Tran;
				$db_d->begin_transaction();
				$db_d->query("delete from transactions where transaction_id = '$transaction_id'");
				$db_d->end_transaction();
			}
			
			$counter = (int) $counter;
		
			if ( $amount < 0 ) {
				$error = 16;
				break;
			}

			if ( $offer < 0 ) {
				$error = 16;
				break;
			}

			if ( $counter < 0 ) {
				$error = 16;
				break;
			}	

			switch($type) {
				case "buy_good":
					$db_g = new ME_DB;

					$db_g->query("SELECT * from goods where sector_id = '$sector_id' and type='$good_type' and buyorsell='sell'");
					
					if ( $db_g->nf() == 0 ) {
						$error = 13;
						break;
					}
					
					if ( $offer > $player->f("credits") or $counter > $player->f("credits") ) {
    				$error = 12;
						break;
					}

					if ( $amount > $cargo->Open_holds ) {
						$error = 14;
						break;
					}

					$turns = $player->f("turns");
					$newturns = $player->f("newturnsleft");
						
					if ( ($player->f("turns") - 2) >= 0 )  {
						if ( $newturns > 0 ) {
							$player->set_new_turns_left($newturns - 2);
						}
						$player->set_turns($turns - 2);
      		} else {
						$error = 15;
						break;
					}

					if ( $counter > 0 ) {
						if ( verify_buy_offer($counter, $offer, $relations, $good_type) )  {
							$debit_amount = $counter;
          		$new_credits = $player->f("credits") - $counter;
						} else {
							set_reject($counter, $amount, $good_type, $player_id);
							$new_transaction_id = create_transaction($offer, $amount, $player->f("player_id"));
							$new_personal_relations = $old_personal_relations - 1;
							set_relations($player, $government, $new_personal_relations);
					  	$returnto = "port_offer";
							$player->save();
							break;
						}
					} else {
						$debit_amount = $offer;
          	$new_credits = $player->f("credits") - $offer;
						$counter = $offer;
					}
	
					$new_good = $cargo->Current_cargo[$good_type]['amount'] + $amount;
					$cargo->set_good($good_type, 1, $new_good);
					$cargo->save();
					
					if ( $new_good == $cargo->Open_holds ) {
						$returnto = $post_trade_screen;
					}

					set_success($debit_amount, $amount, $good_type, $player_id);
					effect_indexes($amount, $good_type, $sector_id);
					$experience_gain = experience_buy($amount, $offer, $counter, $relations, $player->f("experience"), $good_type);
					$new_personal_relations = $old_personal_relations + 1;				

					if ( $experience_gain > 0 ) {
						$experience = $player->f("experience") + $experience_gain;
						$player->set_experience($experience);
						$player->set_success_experience($experience_gain);
		
						$new_status = array();
						$new_status = check_level_gain($experience);
						$player->set_rank($new_status['rank']);
						$player->set_level($new_status['level']);						
					} else {
						$new_personal_relations = $old_personal_relations + 2;
					}
										
					$val = rand(1,25);

					if ( $val == 25 ) {
						if ( $good_type == 'Slaves' or $good_type == 'Weapons' or $good_type == 'Narcotics' ) {
							$new_alignment = $player->f("alignment") - 1;
						} else {
							$new_alignment = $player->f("alignment") + 1;
						}

						$player->set_alignment($new_alignment);
					}

					$player_score = new ME_Player_score;
					$player_score->get_player_score($player_id);
					$player_score->set_credits_from_buys($player_score->f("credits_from_buys") + $offer);
					$player_score->set_goods_traded($good_type, $player_score->goods_traded[$good_type] + $amount);
					$player_score->set_total_trades($player_score->f("total_trades") + 1);
					$player_score->save();

					set_relations($player, $government, $new_personal_relations);
					$player->set_credits($new_credits);
         	$player->save();
					increase_port_goods($amount, $sector_id);
        	break;
				
				case "sell_good":
					$db_g = new ME_DB;
					$db_g->query("SELECT * from goods where sector_id = '$sector_id' and type='$good_type' and buyorsell='buy'");
					
					if ( $db_g->nf() == 0 ) {
						$error = 13;
						break;
					}

					if ( $amount > $cargo->Current_cargo[$good_type]['amount'] ) {					
    				$error = 11;
						break;
					}

					$turns = $player->f("turns");
					$newturns = $player->f("newturnsleft");
						
					if ( ($player->f("turns") - 2) >= 0 )  {
						if ( $newturns > 0 ) {
							$player->set_new_turns_left($newturns - 2);
						}
						$player->set_turns($turns - 2);
      		} else {
						$error = 15;
						break;
					}
				
					if ( $counter > 0 ) {
						if ( verify_sell_offer($counter, $offer, $relations, $good_type) )  {
							$credit_amount = $counter;
          		$new_credits = $player->f("credits") + $counter;
						} else {
							set_reject($counter, $amount, $good_type, $player_id);							
							$new_personal_relations = $old_personal_relations - 1;
							set_relations($player, $government, $new_personal_relations);
							$new_transaction_id = create_transaction($offer, $amount, $player->f("player_id"));
					  	$returnto = "port_offer";
							$player->save();
							break;
						}
					} else {						
						$credit_amount = $offer;
          	$new_credits = $player->f("credits") + $offer;
						$counter = $offer;
					}
	
					$new_good = $cargo->Current_cargo[$good_type]['amount'] - $amount;
					$cargo->set_good($good_type, 1, $new_good);
					$cargo->save();

					set_success($credit_amount, $amount, $good_type, $player_id);
					effect_indexes($amount, $good_type, $sector_id);
					$experience_gain = experience_sell($amount, $offer, $counter, $relations, $player->f("experience"), $good_type);
					$new_personal_relations = $old_personal_relations + 1;

					if ( $experience_gain > 0 ) {
						$experience = $player->f("experience") + $experience_gain;
						$player->set_experience($experience);
						$player->set_success_experience($experience_gain);

						$new_status = array();
						$new_status = check_level_gain($experience);
						$player->set_rank($new_status['rank']);
						$player->set_level($new_status['level']);
					} else {
						$new_personal_relations = $old_personal_relations + 2;
					}
			
					$val = rand(1,25);

					if ( $val == 25 ) {
						if ( $good_type == 'Slaves' or $good_type == 'Weapons' or $good_type == 'Narcotics' ) {
							$new_alignment = $player->f("alignment") - 1;
						} else {
							$new_alignment = $player->f("alignment") + 1;
						}

						$player->set_alignment($new_alignment);
					}

					$player_score = new ME_Player_score;
					$player_score->get_player_score($player_id);
					$player_score->set_credits_from_sales($player_score->f("credits_from_sales") + $offer);
					$player_score->set_goods_traded($good_type, $player_score->goods_traded[$good_type] + $amount);
					$player_score->set_total_trades($player_score->f("total_trades") + 1);
					$player_score->save();

					set_relations($player, $government, $new_personal_relations);							
					$player->set_credits($new_credits);
         	$player->save();
					increase_port_goods($amount, $sector_id);
        	break;							
			}

			break;
	}
}

if ( $error ) {
	if ($returnto == "port")  {
		$newurl = $sess->url(URL . "port.php?error=$error");
		header("Location: $newurl");	
	}	elseif ($returnto == "port_offer")  {
		$newurl = $sess->url(URL . "port_offer.php?error=$error");
		header("Location: $newurl");	
	}

} else {
	if ($returnto == "port")  {
		$newurl = $sess->url(URL . "port.php");
		header("Location: $newurl");	
	} elseif ($returnto == "port_offer")  {
		$newurl = $sess->url(URL . "port_offer.php?nt_id=" . $new_transaction_id);
		header("Location: $newurl");	
	}	elseif ($returnto == "local_map")  {
		$newurl = $sess->url(URL . "local_map.php");
		header("Location: $newurl");	
	}	elseif ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php");
		header("Location: $newurl");	
	}	
}

page_close();
?>