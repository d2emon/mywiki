<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

function get_tactical_defense($this_ship, $level) {
	$tactical_defense = (4.5 - $this_ship->f("turns_per_sector")) * 12;
	$tactical_defense = ceil($tactical_defense - ($this_ship->f("shieldcurrent") + $this_ship->f("armorcurrent")) / 100);
	$tactical_defense = ceil($tactical_defense - ($this_ship->f("cargocurrent") + $this_ship->f("scoutcurrent") + $this_ship->f("combatcurrent") + $this_ship->f("minescurrent") * 2) / 100);
	$tactical_defense = $tactical_defense - ($this_ship->f("hardpoints") * 3.5);

	$level_bonus = floor($level / 4);

	$tactical_defense = $tactical_defense + $level_bonus;
			
	if ( $tactical_defense < 0 ) {
		return 0;
	} else {
		return $tactical_defense;
	}	
}

function get_combined_damage($db) {
	if ( $db->f("weapon_1_shield_damage") < $db->f("weapon_1_armor_damage") ) {
		$w1 = $db->f("weapon_1_armor_damage");
	} else {
		$w1 = $db->f("weapon_1_shield_damage");
	}

	if ( $db->f("weapon_2_shield_damage") < $db->f("weapon_2_armor_damage") ) {
		$w2 = $db->f("weapon_2_armor_damage");
	} else {
		$w2 = $db->f("weapon_2_shield_damage");
	}

	if ( $db->f("weapon_3_shield_damage") < $db->f("weapon_3_armor_damage") ) {
		$w3 = $db->f("weapon_3_armor_damage");
	} else {
		$w3 = $db->f("weapon_3_shield_damage");
	}

	if ( $db->f("weapon_4_shield_damage") < $db->f("weapon_4_armor_damage") ) {
		$w4 = $db->f("weapon_4_armor_damage");
	} else {
		$w4 = $db->f("weapon_4_shield_damage");
	}

	if ( $db->f("weapon_5_shield_damage") < $db->f("weapon_5_armor_damage") ) {
		$w5 = $db->f("weapon_5_armor_damage");
	} else {
		$w5 = $db->f("weapon_5_shield_damage");
	}

	if ( $db->f("weapon_6_shield_damage") < $db->f("weapon_6_armor_damage") ) {
		$w6 = $db->f("weapon_6_armor_damage");
	} else {
		$w6 = $db->f("weapon_6_shield_damage");
	}

	if ( $db->f("weapon_7_shield_damage") < $db->f("weapon_7_armor_damage") ) {
		$w7 = $db->f("weapon_7_armor_damage");
	} else {
		$w7 = $db->f("weapon_7_shield_damage");
	}

	if ( $db->f("weapon_8_shield_damage") < $db->f("weapon_8_armor_damage") ) {
		$w8 = $db->f("weapon_8_armor_damage");
	} else {
		$w8 = $db->f("weapon_8_shield_damage");
	}

	$cd = $w1 + $w2 + $w3 + $w4 + $w5	+ $w6 + $w7 + $w8;
	return $cd;
}

?>