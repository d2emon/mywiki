<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/ship.php");
include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/sector.php");
include("./lib/player_redirect.php");

if ( $player_id > 0 )  {
	$ship = new ME_Ship;
	$ship->get_ship($player_id);

	if ( $ship->f("planet_id") > 0 ) {
		$db = new ME_DB;
		$query = sprintf("select * from planets where planet_id = '%s'", $ship->f("planet_id"));
		$db->query($query);
		$db->next_record();
		
		if ( $db->f("planet_id") > 0 ) {
			$ship->set_planet_id(0);
			$ship->set_starbase_id(0);
			$ship->set_sector_id($db->f("sector_id"));
			$ship->set_public_sector_id($db->f("public_sector_id"));
			$ship->save();
		}
	}
}

$player_config = new ME_Player_config;
$player_config->get_player_config($player_id);

$post_trade_screen = "current_sector";

if ( $player_config->f("post_trade_screen") != "" ) {
	$post_trade_screen = $player_config->f("post_trade_screen");
}

if ( $post_trade_screen == 'local_map' ) {
	$newurl = $sess->url(URL . "local_map.php");
} else {
	$newurl = $sess->url(URL . "current_sector.php");
}

header("Location: $newurl");

page_close();
?>