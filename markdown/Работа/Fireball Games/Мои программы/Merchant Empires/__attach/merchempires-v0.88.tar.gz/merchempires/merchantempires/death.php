<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");

# send player to select a game if no player id
if (!$player_id>0)  {
	$newurl = $sess->url(URL . "select_game.php");
	header("Location: $newurl");
	exit;
}

?>

<html><head><title>Merchant Empires: Death</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $player_dead == 't' ) {
?>

<div id="scene_container_ie" style="position:absolute;width:325px"></div>

<layer id="scene_container_ns" width=450></layer>

<script>
	
	var destination = "<?php

echo $sess->url(URL . "death_post.php");

?>"

	var scene = new Array()
	var open_font_tag = '<font face="Arial" size="4">'
	scene[0] = ' "... shields down ..."<br><br>"... armor destroyed ..."<br><br>" ... all systems critical ..."<br><br><br>You give the order to abandon ship.'
	scene[1] = 'From the narrow confines of your escape pod, you survey the floating wreck of your once proud starship.'
	var close_font_tag = '</font>'
	var interval = 2500

	var i = 0

function display_scene_ns(){
	if ( i < scene.length ){
		scene_ns.visibility = "hide"
		scene_ns.document.write('<b>' + open_font_tag + scene[i] + close_font_tag + '</b>')
		scene_ns.document.close()
		scene_ns.left = pageXOffset + window.innerWidth / 2 - scene_ns.document.width / 2
		scene_ns.top = pageYOffset + window.innerHeight / 2 - scene_ns.document.height / 2
		scene_ns.visibility = "show"
		i++
	} else {
		window.location = destination
		return
	}

	setTimeout("display_scene_ns()", interval)
}

function display_scene_ie(){
	if ( i < scene.length ){
		scene_ie.style.visibility = "hidden"
		scene_ie.innerHTML = '<b>' + open_font_tag + scene[i] + close_font_tag + '</b>'
		scene_ie.style.left = document.body.scrollLeft + document.body.clientWidth / 2 - scene_ie.offsetWidth / 2
		scene_ie.style.top = document.body.scrollTop + document.body.clientHeight / 2 - scene_ie.offsetHeight / 2
		scene_ie.style.visibility = "visible"
		i++
	} else {
		window.location = destination
		return
	}

	setTimeout("display_scene_ie()", interval)
}

function position_scene_container(){
	if (document.all){		
		scene_ie = document.all.scene_container_ie
		scene_ie.style.left = document.body.scrollLeft + document.body.clientWidth / 2 - scene_ie.offsetWidth / 2
		scene_ie.style.top = document.body.scrollTop + document.body.clientHeight / 2 - scene_ie.offsetHeight / 2
		display_scene_ie()
	} else if (document.layers){
		scene_ns = document.scene_container_ns
		scene_ns.left = pageXOffset + window.innerWidth / 2 - scene_ns.document.width / 2
		scene_ns.top = pageYOffset + window.innerHeight / 2 - scene_ns.document.height / 2
		scene_ns.visibility = "show"
		display_scene_ns()
	} else {
		window.location = destination
	}
}

window.onload = position_scene_container

</script><?php

}
?>

</td>
<td valign=top align=right width=100%><?php

?>

</td></tr></table>
</body></html><?php

page_close();
?>
