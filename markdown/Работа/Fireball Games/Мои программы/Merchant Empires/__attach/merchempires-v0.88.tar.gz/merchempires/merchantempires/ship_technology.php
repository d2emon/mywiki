<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton                                                
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./lib/technology.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function display_module($number, $name, $megawatts, $additional_megawatts, &$megawatts_used) {
	for ($i = 1; $i <= $number; $i++) {
		echo "<tr><td><span class=clsNrmTxt>" . $name . "</span></td>";

		if ( $i == 1 ) {
			echo "<td>" . $megawatts[$name] . "</td></tr>";
			$megawatts_used = $megawatts_used + $megawatts[$name];
		} else {
			echo "<td>" . $additional_megawatts[$name] . "</td></tr>";
			$megawatts_used = $megawatts_used + $additional_megawatts[$name];
		}

		echo "</tr>";
	}
}

function get_sector_id(&$scanned_merchants) {
	$my_scanned_merchants = $scanned_merchants;
	$pos = strpos ("." . $scanned_merchants, "s");
	$pos_2 = strpos ($scanned_merchants, "(");
	
	$scanned_merchants = substr($scanned_merchants, $pos_2);
	return substr($my_scanned_merchants, $pos, $pos_2 - 1);
}

function get_ships(&$scanned_merchants) {
	$my_scanned_merchants = $scanned_merchants;
	$pos = strpos ("." . $scanned_merchants, "(");
	$pos_2 = strpos ($scanned_merchants, ")");
	
	$scanned_merchants = substr($scanned_merchants, $pos_2 + 1);
	return substr($my_scanned_merchants, $pos, $pos_2 - 1);
}
?>

<html><head><title>Merchant Empires: Ship Technology</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5>Ship Technology</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

if ( $trifocus_id > 0 and !($error) ) {
	$trifocus_id = (int) $trifocus_id;

	$db = new ME_DB;
	$db->query("select * from trifocus_attacks where trifocus_attack_id = '$trifocus_id'");
	$db->next_record();

	if ( $db->nf() > 0 and $db->f("player_id") == $player->f("player_id") ) {
		echo "<table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=#993300>";
		echo "<table border=0 cellPadding=5 cellSpacing=1 width=500><tr><td class=clsHedTxt id=red1>";
		echo "Tri-Focus Plasma Results</td></tr><tr><td class=clsNrmTxt>";

		if ( $db->f("target_type") == 1 ) {		
			if ( $db->f("merchant_hit") == 't' ) {
				echo "<br>Target merchant was hit for " . $db->f("damage") . " points of damage.<br>";
			} else {
				echo "<br>Target merchant was missed.<br>";
			}

			if ( $db->f("merchant_killed") == 't' ) {
				echo "Target merchant was killed.<br>";
			}
		}

		if ( $db->f("target_type") == 2 ) {
			if ( $db->f("forces_hit") == 't' ) {
				echo "<br>Target forces were hit, destroying " . $db->f("damage") . " total forces.<br>";
			} else {
				echo "<br>Target forces were missed.<br>";
			}

			if ( $db->f("forces_killed") == 't' ) {
				echo "Target forces where eliminated.<br>";
			}
		}

		echo "<br><br></td></tr></table></td></tr></table><br>";

		$db_d = new ME_DB_Tran;
		$db_d->begin_transaction();
		$db_d->query("delete from trifocus_attacks where trifocus_attack_id = '$trifocus_id'");
		$db_d->end_transaction();	
	}
}

$id = (int) $id;

if ( $id > 0 and !($error) ) {
	$id = (int) $id;

	$s1 = new ME_Sector;
	$s1->get_sector($player_id);

	$map_sql = "select * from sectors where ";
	
	$merchants = array();
	$sectors = array();
	$detected = array();
	$sectors_current = array();
	$sectors_previous = array();

	# retrieve the scan record
	$db = new ME_DB;
	$db->query("select * from scans where scan_id = '$id'");
	$db->next_record();

	if ( $db->nf() > 0 and $db->f("player_id") == $player->f("player_id") and $db->f("sector_id") == $ship->f("sector_id") and $db->f("scan_time") < time() - 20 ) {
		$scanned_merchants = $db->f("scanned_merchants");

		while ( strlen($scanned_merchants) > 0 ) {
			$this_sector_id = get_sector_id($scanned_merchants);				
			$ships_previous = get_ships($scanned_merchants);				
			$sectors_previous[$this_sector_id] = $ships_previous;
		}

		if ( $ship->f("deep_scanner") == 1 ) {
			$y_bound = 2;
			$x_bound = -2;
			$search_width = 5;
			$sector_limit = 26;
		} elseif ( $ship->f("deep_scanner") == 2 ) {
			$y_bound = 3;
			$x_bound = -3;
			$search_width = 7;
			$sector_limit = 50;
		} elseif ( $ship->f("deep_scanner") == 3 ) {
			$y_bound = 4;
			$x_bound = -4;
			$search_width = 9;
			$sector_limit = 82;
		} elseif ( $ship->f("deep_scanner") == 4 ) {
			$y_bound = 5;
			$x_bound = -5;
			$search_width = 11;
			$sector_limit = 122;
		}

		$counter = 1;
		$y = $y_bound;
		for ($i = 1; $i <= $search_width; $i++) {
			$x = $x_bound;
			for ($j = 1; $j <= $search_width; $j++) {
				$map_sql = $map_sql . "( map_id = " . $s1->f("map_id") . " and xpos = " . ($s1->f("xpos") + $x) . " and ypos = " . ($s1->f("ypos") + $y) . " )";
				$counter++;

				if ( $counter <> $sector_limit ) {
					$map_sql = $map_sql . " or ";
				}

				$x = $x + 1;
			}
		
			$y = $y - 1;
		}				
			
		$query = $map_sql;
		$db_2 = new ME_DB;
		$db->query($query);

		while ( $db->next_record() ) {
			$query = sprintf("select ship_id, sector_id, public_sector_id from ships where sector_id = '%s' order by ship_id", $db->f("sector_id"));
			$db_2->query($query);

			if ( $db->f("sector_id") <> $ship->f("sector_id") and $db_2->nf() > 0 ) {
					while ( $db_2->next_record() ) {							
					if ( $sectors_current[$db->f("sector_id")] <> 0 ) {
						$sectors_current[$db->f("sector_id")] = $sectors_current[$db->f("sector_id")] . "," . $db_2->f("ship_id");
					} else {
						$sectors_current[$db->f("sector_id")] = $db_2->f("ship_id");
					}
				}

				if ( $sectors_current[$db->f("sector_id")] <> $sectors_previous[$db->f("sector_id")] ) {
					array_push($detected, $db->f("public_sector_id"));
				}				
			}																												
		}			

		$db_d = new ME_DB_Tran;
		$db_d->begin_transaction();
		$db_d->query("delete from scans where scan_id = '$id'");
		$db_d->end_transaction();	

		echo "<table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=#993300>";
		echo "<table border=0 cellPadding=5 cellSpacing=1 width=500><tr><td class=clsHedTxt id=red1>";
		echo "Scan Results</td></tr><tr><td class=clsNrmTxt>";

		if ( count($detected) > 0 ) {
			for ($i = 0; $i <= count($detected) - 1; $i++) {
				echo "Movement detected in sector " . $detected[$i] . ".<br>";
			}
		} else {
			echo "No movement detected.";
		}		

		echo "<br><br></td></tr></table></td></tr></table><br>";
	} else {
		$error = 15;
	}			
}
?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td bgColor=#000000>&nbsp;<?php

$technology = new ME_Technology;
$technology->get_technology($ship->f("ship_id"));

if ( !$ship->f("cloak") and !$ship->f("illusion") and !$ship->f("jump") and !$technology->f("tracking") and !$technology->f("deep_scanner") and !$technology->f("battle_systems_computer") and !$technology->f("trifocus_plasma") ) {
	echo "<br><font color=#cccccc  face=arial,helvetica,swiss size=3>Your ship has no configurable technology.</font>";
}

if ( $ship->f("cloak") ) {
	
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellspacing=2>";
	echo "<tr><td>";
	echo "<font color=#3333FF  face=arial,helvetica,swiss size=3>";
	echo "Cloaking Device<br>";
	echo "</font></td></tr><tr><td>";

	if ( $ship->f("cloak_active") == 'f' ) {
		echo "<input border=0 type=image src='./images/form/activate-off.png' name=cloak_activate>";
	} else {
		echo "<input border=0 type=image src='./images/form/deactivate-off.png' name=cloak_de-activate>";
	}

	echo "</td></tr></table></form>";
}

if ( $ship->f("illusion") ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellspacing=2><tr><td>";
	echo "<font color=#3333FF  face=arial,helvetica,swiss size=3>";
	echo "Illusion Generator<br>";
	echo "</font></td></tr><tr><td class=clsNrmTxt>";

	echo "&nbsp;<select name=ship_type size=8 multiple>";

	$db = new ME_DB;
	$db->query("SELECT ship_type_id, name from ship_types order by name");

	while (	$db->next_record() ) {
		if ( $db->f("ship_type_id") == $ship->f("illusion_type_id") ) {
			echo "<option value=" . $db->f("ship_type_id") . " selected>" . $db->f("name");
		} else {
			echo "<option value=" . $db->f("ship_type_id") . ">" . $db->f("name");
		}
	}

	echo "</select>";
	echo "</td></tr><tr><td>";

	echo "<table cellspacing=2><tr>";
	echo "<td class=clsNrmTxt>Attack Rating:</font></td><td><input type=textbox name=attack size=5 value=" . $ship->f("illusion_attack") . "></td>";
	echo "</tr><tr>";
	echo "<td class=clsNrmTxt>Defense Rating:</td><td><input type=textbox name=defense size=5 value=" . $ship->f("illusion_defense") . "></td>";
	echo "</tr></table>";

  echo "</td></tr><tr><td>";
	if ( $ship->f("illusion_active") == 'f' ) {
		echo "<input border=0 type=image src='./images/form/activate-off.png' name=illusion_activate>";
	} else {	
		echo "<input border=0 type=image src='./images/form/deactivate-off.png' name=illusion_de-activate>";
	}

	echo "</td></tr></table></form>";
}

if ( $ship->f("jump") ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellpadding=1 cellspacing=2>";
	echo "<tr><td>";
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>";
	echo "Jump Drive";
	echo "</font><br></td></tr><tr><td class=clsNrmTxt>";
	echo "&nbsp;Input target sector:</font><br>";
	echo "</td></tr><tr><td>";
	echo "&nbsp;<input type=textbox name=jump_target size=14><br>";
	echo "</td></tr><tr><td>";
	echo "&nbsp;<input border=0 type=image src='./images/form/jump-off.png' name=jump>";
	echo "</td></tr></table></form>";
}

if ( $ship->f("tracking") ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellspacing=2 cellpadding=1 border=0><tr><td>";
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>Tracking Device";
	echo "</font><br></td></tr><tr><td>";	

	if ( $ship->f("tracking_player_id") <> 0 ) {
		$tracked_player_id = $ship->f("tracking_player_id");
		$db = new ME_DB;
		$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id, players.player_id, players.name from ships, sectors, players where ships.player_id = '$tracked_player_id' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id");
		$db->next_record();

		echo "&nbsp;<input type=textbox name=track_target size=14 value=" . stripslashes($db->f("name")) . "><br>";		
	} else {
		echo "&nbsp;<input type=textbox name=track_target size=14><br>";
	}	

	echo "<input type=hidden name=merchant_action value=track_merchant>";
	echo "</td><td class=clsNrmTxt>&nbsp;&nbsp;Track by:&nbsp;";
	echo "<select name=action>";
	echo "<option selected value=merchantname>Name</option>";
	echo "<option value=merchant_id>ID</option>";	
	echo "</select>";

	echo "</td></tr><tr><td>";
	echo "&nbsp;<input border=0 type=image src='./images/form/lock-off.png' name=track>";
	echo "&nbsp;&nbsp;<input border=0 type=image src='./images/form/unlock-off.png' name=untrack></td></tr></table></form>";
}

if ( $ship->f("tractor_beam") and $ship->f("tractor_beam_locked") == 't' ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellspacing=2 cellpadding=1 border=0><tr><td>";
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>Tractor Beam";
	echo "</font><br></td></tr><tr><td class=clsNrmTxt>";	

	if ( $ship->f("tractor_beam_player_id") <> 0 ) {
		$tractor_beam_player_id = $ship->f("tractor_beam_player_id");
		$db = new ME_DB;
		$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id, players.player_id, players.name from ships, sectors, players where ships.player_id = '$tractor_beam_player_id' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id");
		$db->next_record();

		echo "&nbsp;Locked on: " . stripslashes($db->f("name")) . "<br>";		
	}		

	echo "</td></tr><tr><td>";	
	echo "&nbsp;&nbsp;<input border=0 type=image src='./images/form/unlock-off.png' name=untractor_beam></td></tr></table></form>";
}

if ( $ship->f("deep_scanner") ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellspacing=2 cellpadding=1 border=0>";
	echo "<tr><td>";
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>Deep Space Scanner";
	echo "</font><br></td></tr><tr><td>";

	echo "</td></tr><tr><td>";
	echo "&nbsp;<input border=0 type=image src='./images/form/scan-off.png' name=deep_scan>";
	echo "</td></tr></table></form>";	
}

if ( $ship->f("trifocus_plasma") ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

	echo "<table width=350 cellspacing=4 cellpadding=1>";	
	echo "<tr><td>";
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>";
	echo "Tri-Focus Plasma";
	echo "</font><br></td></tr>";
	echo "<tr>";
	echo "<td class=clsNrmTxt>Select Target Type:<br>";
	echo "</td></tr><tr><td class=clsNrmTxt>";
	echo "&nbsp;&nbsp;<input type=radio name=target_type checked value=1>&nbsp;Merchant<br>";
	echo "&nbsp;&nbsp;<input type=radio name=target_type value=2>&nbsp;Forces";
	echo "</td></tr><tr><td class=clsNrmTxt>";
	echo "&nbsp;Target merchant:<br>";	
	echo "</td></tr><tr><td>";
	echo "&nbsp;<input type=textbox name=trifocus_target size=14><br>";	
	echo "</td></tr><tr><td class=clsNrmTxt>";
	echo "&nbsp;Target sector:<br>";
	echo "</td></tr><tr><td>";
	echo "&nbsp;<input type=textbox name=trifocus_sector size=14><br>";
	echo "</td></tr><tr><td class=clsNrmTxt>";

	if ( $ship->f("trifocus_fire_time") > time() - 30 ) {
		echo "&nbsp;That weapon will be prepared to fire in " . (string) ($ship->f("trifocus_fire_time") + 30 - time()) . " seconds.";
	} else {
		echo "&nbsp;<input border=0 type=image src='./images/form/fire-off.png' name=trifocus_fire>";
	}	

	echo "</td></tr></table></form>";
}

if ( $ship->f("battle_systems_computer") ) {
	echo "<form action=";
	echo $sess->url(URL . "ship_technology_update.php");
	echo " method=post>";

	echo "<table cellspacing=2>";
	echo "<tr><td>";
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>";
	echo "Battle Systems Computer";
	echo "</font><br></td></tr>";
	echo "</table></form>";
}
?>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table>
<br><?php

$megawatts = array();

$db = new ME_DB;
$db->query("select * from technology_types");

while (	$db->next_record() ) {
	$megawatts[$db->f("name")] = $db->f("megawatts");
	$additional_megawatts[$db->f("name")] = $db->f("additional_megawatts");
}

echo "<table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=#993300>";
echo "<table border=0 cellPadding=5 cellSpacing=1 width=500><tr><td class=clsHedTxt id=red1>";
echo "Powerplant Status</td></tr><tr><td class=clsNrmTxt>";

echo "<table width=500 cols=2><tr><th align=left><span class=clsNrmTxt>Module</span></th><th align=left><span class=clsNrmTxt>Megawatt Useage</span></th></tr>";

$megawatts_used = 0;

display_module($ship->f("cloak"), "Cloaking Device", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("illusion"), "Illusion Generator", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("jump"), "Jump Drive", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("scanner"), "Scanners", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("tracking"), "Tracking Device", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("deep_scanner"), "Deep Space Scanner", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("targeting_computer"), "Targeting Computer", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("active_screens"), "Active Screens", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("plasma_booster"), "Plasma Booster", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("tractor_beam"), "Tractor Beam", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("trifocus_plasma"), "Tri-Focus Plasma", $megawatts, $additional_megawatts, $megawatts_used);
display_module($ship->f("battle_systems_computer"), "Battle Systems Computer", $megawatts, $additional_megawatts, $megawatts_used);

echo "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>";

echo "<tr><td><span class=clsNrmTxt>Total Megawatt Demand</span></td>";
echo "<td>" . $megawatts_used . "</td></tr>";

echo "<tr><td><span class=clsNrmTxt>Current Megawatt Supply</span></td>";
echo "<td>" . $ship->f("powercurrent") . "</td></tr>";

if ( $megawatts_used > $ship->f("powercurrent") ) {
	echo "<tr><td><span class=clsNrmTxt>Megawatt Deficit</span></td>";
	echo "<td><font color=CC0000>" . ($megawatts_used - $ship->f("powercurrent")) . "</font></td></tr>";
} elseif ( $megawatts_used < $ship->f("powercurrent") ) {
	echo "<tr><td><span class=clsNrmTxt>Megawatt Surplus</span></td>";
	echo "<td><font color=33CC00>" . ($ship->f("powercurrent") - $megawatts_used) . "</font></td></tr>";
}

echo "</tr></td></table>";
echo "<br><br></td></tr></table></td></tr></table><br>";

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Your ship has no cloaking device.");
	} else if ($error == 2) {
		$db->add_parameter("message", "Your ship has no illusion generator.");
	} else if ($error == 3) {
		$db->add_parameter("message", "Attack and defense values must be greater than 0.");
	} else if ($error == 4) {
		$db->add_parameter("message", "The maximum attack and defense value is 30.");
	} else if ($error == 5) {
		$db->add_parameter("message", "You have no jump drive.");
	} else if ($error == 6) {
		$db->add_parameter("message", "Command not processed due to insufficient turns.");
	} else if ($error == 7) {
		$db->add_parameter("message", "That technology cannot be used from the surface of a planet.");
	} else if ($error == 8) {
		$db->add_parameter("message", "Jump drive malfunction due to warp inhibitor.");
	} else if ($error == 9) {
		$db->add_parameter("message", "Your ship type cannot jump to a different galaxy.");
	} else if ($error == 10) {
		$db->add_parameter("message", "Your ship does not have that technology installed.");
	} else if ($error == 11) {
		$db->add_parameter("message", "A merchant with that name or ID does not exist.");
	} else if ($error == 12) {
		$db->add_parameter("message", "Target merchant cannot be found in the current sector.");
	} else if ($error == 13) {
		$db->add_parameter("message", "Command not processed due to invalid value.");
	} else if ($error == 14) {
		$db->add_parameter("message", "That technology cannot be used while your ship is cloaked.");
	} else if ($error == 15) {
		$db->add_parameter("message", "Error occurred while performing a deep sector scan.");
	} else if ($error == 16) {
		$db->add_parameter("message", "Ship powerplant overloaded.");
	} else if ($error == 17) {
		$db->add_parameter("message", "There will be a short delay before that weapon is prepared to fire.");
	} else if ($error == 18) {
		$db->add_parameter("message", "The target cannot be found in that sector.");
	} else if ($error == 19) {
		$db->add_parameter("message", "The target is out of weapon range.");
	} else if ($error == 20) {
		$db->add_parameter("message", "The target merchant is currently under Protection.");
	} else if ($error == 21) {
		$db->add_parameter("message", "Jump drive malfunction due to presence of enemy mines.");
	} else if ($error == 22) {
		$db->add_parameter("message", "Insufficient forces found in target sector.");
	} else if ($error == 23) {
		$db->add_parameter("message", "That weapon cannot be used while your merchant is under protection.");
	} else if ($error == 24) {
		$db->add_parameter("message", "The target ship cannot be towed by your ship.");
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>