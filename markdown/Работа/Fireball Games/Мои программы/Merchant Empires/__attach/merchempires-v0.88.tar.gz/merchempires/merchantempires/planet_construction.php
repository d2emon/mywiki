<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function get_cargo_requirements($db) {
	$cargo_temp = explode(",", $db->f("cargo"));

	for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 2) {
		$cargo_requirements[$cargo_temp[$i]] = $cargo_temp[$i + 1];
	}		

	return $cargo_requirements;
}


function get_all_good_types() {
	$db_g = new ME_DB;
	$db_g->query("select * from good_types");

	while ( $db_g->next_record() ) {
		$all_good_types[$db_g->f("good_type_id")] = $db_g->f("name");
	}

	return $all_good_types;
}

?>

<html><head><title>Merchant Empires: Planet Construction</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$db_p = new ME_DB_Xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();

$db_st = new ME_DB;
$db_st->query("select * from planet_structure_types order by planet_structure_type_id");
	
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {
	$db_p->add_parameter("current_screen", "planet_construction");	
	echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());
?>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=500>
				<tr>
					<td class=clsHedTxt id=blu1>					
					Type
					</td>
					<td class=clsHedTxt id=blu1>
					Description
					</td>
					<td width=40 class=clsHedTxt id=blu1>
					Current
					</td>
					<td width=100 class=clsHedTxt id=blu1>
					Cost
					</td>
					<td class=clsHedTxt id=blu1>
					Action
					</td>
				</tr><?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("generatorcurrent") . "/" . $db_p->f("generatormax");
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}				
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("generatorcurrent") < $db_p->f("generatormax") )  {
		echo "<form name=form_build_1 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_1.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_1 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr><?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("hangarcurrent") . "/" . $db_p->f("hangarmax");
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}		
?>
					</td>	
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("hangarcurrent") < $db_p->f("hangarmax") )  {
		echo "<form name=form_build_2 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_2.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_2 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>
				</tr><?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("turretscurrent") . "/" . $db_p->f("turretsmax");
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}		
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("turretscurrent") < $db_p->f("turretsmax") )  {
		echo "<form name=form_build_3 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_3.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_3 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>


<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("warp_inhibitor") == 't' ) {
		echo "Installed";
	} else {
		echo "Not Installed";
	}
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}	
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("warp_inhibitor") == 'f' ) {
		echo "<form name=form_build_4 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_4.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_4 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>

	<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("scanner") == 't' ) {
		echo "Installed";
	} else {
		echo "Not Installed";
	}				
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}	
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("scanner") == 'f' ) {
		echo "<form name=form_build_5 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_5.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_5 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>

<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("storagecurrent") . "/" . $db_p->f("storagemax");		
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("storagecurrent") < $db_p->f("storagemax") ) {
		if ( $db_p->f("structure_type_id") == 0 )  {
			echo "<form name=form_build_7 action=";
			echo $sess->url(URL . "planet_update.php");
			echo " method=post>";
			echo "<a href='javascript:document.form_build_7.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
			echo "<input type=hidden name=build_7 value=Build></form>";
		} else {
			echo "&nbsp;";
		}
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>
				<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("trifocus_plasma") == 't' ) {
		echo "Installed";
	} else {
		echo "Not Installed";
	}	
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("trifocus_plasma") == 'f' )  {
		echo "<form name=form_build_8 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_8.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_8 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>

				<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("battle_management_control_unit") == 't' ) {
		echo "Installed";
	} else {
		echo "Not Installed";
	}	
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("battle_management_control_unit") == 'f' )  {
		echo "<form name=form_build_9 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_build_9.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
		echo "<input type=hidden name=build_9 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>

				<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_p->f("disruptor_missile_current") . "/" . $db_p->f("disruptor_missile_max");			
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("disruptor_missile_current") < $db_p->f("disruptor_missile_max") ) {
		if ( $db_p->f("structure_type_id") == 0 )  {
			echo "<form name=form_build_10 action=";
			echo $sess->url(URL . "planet_update.php");
			echo " method=post>";
			echo "<a href='javascript:document.form_build_10.submit()'><img border=0  src='./images/form/build-off.png'></a><br>";
			echo "<input type=hidden name=build_10 value=Build></form>";
		} else {
			echo "&nbsp;";
		}
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>

				<?php

	$db_st->next_record();
?>
				<tr>
        	<td class=clsNrmTxt><?php

	echo $db_st->f("type");
?>
					</td>
					<td class=clsNrmTxt><?php

	echo $db_st->f("description");
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("star_gate") == 't' ) {
		echo "Installed";
	} else {
		echo "Not Installed";
	}				
?>
					</td>
					<td class=clsNrmTxtSml><?php

	echo "Buildtime: " . $db_st->f("buildtime") . " hours<br>";
	echo "Cost: " . $db_st->f("credits"). "<br>";

	$all_good_types = get_all_good_types();							  		
	$cargo_requirements = get_cargo_requirements($db_st);
				
	while (list($key, $val) = each($all_good_types)) {
		while (list($key_2, $val_2) = each($cargo_requirements)) {
			if ( $key == $key_2 ) {
				echo $val_2 . " " . $val . "<br>";				
			}
		}

		reset($cargo_requirements);					
	}
?>
					</td>
					<td class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") == 0 and $db_p->f("star_gate") == 'f' )  {
		echo "<form name=form_build_11 action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<table cellspacing=1 cellpadding=1><tr><td class=clsNrmTxt>Linked sector:</td></tr><tr><td><input type=text name=star_gate_public_sector_id size=5></td></tr></table><br>";
		echo "<input type=image border=0  src='./images/form/build-off.png' name=build_11><br>";		
		echo "<input type=hidden name=build_11 value=Build></form>";
	} else {
		echo "&nbsp;";
	}
?>
					</td>	
				</tr>

				<tr>
        	<td colspan=5 class=clsNrmTxt><?php

	if ( $db_p->f("structure_type_id") <> 0 )  {
		$db = new ME_DB;
		$str = $db_p->f("structure_type_id");
		$db->query("select * from planet_structure_types where planet_structure_type_id = '$str'");
		$db->next_record();
		echo "<table><tr>";
		echo "<td width=50%>";
		echo "Building: " . $db->f("type") . "<br>";
		$comptime = $db_p->f("structure_completion_time");
		$currenttime = time();
		$d = ($comptime - $currenttime) / 3600;
		$g = ceil($d) - (($comptime - $currenttime) / 3600);

		if ( $comptime - $currenttime <= 0 ) {
			echo "Structure will be completed momentarily.";
		} else {
			if ($g == 0) {
				$minutes = "0";
			} else {
				$minutes = ((1 - $g) * 60) / 100;
				$minutes = substr($minutes, 2, 2);

		  	if ( strlen($minutes) == 1) {
	  			$minutes = $minutes . "0";
				}
			}

			echo "Completion time: " . floor($d) . " hours and " . $minutes . " minutes";
		}

		echo "</font></td>";
		echo "<td width=50% align=right>";
		echo "<form name=form_cancel action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post>";
		echo "<a href='javascript:document.form_cancel.submit()'><img border=0  src='./images/form/cancel-off.png'></a><br>";
		echo "<input type=hidden name=cancel_build value=Cancel></form>";
		echo "</td>";
		echo "</tr></table>";
	} else {
		echo "Building: Nothing.";
	}
?>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table>
<?php

} else {
	$error = 5;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to insufficient credits.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient goods.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "Command not processed due to insufficient drones on planet.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "Command not processed due to insufficient shields on planet.");			
	} elseif ($error == 5) {
		$db->add_parameter("message", "Your merchant is currently not landed on a planet.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "Command not processed due to insufficient planet capacity.");			
	} elseif ($error == 7) {
		$db->add_parameter("message", "Planet not found in target sector.");			
	} elseif ($error == 25) {
		$db->add_parameter("message", "Access to that functionality not allowed by planet owner.");			
	} elseif ($error == 26) {
		$db->add_parameter("message", "You must first cancel the current structure before you can build a different structure.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
