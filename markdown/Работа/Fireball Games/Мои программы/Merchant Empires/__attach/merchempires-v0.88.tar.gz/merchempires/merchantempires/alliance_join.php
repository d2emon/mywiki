<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Alliance Join</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
}

$alliance_id = (int) $alliance_id;
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "");	
echo $db->get_transform("./xslt/menu_top_alliance.xslt", "");

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	$db = new ME_DB;

	switch ($key) {
		case "join":				
     		$db->query("select * from alliances where alliance_id = '$alliance_id' and game_id = '$game_id'");				

				if ( $db->nf() > 0 ) {
        	$db->next_record();
					
					if ( $password == $db->f("password") )  {
						$alliance_name = addslashes($db->f("name"));

						$db_2 = new ME_DB;
						$db_2->query("update players set alliance_id = '$alliance_id', alliance_name = '$alliance_name' where player_id = '$player_id'");	

						# reset the player's forces to the alliance					
						$db_2->query("update forces set alliance_id = '$alliance_id', alliance_name = '$alliance_name' where player_id = '$player_id'");

						# reset the player's planet to the alliance			
						$db_2->query("update planets set alliance_id = '$alliance_id' where owner_id = '$player_id'");

						#merge maps
						$db_p = new ME_DB;
						$query = sprintf("select * from player_maps where player_id = '%s'", $player->f("player_id"));
						$db_p->query($query);
						$db_p->next_record();

						$db_a = new ME_DB;
						$db_a->query("select * from alliance_maps where alliance_id = '$alliance_id'");
						$db_a->next_record();

						$db = new ME_DB;
						$query = sprintf("select * from maps where game_id = '$game_id' order by map_rank");
						$db->query($query);
						$db->next_record();

						$map_1_id = $db->f("map_id");
						$map_1_array = array();						
						$db->next_record();
						$map_2_id = $db->f("map_id");
						$map_2_array = array();
						$db->next_record();
						$map_3_id = $db->f("map_id");
						$map_3_array = array();
						$db->next_record();
						$map_4_id = $db->f("map_id");
						$map_4_array = array();
						$db->next_record();
						$map_5_id = $db->f("map_id");
						$map_5_array = array();
						$db->next_record();
						$map_6_id = $db->f("map_id");
						$map_6_array = array();
						$db->next_record();
						$map_7_id = $db->f("map_id");
						$map_7_array = array();	
						$db->next_record();
						$map_8_id = $db->f("map_id");
						$map_8_array = array();
     				
						$map_1_array = explode(",", $db_a->f("map_1"));
						$map_2_array = explode(",", $db_a->f("map_2"));
						$map_3_array = explode(",", $db_a->f("map_3"));
						$map_4_array = explode(",", $db_a->f("map_4"));
						$map_5_array = explode(",", $db_a->f("map_5"));
						$map_6_array = explode(",", $db_a->f("map_6"));
						$map_7_array = explode(",", $db_a->f("map_7"));
						$map_8_array = explode(",", $db_a->f("map_8"));

						if ( strlen($db_p->f("map_1")) > 0 ) {
							$player_map_1 = array();
							$player_map_1 = explode(",", $db_p->f("map_1"));	
      			
							for ($i = 0; $i <= count($player_map_1) - 1; $i++) {
								if ( ! (in_array($player_map_1[$i], $map_1_array)) ) {
									array_push($map_1_array, $player_map_1[$i]);
								}
							}
						}				

						if ( strlen($db_p->f("map_2")) > 0 ) {
							$player_map_2 = array();
							$player_map_2 = explode(",", $db_p->f("map_2"));	
      			
							for ($i = 0; $i <= count($player_map_2) - 1; $i++) {
								if ( ! (in_array($player_map_2[$i], $map_2_array)) ) {
									array_push($map_2_array, $player_map_2[$i]);
								}
							}
						}

						if ( strlen($db_p->f("map_3")) > 0 ) {
							$player_map_3 = array();
							$player_map_3 = explode(",", $db_p->f("map_3"));	
      			
							for ($i = 0; $i <= count($player_map_3) - 1; $i++) {
								if ( ! (in_array($player_map_3[$i], $map_3_array)) ) {
									array_push($map_3_array, $player_map_3[$i]);
								}
							}
						}

						if ( strlen($db_p->f("map_4")) > 0 ) {
							$player_map_4 = array();
							$player_map_4 = explode(",", $db_p->f("map_4"));	
      			
							for ($i = 0; $i <= count($player_map_4) - 1; $i++) {
								if ( ! (in_array($player_map_4[$i], $map_4_array)) ) {
									array_push($map_4_array, $player_map_4[$i]);
								}
							}
						}

						if ( strlen($db_p->f("map_5")) > 0 ) {
							$player_map_5 = array();
							$player_map_5 = explode(",", $db_p->f("map_5"));	
      			
							for ($i = 0; $i <= count($player_map_5) - 1; $i++) {
								if ( ! (in_array($player_map_5[$i], $map_5_array)) ) {
									array_push($map_5_array, $player_map_5[$i]);
								}
							}
						}

						if ( strlen($db_p->f("map_6")) > 0 ) {
							$player_map_6 = array();
							$player_map_6 = explode(",", $db_p->f("map_6"));	
      			
							for ($i = 0; $i <= count($player_map_6) - 1; $i++) {
								if ( ! (in_array($player_map_6[$i], $map_6_array)) ) {
									array_push($map_6_array, $player_map_6[$i]);
								}
							}
						}

						if ( strlen($db_p->f("map_7")) > 0 ) {
							$player_map_7 = array();
							$player_map_7 = explode(",", $db_p->f("map_7"));	
      			
							for ($i = 0; $i <= count($player_map_7) - 1; $i++) {
								if ( ! (in_array($player_map_7[$i], $map_7_array)) ) {
									array_push($map_7_array, $player_map_7[$i]);
								}
							}
						}

						if ( strlen($db_p->f("map_8")) > 0 ) {
							$player_map_8 = array();
							$player_map_8 = explode(",", $db_p->f("map_8"));	
      			
							for ($i = 0; $i <= count($player_map_8) - 1; $i++) {
								if ( ! (in_array($player_map_8[$i], $map_8_array)) ) {
									array_push($map_8_array, $player_map_8[$i]);
								}
							}
						}

						if ( count($map_1_array) > 0 ) {
							$new_map_1 = implode (",", $map_1_array);
						}
			
						if ( count($map_2_array) > 0 ) {
							$new_map_2 = implode (",", $map_2_array);
						}

						if ( count($map_3_array) > 0 ) {
							$new_map_3 = implode (",", $map_3_array);
						}
	
						if ( count($map_4_array) > 0 ) {
							$new_map_4 = implode (",", $map_4_array);
						}

						if ( count($map_5_array) > 0 ) {
							$new_map_5 = implode (",", $map_5_array);
						}

						if ( count($map_6_array) > 0 ) {
							$new_map_6 = implode (",", $map_6_array);
						}

						if ( count($map_7_array) > 0 ) {
							$new_map_7 = implode (",", $map_7_array);
						}

						if ( count($map_8_array) > 0 ) {
							$new_map_8 = implode (",", $map_8_array);
						}

						$query = "update alliance_maps set map_1 = '$new_map_1', map_2 = '$new_map_2', map_3 = '$new_map_3',
							map_4 = '$new_map_4', map_5 = '$new_map_5', map_6 = '$new_map_6', map_7 = '$new_map_7',
							map_8 = '$new_map_8', map_1_id = '$map_1_id', map_2_id = '$map_2_id', map_3_id = '$map_3_id',
							map_4_id = '$map_4_id', map_5_id = '$map_5_id', map_6_id = '$map_6_id', map_7_id = '$map_7_id',
							map_8_id = '$map_8_id' where alliance_id = '$alliance_id'";
						$db->query($query);			

						$db = new ME_DB_Xml;
						$db->add_parameter("title", "Success");
						$db->add_parameter("message", "You have joined " . $alliance_name . ".");
						echo $db->get_transform("./xslt/message_box.xslt", "");

						break;	
					} else {
						$db = new ME_DB_Xml;
						$db->add_parameter("title", "Error");
						$db->add_parameter("message", "Incorrect Password");
						echo $db->get_transform("./xslt/message_box.xslt", "");
					}
				} else {
					$db = new ME_DB_Xml;
					$db->add_parameter("title", "Error");
					$db->add_parameter("message", "You cannot join an alliance in a different game.");
					echo $db->get_transform("./xslt/message_box.xslt", "");
				}
 	}
}

?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
