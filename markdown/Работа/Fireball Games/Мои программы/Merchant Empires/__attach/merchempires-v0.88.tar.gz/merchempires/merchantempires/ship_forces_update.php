<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$public_sector_id = $ship->f("public_sector_id");

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "drop":
			$returnto = "ship_forces";

			$amount_scout = (int) $amount_scout;
			$amount_combat = (int) $amount_combat;
			$amount_mines = (int) $amount_mines;

  		$db = new ME_DB;
			$query = sprintf("SELECT location_id from locations where sector_id = '%s'", $ship->f("sector_id"));
			$db->query($query);

			if ( $db->nf() > 0 ) {
				$error = 4;
				break;	
			}

			$db_f = new ME_DB;
			$db_f->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
			$db_f->next_record();

			$amount_scout_sector = $amount_scout + $db_f->f("scout");
			$amount_combat_sector = $amount_combat + $db_f->f("combat");
			$amount_mines_sector = $amount_mines + $db_f->f("mine");
			
			if ( $amount_scout_sector > 10 or $amount_combat_sector > 50 or $amount_mines_sector > 50 ) {
				$error = 7;
				break;	
			}			

			if ( $amount_mines < 0 or $amount_combat < 0 or $amount_scout < 0 ) {
				$error = 5;
				break;
			}
			
			if ( $amount_mines > 0 ) {
				if ( $amount_mines > $ship->f("minescurrent") ) {										
	      	$error = 1;
					break;	
      	}

				$new_mines = $ship->f("minescurrent") - $amount_mines;
				$ship->set_minescurrent($new_mines);
			}

			if ( $amount_combat > 0 ) {
				if ( $amount_combat > $ship->f("combatcurrent") ) {
	      	$error = 1;
					break;	
      	}
			
				$new_combat = $ship->f("combatcurrent") - $amount_combat;
				$ship->set_combatcurrent($new_combat);
			}

			if ( $amount_scout > 0 ) {
				if ( $amount_scout > $ship->f("scoutcurrent") ) {
	      	$error = 1;
					break;	
      	}

				$new_scout = $ship->f("scoutcurrent") - $amount_scout;
				$ship->set_scoutcurrent($new_scout);
			}

			$ship->save();
			
			if ( $player->f("newturnsleft") > 0 ) {
				$player->set_new_turns_left(0);
				$player->save();			
			}

			$player_name = addslashes($player->f("name"));
			$public_player_id = $player->f("public_player_id");
      $alliance_id = $player->f("alliance_id");
			$alliance_name = addslashes($player->f("alliance_name"));			

			if ( $db_f->nf() >  0 ) {				
				$query = "update forces set sector_id = '$sector_id', player_id = '$player_id',
					player_name = '$player_name', scout = '$amount_scout_sector', combat = '$amount_combat_sector',
					mine = '$amount_mines_sector' where player_id = '$player_id' and sector_id = '$sector_id'";
				$db_f->query($query);

				if ( $amount_mines > 0 ) {
					$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
					$db_f->query($query);
				}
			} else {
    		$expiration = time() + 1209600;

				if ( $amount_combat_sector > 0 or $amount_scout_sector > 0 or $amount_mines_sector > 0 ) {
					$query = "insert into forces (sector_id, player_id, player_name, scout,
							combat, mine, expiration, alliance_id, alliance_name, public_player_id,
							public_sector_id) values ('$sector_id', '$player_id', '$player_name', '$amount_scout_sector',
							'$amount_combat_sector', '$amount_mines_sector', '$expiration', '$alliance_id', '$alliance_name',
							'$public_player_id', '$public_sector_id')";
					$db_f->query($query);
				}

				if ( $amount_mines > 0 ) {
					$query = "update ships set last_move_sector_id = 0 where sector_id = '$sector_id' and player_id <> '$player_id'";
					$db_f->query($query);
				}
			}

			break;

		case "take":
			$returnto = "ship_forces";

			$amount_scout = (int) $amount_scout;
			$amount_combat = (int) $amount_combat;
			$amount_mines = (int) $amount_mines;
  		
			$db = new ME_DB;
			$db->query("SELECT * from forces where sector_id = '$sector_id' and player_id = '$player_id'");
			$db->next_record();

			if ( ! ($db->nf() > 0) ) {
				$error = 3;
				break;
			}

			if ( $amount_mines + $ship->f("minescurrent") > $ship->f("minesmax") ) {
				$error = 6;
				break;
			}

			if ( $amount_combat + $ship->f("combatcurrent") > $ship->f("combatmax") ) {
				$error = 6;
				break;
			}

			if ( $amount_scout + $ship->f("scoutcurrent") > $ship->f("scoutmax") ) {
				$error = 6;
				break;
			}

			if ( $amount_mines < 0 or $amount_combat < 0 or $amount_scout < 0 ) {
				$error = 5;
				break;
			}

			if ( $amount_mines > 0 ) {
				if ( $amount_mines > $db->f("mine") ) {
	      	$error = 2;
					break;	
      	}

				$new_mines = $ship->f("minescurrent") + $amount_mines;
				$ship->set_minescurrent($new_mines);
			}

			if ( $amount_combat > 0 ) {
				if ( $amount_combat > $db->f("combat") ) {
	      	$error = 2;
					break;	
      	}
		
				$new_combat = $ship->f("combatcurrent") + $amount_combat;
				$ship->set_combatcurrent($new_combat);
			}

			if ( $amount_scout > 0 ) {
				if ( $amount_scout > $db->f("scout") ) {
	      	$error = 2;
					break;	
      	}

				$new_scout = $ship->f("scoutcurrent") + $amount_scout;
				$ship->set_scoutcurrent($new_scout);
			}

			$ship->save();

			if ( $db->nf() >  0 ) {
				$amount_scout = $db->f("scout") - $amount_scout;
				$amount_combat = $db->f("combat") - $amount_combat;
				$amount_mines = $db->f("mine") - $amount_mines;	
				$forces_id = $db->f("forces_id");

				if ( $amount_scout == 0 and $amount_combat == 0 and $amount_mines == 0 ) {
					$query = "delete from forces where forces_id = '$forces_id'";
					$db->query($query);
				} else {
					$query = "update forces set scout = '$amount_scout', combat = '$amount_combat',
						mine = '$amount_mines' where forces_id = '$forces_id'";
					$db->query($query);
				}
			}

			break;
	}
}

if ( $error ) {
	if ($returnto == "ship_forces")  {
		$newurl = $sess->url(URL . "ship_forces.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "ship_forces")  {
		$newurl = $sess->url(URL . "ship_forces.php");
		header("Location: $newurl");	
	}
}

page_close();
?>