<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/weapons.php");
include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function get_next_weapon_down($id, $weapons) {

	while (list($key, $val) = each($weapons->Current_weapons)) {
		if ( $key > $id ) {
			$next_weapon = $key;
			break;
		}
	}

	return $next_weapon;
}

function get_next_weapon_up($id, $weapons) {

	while (list($key, $val) = each($weapons->Current_weapons)) {
		if ( $key < $id ) {
			$next_weapon = $key;
		}
	}

	return $next_weapon;
}

function switch_weapons($id, $next_weapon, &$weapons) {

switch ($id) {
	case "1":	
		$first_id = $weapons->f("weapon_1_id");
		$first_name = $weapons->f("weapon_1_name");
		$first_shield_damage = $weapons->f("weapon_1_shield_damage");
		$first_armor_damage = $weapons->f("weapon_1_armor_damage");
		break;
	case "2":	
		$first_id = $weapons->f("weapon_2_id");
		$first_name = $weapons->f("weapon_2_name");
		$first_shield_damage = $weapons->f("weapon_2_shield_damage");
		$first_armor_damage = $weapons->f("weapon_2_armor_damage");
		break;
	case "3":	
		$first_id = $weapons->f("weapon_3_id");
		$first_name = $weapons->f("weapon_3_name");
		$first_shield_damage = $weapons->f("weapon_3_shield_damage");
		$first_armor_damage = $weapons->f("weapon_3_armor_damage");
		break;
	case "4":	
		$first_id = $weapons->f("weapon_4_id");
		$first_name = $weapons->f("weapon_4_name");
		$first_shield_damage = $weapons->f("weapon_4_shield_damage");
		$first_armor_damage = $weapons->f("weapon_4_armor_damage");
		break;
	case "5":	
		$first_id = $weapons->f("weapon_5_id");
		$first_name = $weapons->f("weapon_5_name");
		$first_shield_damage = $weapons->f("weapon_5_shield_damage");
		$first_armor_damage = $weapons->f("weapon_5_armor_damage");
		break;
	case "6":	
		$first_id = $weapons->f("weapon_6_id");
		$first_name = $weapons->f("weapon_6_name");
		$first_shield_damage = $weapons->f("weapon_6_shield_damage");
		$first_armor_damage = $weapons->f("weapon_6_armor_damage");
		break;
	case "7":	
		$first_id = $weapons->f("weapon_7_id");
		$first_name = $weapons->f("weapon_7_name");
		$first_shield_damage = $weapons->f("weapon_7_shield_damage");
		$first_armor_damage = $weapons->f("weapon_7_armor_damage");
		break;
	case "8":	
		$first_id = $weapons->f("weapon_8_id");
		$first_name = $weapons->f("weapon_8_name");
		$first_shield_damage = $weapons->f("weapon_8_shield_damage");
		$first_armor_damage = $weapons->f("weapon_8_armor_damage");
		break;
}

switch ($next_weapon) {
	case "1":	
		$second_id = $weapons->f("weapon_1_id");
		$second_name = $weapons->f("weapon_1_name");
		$second_shield_damage = $weapons->f("weapon_1_shield_damage");
		$second_armor_damage = $weapons->f("weapon_1_armor_damage");
		break;
	case "2":	
		$second_id = $weapons->f("weapon_2_id");
		$second_name = $weapons->f("weapon_2_name");
		$second_shield_damage = $weapons->f("weapon_2_shield_damage");
		$second_armor_damage = $weapons->f("weapon_2_armor_damage");
		break;
	case "3":
		$second_id = $weapons->f("weapon_3_id");
		$second_name = $weapons->f("weapon_3_name");
		$second_shield_damage = $weapons->f("weapon_3_shield_damage");
		$second_armor_damage = $weapons->f("weapon_3_armor_damage");
		break;
	case "4":
		$second_id = $weapons->f("weapon_4_id");
		$second_name = $weapons->f("weapon_4_name");
		$second_shield_damage = $weapons->f("weapon_4_shield_damage");
		$second_armor_damage = $weapons->f("weapon_4_armor_damage");
		break;
	case "5":
		$second_id = $weapons->f("weapon_5_id");
		$second_name = $weapons->f("weapon_5_name");
		$second_shield_damage = $weapons->f("weapon_5_shield_damage");
		$second_armor_damage = $weapons->f("weapon_5_armor_damage");
		break;
	case "6":
		$second_id = $weapons->f("weapon_6_id");
		$second_name = $weapons->f("weapon_6_name");
		$second_shield_damage = $weapons->f("weapon_6_shield_damage");
		$second_armor_damage = $weapons->f("weapon_6_armor_damage");
		break;
	case "7":
		$second_id = $weapons->f("weapon_7_id");
		$second_name = $weapons->f("weapon_7_name");
		$second_shield_damage = $weapons->f("weapon_7_shield_damage");
		$second_armor_damage = $weapons->f("weapon_7_armor_damage");
		break;
	case "8":
		$second_id = $weapons->f("weapon_8_id");
		$second_name = $weapons->f("weapon_8_name");
		$second_shield_damage = $weapons->f("weapon_8_shield_damage");
		$second_armor_damage = $weapons->f("weapon_8_armor_damage");
		break;
}

switch ($id) {
	case "1":	
		$weapons->set_weapon_1_id($second_id);
		$weapons->set_weapon_1_name($second_name);
		$weapons->set_weapon_1_shield_damage($second_shield_damage);	
		$weapons->set_weapon_1_armor_damage($second_armor_damage);		
		break;
	case "2":	
		$weapons->set_weapon_2_id($second_id);
		$weapons->set_weapon_2_name($second_name);
		$weapons->set_weapon_2_shield_damage($second_shield_damage);	
		$weapons->set_weapon_2_armor_damage($second_armor_damage);	
		break;
	case "3":	
		$weapons->set_weapon_3_id($second_id);
		$weapons->set_weapon_3_name($second_name);
		$weapons->set_weapon_3_shield_damage($second_shield_damage);	
		$weapons->set_weapon_3_armor_damage($second_armor_damage);	
		break;
	case "4":	
		$weapons->set_weapon_4_id($second_id);
		$weapons->set_weapon_4_name($second_name);
		$weapons->set_weapon_4_shield_damage($second_shield_damage);	
		$weapons->set_weapon_4_armor_damage($second_armor_damage);	
		break;
	case "5":	
		$weapons->set_weapon_5_id($second_id);
		$weapons->set_weapon_5_name($second_name);
		$weapons->set_weapon_5_shield_damage($second_shield_damage);	
		$weapons->set_weapon_5_armor_damage($second_armor_damage);	
		break;
	case "6":	
		$weapons->set_weapon_6_id($second_id);
		$weapons->set_weapon_6_name($second_name);
		$weapons->set_weapon_6_shield_damage($second_shield_damage);	
		$weapons->set_weapon_6_armor_damage($second_armor_damage);	
		break;
	case "7":	
		$weapons->set_weapon_7_id($second_id);
		$weapons->set_weapon_7_name($second_name);
		$weapons->set_weapon_7_shield_damage($second_shield_damage);	
		$weapons->set_weapon_7_armor_damage($second_armor_damage);	
		break;
	case "8":	
		$weapons->set_weapon_8_id($second_id);
		$weapons->set_weapon_8_name($second_name);
		$weapons->set_weapon_8_shield_damage($second_shield_damage);	
		$weapons->set_weapon_8_armor_damage($second_armor_damage);	
		break;
}

switch ($next_weapon) {
	case "1":	
		$weapons->set_weapon_1_id($first_id);
		$weapons->set_weapon_1_name($first_name);
		$weapons->set_weapon_1_shield_damage($first_shield_damage);	
		$weapons->set_weapon_1_armor_damage($first_armor_damage);	
		break;
	case "2":	
		$weapons->set_weapon_2_id($first_id);
		$weapons->set_weapon_2_name($first_name);
		$weapons->set_weapon_2_shield_damage($first_shield_damage);	
		$weapons->set_weapon_2_armor_damage($first_armor_damage);	
		break;
	case "3":
		$weapons->set_weapon_3_id($first_id);
		$weapons->set_weapon_3_name($first_name);
		$weapons->set_weapon_3_shield_damage($first_shield_damage);	
		$weapons->set_weapon_3_armor_damage($first_armor_damage);	
		break;
	case "4":
		$weapons->set_weapon_4_id($first_id);
		$weapons->set_weapon_4_name($first_name);
		$weapons->set_weapon_4_shield_damage($first_shield_damage);	
		$weapons->set_weapon_4_armor_damage($first_armor_damage);	
		break;
	case "5":
		$weapons->set_weapon_5_id($first_id);
		$weapons->set_weapon_5_name($first_name);
		$weapons->set_weapon_5_shield_damage($first_shield_damage);	
		$weapons->set_weapon_5_armor_damage($first_armor_damage);	
		break;
	case "6":
		$weapons->set_weapon_6_id($first_id);
		$weapons->set_weapon_6_name($first_name);
		$weapons->set_weapon_6_shield_damage($first_shield_damage);	
		$weapons->set_weapon_6_armor_damage($first_armor_damage);	
		break;
	case "7":
		$weapons->set_weapon_7_id($first_id);
		$weapons->set_weapon_7_name($first_name);
		$weapons->set_weapon_7_shield_damage($first_shield_damage);	
		$weapons->set_weapon_7_armor_damage($first_armor_damage);	
		break;
	case "8":
		$weapons->set_weapon_8_id($first_id);
		$weapons->set_weapon_8_name($first_name);
		$weapons->set_weapon_8_shield_damage($first_shield_damage);	
		$weapons->set_weapon_8_armor_damage($first_armor_damage);	
		break;
}

$weapons->save();

}

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);

$error = 0;

$weapons = new ME_Weapons;
$weapons->get_weapons($ship->f("ship_id"));

switch ($action) {
		case "1d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(1, $weapons);
			switch_weapons(1, $next_weapon, $weapons);
			break;
		case "2d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(2, $weapons);
			switch_weapons(2, $next_weapon, $weapons);
			break;
		case "3d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(3, $weapons);
			switch_weapons(3, $next_weapon, $weapons);
			break;
		case "4d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(4, $weapons);
			switch_weapons(4, $next_weapon, $weapons);
			break;
		case "5d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(5, $weapons);
			switch_weapons(5, $next_weapon, $weapons);
			break;
		case "6d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(6, $weapons);
			switch_weapons(6, $next_weapon, $weapons);
			break;
		case "7d":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_down(7, $weapons);
			switch_weapons(7, $next_weapon, $weapons);
			break;	
		case "2u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(2, $weapons);
			switch_weapons(2, $next_weapon, $weapons);
			break;	
		case "3u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(3, $weapons);
			switch_weapons(3, $next_weapon, $weapons);
			break;	
		case "4u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(4, $weapons);
			switch_weapons(4, $next_weapon, $weapons);
			break;	
		case "5u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(5, $weapons);
			switch_weapons(5, $next_weapon, $weapons);
			break;	
		case "6u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(6, $weapons);
			switch_weapons(6, $next_weapon, $weapons);
			break;
		case "7u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(7, $weapons);
			switch_weapons(7, $next_weapon, $weapons);
			break;	
		case "8u":
			$returnto = "ship_weapons";
			$next_weapon = get_next_weapon_up(8, $weapons);
			switch_weapons(8, $next_weapon, $weapons);
			break;		
}

if ( $error ) {
	if ($returnto == "ship_weapons")  {
		$newurl = $sess->url(URL . "ship_weapons.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "ship_weapons")  {
		$newurl = $sess->url(URL . "ship_weapons.php");
		header("Location: $newurl");	
	}
}

page_close();
?>