<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Player_config extends ME_DB {
	var $id = 0;	

  function get_player_config($id) {
		$this->connect();
		$query = sprintf("select player_config_id, player_id, hot_list, cloaked_combat, group_combat_ships, group_combat_planets, group_combat_forces, map_size, ignore_newbie, post_trade_screen from player_config where player_id = '%s'", $id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();

		$this->id = $this->f("player_config_id");		 							
		
    return $this->Query_ID;
  }

  function get_new_player_config($this_player_id) {
  	$this->connect();
  	$query = "insert into player_config (player_id) values ('$this_player_id')";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   			
   	$db = new ME_DB;
		$db->query("select * from player_config_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;
	
	  $query = sprintf("select * from player_config where player_config_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
					
		$this->next_record();	
   	return $this->Query_ID;
  }

  function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update player_config set ";
			$i = 1;

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}
			
				$i++;
			}
					
			$str = $str . " where player_config_id = '$this->id'";		
			$db->query($str);
		
			$this->dirty_fields = array();
		}
  }

  function set_hot_list($n) {
		$this->dirty_fields["hot_list"] = $n;	
  }

	function set_cloaked_combat($n) {
		$this->dirty_fields["cloaked_combat"] = $n;	
  }

	function set_group_combat_planets($n) {
		$this->dirty_fields["group_combat_planets"] = $n;	
  }

	function set_group_combat_forces($n) {
		$this->dirty_fields["group_combat_forces"] = $n;	
  }

	function set_group_combat_ships($n) {
		$this->dirty_fields["group_combat_ships"] = $n;	
  }

	function set_map_size($n) {
		$this->dirty_fields["map_size"] = $n;	
  }

	function set_ignore_newbie($n) {
		$this->dirty_fields["ignore_newbie"] = $n;	
  }

	function set_post_trade_screen($n) {
		$this->dirty_fields["post_trade_screen"] = $n;	
  }
 }
?>