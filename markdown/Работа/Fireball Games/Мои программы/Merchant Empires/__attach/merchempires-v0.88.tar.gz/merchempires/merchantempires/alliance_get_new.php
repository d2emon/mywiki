<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Create Alliance</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
} else {
	$alliance_id = -1;
}
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5>CREATE ALLIANCE</font>
								</td>
							</tr>
							<tr>
								<td><?php
	echo "<a href=";
	echo $sess->url(URL . "alliance.php");
	echo "><img alt='Alliance Status' border=0 src='./images/submenu/alliancestatus-off.png'>";
?>								
								</td>
								<td width=30><?php
  if ( $alliance_id <> -1 )  {
		echo "<a href=";
		echo $sess->url(URL . "send_messages_alliance.php") . "?alliance=" . $alliance_id;
		echo "><img alt='Alliance Message' border=0 src='./images/submenu/alliancemessage-off.png'>";
	} else {
  	echo "<img border=0 src='./images/submenu/alliancemessage-grey.png'>"; 	
	}
?>														
								</td>
								<td><a href=<?php
echo $sess->url(URL . "alliance_list.php");
?>
									><img alt="Alliance List" border=0 src="./images/submenu/alliancelist-off.png">
								</td>
								<td align=left><?php

if ( $player->f("alliance_id") == $alliance_id ) {
	echo "<a href=";
	echo $sess->url(URL . "alliance_planets.php");
	echo "><img alt='Alliance Planets' border=0 src='./images/submenu/allianceplanets-off.png'>";
} else {
	echo "<img alt='Alliance Planets' border=0 src='./images/submenu/allianceplanets-grey.png'>";
}
?>								
								</td>
								<td><?php

if ( $player->f("alliance_id") == $alliance_id ) {
	echo "<a href=";
	echo $sess->url(URL . "alliance_forces.php");
	echo "><img alt='Alliance Forces' border=0 src='./images/submenu/allianceforces-off.png'>";
} else {
	echo "<img alt='Alliance Forces' border=0 src='./images/submenu/allianceforces-grey.png'>";
}
?>								
								</td>
								<td>
									<img src="./images/submenu/allianceoptions-grey.png">			
								</td>
								<td><?php

if ( $player->f("alliance_id") == $alliance_id ) {
	echo "<a href=";
	echo $sess->url(URL . "alliance_politics.php");
	echo "><img alt='Alliance Politics' border=0 src='./images/submenu/alliancepolitics-off.png'>";
} else {
	echo "<img alt='Alliance Politics' border=0 src='./images/submenu/alliancepolitics-grey.png'>";
}

?>							
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br>
<table border=0 cellPadding=0 cellSpacing=0 width=450>
	<tr>
  	<td bgColor=#003399>
    	<table border=0 cellPadding=5 cellSpacing=1 width=450>
      	<tr>
        	<td bgColor=#000033><FONT color=#ffffff  face=arial,helvetica,swiss size=4><B>Form an alliance
          	</B></FONT><BR clear=all>
          </td>
	    	</tr>
        <tr>
        	<td bgColor=#000000><FONT  color=#cccccc face=arial,helvetica,swiss size=2>
						<form METHOD="POST" ACTION=<?php $sess->purl(URL . "alliance_create.php") ?>>
						<table>
		   				<tr>
		   					<td>Alliance name:</td>
  		   				<td><input type="textbox" name="name"></td>	
		   				</tr>
							<tr>
		   					<td>Description:</td>
  		   					<td><textarea rows=4 cols=40 name="description"></textarea></td>	
		   				</tr>
							<tr>
  		   				<td>Password:</td>
  		   				<td><input type="password" name="password"></td>
		   				</tr>
							<tr>
		   					<td></td>
 		   					<td><input type="submit" name="create_alliance" value="Form"></td>
		   				</tr>
							<tr>
		   					<td></td>
 		   					<td><FONT  color=#cccccc face=arial,helvetica,swiss size=2>As the alliance leader you will have the ability to configure
								a number of parameters for your alliance (removing members, creating an alliance bank account, etc.)
								You may view these parameters under the alliance options screen.</font>
								</td>
		   				</tr>
		   			</table>
		   			</form>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table>
<br>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
