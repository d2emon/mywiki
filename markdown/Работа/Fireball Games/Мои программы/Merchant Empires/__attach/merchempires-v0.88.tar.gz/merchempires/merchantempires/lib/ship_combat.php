<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

function get_targeting_bonus($targeting_computer) {
	if ( $targeting_computer == 1 ) {
		return 4;
	} elseif ( $targeting_computer == 2 ) {
		return 6;
	} elseif ( $targeting_computer == 3 ) {
		return 8;
	} elseif ( $targeting_computer == 4 ) {
		return 10;
	}
}

function get_damage_bonus($plasma_booster) {
	if ( $plasma_booster == 1 ) {
		return 5;
	} elseif ( $plasma_booster == 2 ) {
		return 7;
	} elseif ( $plasma_booster == 3 ) {
		return 9;
	} elseif ( $plasma_booster == 4 ) {
		return 11;
	}
}

?>