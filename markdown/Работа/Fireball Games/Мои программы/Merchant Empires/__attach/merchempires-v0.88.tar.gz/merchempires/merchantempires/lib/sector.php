<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Sector extends ME_DB {
  function get_sector($id) {
		$this->connect();		
		$query = sprintf("select ships.player_id, ships.sector_id, sectors.* from ships, sectors where ships.player_id='$id' and ships.sector_id = sectors.sector_id");		
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
    }
	
		$this->next_record();
   	return $this->Query_ID;
  }

  function get_offset_sector($map_id, $xpos, $ypos)  {
		$this->connect();
		$query = sprintf("select * from sectors where xpos = '%s'
		and ypos = '%s' and map_id = '%s'", $xpos, $ypos, $map_id); 
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
    	$this->halt("Invalid SQL: ".$Query_String);
    }
	
		$this->next_record();
  	return $this->Query_ID;
  }
}
?>
