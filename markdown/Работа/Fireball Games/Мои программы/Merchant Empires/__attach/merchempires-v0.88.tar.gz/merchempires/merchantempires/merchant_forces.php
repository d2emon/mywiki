<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Merchant Forces</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "merchant");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "merchant_forces");	
echo $db->get_transform("./xslt/menu_top_merchant.xslt", "");

$sector_id = $ship->f("sector_id");
$db = new ME_DB;
$db->query("SELECT * from forces where player_id = '$player_id' order by sector_id");

?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td class=clsHedTxt id=blu1 align=center>
					Sector
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Combat Drones
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Scout Drones
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Mines
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Expiration
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Target
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Repulsion
					</td>
					<td class=clsHedTxt id=blu1 align=center>
					Action
					</td>
				</tr><?php

while ( $db->next_record() ) {
	echo "<tr>";
	echo "<td class=clsNrmTxt align=center>" . $db->f("public_sector_id") . "</td>";

	echo "<td class=clsNrmTxt align=center>" . $db->f("combat") . "</td>";

	echo "<td class=clsNrmTxt align=center>" . $db->f("scout") . "</td>";

	echo "<td class=clsNrmTxt align=center>" . $db->f("mine") . "</td>";

	echo "<td class=clsNrmTxt align=center>" . date ("m/d/y H:i:s", $db->f("expiration")) . "</td>";		

	echo "<td class=clsNrmTxt align=center>";

	if ( $db->f("focused_alliance_id") <> 0 ) {
		echo "Alliance: " . $db->f("focused_alliance_name");	
	} else {
		if ( $db->f("focused_player_id") <> 0 ) {
			echo "Merchant: " . $db->f("focused_player_name");	
		} else {
			echo "---";
		}
	}

	echo "</td>";

	echo "<td class=clsNrmTxt align=center>" . $db->f("repulsion") . "</td>";

	echo "<td class=clsNrmTxt align=center>";

	echo "<table cellpadding=0 cellspacing=0><tr><td class=clsNrmTxt align=center>";
	echo "<a href=";
	echo $sess->url(URL . "merchant_update.php");
	echo "?id=" . $db->f("forces_id") . "&action=self_destruct>Self Destruct</a><br>";

	echo "<a href=";
	echo $sess->url(URL . "merchant_forces_target.php?id=" . $db->f("forces_id"));
	echo ">Target</a><br>";

	if ( $db->f("mine") > 19 and $db->f("repulsion") == 'f' ) {
		echo "<a href=";
		echo $sess->url(URL . "merchant_update.php");
		echo "?id=" . $db->f("forces_id") . "&action=repulsion&toggle=t>Repulsion</a>";		
  } elseif ( $db->f("repulsion") == 't' ) {
		echo "<a href=";
		echo $sess->url(URL . "merchant_update.php");
		echo "?id=" . $db->f("forces_id") . "&action=repulsion&toggle=f>Non-Repulsion</a>";
  }

	echo "</td><td>";	
	echo "</td></tr></table>";	

	echo "</tr>";
}
?>
			</table>
		<td>
  </tr>
</table>
<br><?php

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "An alliance with that name could not be found.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "You cannot target forces upon your own alliance.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "You cannot target forces upon yourself.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>