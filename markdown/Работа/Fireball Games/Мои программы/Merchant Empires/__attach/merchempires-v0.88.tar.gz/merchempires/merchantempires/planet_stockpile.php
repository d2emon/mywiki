<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Planet Stockpile</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
	
$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

$db_p = new ME_DB_Xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();
	
$db_g = new ME_DB;
$db_g->query("select * from good_types");

while ( $db_g->next_record() ) {
	$all_good_types[$db_g->f("good_type_id")] = $db_g->f("name");
}

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {
	$db_p->add_parameter("current_screen", "planet_stockpile");	
	echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());
?>

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
		<td bgColor=#003399>
			<table cols=5 border=0 cellpadding=2 cellspacing=1 width=490>
				<tr>
					<td class=clsHedTxt id=blu1>
					Type
					</td>
					<td width=50 class=clsHedTxt id=blu1>
					On Planet
					</td>
					<td width=50 class=clsHedTxt id=blu1>
					On Ship
					</td>
					<td align=center class=clsHedTxt id=blu1>
					Amount
					</td>
					<td align=center width=100 class=clsHedTxt id=blu1>
					Transfer To
					</td>
				</tr><?php

$cargo_temp = explode(",", $db_p->f("cargo"));

for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 2) {
	$planetary_cargo[$cargo_temp[$i]] = $cargo_temp[$i + 1];
}

$good_types = explode(",", $db_p->f("good_types"));

for ($i = 0; $i <= count($good_types) - 1; $i++) {
	echo "<form action=";
	echo $sess->url(URL . "planet_update.php");
	echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

	echo "<tr><td class=clsNrmTxt>";
	echo $all_good_types[$good_types[$i]];
	echo "</td><td class=clsNrmTxt>";

	if ( $planetary_cargo[$all_good_types[$good_types[$i]]] > 0 ) {
		echo $planetary_cargo[$all_good_types[$good_types[$i]]];
	} else {
		echo "0";
	}

	echo "</td><td class=clsNrmTxt>";

	if ( $cargo->Current_cargo[$all_good_types[$good_types[$i]]]['amount'] > 0 ) {
		echo $cargo->Current_cargo[$all_good_types[$good_types[$i]]]['amount'];
	} else {
		echo "0";
	}

	echo "</td><td align=center class=clsNrmTxt>";
	echo "<input type=textbox size=5 name=amount>";
	echo "</td><td align=center class=clsNrmTxt>";
	echo "<input type=hidden name=good_type value='" . $all_good_types[$good_types[$i]] . "'>";

	echo "<input border=0 type=image src='./images/form/planet-off.png' name=deposit>";
	echo "<input border=0 type=image src='./images/form/ship-off.png' name=withdraw>";
	echo "</td></tr></form>";
}

?>			
			</table>
		<td>
  </tr>
</table>
<?php

} else {
	$error = 5;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to insufficient goods on ship.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient goods on ship.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "Command not processed due to insufficient drones on planet.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "Command not processed due to insufficient shields on planet.");			
	} elseif ($error == 5) {
		$db->add_parameter("message", "Your merchant is currently not landed on a planet.");			
	} elseif ($error == 8) {
		$db->add_parameter("message", "Command not processed due to insufficient cargo holds.");			
	} elseif ($error == 9) {
		$db->add_parameter("message", "Command not processed due to invalid amount.");			
	} elseif ($error == 10) {
		$db->add_parameter("message", "Command not processed due to insufficient planetary capacity.");			
	} elseif ($error == 25) {
		$db->add_parameter("message", "Access to that functionality not allowed by planet owner.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
