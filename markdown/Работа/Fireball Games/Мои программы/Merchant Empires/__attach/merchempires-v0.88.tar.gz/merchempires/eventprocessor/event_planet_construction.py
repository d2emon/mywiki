
def planet_construction():
	from pg import DB
	from Defines import *
	import time

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT * from planets where structure_type_id <> 0"
	q = pgcnx.query(qrystr)

	res = q.getresult()
	for value in range(len(res)):
		completion_time = res[value][q.fieldnum('structure_completion_time')]

		if completion_time <= time.time():
			#update the planet record
			if res[value][q.fieldnum('structure_type_id')] == 1:
				new_shields = res[value][q.fieldnum('generatorcurrent')] + 1
				qrystr = "update planets set structure_type_id = '%d', generatorcurrent = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, new_shields, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 2:
				new_hangar = res[value][q.fieldnum('hangarcurrent')] + 1
				qrystr = "update planets set structure_type_id = '%d', hangarcurrent = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, new_hangar, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 3:
				new_turrets = res[value][q.fieldnum('turretscurrent')] + 1
				qrystr = "update planets set structure_type_id = '%d', turretscurrent = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, new_turrets, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 4:
				qrystr = "update planets set structure_type_id = '%d', warp_inhibitor = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, 1, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 5:
				qrystr = "update planets set structure_type_id = '%d', scanner = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, 1, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 7:
				new_storage = res[value][q.fieldnum('storagecurrent')] + 1
				qrystr = "update planets set structure_type_id = '%d', storagecurrent = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, new_storage, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 8:
				qrystr = "update planets set structure_type_id = '%d', trifocus_plasma = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, 1, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 9:
				qrystr = "update planets set structure_type_id = '%d', battle_management_control_unit = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, 1, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 10:
				new_missiles = res[value][q.fieldnum('disruptor_missile_current')] + 1
				qrystr = "update planets set structure_type_id = '%d', disruptor_missile_current = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, new_missiles, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)
			elif res[value][q.fieldnum('structure_type_id')] == 11:
				qrystr = "update planets set structure_type_id = '%d', star_gate = '%d', structure_completion_time = '%d' where planet_id = '%d'" % (0, 1, 0, res[value][q.fieldnum('planet_id')])
				pgcnx.query(qrystr)

