<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
include("./merchantempiresdefines.php");
$sess->register("player_dead");

include("./lib/player_config.php");

#if player dead, send to post-death screen
if ( $player_dead == 't' ) {	
	$newurl = $sess->url(URL . "death.php");
	header("Location: $newurl");
	exit;
}

?>

<html><head><title>Merchant Empires: Preferences</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$db = new ME_DB_Xml;
$db->add_parameter("time", date ("Y H:i:s"));
$db->add_parameter("current_screen", "preferences");
echo $db->get_transform("./xslt/mainmenu_small.xslt", "");

$db = new ME_DB;
$query = sprintf("select * from auth_user where user_id = '%s'", $user->id);
$db->query($query);
$db->next_record();
?>

</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0 width=450>
	<tr>
  	<td bgColor=#993300>
    	<table border=0 cellPadding=5 cellSpacing=1 width=450>
      	<tr>
        	<td class=clsHedTxt id=red1>Preferences
          	<br>
          </td>
	    	</tr>
        <tr>
        	<td class=clsNrmTxt>
						<form METHOD="POST" ACTION=<?php $sess->purl(URL . "preferences_update.php") ?>>
						<table>
 		   				<tr>
  		   				<td class=clsNrmTxt> New password:</td>
  		   				<td><input type="password" NAME="password"></td>
		   				</tr>
		   				<tr>
  		   				<td class=clsNrmTxt> Verify:</td>
  		   				<td><input type="password" NAME="verify"></td>
		   				</tr>
		   				<tr>
		   					<td></td>
 		   					<td class=clsNrmTxt><input type="submit" NAME="update_password" VALUE="Submit New Password"></td>
		   				</tr>
		   				<tr>
		   					</form>
		   					<form METHOD="POST" ACTION=<?php $sess->purl(URL . "preferences_update.php") ?>>
		   					<tr>
  		   					<td class=clsNrmTxt> Email:</td>
  		   					<td class=clsNrmTxt><input type="textbox" NAME="email" VALUE="<?php
  		   					
printf("%s", $db->f("email"));
?>									"></td>
		   					</tr>
		   					<tr>
		   						<td></td>
 		   						<td class=clsNrmTxt><input type="submit" NAME="update_email" VALUE="Submit New Email"></td>
		   					</tr><?php

if ( $player_id > 0 ) {
	$player_config = new ME_Player_config;
	$player_config->get_player_config($player_id);

	echo "<tr><td></td><td class=clsNrmTxt><br>";
	echo "Following a successful purchase that leaves your merchant with no open cargo holds, which screen do you want to appear?  This value also determines the screen that appears after taking off from a planet and jumping to a new sector.<br>";

	echo "<input type=radio name=screen";

	if ( $player_config->f("post_trade_screen") == "local_map" ) {
		echo ' checked ';
	}

	echo " value=1>&nbsp;Local Map<br>";
	echo "<input type=radio name=screen";

	if ( $player_config->f("post_trade_screen") == "current_sector" ) {
		echo ' checked ';
	}

	echo " value=2>&nbsp;Current Sector<br><br>";
	echo "</td></tr>";

	echo "<tr><td></td><td class=clsNrmTxt>";
	echo "Adjust your ship scanner to ignore the presence of Newbies when displaying the local map.<br>";

	echo "<input type=radio name=ignore_newbie";

	if ( $player_config->f("ignore_newbie") == "t" ) {
		echo ' checked ';
	}

	echo " value=1>&nbsp;Yes<br>";
	echo "<input type=radio name=ignore_newbie";

	if ( $player_config->f("ignore_newbie") == "f" ) {
		echo ' checked ';
	}

	echo " value=2>&nbsp;No<br><br>";
	echo "</td></tr>";

	echo "<tr><td></td><td class=clsNrmTxt>";
	echo "Participate in ship to ship combat when not directly attacked?<br>";	

	echo "<input type=radio name=group_combat_ships";

	if ( $player_config->f("group_combat_ships") == "t" ) {
		echo ' checked ';
	}

	echo " value=1>&nbsp;Yes<br>";
	echo "<input type=radio name=group_combat_ships";

	if ( $player_config->f("group_combat_ships") == "f" ) {
		echo ' checked ';
	}

	echo " value=2>&nbsp;No<br><br>";
	echo "</td></tr>";

	echo "<tr><td></td><td class=clsNrmTxt>";
	echo "Defend forces when not directly attacked?<br>";	

	echo "<input type=radio name=group_combat_forces";

	if ( $player_config->f("group_combat_forces") == "t" ) {
		echo ' checked ';
	}

	echo " value=1>&nbsp;Yes<br>";
	echo "<input type=radio name=group_combat_forces";

	if ( $player_config->f("group_combat_forces") == "f" ) {
		echo ' checked ';
	}

	echo " value=2>&nbsp;No<br><br>";
	echo "</td></tr>";

	echo "<tr><td></td><td class=clsNrmTxt>";
	echo "Participate in group attacks on planets?<br>";	

	echo "<input type=radio name=group_combat_planets";

	if ( $player_config->f("group_combat_planets") == "t" ) {
		echo ' checked ';
	}

	echo " value=1>&nbsp;Yes<br>";
	echo "<input type=radio name=group_combat_planets";

	if ( $player_config->f("group_combat_planets") == "f" ) {
		echo ' checked ';
	}

	echo " value=2>&nbsp;No<br><br>";
	echo "</td></tr>";

	echo "<tr><td></td><td class=clsNrmTxt>";
	echo "Local map size<br>";	

	echo "<input type=radio name=group_map_size";

	if ( $player_config->f("map_size") == 1 ) {
		echo ' checked ';
	}

	echo " value=1>&nbsp;5 X 5<br>";
	echo "<input type=radio name=group_map_size";

	if ( $player_config->f("map_size") == 2 ) {
		echo ' checked ';
	}

	echo " value=2>&nbsp;7 x 7<br><br>";
	echo "<input type=submit name=update_player_config value=Update><br></td></tr>";

}

?>
		   			</table>
		   			</form>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");		
		
	if ($error == 1) {
		$db->add_parameter("message", "Please fill out all of the fields.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Your password was not successfully verified.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "Password length limit is 10 characters.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "Illegal character in submitted.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td>

</td></tr></table>
</body></html><?php

page_close();
?>
