<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/relations.php");
include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./lib/trading.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function create_transaction($offer, $amount, $this_player_id) {
	$db = new ME_DB;	
	$query = "insert into transactions (offer, amount, player_id)
		values('$offer', '$amount', '$this_player_id')";
	$db->record_oid();	
	$db->query($query);

	$query = sprintf("select * from transactions where oid = '%s'", $db->Last_OID);	
	$db->query($query);
	$db->next_record();
	
	return $db->f("transaction_id");	
}

$error = 0;
?>

<html><head><title>Merchant Empires: Trade at Port</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$db = new ME_DB;
$db->query("select * from ports where sector_id = '$sector_id'");
$db->next_record();
$public_sector_id = $db->f("public_sector_id");

$global_relations = new ME_Relations;
$global_relations->initialize($player->f("game_id"), $player->f("race_number"));
$government = $db->f("government");

switch ( $db->f("government") ) {
	case "1":
		$old_personal_relations = $player->f("relationrace_1");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_1();
		break;
	case "2":
		$old_personal_relations = $player->f("relationrace_2");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_2();
		break;
	case "3":
		$old_personal_relations = $player->f("relationrace_3");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_3();
		break;
	case "4":
		$old_personal_relations = $player->f("relationrace_4");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_4();
		break;
	case "5":
		$old_personal_relations = $player->f("relationrace_5");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_5();
		break;
	case "6":
		$old_personal_relations = $player->f("relationrace_6");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_6();
		break;
	case "7":
		$old_personal_relations = $player->f("relationrace_7");
		$relations = $player->f("relationrace_1") + $global_relations->get_relations_7();
		break;
}

$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=490>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5>Trade at Port : <?php

echo $public_sector_id;
?>				
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

$db->query("select player_id, reject_counter, reject_amount, reject_type from
	players where player_id = '$player_id'");
$db->next_record();

if ( $db->f("reject_counter") <> 0 ) {
	$good_type = $db->f("reject_type");
?>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=490>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#cccccc face=arial,helvetica,swiss size=3> <?php

	echo "Your offer of " . $db->f("reject_counter") . " credits for " . $db->f("reject_amount") . " units";
	echo " of " . $good_type . " was rejected.";
?>				
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

	# delete the reject record
	$db = new ME_DB;
	$db->query("update players set reject_counter = '0',	reject_amount = '0',
		reject_type = '' where player_id = '$player_id'");		

	if ( strstr($player->f("transaction_type"), 'sell') ) {
		$msg = "I will buy ";
	} else {
		$msg = "I will sell ";
	}	

	$nt_id = (int) $nt_id;

	if ( $nt_id > 0 ) {
		$transaction_id = (int) $nt_id;
		$db_t = new ME_DB;
		$db_t->query("select * from transactions where transaction_id = '$transaction_id' and player_id = '$player_id'");
		$db_t->next_record();

		if ( $db_t->nf() > 0 ) {
			$old_offer = $db_t->f("offer");		
			$amount = $db_t->f("amount");
			$db_t->query("delete from transactions where transaction_id = '$transaction_id'");
		}

		$msg = $msg . $amount . " units of ";
	
		switch ($player->f("transaction_type")) {
			case "buy_good":
				$offer = compute_sell_offer($good_type, $amount, $relations, $sector_id, $old_offer);
				$msg = $msg . $good_type;
				break;  	
			case "sell_good":
				$offer = compute_buy_offer($good_type, $amount, $relations, $sector_id, $old_offer);
				$msg = $msg . $good_type;
				break;
		}

		$transaction_id = create_transaction($offer, $amount, $player->f("player_id"));	
	}

	$msg = $msg . " for " . $offer . " credits.";
	$type = $player->f("transaction_type");
}

$newbie_goods = array("Food", "Biochemicals", "Ore", "Precious Metals", "Slaves");

?>

<br><?php

if ( !($nt_id > 0) ) {
	// Check if there was a submission
	while (is_array($HTTP_POST_VARS)
  	&& list($key, $val) = each($HTTP_POST_VARS)) {
	
		switch ($key) {
			case "buy":
				$offer = (int) $offer;
				$amount_good = (int) $amount_good;

				if ( $amount_good <= 0 ) {
					$error = "Command not processed due to incorrect amount entered.";
					break;					
				}

				if ( $player->f("newturnsleft") > 0 and !in_array($good_type, $newbie_goods) ) {
					$error = "Newbies are allowed to trade only first level goods.";
					break;
				}

				if ( $amount_good > $cargo->Open_holds ) {
					$error = "Your ship cannot hold all of the requested goods.";
					break;
				}
			
				$type = "buy_good";
				$offer = compute_sell_offer($good_type, $amount_good, $relations, $sector_id, 0);

				if ( $offer > $player->f("credits") ) {
					$error = "Your merchant has insufficient credits to purchase the requested goods.";
					break;
				}

  			$msg = "I will sell " . $amount_good . " units of " . $good_type . " for " . $offer . " credits.";
				$transaction_id = create_transaction($offer, $amount_good, $player->f("player_id"));

				break;
		
  	  case "sell":
				$offer = (int) $offer;
				$amount_good = (int) $amount_good;

				if ( $amount_good <= 0 ) {
					$error = "Command not processed due to incorrect amount entered.";
					break;					
				}

				if ( $player->f("newturnsleft") > 0 and !in_array($good_type, $newbie_goods) ) {
					$error = "Newbies are allowed to trade only first level goods.";
					break;
				}

				$type = "sell_good";
				$offer = compute_buy_offer($good_type, $amount_good, $relations, $sector_id, 0);
	  		$msg = "I will buy " . $amount_good . " units of " . $good_type . " for " . $offer . " credits.";

				$transaction_id = create_transaction($offer, $amount_good, $player->f("player_id"));
			
				break;
		}
	}
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	$db->add_parameter("message", $error);
	echo $db->get_transform("./xslt/message_box.xslt", "");	
} else {
?>

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
  	<td bgColor=#003399>
    	<table border=0 cellPadding=5 cellSpacing=1 width=490>
        <tr>
        	<td class=clsNrmTxt>
						<br><?php

echo $msg;
?>
						<br><br>
						<form name=form_port_offer action=<?php

echo $sess->url(URL . "port_transaction.php");
?>
						method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>
						<table cellspacing=1 cellpadding=1>
							<tr>
								<td>
									<a href='javascript:document.form_port_offer.submit()'><img border=0 width=100 height=20 src='./images/form/accept_offer-off.png'></a><br>
									<input type=hidden name=accept value="Accept Offer">
								</td>
								<td>
								</td>
							</tr>
							<tr>
								<td>
									<a href='javascript:document.form_port_offer.submit()'><img border=0 width=100 height=20 src='./images/form/counter_offer-off.png'></a><br>
								</td>
								<td>
									&nbsp;&nbsp;<input type=textbox name=counter size=15><?php

echo "<input type=hidden name=transaction_id value=" . $transaction_id . ">";
echo "<input type=hidden name=type value=" . $type . ">";
echo "<input type=hidden name=good_type value='" . $good_type . "'>";

$db = new ME_DB;
$db->query("update players set transaction_type = '$type', transaction_amount = '$amount'
	where player_id = '$player_id'");
?>
								</td>
							</tr>
						</table>
						</form>
					</td>
		  	</tr>
				<tr>
        	<td bgColor=#000000><?php

echo "<a href=";
echo $sess->url(URL . "port.php");
?>				
						><center>Return to Port</center></a>
						</td>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>