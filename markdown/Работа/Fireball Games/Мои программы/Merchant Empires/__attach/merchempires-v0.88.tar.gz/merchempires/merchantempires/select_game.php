<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
include("./merchantempiresdefines.php");
?>

<html><head><title>Merchant Empires: Select Game</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white text=white background="./images/createbg.gif"><?php

include("./templates/header.html");

?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$db = new ME_DB_Xml;
$db->add_parameter("time", date ("Y H:i:s"));
$db->add_parameter("current_screen", "selectgame");
echo $db->get_transform("./xslt/mainmenu_small.xslt", "");

printf("</td><td vAlign=top align=left width=500>");
$joinedgames = array();

## Get a database connection
$db = new ME_DB;
$db_2 = new ME_DB;

$db->query("select user_id, game_id from players where user_id='$user->id' order by game_id");
if ($db->nf()>0) {
	?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#993300>
			<table BORDER=0 cellpadding=5 cellspacing=1 COLS=2 WIDTH=100%>
				<tr>
					<td width=100 class=clsHedTxt id=red1>Active Games</td>
					<td width=170 class=clsHedTxt id=red1>Description</td>
					<td width=180 class=clsHedTxt id=red1>Details</td>
					<td width=70 class=clsHedTxt id=red1>&nbsp;</td>
				</tr><?php

	while($db->next_record()) {		
		$query = sprintf("select * from games where game_id='%s' order by game_id", $db->f("game_id"));
		$db_2->query($query);
 		$db_2->next_record();
		
		echo "<tr><td class=clsNrmTxt align=left valign=top>" . $db_2->f("name") . "</td>\n";
		echo "<td class=clsNrmTxt align=left valign=top>" .  $db_2->f("description") . "</td>\n";
		echo "<td class=clsNrmTxt align=left valign=top>";
		echo "<table BORDER=0 cellpadding=0 cellspacing=0>";
		echo "<tr>";
		echo "<td class=clsNrmTxt>Type</td><td class=clsSmlTxtWht>&nbsp;" . $db_2->f("type") . "</td>";
		echo "</tr><tr>";
		echo "<td class=clsNrmTxt>Start</td><td class=clsSmlTxtWht>&nbsp;" . $db_2->f("startdate") . "</td>";
		echo "</tr><tr>";
		echo "<td class=clsNrmTxt>Close</td><td class=clsSmlTxtWht>&nbsp;" . $db_2->f("closedate") . "</td>";
		echo "</tr><tr>";
		echo "<td class=clsNrmTxt>End</td><td class=clsSmlTxtWht>&nbsp;" . $db_2->f("enddate") . "</td>";
		echo "</tr><tr>";
		echo "<td class=clsNrmTxt>Turns</td><td class=clsSmlTxtWht>&nbsp;" . $db_2->f("turnrate") . "</td>";
		echo "</tr><tr>";
		echo "<td class=clsNrmTxt>Interest</td><td class=clsSmlTxtWht>&nbsp;" . $db_2->f("interestrate") . "</td>";
		echo "</tr></table>";
		printf("</td>");
		printf("<td class=clsNrmTxt>\n");
		echo "<form name=play_game_" . $db_2->f("game_id") . " METHOD=POST ACTION=\n";
		$sess->purl(URL . "play_game.php");
		printf(">");
		echo "<INPUT TYPE=hidden NAME=game_id VALUE=" . $db_2->f("game_id") . ">";
		echo "<a href='javascript:document.play_game_" . $db_2->f("game_id") . ".submit()'><img border=0 src='./images/form/play-off.png'></a>";
		echo "<INPUT TYPE=hidden NAME=play VALUE=Play>";

		printf("</form></td>\n");
		printf("</tr>\n");
		$joinedgames[$db_2->f("game_id")] = $db_2->f("name");
	}
	printf("</table></td></table><br><br>");
}

	$db_3 = new ME_DB;
	$db_3->query("select * from games order by game_id");
	if ($db_3->nf()>0) {

	while($db_3->next_record()) {
			if (!isset ($joinedgames[$db_3->f("game_id")])) {	
				$gamefound = 1;
			}
	}

	$db_3->query("select * from games order by game_id");
	if ($db_3->nf()>0) {
		if (isset($gamefound))	{
?>
		<table border=0 cellPadding=0 cellSpacing=0 width=500>
		<tr>
		<td bgColor=#993300>
			<table BORDER=0 cellpadding=5 cellspacing=1 COLS=2 WIDTH=100%>
				<tr>
					<td width=100 class=clsHedTxt id=red1>Open Games</td>
					<td width=170 class=clsHedTxt id=red1>Description</td>
					<td width=180 class=clsHedTxt id=red1>Details</td>
					<td width=70 class=clsHedTxt id=red1>&nbsp;</td>
				</tr><?php
		
			while($db_3->next_record()) {
				if (!isset ($joinedgames[$db_3->f("game_id")])) {
					printf("<tr>\n");
					echo "<td class=clsNrmTxt align=left valign=top>" . $db_3->f("name"). "</td>\n";
					echo "<td class=clsNrmTxt align=left valign=top>" . $db_3->f("description") . " </td>\n";
					echo "<td class=clsNrmTxt align=left valign=top>";
					echo "<table BORDER=0 cellpadding=0 cellspacing=0>";
					echo "<tr>";
					echo "<td class=clsNrmTxt>Type</td><td class=clsSmlTxtWht>&nbsp;" . $db_3->f("type") . "</td>";
					echo "</tr><tr>";
					echo "<td class=clsNrmTxt>Start</td><td class=clsSmlTxtWht>&nbsp;" . $db_3->f("startdate") . "</td>";
					echo "</tr><tr>";
					echo "<td class=clsNrmTxt>Close</td><td class=clsSmlTxtWht>&nbsp;" . $db_3->f("closedate") . "</td>";
					echo "</tr><tr>";
					echo "<td class=clsNrmTxt>End</td><td class=clsSmlTxtWht>&nbsp;" . $db_3->f("enddate") . "</td>";
					echo "</tr><tr>";
					echo "<td class=clsNrmTxt>Turns</td><td class=clsSmlTxtWht>&nbsp;" . $db_3->f("turnrate") . "</td>";
					echo "</tr><tr>";
					echo "<td class=clsNrmTxt>Interest</td><td class=clsSmlTxtWht>&nbsp;" . $db_3->f("interestrate") . "</td>";
					echo "</tr>";
					echo "</table></td>";
					printf("<td class=clsNrmTxt>\n");
					echo "<form name=join_game_" . $db_3->f("game_id") . " METHOD=POST ACTION=\n";					
					$sess->purl(URL . "get_new_player.php");
					echo "><a href='javascript:document.join_game_" . $db_3->f("game_id") . ".submit()'><img border=0 src='./images/form/join-off.png'></a>";
					echo "<INPUT TYPE=hidden NAME=play VALUE=Play>";

					printf("<INPUT TYPE=hidden NAME=game_id VALUE=%s>\n", $db_3->f("game_id"));
					printf("</form></td>\n");
					printf("</tr>\n");
				}
			}
		}
	}

	if (!isset($gamefound))	{
?>
	<table border=0 cellPadding=0 cellSpacing=0 width=500>
		<tr>
			<td bgColor=#993300>
				<table BORDER=0 cellpadding=5 cellspacing=1 COLS=2 WIDTH=100%>
					<tr>
						<td class=clsNrmTxt align=left valign=top>No Open Games</td>
					</tr>
				</table>
			</td>
		</tr>
	</table><?php
	
	}

	printf("</table></td></table><br><br>");
}
?>

</td>
<td>

</td></tr></table>
</body></html><?php

page_close();
?>
