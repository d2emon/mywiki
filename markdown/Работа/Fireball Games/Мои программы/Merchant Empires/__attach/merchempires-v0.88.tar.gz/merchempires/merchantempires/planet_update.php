<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify       f
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/ship_combat.php");
include("./lib/ship_weapons.php");
include("./lib/cargo.php");
include("./lib/weapons.php");
include("./lib/technology.php");
include("./lib/relations.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

function merchant_dead($dead_player_id, $killer_id, $sector_id, $killer_type) {
	$dead_player = new ME_Player;
	$dead_player->get_player($dead_player_id);
	$victor_credits = $dead_player->f("credits");
	$dead_player->set_credits(3000);
	$dead_player->set_new_turns_left(100);	

	$dead_player_alignment = $dead_player->f("alignment");
	$dead_player_experience = $dead_player->f("experience");
	$dead_player_race_id = $dead_player->f("race_number");
	$new_experience = (int) ($dead_player->f("experience") * .85);
	$dead_player->set_experience($new_experience);

	$db = new ME_DB;
	$query = "select * from levels where experience <= '$new_experience' order by experience desc limit 1";
	$db->query($query);
	$db->next_record();

	$dead_player->set_rank($db->f("rank"));
	$dead_player->set_dead("t");
	$dead_player->save();

	$game_id = $dead_player->f("game_id");
	$race = $dead_player->f("race");
	# find the player's starting sector	
	$db->query("select * from games where game_id = '$game_id'");
	$db->next_record();
		
	if ($race == $db->f("namerace_1")) {
		$sector_id = $db->f("startsectrace_1");
	} elseif ($race == $db->f("namerace_2")) {
		$sector_id = $db->f("startsectrace_2");
	} elseif ($race == $db->f("namerace_3")) {
		$sector_id = $db->f("startsectrace_3");
	} elseif ($race == $db->f("namerace_4")) {
		$sector_id = $db->f("startsectrace_4");
	} elseif ($race == $db->f("namerace_5")) {
		$sector_id = $db->f("startsectrace_5");
	} elseif ($race == $db->f("namerace_6")) {
		$sector_id = $db->f("startsectrace_6");
	} elseif ($race == $db->f("namerace_7")) {
		$sector_id = $db->f("startsectrace_7");
	}

	$db->query("select player_id, type_id from ships where player_id = '$dead_player_id'");
	$db->next_record();
	$dead_ship_type_id = $db->f("type_id");
	
	$db_d = new ME_DB_Tran;
	$db_d->begin_transaction();
  $db_d->query("delete from ships where player_id = '$dead_player_id'");

	$delete_success = $db_d->affected_rows();

	if ( $delete_success ) {
	  $db_d->query("delete from ship_weapons where player_id = '$dead_player_id'");
		$db_d->query("delete from ship_technology where player_id = '$dead_player_id'");
	}

	$delete_success = $db_d->affected_rows();
	$db_d->end_transaction();

	if ( $delete_success ) {
		# set some default values
		$ship = new ME_Ship;
		$ship->get_new_ship($dead_player_id, $sector_id);
		$ship->set_type("Light Freighter");
		$ship->set_shieldmax(250);
		$ship->set_shieldcurrent(150);
		$ship->set_armormax(200);
		$ship->set_armorcurrent(75);
		$ship->set_powermax(50);
		$ship->set_powercurrent(15);
		$ship->set_minesmax(0);
		$ship->set_minescurrent(0);
		$ship->set_combatmax(0);
		$ship->set_combatcurrent(0);
		$ship->set_scoutmax(0);
		$ship->set_scoutcurrent(0);
		$ship->set_cargocurrent(40);
		$ship->set_cargomax(100);
		$ship->set_type_id(53);		
		$ship->set_turns_per_sector(2.5);
		$ship->set_hardpoints(1);
		$ship->set_last_move_date(time());	
		$ship->save();		
	
		$weapons = new ME_Weapons;
		$weapons->get_new_weapons($ship->id);
		$weapons->set_player_id($dead_player_id);
		$weapons->save();

		$technology = new ME_Technology;
		$technology->get_new_technology($ship->id);
		$technology->set_player_id($dead_player_id);		
		$technology->save();
	}
	
	$date = time();	

	if ( $killer_type == 's' ) {				
		$db->query("select * from bounties where player_target_id = '$dead_player_id'");
    $db->next_record();

		if ( $db->nf() > 0 ) {
			$new_bounties = $db->f("bounty_id");
		}

		$db->query("select * from underground_bounties where player_target_id = '$dead_player_id'");
		$db->next_record();

		if ( $db->nf() > 0 ) {
			$new_ug_bounties = $db->f("underground_bounty_id");
		}

		$db->query("select players.player_id, players.name, players.alignment, players.race, players.credits, players.race_number,
			players.experience, players.unclaimed_bounties, players.unclaimed_ug_bounties, players.unclaimed_military_bounties, ships.player_id,
			ships.sector_id, ships.public_sector_id from players, ships where players.player_id = '$killer_id'
			and players.player_id = ships.player_id");

		$db->next_record();

		$relations = new ME_Relations;
		$relations->initialize($game_id, $db->f("race_number"));

		if ( $dead_player_race_id == 1 ) {
			$this_relations = $relations->get_relations_1();
		} elseif ( $dead_player_race_id == 2 ) {
			$this_relations = $relations->get_relations_2();
		} elseif ( $dead_player_race_id == 3 ) {
			$this_relations = $relations->get_relations_3();
		} elseif ( $dead_player_race_id == 4 ) {
			$this_relations = $relations->get_relations_4();
		} elseif ( $dead_player_race_id == 5 ) {
			$this_relations = $relations->get_relations_5();
		} elseif ( $dead_player_race_id == 6 ) {
			$this_relations = $relations->get_relations_6();
		} elseif ( $dead_player_race_id == 7 ) {
			$this_relations = $relations->get_relations_7();
		}

		$new_military_bounties = $db->f("unclaimed_military_bounties");

		if ( $dead_player_experience > 100 ) {
			if ( $this_relations <= -300 ) {
				if ( strlen($new_military_bounties) > 0 ) {
					$new_military_bounties = $new_military_bounties . "," . $dead_ship_type_id;
				} else {
					$new_military_bounties = $dead_ship_type_id;
				}
			}
		}

		if ( strlen($new_bounties) > 0 ) {
			if ( strlen($db->f("unclaimed_bounties")) > 0 ) {

				$bounties = array();
				$bounties = explode(",", $db->f("unclaimed_bounties"));	

				$bounty_found = 0;
				while (list($key, $val) = each($bounties)) {
					if ( $val == $new_bounties ) {
						$bounty_found = 1;
					}		
				}	

				if ( !(bounty_found) ) {
					$new_bounties = $db->f("unclaimed_bounties") . "," . $new_bounties;
				} else {
					$new_bounties = $db->f("unclaimed_bounties");
				}
			}
		} else {
			$new_bounties = $db->f("unclaimed_bounties");
		}

		if ( strlen($new_ug_bounties) > 0 ) {
			if ( strlen($db->f("unclaimed_ug_bounties")) > 0 ) {

				$bounties = array();
				$bounties = explode(",", $db->f("unclaimed_ug_bounties"));	

				$bounty_found = 0;
				while (list($key, $val) = each($bounties)) {
					if ( $val == $new_ug_bounties ) {
						$bounty_found = 1;
					}		
				}	

				if ( !(bounty_found) ) {
					$new_ug_bounties = $db->f("unclaimed_ug_bounties") . "," . $new_ug_bounties;					
				} else {
					$new_ug_bounties = $db->f("unclaimed_ug_bounties");
				}				
			}
		} else {
			$new_ug_bounties = $db->f("unclaimed_ug_bounties");
		}
		
		$public_sector_id = $db->f("public_sector_id");
	  $message = addslashes($db->f("name")) . " killed " . addslashes($dead_player->f("name")) . " in sector " . $db->f("public_sector_id") . ".";
		$new_credits = $db->f("credits") + $victor_credits;

		$new_experience = ($dead_player_experience / 1000) * 50;
		if ( $new_experience < 50 ) {
			$new_experience = $db->f("experience") + 50;			
		} else {
			$new_experience = (int) ($db->f("experience") + $new_experience);	
		}

		$new_alignment = $db->f("alignment");

		if ( $dead_player_experience > 300 ) {
			if ( $dead_player_alignment > 200 ) {
				$new_alignment = $new_alignment - 70;
			} elseif ( $dead_player_alignment > 150 ) {
	  		$new_alignment = $new_alignment - 50;
			} elseif ( $dead_player_alignment > 100 ) {
				$new_alignment = $new_alignment - 30;
			} elseif ( $dead_player_alignment > 50 ) {
				$new_alignment = $new_alignment - 10;
			} elseif ( $dead_player_alignment < -200 ) {
				$new_alignment = $new_alignment + 70;
			} elseif ( $dead_player_alignment < -150 ) {
				$new_alignment = $new_alignment + 40;
			} elseif ( $dead_player_alignment < -100 ) {
				$new_alignment = $new_alignment + 20;
			}	elseif ( $dead_player_alignment < -50 ) {
				$new_alignment = $new_alignment + 10;
			}			

			if ( $new_alignment > 500 ) {
				$new_alignment = 500;
			} elseif ( $new_alignment < -500 ) {
				$new_alignment = -500;
			}
		}

		$killer_name = $db->f("name");
		$query = "insert into news (date, item, game_id) values ('$date', '$message', '$game_id')";
		$db->query($query);

		$query = "update players set credits = '$new_credits', experience = '$new_experience', alignment = '$new_alignment', unclaimed_bounties = '$new_bounties', unclaimed_ug_bounties = '$new_ug_bounties', unclaimed_military_bounties = '$new_military_bounties' where player_id = '$killer_id'";
		$db->query($query);
		
		$message = addslashes($killer_name) . " destroyed you in sector " . $public_sector_id;
		$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
			values ('$dead_player_id', '$message', 'Bridge', 't', '$date')";
		$db->query($query);
	}	
}

function attack_merchant_with_trifocus($attacker_id, $defender_id) {	
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.shieldmax, ships.armorcurrent, ships.armormax, ships.combatcurrent, ships.type, ship_technology.player_id, ship_technology.active_screens, ship_technology.screenscurrent from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $defender_id);
	$db_ds->query($query);
	$db_ds->next_record();	

	$db_as = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.rank, players.level, players.turns, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.combatcurrent, ships.type, ship_technology.player_id, ship_technology.targeting_computer, ship_technology.plasma_booster from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_as->query($query);
	$db_as->next_record();

	$targeting_bonus = 0;
	$damage_bonus = 0;

	$attacker_level = $db_as->f("level");	
	
	$defender_name = htmlentities($db_ds->f("name"));
	$attacker_name = htmlentities($db_as->f("name"));			

	$merchant_and_forces = array();
	$merchant_and_forces[0] = 0;
	$merchant_and_forces[1] = 0;	

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$target_screens = $db_ds->f("screenscurrent");
	$shield_damage = 0;
	$armor_damage = 0;
	$screens_damage = 0;

	$merchant_hit = 0;	
	$merchant_killed = 0;		

	$num = rand(1,100);	

	if ( (($num - $attacker_level) - $targeting_bonus) <= 60 ) {
		$num = rand(-5,5);	

		$merchant_hit = 1;	

		if ( $target_shields + $target_screens > 0 ) {
			$damage = 150;
			$damage = $damage + $num;
			
			if ( $target_screens > 0 and $target_screens - $damage < 0 ) {
				$target_screens = 0;
				$screens_damage = $db_ds->f("screenscurrent");
			} elseif ( $target_screens > 0 ) {
				$target_screens = $target_screens - $damage;
				$screens_damage = $damage;
			} elseif ( $target_shields > 0 and $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} elseif ( $target_shields > 0 ) {
				$target_shields = $target_shields - $damage;
				$shield_damage = $damage;				
			}				
		} elseif ( $target_shields <= 0 and $target_screens <= 0 ) {
			$damage = 150;
			$damage = $damage + $num;

			if ( $target_armor - $damage < 0 ) {
 				$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent");
					
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $damage;
			}	
		}
	}
	
	if ( $shield_damage > 0 or $armor_damage > 0 or $screens_damage > 0 ) {
		$total_damage = $shield_damage + $armor_damage + $screens_damage;

		if ( $db_ds->f("screenscurrent") - $screens_damage <= 0 ) {
			$new_screens = 0;			
		} else {
			$new_screens = $db_ds->f("screenscurrent") - $screens_damage;
		}

		if ( $db_ds->f("shieldcurrent") - $shield_damage <= 0 ) {
			$new_shields = 0;			
		} else {
			$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		}

		if ( $db_ds->f("armorcurrent") - $armor_damage <= 0 ) {
			$new_armor = 0;
		} else {
			$new_armor = $db_ds->f("armorcurrent") - $armor_damage;
		}

		$ship_id = $db_ds->f("ship_id");
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";

		if ( $screens_damage > 0 ) {
			$query = "update ship_technology set screenscurrent = '$new_screens' where ship_id = '$ship_id'";
		}

		$db_as->query($query);

		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_as->query($query);
	}		

	$merchant_and_forces[0] = $merchant_killed;	

	if ( $shield_damage > 0 or $armor_damage > 0 or $screens_damage > 0 ) {
		$merchant_and_forces[1] = 1;		
	}

	$merchant_and_forces[2] = $new_shields;
	$merchant_and_forces[3] = $new_armor;
	
	return $merchant_and_forces;
}

function get_planetary_cargo($db_p) {
	$cargo_temp = explode(",", $db_p->f("cargo"));

	for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 2) {
		$planetary_cargo[$cargo_temp[$i]] = $cargo_temp[$i + 1];
	}		

	return $planetary_cargo;
}

function get_planetary_tech($db_p) {
	$tech_temp = explode(",", $db_p->f("ship_technology"));

	for ($i = 0; $i <= count($tech_temp) - 1; $i = $i + 2) {
		$planetary_tech[$tech_temp[$i]] = $tech_temp[$i + 1];
	}		

	return $planetary_tech;
}

function get_planetary_weapons($db_p) {
	$weapons_temp = explode(",", $db_p->f("ship_weapons"));

	for ($i = 0; $i <= count($weapons_temp) - 1; $i = $i + 2) {
		$planetary_weapons[$weapons_temp[$i]] = $weapons_temp[$i + 1];
	}		

	return $planetary_weapons;
}

function get_cargo_requirements($db) {
	$cargo_temp = explode(",", $db->f("cargo"));

	for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 2) {
		$cargo_requirements[$cargo_temp[$i]] = $cargo_temp[$i + 1];
	}		

	return $cargo_requirements;
}

function get_all_good_types() {
	$db_g = new ME_DB;
	$db_g->query("select * from good_types");

	while ( $db_g->next_record() ) {
		$all_good_types[$db_g->f("good_type_id")] = $db_g->f("name");
	}

	return $all_good_types;
}

function get_new_cargo($planetary_cargo) {
	$cargo_temp = array();

	while (list($key, $val) = each($planetary_cargo)) {
		if ( $val > 0 ) {
			array_push($cargo_temp, $key);
			array_push($cargo_temp, $val);
		}
	}		
		
	return implode(",", $cargo_temp);
}

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$db_p = new ME_DB;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "deposit_defenses_x":
			$combat_amount = (int) $combat_amount;
			$shield_amount = (int) $shield_amount;			

			$returnto = "defenses";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}			

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_military") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $combat_amount != NULL ) {
				if ( $combat_amount < 0 ) {
					$error = 9;
					break;
				}
			}

			if ( $shield_amount != NULL ) {
				if ( $shield_amount < 0 ) {
					$error = 9;
					break;
				}
			}

			if ( $combat_amount > 0 ) {
      	if ( $combat_amount > $ship->f("combatcurrent") ) {
        	$error = 1;
					#Command not processed due to insufficient drones
					break;
				}
			}
			
			if ( $shield_amount > 0 ) {
				if ( $shield_amount > $ship->f("shieldcurrent") ) {
        	$error = 2;
					#Command not processed due to insufficient shields
					break;
				}      	
			}
			
			if ( ($combat_amount + $db_p->f("combatcurrent")) > ($db_p->f("hangarcurrent") * 20) and ( $combat_amount > 0 ) ) {
				$error = 6;
				#Command not processed due to insufficient drone capacity
				break;
			}

			if ( ($shield_amount + $db_p->f("shieldcurrent")) > ($db_p->f("generatorcurrent") * 100) and ( $shield_amount > 0 ) ) {
				$error = 7;
				#Command not processed due to insufficient shield capacity
				break;
			}

			$altered_combat = 0;
			$altered_shields = 0;
			
			if ( $combat_amount >= 0 ) {
      	if ( $combat_amount <= $ship->f("combatcurrent") ) {
					$new_amt = $ship->f("combatcurrent") - $combat_amount;
					$new_p_amt = $db_p->f("combatcurrent") + $combat_amount;
					$altered_combat = 1;
					$ship->set_combatcurrent($new_amt);					

					$transactions = array();
					$transactions = explode(",", $db_p->f("defense_transactions"));

					if ( count($transactions) >= 10 ) {		
						array_splice($transactions, 0, 1);				
						$transactions[10] = $player->f("name") . " installed " . $combat_amount . " combat drones.";
						$str_transactions = addslashes(implode(",", $transactions));
					} else {
						$transactions = array();
						$transactions = explode(",", $db_p->f("defense_transactions"));
						$transactions[count($transactions) + 1] = $player->f("name") . " installed " . $combat_amount . " combat drones.";
						$str_transactions = addslashes(implode(",", $transactions));
					}

					$db_p_u = new ME_DB;
					$db_p_u->query("update planets set combatcurrent = '$new_p_amt', defense_transactions = '$str_transactions' where planet_id = '$planet_id'");
				}
			}
		
			if ( $shield_amount >= 0 ) {
				if ( $shield_amount <= $ship->f("shieldcurrent") ) {
        	$new_amt = $ship->f("shieldcurrent") - $shield_amount;
					$new_p_amt = $db_p->f("shieldcurrent") + $shield_amount;
					$altered_shields = 1;
					$ship->set_shieldcurrent($new_amt);					

					if ( $combat_amount > 0 and $shield_amount > 0 ) {
						if ( count($transactions) >= 10 ) {	
							array_splice($transactions, 0, 1);		
							$transactions[10] = $player->f("name") . " installed " . $shield_amount . " shields.";
							$str_transactions = addslashes(implode(",", $transactions));
						} else {
							$transactions[count($transactions) + 1] = $player->f("name") . " installed " . $shield_amount . " shields.";
							$str_transactions = addslashes(implode(",", $transactions));
						}
					} else {
						$transactions = array();
						$transactions = explode(",", $db_p->f("defense_transactions"));

						if ( $shield_amount > 0 ) {
							if ( count($transactions) >= 10 ) {	
								array_splice($transactions, 0, 1);		
								$transactions[10] = $player->f("name") . " installed " . $shield_amount . " shields.";
								$str_transactions = addslashes(implode(",", $transactions));
							} else {
								$transactions = array();
								$transactions = explode(",", $db_p->f("defense_transactions"));
								$transactions[count($transactions) + 1] = $player->f("name") . " installed " . $shield_amount . " shields.";
								$str_transactions = addslashes(implode(",", $transactions));		
							}
						}
					}

					$db_p_u = new ME_DB;
					$db_p_u->query("update planets set shieldcurrent = '$new_p_amt', defense_transactions = '$str_transactions' where planet_id = '$planet_id'");
				}
			}

			if ( $altered_combat or $altered_shields ) {
				$ship->save();
			}
			
			break;	
    case "withdraw_defenses_x":
			$combat_amount = (int) $combat_amount;
			$shield_amount = (int) $shield_amount;			
			$returnto = "defenses";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_military") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $combat_amount != NULL ) {
				if ( $combat_amount < 0 ) {
					$error = 9;
					break;
				}
			}

			if ( $shield_amount != NULL ) {
				if ( $shield_amount < 0 ) {
					$error = 9;
					break;
				}
			}		

			if ( $shield_amount + $ship->f("shieldcurrent") > $ship->f("shieldmax") ) {
				$error = 10;
				break;
			}

			if ( $combat_amount + $ship->f("combatcurrent") > $ship->f("combatmax") ) {
				$error = 10;
				break;
			}			

	    if ( $combat_amount > 0 ) {
      	if ( $combat_amount > $db_p->f("combatcurrent") ) {
        	$error = 3;
					#Command not processed due to insufficient drones
					break;
				}
			}

			if ( $shield_amount > 0 ) {
				if ( $shield_amount > $db_p->f("shieldcurrent") ) {
        	$error = 4;
					#Command not processed due to insufficient shields
					break;
				}      	
			}

			$altered_combat = 0;
			$altered_shields = 0;
			
			if ( $combat_amount > 0 ) {
      	if ( $combat_amount <= $db_p->f("combatcurrent") ) {
        	$new_amt = $ship->f("combatcurrent") + $combat_amount;
					$new_p_amt = $db_p->f("combatcurrent") - $combat_amount;
					$altered_combat = 1;
					$ship->set_combatcurrent($new_amt);					

					$transactions = array();
					$transactions = explode(",", $db_p->f("defense_transactions"));

					if ( count($transactions) >= 10 ) {		
						array_splice($transactions, 0, 1);				
						$transactions[10] = $player->f("name") . " extracted " . $combat_amount . " combat drones.";
						$str_transactions = addslashes(implode(",", $transactions));
					} else {
						$transactions = array();
						$transactions = explode(",", $db_p->f("defense_transactions"));
						$transactions[count($transactions) + 1] = $player->f("name") . " extracted " . $combat_amount . " combat drones.";
						$str_transactions = addslashes(implode(",", $transactions));
					}

					$db_p_u = new ME_DB;
					$db_p_u->query("update planets set combatcurrent = '$new_p_amt', defense_transactions = '$str_transactions' where planet_id = '$planet_id'");	
				}
			}

			if ( $shield_amount > 0 ) {
				if ( $shield_amount <= $db_p->f("shieldcurrent") ) {
					$new_amt = $ship->f("shieldcurrent") + $shield_amount;
					$new_p_amt = $db_p->f("shieldcurrent") - $shield_amount;
					$altered_shields = 1;
					$ship->set_shieldcurrent($new_amt);					

					if ( $combat_amount > 0 and $shield_amount > 0 ) {
						if ( count($transactions) >= 10 ) {	
							array_splice($transactions, 0, 1);		
							$transactions[10] = $player->f("name") . " extracted " . $shield_amount . " shields.";
							$str_transactions = addslashes(implode(",", $transactions));
						} else {
							$transactions[count($transactions) + 1] = $player->f("name") . " extracted " . $shield_amount . " shields.";
							$str_transactions = addslashes(implode(",", $transactions));
						}
					} else {
						$transactions = array();
						$transactions = explode(",", $db_p->f("defense_transactions"));

						if ( $shield_amount > 0 ) {
							if ( count($transactions) >= 10 ) {	
								array_splice($transactions, 0, 1);		
								$transactions[10] = $player->f("name") . " extracted " . $shield_amount . " shields.";
								$str_transactions = addslashes(implode(",", $transactions));
							} else {
								$transactions = array();
								$transactions = explode(",", $db_p->f("defense_transactions"));
								$transactions[count($transactions) + 1] = $player->f("name") . " extracted " . $shield_amount . " shields.";
								$str_transactions = addslashes(implode(",", $transactions));		
							}
						}
					}

					$db_p_u = new ME_DB;
					$db_p_u->query("update planets set shieldcurrent = '$new_p_amt', defense_transactions = '$str_transactions' where planet_id = '$planet_id'");        	
				}      	
			}
			
			if ( $altered_combat or $altered_shields ) {
				$ship->save();
			}

			break;
		case "change_password_x":
			$returnto = "ownership";

			if ( $player->f("experience") < 700 ) {
				$error = 6;
				break;
			}

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if (empty($password)) {
				$error = 1;
				#Password not entered
				break;
			}

			if ( stristr($password, ';') ) {
				$error = 1;
				break;			
			}

			#if player already has a planet, exit
			$db = new ME_DB;
			$db->query("select * from planets where owner_id = '$player_id'");	
      $db->next_record();			

			if ( $password == "00" ) {
				if ( $db_p->f("owner_id") == $player->f("player_id") ) {
					$db_p_u = new ME_DB;
					$query = "update planets set password = '', owner_id = 0, owner_name = '',
					alliance_id = 0 where planet_id = '$planet_id'";
					$db_p_u->query($query);
				} else {
					$error = 7;
					break;					
				}
				
				break;				
			}
				
			if ( $db->nf() == 1 and $player->f("experience") < 61000 ) {				
				$error = 3;
				break;
			} elseif ( $db->nf() >= 2 and $player->f("experience") >= 61000 ) {				
				$error = 3;
				break;
			}
			
			#if no owner, allow the player to claim the planet
			$db = new ME_DB;
			$db_3 = new ME_DB;
			$db->query("select * from planets where planet_id = '$planet_id'");
      $db->next_record();
			$this_sector_id = $db->f("sector_id");
			
			if ( $db->f("owner_id") <> 0 ) {
				if ( $password <> $db_p->f("password") ) {
					$error = 2;
					#Incorrect password
					break;
				}
			} else {			
				#move all players on the planet's players into the planet's sector
				if ( $player->f("alliance_id") <> 0 ) {					
					$query = sprintf("select ships.ship_id, ships.planet_id, ships.sector_id, ships.player_id, players.player_id, players.alliance_id from ships, players where ships.planet_id = '%s' and ships.player_id <> '%s' and players.alliance_id <> '%s' and players.player_id = ships.player_id", $planet_id, $player->f("player_id"), $player->f("alliance_id"));
  			} else {
					$query = sprintf("select ship_id, planet_id, sector_id, player_id from ships where planet_id = '%s' and player_id <> '%s'", $planet_id, $player->f("player_id"));	
				}

				$db->query($query);												
						
				while ( $db->next_record() ) {
					$query = sprintf("update ships set planet_id = 0, sector_id = '%s' where ship_id = '%s'", $this_sector_id, $db->f("ship_id"));
					$db_3->query($query);
				}																																										
			}

			$alliance_id = $player->f("alliance_id");

			$db_p_u = new ME_DB;
			$query = sprintf("update planets set password = '%s', owner_id = '$player_id', owner_name = '%s',
				alliance_id = '$alliance_id' where planet_id = '$planet_id'", addslashes($password), addslashes($player->f("name")));

			$db_p_u->query($query);

			break;

		case "change_name_x":
			$returnto = "ownership";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}
	
			if ( stristr($name, ';') ) {
				$error = 5;
				break;			
			}

			$db_p_u = new ME_DB;
			$db_p_u->query("update planets set name = '$name' where planet_id = '$planet_id'");	

			break;
		case "cancel_build":
			$returnto = "construction";
			
			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			$player->set_experience($player->f("experience") - 350);
			$player->save();

			$db_p_u = new ME_DB;
			$db_p_u->query("update planets set structure_type_id = '0', structure_completion_time = '0' where planet_id = '$planet_id'");

			break;

		case "update_squadrons_x":
			$returnto = "defenses";
	
			$squadrons = (int) $squadrons;
			
			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_military") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $squadrons < 1 or $squadrons > 5 ) {
				$error = 26;
				break;
			}

			$db_p_u = new ME_DB;
			$db_p_u->query("update planets set combat_squadrons = '$squadrons' where planet_id = '$planet_id'");

			break;

		case "build_1":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			if ( 1 + $db_p->f("generatorcurrent") > $db_p->f("generatormax") ) {
				$error = 6;
				break;
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '1'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	
			
			if ( !$error ) {
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}
	
					reset($cargo_requirements);
				}

				$new_cargo = get_new_cargo($planetary_cargo);
  	
				$db_p_u = new ME_DB;
				$completion_time = time() + 10800;

				$db_p_u->query("update planets set structure_type_id = '1', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
  		}

			break;
	
		case "build_2":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			if ( 1 + $db_p->f("hangarcurrent") > $db_p->f("hangarmax") ) {
				$error = 6;
				break;
			}		
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '2'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	
			
			if ( !$error ) {
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				
  	
				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 21600;

				$db_p_u->query("update planets set structure_type_id = '2', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
			}

			break;

		case "build_3":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			if ( 1 + $db_p->f("turretscurrent") > $db_p->f("turretsmax") ) {
				$error = 6;
				break;
			}		
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '3'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	
			
			if ( !$error ) {
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_experience($player->f("experience") + 150);
				$player->set_credits($new_credits);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 64800;
	
				$db_p_u->query("update planets set structure_type_id = '3', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
    	}

			break;

		case "build_4":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}			

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '4'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	

			if ( !$error ) {			
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 36000;

				$db_p_u->query("update planets set structure_type_id = '4', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
			}

			break;

		case "build_5":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}			

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '5'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	

			if ( !$error ) {			
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 50400;

				$db_p_u->query("update planets set structure_type_id = '5', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
			}

			break;

		case "build_7":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			if ( 1 + $db_p->f("storagecurrent") > $db_p->f("storagemax") ) {
				$error = 6;
				break;
			}
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '7'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	

			if ( !$error ) {			
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 43200;

				$db_p_u->query("update planets set structure_type_id = '7', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
			}	
		
			break;		

		case "build_8":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}			

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '8'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	

			if ( !$error ) {			
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 64800;

				$db_p_u->query("update planets set structure_type_id = '8', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
			}

			break;

		case "build_9":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}			

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '9'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	

			if ( !$error ) {			
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 72000;

				$db_p_u->query("update planets set structure_type_id = '9', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
			}

			break;

		case "build_10":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			if ( 1 + $db_p->f("disruptor_missile_current") > $db_p->f("disruptor_missile_max") ) {
				$error = 6;
				break;
			}		
			
			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$planetary_cargo = get_planetary_cargo($db_p);			
			$all_good_types = get_all_good_types();				
			
  		$db = new ME_DB;
			$db->query("select * from planet_structure_types where planet_structure_type_id = '10'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
      	$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	
			
			if ( !$error ) {
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->set_experience($player->f("experience") + 150);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 10800;
	
				$db_p_u->query("update planets set structure_type_id = '10', structure_completion_time = '$completion_time',
					cargo = '$new_cargo' where planet_id = '$planet_id'");
    	}

			break;

		case "build_11_x":
			$returnto = "construction";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}			

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_construction") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $db_p->f("structure_type_id") <> 0 ) {
				$error = 26;
				break;			
			}
			
			$db = new ME_DB;
			$db_m = new ME_DB;
			$query = sprintf("select * from sectors where public_sector_id = '%s'", $star_gate_public_sector_id);
			$db->query($query);								
				
			$valid_sector = 0;

			while (	$db->next_record() and !$valid_sector ) {
				$sector_id = $db->f("sector_id");				
				$query = sprintf("select * from maps where map_id = '%s'", $db->f("map_id"));
				$db_m->query($query);
				$db_m->next_record();

				if ( $game_id == $db_m->f("game_id") ) {
					$valid_sector = 1;
					$map_id = $db_m->f("map_id");											
					$star_gate_public_sector_id = $db->f("public_sector_id");
					$star_gate_sector_id = $db->f("sector_id");
					$this_sector_id = $db->f("sector_id");
				}
			}
			
			$db->query("select * from planets where sector_id = '$this_sector_id'");	
			$db->next_record();

			if ( !$valid_sector or $db->nf() == 0 or $db->f("planet_id") == $planet_id ) {
				$error = 7;
				break;
			}

			$planetary_cargo = get_planetary_cargo($db_p);
			$all_good_types = get_all_good_types();
			  		
			$db->query("select * from planet_structure_types where planet_structure_type_id = '11'");
			$db->next_record();

			$cargo_requirements = get_cargo_requirements($db);
			
			if ( $player->f("credits") < $db->f("credits") ) {
				$error = 1;
				# insufficient credits
				break;
			}				

			while (list($key, $val) = each($all_good_types)) {
				while (list($key_2, $val_2) = each($cargo_requirements)) {
					if ( $key == $key_2 ) {
						if ( $planetary_cargo[$val] < $val_2 ) {
							$error = 2;
							break;	
						}					
					}
				}

				reset($cargo_requirements);					
			}	

			if ( !$error ) {			
				$new_credits = $player->f("credits") - $db->f("credits");
				$player->set_credits($new_credits);
				$player->save();

				reset($all_good_types);
				reset($cargo_requirements);
				while (list($key, $val) = each($all_good_types)) {
					while (list($key_2, $val_2) = each($cargo_requirements)) {
						if ( $key == $key_2 ) {
							$planetary_cargo[$val] = $planetary_cargo[$val] - $val_2;
						}
					}

					reset($cargo_requirements);					
				}				

				$new_cargo = get_new_cargo($planetary_cargo);

				$db_p_u = new ME_DB;
				$completion_time = time() + 64800;

				$this_time = time();
				$db_p_u->query("update planets set structure_type_id = '11', structure_completion_time = '$completion_time',
					cargo = '$new_cargo', star_gate_sector_id = '$star_gate_sector_id', star_gate_public_sector_id = '$star_gate_public_sector_id', star_gate_build_time = '$this_time' where planet_id = '$planet_id'");
			}
			
			break;

		case "deposit_x":
			$amount = (int) $amount;
			$returnto = "stockpile";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_stockpile") == 'f' ) {
				$error = 25;
				break;
			}

			$planetary_cargo = get_planetary_cargo($db_p);

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $amount > $cargo->Current_cargo[$good_type]['amount'] ) {
	      	$error = 1;
					break;
     	}

			if ( $amount <= 0 ) {
 				$error = 9;
				break;
			}				

			$new_good = $cargo->Current_cargo[$good_type]['amount'] - $amount;			
			$cargo->set_good($good_type, 1, $new_good);		

			$db_p_u = new ME_DB;
			
      $new_good = $planetary_cargo[$good_type] + $amount;

			if ( $new_good > ( 600 + ($db_p->f("storagecurrent") * 100)) ) {
 				$error = 10;
				break;
			}		

			$cargo->save();

			$planetary_cargo[$good_type] = $planetary_cargo[$good_type] + $amount;
			$cargo_temp = array();

			while (list($key, $val) = each($planetary_cargo)) {
				if ( $val > 0 ) {
					array_push($cargo_temp, $key);
					array_push($cargo_temp, $val);
				}
			}		
		
			$new_cargo = implode(",", $cargo_temp);
			$db_p_u->query("update planets set cargo = '$new_cargo'	where planet_id = '$planet_id'");		

			break;
		
		case "withdraw_x":
			$amount = (int) $amount;
			$returnto = "stockpile";			

			$planetary_cargo = get_planetary_cargo($db_p);

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_stockpile") == 'f' ) {
				$error = 25;
				break;
			}

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $amount > $cargo->Open_holds ) {
				$error = 8;
				break;
			}

			if ( $planetary_cargo[$good_type] < $amount ) {
				$error = 2;
				break;
			}

			if ( $amount <= 0 ) {
 				$error = 9;
				break;
			}		

			$new_good = $cargo->Current_cargo[$good_type]['amount'] + $amount;
			$cargo->set_good($good_type, 1, $new_good);			
      $cargo->save();

			$db_p_u = new ME_DB;
      $planetary_cargo[$good_type] = $planetary_cargo[$good_type] - $amount;
			$cargo_temp = array();

			while (list($key, $val) = each($planetary_cargo)) {
				if ( $val > 0 ) {
					array_push($cargo_temp, $key);
					array_push($cargo_temp, $val);
				}
			}		
		
			$new_cargo = implode(",", $cargo_temp);
			$db_p_u->query("update planets set cargo = '$new_cargo'	where planet_id = '$planet_id'");

			break;
		
		case "board_x":
			$returnto = "hangar";

			$db = new ME_DB;		
			$id = (int) $id;
			$db->query("SELECT * from ships_storage where ship_storage_id = '$id' and player_id = '$player_id' and planet_id = '$planet_id'");
			$db->next_record();
		
			if ( $db->nf() == 0 ) {
				$returnto = "hangar";
				$error = 5;
				break;
			}					

			if ( $db->f("board_time") >= time() - 400 and $db->f("board_time") <> 0 ) {
				$returnto = "hangar";
				$error = 6;
				break;				
			}

			$stored_ship_type_id = $ship->f("type_id");
			$stored_ship_type = $ship->f("type");
			$stored_ship_shieldmax = $ship->f("shieldmax");			
			$stored_ship_shieldcurrent = $ship->f("shieldcurrent");
			$stored_ship_armormax = $ship->f("armormax");			
			$stored_ship_armorcurrent = $ship->f("armorcurrent");
			$stored_ship_minesmax = $ship->f("minesmax");
			$stored_ship_minescurrent = $ship->f("minescurrent");
			$stored_ship_combatmax = $ship->f("combatmax");
			$stored_ship_combatcurrent = $ship->f("combatcurrent");
			$stored_ship_scoutmax = $ship->f("scoutmax");
 			$stored_ship_scoutcurrent = $ship->f("scoutcurrent");
			$stored_ship_cargomax = $ship->f("cargomax");			
			$stored_ship_cargocurrent = $ship->f("cargocurrent");		
			$stored_ship_hardpoints = $ship->f("hardpoints");				
			$stored_ship_turns_per_sector = $ship->f("turns_per_sector");			
			$stored_ship_scanner = $ship->f("scanner");		
			$stored_ship_illusion = $ship->f("illusion");
			$stored_ship_jump = $ship->f("jump");
			$stored_ship_galaxy_jump = $ship->f("galaxy_jump");
			$stored_ship_cloak = $ship->f("cloak");		
			$stored_ship_tracking = $ship->f("tracking");		
			$stored_ship_deep_scanner = $ship->f("deep_scanner");	
			$stored_ship_powermax = $ship->f("powermax");			
			$stored_ship_powercurrent = $ship->f("powercurrent");
			$stored_ship_targeting_computer = $ship->f("targeting_computer");
			$stored_ship_active_screens = $ship->f("active_screens");
			$stored_ship_screensmax = $ship->f("screensmax");
			$stored_ship_plasma_booster = $ship->f("plasma_booster");
			$stored_ship_tractor_beam = $ship->f("tractor_beam");
			$stored_ship_trifocus_plasma = $ship->f("trifocus_plasma");
			$stored_ship_battle_systems_computer = $ship->f("battle_systems_computer");
			$stored_ship_cargo = $ship->f("cargo");

			$ship->set_type_id($db->f("type_id"));
			$ship->set_type($db->f("type"));
			$ship->set_shieldmax($db->f("shieldmax"));
			$ship->set_shieldcurrent($db->f("shieldcurrent"));
			$ship->set_armormax($db->f("armormax"));
			$ship->set_armorcurrent($db->f("armorcurrent"));
			$ship->set_minesmax($db->f("minesmax"));
			$ship->set_minescurrent($db->f("minescurrent"));
			$ship->set_combatmax($db->f("combatmax"));
			$ship->set_combatcurrent($db->f("combatcurrent"));
			$ship->set_scoutmax($db->f("scoutmax"));
			$ship->set_scoutcurrent($db->f("scoutcurrent"));
			$ship->set_cargomax($db->f("cargomax"));
			$ship->set_cargocurrent($db->f("cargocurrent"));
			$ship->set_hardpoints($db->f("hardpoints"));			
			$ship->set_turns_per_sector($db->f("turns_per_sector"));								
			$ship->set_powermax($db->f("powermax"));
			$ship->set_powercurrent($db->f("powercurrent"));
			$ship->set_cargo($db->f("cargo"));
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_tracking($db->f("tracking"));
			$technology->set_deep_scanner($db->f("deep_scanner"));
			$technology->set_tracking_locked('f');		
			$technology->set_tracking_player_id(0);
			$technology->set_targeting_computer($db->f("targeting_computer"));
			$technology->set_active_screens($db->f("active_screens"));
			$technology->set_screensmax($db->f("screensmax"));
			$technology->set_screenscurrent($db->f("screensmax"));
			$technology->set_plasma_booster($db->f("plasma_booster"));
			$technology->set_tractor_beam($db->f("tractor_beam"));
			$technology->set_trifocus_plasma($db->f("trifocus_plasma"));
			$technology->set_battle_systems_computer($db->f("battle_systems_computer"));
			$technology->set_scanner($db->f("scanner"));
			$technology->set_illusion($db->f("illusion"));
			$technology->set_jump($db->f("jump"));
			$technology->set_galaxy_jump($db->f("galaxy_jump"));
			$technology->set_cloak($db->f("cloak"));												
			$technology->set_cloak_active('f');
			$technology->set_illusion_active('f');	
			$technology->save();

			$board_time = time();

			$query = "update ships_storage set
				type_id = $stored_ship_type_id,
				type = '$stored_ship_type',
				shieldmax = '$stored_ship_shieldmax',
				shieldcurrent = '$stored_ship_shieldcurrent',
				armormax = '$stored_ship_armormax',
				armorcurrent = '$stored_ship_armorcurrent',
				minesmax = '$stored_ship_minesmax',
				minescurrent = '$stored_ship_minescurrent',
				combatmax = '$stored_ship_combatmax',
				combatcurrent = '$stored_ship_combatcurrent',
				scoutmax = '$stored_ship_scoutmax',
				scoutcurrent = '$stored_ship_scoutcurrent',
				cargomax = '$stored_ship_cargomax',
				cargocurrent = '$stored_ship_cargocurrent',
				hardpoints = '$stored_ship_hardpoints',				
				scanner = '$stored_ship_scanner',
				illusion = '$stored_ship_illusion',
				cloak = '$stored_ship_cloak',
				jump = '$stored_ship_jump',
				galaxy_jump = '$stored_ship_galaxy_jump',
				turns_per_sector = '$stored_ship_turns_per_sector',
				board_time = '$board_time',
				tracking = '$stored_ship_tracking',
				deep_scanner = '$stored_ship_deep_scanner',
				powermax = '$stored_ship_powermax',
				powercurrent = '$stored_ship_powercurrent',
				targeting_computer = '$stored_ship_targeting_computer',
				active_screens = '$stored_ship_active_screens',
				screensmax = '$stored_ship_screensmax',
				plasma_booster = '$stored_ship_plasma_booster',
				tractor_beam = '$stored_ship_tractor_beam',
				trifocus_plasma = '$stored_ship_trifocus_plasma',
				battle_systems_computer = '$stored_ship_battle_systems_computer',
				cargo = '$stored_ship_cargo'
				where ship_storage_id = '$id'";
				
			$db->query($query);

			$weapons = new ME_Weapons;
			$weapons->get_weapons($ship->f("ship_id"));

			$stored_weapon_1_id = $weapons->f("weapon_1_id");
			$stored_weapon_1_name = $weapons->f("weapon_1_name");
			$stored_weapon_1_shield_damage = $weapons->f("weapon_1_shield_damage");
			$stored_weapon_1_armor_damage = $weapons->f("weapon_1_armor_damage");

			$stored_weapon_2_id = $weapons->f("weapon_2_id");
			$stored_weapon_2_name = $weapons->f("weapon_2_name");
			$stored_weapon_2_shield_damage = $weapons->f("weapon_2_shield_damage");
			$stored_weapon_2_armor_damage = $weapons->f("weapon_2_armor_damage");

			$stored_weapon_3_id = $weapons->f("weapon_3_id");
			$stored_weapon_3_name = $weapons->f("weapon_3_name");
			$stored_weapon_3_shield_damage = $weapons->f("weapon_3_shield_damage");
			$stored_weapon_3_armor_damage = $weapons->f("weapon_3_armor_damage");

			$stored_weapon_4_id = $weapons->f("weapon_4_id");
			$stored_weapon_4_name = $weapons->f("weapon_4_name");
			$stored_weapon_4_shield_damage = $weapons->f("weapon_4_shield_damage");
			$stored_weapon_4_armor_damage = $weapons->f("weapon_4_armor_damage");

			$stored_weapon_5_id = $weapons->f("weapon_5_id");
			$stored_weapon_5_name = $weapons->f("weapon_5_name");
			$stored_weapon_5_shield_damage = $weapons->f("weapon_5_shield_damage");
			$stored_weapon_5_armor_damage = $weapons->f("weapon_5_armor_damage");

			$stored_weapon_6_id = $weapons->f("weapon_6_id");
			$stored_weapon_6_name = $weapons->f("weapon_6_name");
			$stored_weapon_6_shield_damage = $weapons->f("weapon_6_shield_damage");
			$stored_weapon_6_armor_damage = $weapons->f("weapon_6_armor_damage");

			$stored_weapon_7_id = $weapons->f("weapon_7_id");
			$stored_weapon_7_name = $weapons->f("weapon_7_name");
			$stored_weapon_7_shield_damage = $weapons->f("weapon_7_shield_damage");
			$stored_weapon_7_armor_damage = $weapons->f("weapon_7_armor_damage");

			$stored_weapon_8_id = $weapons->f("weapon_8_id");
			$stored_weapon_8_name = $weapons->f("weapon_8_name");
			$stored_weapon_8_shield_damage = $weapons->f("weapon_8_shield_damage");
			$stored_weapon_8_armor_damage = $weapons->f("weapon_8_armor_damage");

			$db->query("SELECT * from ship_weapons_stored where ship_stored_id = '$id'");
			$db->next_record();
	
			$weapons->set_weapon_1_id($db->f("weapon_1_id"));
			$weapons->set_weapon_1_name($db->f("weapon_1_name"));
			$weapons->set_weapon_1_shield_damage($db->f("weapon_1_shield_damage"));	
			$weapons->set_weapon_1_armor_damage($db->f("weapon_1_armor_damage"));	

			$weapons->set_weapon_2_id($db->f("weapon_2_id"));
			$weapons->set_weapon_2_name($db->f("weapon_2_name"));
			$weapons->set_weapon_2_shield_damage($db->f("weapon_2_shield_damage"));	
			$weapons->set_weapon_2_armor_damage($db->f("weapon_2_armor_damage"));	
	
			$weapons->set_weapon_3_id($db->f("weapon_3_id"));
			$weapons->set_weapon_3_name($db->f("weapon_3_name"));
			$weapons->set_weapon_3_shield_damage($db->f("weapon_3_shield_damage"));	
			$weapons->set_weapon_3_armor_damage($db->f("weapon_3_armor_damage"));	
	
			$weapons->set_weapon_4_id($db->f("weapon_4_id"));
			$weapons->set_weapon_4_name($db->f("weapon_4_name"));
			$weapons->set_weapon_4_shield_damage($db->f("weapon_4_shield_damage"));	
			$weapons->set_weapon_4_armor_damage($db->f("weapon_4_armor_damage"));	
	
			$weapons->set_weapon_5_id($db->f("weapon_5_id"));
			$weapons->set_weapon_5_name($db->f("weapon_5_name"));
			$weapons->set_weapon_5_shield_damage($db->f("weapon_5_shield_damage"));	
			$weapons->set_weapon_5_armor_damage($db->f("weapon_5_armor_damage"));	
	
			$weapons->set_weapon_6_id($db->f("weapon_6_id"));
			$weapons->set_weapon_6_name($db->f("weapon_6_name"));
			$weapons->set_weapon_6_shield_damage($db->f("weapon_6_shield_damage"));	
			$weapons->set_weapon_6_armor_damage($db->f("weapon_6_armor_damage"));	
	
			$weapons->set_weapon_7_id($db->f("weapon_7_id"));
			$weapons->set_weapon_7_name($db->f("weapon_7_name"));
			$weapons->set_weapon_7_shield_damage($db->f("weapon_7_shield_damage"));	
			$weapons->set_weapon_7_armor_damage($db->f("weapon_7_armor_damage"));	
	
			$weapons->set_weapon_8_id($db->f("weapon_8_id"));
			$weapons->set_weapon_8_name($db->f("weapon_8_name"));
			$weapons->set_weapon_8_shield_damage($db->f("weapon_8_shield_damage"));	
			$weapons->set_weapon_8_armor_damage($db->f("weapon_8_armor_damage"));				
			  		
			$query = "update ship_weapons_stored set

			weapon_1_id = '$stored_weapon_1_id',
			weapon_2_id = '$stored_weapon_2_id',
			weapon_3_id = '$stored_weapon_3_id',
			weapon_4_id = '$stored_weapon_4_id',
			weapon_5_id = '$stored_weapon_5_id',
			weapon_6_id = '$stored_weapon_6_id',
			weapon_7_id = '$stored_weapon_7_id',
			weapon_8_id = '$stored_weapon_8_id',

			weapon_1_name = '$stored_weapon_1_name',
			weapon_2_name = '$stored_weapon_2_name',
			weapon_3_name = '$stored_weapon_3_name',
			weapon_4_name = '$stored_weapon_4_name',
			weapon_5_name = '$stored_weapon_5_name',
			weapon_6_name = '$stored_weapon_6_name',
			weapon_7_name = '$stored_weapon_7_name',
			weapon_8_name = '$stored_weapon_8_name',

			weapon_1_shield_damage = '$stored_weapon_1_shield_damage',
			weapon_2_shield_damage = '$stored_weapon_2_shield_damage',
			weapon_3_shield_damage = '$stored_weapon_3_shield_damage',
			weapon_4_shield_damage = '$stored_weapon_4_shield_damage',
			weapon_5_shield_damage = '$stored_weapon_5_shield_damage',
			weapon_6_shield_damage = '$stored_weapon_6_shield_damage',
			weapon_7_shield_damage = '$stored_weapon_7_shield_damage',
			weapon_8_shield_damage = '$stored_weapon_8_shield_damage',

			weapon_1_armor_damage = '$stored_weapon_1_armor_damage',
			weapon_2_armor_damage = '$stored_weapon_2_armor_damage',
			weapon_3_armor_damage = '$stored_weapon_3_armor_damage',
			weapon_4_armor_damage = '$stored_weapon_4_armor_damage',
			weapon_5_armor_damage = '$stored_weapon_5_armor_damage',
			weapon_6_armor_damage = '$stored_weapon_6_armor_damage',
			weapon_7_armor_damage = '$stored_weapon_7_armor_damage',
			weapon_8_armor_damage = '$stored_weapon_8_armor_damage'

			where ship_stored_id = '$id'";
		
			$db->query($query);

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);
			$cargo->delete_cargo();			

			$cargo->save();
			$ship->save();	
			$weapons->save();

			break;

		case "store_tech_x":
			$amount = (int) $amount;
			$returnto = "hangar";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}

			if ( $source == 'shared' ) {
				$planetary_tech = get_planetary_tech($db_p);
			} else {
				$db = new ME_DB;
				$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				$db->next_record();
			
				$planetary_tech = get_planetary_tech($db);		
			}			

			if ( $amount > $planetary_tech[$tech_type] ) {
				$error = 7;
				break;
     	}

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $cargo->Open_holds < $amount ) {
				$error = 8;
				break;    				
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where name = '$tech_type'");
			$db->next_record();								

			$new_tech = $cargo->Current_cargo[$tech_type]['amount'] + $amount;
				
			$cargo->set_good($tech_type, 2, $new_tech);
			$cargo->save();						

			$planetary_tech[$tech_type] = $planetary_tech[$tech_type] - $amount;
			$tech_temp = array();

			while (list($key, $val) = each($planetary_tech)) {
				if ( $val > 0 ) {
					array_push($tech_temp, $key);
					array_push($tech_temp, $val);
				}
			}		
		
			$new_tech = implode(",", $tech_temp);

			if ( $source == 'shared' ) {
				$db_p_u = new ME_DB;
				$db_p_u->query("update planets set ship_technology = '$new_tech'	where planet_id = '$planet_id'");	
			} else {
				$db_p_u = new ME_DB;
				$db_p_u->query("update planet_merchant_storage set ship_technology = '$new_tech' where planet_id = '$planet_id' and player_id = '$player_id'");			
			}
			
			break;

		case "install_tech_x":
			$amount = (int) $amount;
			$returnto = "hangar";		

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}

			if ( $source == 'shared' ) {
				$planetary_tech = get_planetary_tech($db_p);					
			} else {
				$db = new ME_DB;
				$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				$db->next_record();
			
				$planetary_tech = get_planetary_tech($db);		
			}

			if ( $amount > $planetary_tech[$tech_type] ) {
				$error = 7;
				break;
     	}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where name = '$tech_type'");
			$db->next_record();

			switch ($db->f("technology_type_id")) {
				case "1":
					$current_shields = $ship->f("shieldcurrent");
  		    $max_shields = $ship->f("shieldmax");

					if ( $current_shields + $amount > $max_shields ) {
	    	  	$error = 10;
						break;
					}

					$new_shields = $ship->f("shieldcurrent") + $amount;
					$ship->set_shieldcurrent($new_shields);
					$ship->save();

					break;
				case "2":
					$current_armor = $ship->f("armorcurrent");
    		  $max_armor = $ship->f("armormax");

					if ( $current_armor + $amount > $max_armor ) {
    		  	$error = 10;
						break;	
					}
					
					$new_armor = $ship->f("armorcurrent") + $amount;
					$ship->set_armorcurrent($new_armor);
					$ship->save();

					break;
				case "3":
					$current_cargo = $ship->f("cargocurrent");
					$max_cargo = $ship->f("cargomax");

					if ( $current_cargo + $amount > $max_cargo ) {
		      	$error = 10;
						break;	
					}				

					$new_cargo = $ship->f("cargocurrent") + $amount;
					$ship->set_cargocurrent($new_cargo);
					$ship->save();

					break;
				case "4":
					$type_id = $ship->f("type_id");					

					$db = new ME_DB;
					$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
					$db->next_record();

					if ( $db->f("illusion") == 'f' ) {
						$error = 12;
						break;		
					}

					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("illusion") ) {
						$error = 11;
						break;
					}					
																	
					$technology->set_illusion($technology->f("illusion") + 1);
					$technology->save();

					break;
				case "5":
					$type_id = $ship->f("type_id");
			
					$db = new ME_DB;
					$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
					$db->next_record();					

					if ( $db->f("scanner") == 'f' ) {
						$error = 12;
						break;		
					}

					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("scanner") ) {
						$error = 11;
						break;
					}

					$technology->set_scanner($technology->f("scanner") + 1);
					$technology->save();

					break;
				case "6":
					$type_id = $ship->f("type_id");
			
					$db = new ME_DB;
					$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
					$db->next_record();
					
					if ( $db->f("jump") == 'f' ) {
						$error = 12;
						break;		
					}
			
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("jump") ) {
						$error = 11;
						break;
					}

					$technology->set_jump($technology->f("jump") + 1);
					$technology->save();

					break;
				case "7":
					$type_id = $ship->f("type_id");
			
					$db = new ME_DB;
					$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
					$db->next_record();					

					if ( $db->f("cloak") == 'f' ) {
						$error = 12;
						break;		
					}
			
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("cloak") ) {
						$error = 11;
						break;
					}

					$technology->set_cloak($technology->f("cloak") + 1);
					$technology->save();

					break;
				case "8":
					$current_mines = $ship->f("minescurrent");
		      $max_mines = $ship->f("minesmax");
    	
					if ( $current_mines + $amount > $max_mines ) {
		      	$error = 10;
						break;	
					}
		
					$new_mines = $ship->f("minescurrent") + $amount;
					$ship->set_minescurrent($new_mines);
					$ship->save();

					break;
				case "9":
					$current_combat = $ship->f("combatcurrent");
		      $max_combat = $ship->f("combatmax");

					if ( $current_combat + $amount > $max_combat ) {
		      	$error = 10;
						break;	
					}
				
					$new_combat = $ship->f("combatcurrent") + $amount;
					$ship->set_combatcurrent($new_combat);
					$ship->save();

					break;
				case "10":
					$current_scout = $ship->f("scoutcurrent");
		      $max_scout = $ship->f("scoutmax");

					if ( $current_scout + $amount > $max_scout ) {
		      	$error = 10;
						break;	
					}			
    		
					$new_scout = $ship->f("scoutcurrent") + $amount;
					$ship->set_scoutcurrent($new_scout);
					$ship->save();

					break;
				case "11":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("tracking") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_tracking($technology->f("tracking") + $amount);
					$technology->save();

					break;
				case "12":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("deep_scanner") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_deep_scanner($technology->f("deep_scanner") + $amount);
					$technology->save();

					break;
				case "13":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("targeting_computer") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_targeting_computer($technology->f("targeting_computer") + $amount);
					$technology->save();

					break;
				case "14":					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("plasma_booster") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_plasma_booster($technology->f("plasma_booster") + $amount);
					$technology->save();

					break;
				case "15":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("tractor_beam") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_tractor_beam($technology->f("tractor_beam") + $amount);
					$technology->save();

					break;
				
				case "16":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("active_screens") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_active_screens($technology->f("active_screens") + $amount);
					$technology->save();

					break;
				case "17":
					$current_power = $ship->f("powercurrent");
		      $max_power = $ship->f("powermax");

					if ( $current_power + $amount > $max_power ) {
		      	$error = 10;
						break;	
					}			

					$new_power = $ship->f("powercurrent") + $amount;
					$ship->set_powercurrent($new_power);
      		$ship->save();

					break;

				case "18":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("trifocus_plasma") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_trifocus_plasma($technology->f("trifocus_plasma") + $amount);
					$technology->save();
					break;
	
				case "19":
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));

					if ( $technology->f("battle_systems_computer") + $amount > 4 ) {
						$error = 16;
						break;
					}

					$technology->set_battle_systems_computer($technology->f("battle_systems_computer") + $amount);
					$technology->save();
					break;
			}												
			
			if ( !$error ) {				
				$planetary_tech[$tech_type] = $planetary_tech[$tech_type] - $amount;
				$tech_temp = array();

				while (list($key, $val) = each($planetary_tech)) {
					if ( $val > 0 ) {
						array_push($tech_temp, $key);
						array_push($tech_temp, $val);
					}
				}		
		
				$new_tech = implode(",", $tech_temp);

				if ( $source == 'shared' ) {
					$db_p_u = new ME_DB;
					$db_p_u->query("update planets set ship_technology = '$new_tech'	where planet_id = '$planet_id'");	
				} else {
					$db_p_u = new ME_DB;
					$db_p_u->query("update planet_merchant_storage set ship_technology = '$new_tech' where planet_id = '$planet_id' and player_id = '$player_id'");			
				}
			}

			break;

		case "unload_installed_tech_x":
			$amount = (int) $amount;
			$returnto = "hangar";		

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}
			
			$planetary_tech = get_planetary_tech($db_p);

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where name = '$tech_type'");
			$db->next_record();

			switch ($db->f("technology_type_id")) {
				case "1":
					$current_shields = $ship->f("shieldcurrent");
  		    $max_shields = $ship->f("shieldmax");					

					if ( $current_shields - $amount < 0 ) {
	    	  	$error = 10;
						break;
					}

					$new_shields = $ship->f("shieldcurrent") - $amount;
					$ship->set_shieldcurrent($new_shields);
					$ship->save();
					break;

				case "2":
					$current_armor = $ship->f("armorcurrent");
    		  $max_armor = $ship->f("armormax");

					if ( $current_armor - $amount < 0 ) {
    		  	$error = 10;
						break;	
					}
					
					$new_armor = $ship->f("armorcurrent") - $amount;
					$ship->set_armorcurrent($new_armor);
					$ship->save();
					break;

				case "3":
					$current_cargo = $ship->f("cargocurrent");
					$max_cargo = $ship->f("cargomax");

					if ( $current_cargo - $amount < 0 ) {
		      	$error = 10;
						break;	
					}				

					$new_cargo = $ship->f("cargocurrent") - $amount;
					$ship->set_cargocurrent($new_cargo);
					$ship->save();
					break;

				case "4":
					$type_id = $ship->f("type_id");
					
					if ( $amount > $ship->f("illusion") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_illusion($technology->f("illusion") - $amount);		
					$technology->save();

					break;
				case "5":
					$type_id = $ship->f("type_id");										

					if ( $amount > $ship->f("scanner") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_scanner($technology->f("scanner") - $amount);		
					$technology->save();
	
					break;
				case "6":
					$type_id = $ship->f("type_id");										

					if ( $amount > $ship->f("jump") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_jump($technology->f("jump") - $amount);		
					$technology->save();					

					break;
				case "7":
					$type_id = $ship->f("type_id");								

					if ( $amount > $ship->f("cloak") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_cloak($technology->f("cloak") - $amount);		
					$technology->save();					

					break;
				case "8":
					$current_mines = $ship->f("minescurrent");
		      $max_mines = $ship->f("minesmax");
    	
					if ( $current_mines - $amount < 0 ) {
		      	$error = 10;
						break;	
					}
		
					$new_mines = $ship->f("minescurrent") - $amount;
					$ship->set_minescurrent($new_mines);
					$ship->save();

					break;
				case "9":
					$current_combat = $ship->f("combatcurrent");
		      $max_combat = $ship->f("combatmax");

					if ( $current_combat - $amount < 0 ) {
		      	$error = 10;
						break;	
					}
				
					$new_combat = $ship->f("combatcurrent") - $amount;
					$ship->set_combatcurrent($new_combat);
					$ship->save();

					break;
				case "10":
					$current_scout = $ship->f("scoutcurrent");
		      $max_scout = $ship->f("scoutmax");

					if ( $current_scout - $amount < 0 ) {
		      	$error = 10;
						break;	
					}			
    		
					$new_scout = $ship->f("scoutcurrent") - $amount;
					$ship->set_scoutcurrent($new_scout);
					$ship->save();

					break;
				case "11":
					if ( $amount > $ship->f("tracking") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_tracking($technology->f("tracking") - $amount);		
					$technology->save();	

					break;
				case "12":
					if ( $amount > $ship->f("deep_scanner") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_deep_scanner($technology->f("deep_scanner") - $amount);
					$technology->save();	

					break;
				case "13":
					if ( $amount > $ship->f("targeting_computer") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_targeting_computer($technology->f("targeting_computer") - $amount);
					$technology->save();	

					break;
				case "14":					
					if ( $amount > $ship->f("plasma_booster") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_plasma_booster($technology->f("plasma_booster") - $amount);
					$technology->save();	

					break;
				case "15":
					if ( $amount > $ship->f("tractor_beam") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_tractor_beam($technology->f("tractor_beam") - $amount);
					$technology->save();	

					break;
				case "16":
					if ( $amount > $ship->f("active_screens") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_active_screens($technology->f("active_screens") - $amount);
					$technology->save();	

					break;
				case "17":
					$current_power = $ship->f("powercurrent");
		      $max_power = $ship->f("powermax");

					if ( $current_power - $amount < 0 ) {
		      	$error = 10;
						break;	
					}			

					$new_power = $ship->f("powercurrent") - $amount;
					$ship->set_powercurrent($new_power);
					$ship->save();

					break;
				case "18":
					if ( $amount > $ship->f("trifocus_plasma") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_trifocus_plasma($technology->f("trifocus_plasma") - $amount);
					$technology->save();	

					break;
				case "19":
					if ( $amount > $ship->f("battle_systems_computer") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_battle_systems_computer($technology->f("battle_systems_computer") - $amount);
					$technology->save();	

					break;
			}												
			
			if ( !$error ) {
				if ( $planetary_tech[$tech_type] + $amount > 500 ) {
  	 	  	$error = 15;
					break;
				}

				$planetary_tech[$tech_type] = $planetary_tech[$tech_type] + $amount;
				$tech_temp = array();

				while (list($key, $val) = each($planetary_tech)) {
					if ( $val > 0 ) {
						array_push($tech_temp, $key);
						array_push($tech_temp, $val);
					}
				}		
		
				$new_tech = implode(",", $tech_temp);

				$db_p_u = new ME_DB;
				$db_p_u->query("update planets set ship_technology = '$new_tech'	where planet_id = '$planet_id'");				
			}

			break;

		case "unload_installed_tech_personal_x":
			$amount = (int) $amount;
			$returnto = "hangar";		

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}
			
			$db = new ME_DB;
			$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
			$db->next_record();
			
			$planetary_tech_personal = get_planetary_tech($db);		

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where name = '$tech_type'");
			$db->next_record();

			switch ($db->f("technology_type_id")) {
				case "1":
					$current_shields = $ship->f("shieldcurrent");
  		    $max_shields = $ship->f("shieldmax");					

					if ( $current_shields - $amount < 0 ) {
	    	  	$error = 10;
						break;
					}

					$new_shields = $ship->f("shieldcurrent") - $amount;
					$ship->set_shieldcurrent($new_shields);
					$ship->save();

					break;

				case "2":
					$current_armor = $ship->f("armorcurrent");
    		  $max_armor = $ship->f("armormax");

					if ( $current_armor - $amount < 0 ) {
    		  	$error = 10;
						break;	
					}
					
					$new_armor = $ship->f("armorcurrent") - $amount;
					$ship->set_armorcurrent($new_armor);
					$ship->save();

					break;

				case "3":
					$current_cargo = $ship->f("cargocurrent");
					$max_cargo = $ship->f("cargomax");

					if ( $current_cargo - $amount < 0 ) {
		      	$error = 10;
						break;	
					}				

					$new_cargo = $ship->f("cargocurrent") - $amount;
					$ship->set_cargocurrent($new_cargo);
					$ship->save();

					break;

				case "4":
					$type_id = $ship->f("type_id");
					
					if ( $amount > $ship->f("illusion") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_illusion($technology->f("illusion") - $amount);		
					$technology->save();

					break;
				case "5":
					$type_id = $ship->f("type_id");										

					if ( $amount > $ship->f("scanner") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_scanner($technology->f("scanner") - $amount);		
					$technology->save();
	
					break;
				case "6":
					$type_id = $ship->f("type_id");										

					if ( $amount > $ship->f("jump") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_jump($technology->f("jump") - $amount);		
					$technology->save();					

					break;
				case "7":
					$type_id = $ship->f("type_id");								

					if ( $amount > $ship->f("cloak") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_cloak($technology->f("cloak") - $amount);		
					$technology->save();					

					break;
				case "8":
					$current_mines = $ship->f("minescurrent");
		      $max_mines = $ship->f("minesmax");
    	
					if ( $current_mines - $amount < 0 ) {
		      	$error = 10;
						break;	
					}
		
					$new_mines = $ship->f("minescurrent") - $amount;
					$ship->set_minescurrent($new_mines);
					$ship->save();

					break;

				case "9":
					$current_combat = $ship->f("combatcurrent");
		      $max_combat = $ship->f("combatmax");

					if ( $current_combat - $amount < 0 ) {
		      	$error = 10;
						break;	
					}
				
					$new_combat = $ship->f("combatcurrent") - $amount;
					$ship->set_combatcurrent($new_combat);
					$ship->save();

					break;

				case "10":
					$current_scout = $ship->f("scoutcurrent");
		      $max_scout = $ship->f("scoutmax");

					if ( $current_scout - $amount < 0 ) {
		      	$error = 10;
						break;	
					}			
    		
					$new_scout = $ship->f("scoutcurrent") - $amount;
					$ship->set_scoutcurrent($new_scout);
					$ship->save();

					break;

				case "11":
					if ( $amount > $ship->f("tracking") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_tracking($technology->f("tracking") - $amount);		
					$technology->save();	

					break;
				case "12":
					if ( $amount > $ship->f("deep_scanner") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_deep_scanner($technology->f("deep_scanner") - $amount);
					$technology->save();	

					break;
				case "13":
					if ( $amount > $ship->f("targeting_computer") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_targeting_computer($technology->f("targeting_computer") - $amount);
					$technology->save();	

					break;
				case "14":					
					if ( $amount > $ship->f("plasma_booster") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_plasma_booster($technology->f("plasma_booster") - $amount);
					$technology->save();	
					break;
				case "15":
					if ( $amount > $ship->f("tractor_beam") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_tractor_beam($technology->f("tractor_beam") - $amount);
					$technology->save();	

					break;
				case "16":
					if ( $amount > $ship->f("active_screens") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_active_screens($technology->f("active_screens") - $amount);
					$technology->save();	

					break;
				case "17":
					$current_power = $ship->f("powercurrent");
		      $max_power = $ship->f("powermax");

					if ( $current_power - $amount < 0 ) {
		      	$error = 10;
						break;	
					}			

					$new_power = $ship->f("powercurrent") - $amount;
					$ship->set_powercurrent($new_power);
					$ship->save();

					break;

				case "18":
					if ( $amount > $ship->f("trifocus_plasma") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_trifocus_plasma($technology->f("trifocus_plasma") - $amount);
					$technology->save();	

					break;
				case "19":
					if ( $amount > $ship->f("battle_systems_computer") ) {
						$error = 13;
						break;	
					}
					
					$technology = new ME_Technology;
					$technology->get_technology($ship->f("ship_id"));	
					$technology->set_battle_systems_computer($technology->f("battle_systems_computer") - $amount);
					$technology->save();	

					break;
			}												
			
			if ( !$error ) {
				if ( $planetary_tech_personal[$tech_type] + $amount > 500 ) {
  	 	  	$error = 15;
					break;
				}

				$planetary_tech_personal[$tech_type] = $planetary_tech_personal[$tech_type] + $amount;
				$tech_temp = array();

				while (list($key, $val) = each($planetary_tech_personal)) {
					if ( $val > 0 ) {
						array_push($tech_temp, $key);
						array_push($tech_temp, $val);
					}
				}		
		
				$new_tech = implode(",", $tech_temp);

				$db_p_u = new ME_DB;
				$db_p_u->query("update planet_merchant_storage set ship_technology = '$new_tech' where planet_id = '$planet_id' and player_id = '$player_id'");							
			}

			break;

		case "unload_stored_tech_x":
			$amount = (int) $amount;			
			$returnto = "hangar";			
			
			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}						

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $cargo->Current_cargo[$tech_type]['amount'] < $amount ) {
				$error = 13;
				break;
			}			
			
			$planetary_tech = get_planetary_tech($db_p);
			
			if ( $planetary_tech[$tech_type] + $amount > 500 ) {
 	 	  	$error = 15;
				break;
			}

			$new_tech = $cargo->Current_cargo[$tech_type]['amount'] - $amount;
				
			$cargo->set_good($tech_type, 2, $new_tech);
			$cargo->save();
			
			$planetary_tech[$tech_type] = $planetary_tech[$tech_type] + $amount;
			$tech_temp = array();

			while (list($key, $val) = each($planetary_tech)) {
				if ( $val > 0 ) {
					array_push($tech_temp, $key);
					array_push($tech_temp, $val);
				}
			}		
		
			$new_tech = implode(",", $tech_temp);

			$db_p_u = new ME_DB;
			$db_p_u->query("update planets set ship_technology = '$new_tech' where planet_id = '$planet_id'");		
			
			break;

		case "unload_stored_tech_personal_x":
			$amount = (int) $amount;			
			$returnto = "hangar";			
			
			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}						

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $cargo->Current_cargo[$tech_type]['amount'] < $amount ) {
				$error = 13;
				break;
			}			

			$db = new ME_DB;
			$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
			$db->next_record();
			
			$planetary_tech_personal = get_planetary_tech($db);
			
			if ( $planetary_tech_personal[$tech_type] + $amount > 500 ) {
 	 	  	$error = 15;
				break;
			}

			$new_tech = $cargo->Current_cargo[$tech_type]['amount'] - $amount;
				
			$cargo->set_good($tech_type, 2, $new_tech);
			$cargo->save();
			
			$planetary_tech_personal[$tech_type] = $planetary_tech_personal[$tech_type] + $amount;
			$tech_temp = array();

			while (list($key, $val) = each($planetary_tech_personal)) {
				if ( $val > 0 ) {
					array_push($tech_temp, $key);
					array_push($tech_temp, $val);
				}
			}		
		
			$new_tech = implode(",", $tech_temp);

			$db_p_u = new ME_DB;
			$db_p_u->query("update planet_merchant_storage set ship_technology = '$new_tech' where planet_id = '$planet_id' and player_id = '$player_id'");
			
			break;

		case "trifocus_fire":	
			$returnto = 'attack';
		  		
			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_military") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $db_p->f("trifocus_plasma") == 'f' ) {
				$error = 10;
				break;					
			}			

			if ( $player->f("newturnsleft") > 0 ) {
				$error = 24;
				break;
			}

			if ( $player->f("turns") - 2 < 0 ) {
				$error = 6;
				break;
			}
			
			$db = new ME_DB;
			$db->query("select player_id, public_player_id, experience, level, name, game_id, race, alliance_name, newturnsleft from players where name = '$trifocus_target' and game_id = '$game_id'");
			$db->next_record();

			$target_player_id = $db->f("player_id");
				
			if ( $db->nf() == 0 ) {
				$error = 11;
				break;
			}

			if ( !($trifocus_sector > 0) ) {
				$error = 3;
				break;
			}

			if ( $db_p->f("trifocus_fire_time") >= time() - 60 ) {
				$error = 17;
				break;
			}			

			$this_sector_id = $db_p->f("sector_id");
			$db->query("select * from sectors where sector_id = '$this_sector_id'");
			$db->next_record();
			$this_xpos = $db->f("xpos");
			$this_ypos = $db->f("ypos");
			
			$db->query("select * from sectors where public_sector_id = '$trifocus_sector'");
			$db->next_record();

			$player_map_id = $db->f("map_id");			
			$target_sector_id = $db->f("sector_id");		

			$map_sql = "select * from sectors where ";
		
			$merchants = array();
			$sectors = array();

			$counter = 1;
		
			$y_bound = 3;
			$x_bound = -3;
			$search_width = 7;
			$sector_limit = 50;		

			$y = $y_bound;
			for ($i = 1; $i <= $search_width; $i++) {
				$x = $x_bound;
				for ($j = 1; $j <= $search_width; $j++) {
					$map_sql = $map_sql . "( map_id = " . $player_map_id . " and xpos = " . ($this_xpos + $x) . " and ypos = " . ($this_ypos + $y) . " )";
					$counter++;

					if ( $counter <> $sector_limit ) {
						$map_sql = $map_sql . " or ";
					}

					$x = $x + 1;
				}
			
				$y = $y - 1;
			}				
											
			$query = $map_sql;
			$db->query($query);

			$surrounding_sectors = array();

			while ( $db->next_record() ) {
				if ( $db->f("public_sector_id") <> $db_p->f("public_sector_id") ) {
					array_push($surrounding_sectors, $db->f("public_sector_id"));
				}
			}

			if ( !in_array($trifocus_sector, $surrounding_sectors) ) {
				$error = 19;
				break;
			}
			
			$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, ship_technology.cloak_active, ship_technology.cloak, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id, players.player_id, players.name, players.experience from ships, sectors, players, ship_technology where ships.player_id = '$target_player_id' and ships.public_sector_id = '$trifocus_sector' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id and ship_technology.player_id = players.player_id");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = 18;
				break;
			} else {
				if ( $db->f("cloak_active") == 't' and $db->f("cloak") and $db->f("experience") > $player->f("experience") ) {
					$error = 18;
					break;
				}

				$target_sector_id = $db->f("sector_id");				
				
				$target_xpos = $db->f("xpos");
				$target_ypos = $db->f("ypos");
				$target_map_id = $db->f("map_id");
				$target_player_name = $db->f("name");
				
				$query = sprintf("select sector_id, type from locations where sector_id = '%s' and type = 'Authority'", $target_sector_id);
				$db->query($query);

				if ( $db->nf() > 0 ) {
					$error = 20;
					break;
				}			
	
				$db->query("select player_id, public_player_id, experience, name, game_id, race, alliance_name, newturnsleft from players where name = '$trifocus_target' and game_id = '$game_id'");
				$db->next_record();

				if ( $db->f("newturnsleft") > 0 ) {
					$error = 20;
					break;
				}

				$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id from ships, sectors where ships.player_id = '$player_id' and sectors.sector_id = '$planet_sector_id'");
				$db->next_record();			

				if ( $target_map_id <> $player_map_id ) {
					$error = 18;
					break;
				}
								
				$merchant_and_forces = array();

				$merchant_and_forces = attack_merchant_with_trifocus($player_id, $target_player_id);
		  }

			$merchant_killed = 'f';
			if ( $merchant_and_forces[0] == 1 ) {
				$merchant_killed = 't';
				merchant_dead($target_player_id, $player_id, $sector_id, "s");
			}

			$merchant_hit = 'f';
			if ( $merchant_and_forces[1] == 1 ) {
				$merchant_hit = 't';
					
				$date = time();	

				$message = "Your ship was hit by a long range energy weapon in sector " . $trifocus_sector . " that was fired from sector " . $db_p->f("public_sector_id") . ".";
				$message = $message . "<br><br>Ship status:";
				$message = $message . "<br>Shields: " . $merchant_and_forces[2];
				$message = $message . "<br>Armor: " . $merchant_and_forces[3];
				$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
					values ('$target_player_id', '$message', 'Bridge', 't', '$date')";
				$db->query($query);				
			}

			$query = "insert into trifocus_attacks (player_id, merchant_killed, merchant_hit, trifocus_target) values('$player_id', '$merchant_killed', '$merchant_hit', '$target_player_id')";
			$db->record_oid();	
			$db->query($query);

			$query = sprintf("select trifocus_attack_id from trifocus_attacks where oid = '%s'", $db->Last_OID);
			$db->query($query);
			$db->next_record();
		
			$trifocus_attack_id = $db->f("trifocus_attack_id");

			$query = sprintf("update planets set trifocus_fire_time = '%d' where planet_id = '$planet_id'", time());
			$db->query($query);

			$player->set_turns($player->f("turns") - 2);
			$player->save();

			break;					

		case "install_weapon_x":
    	$returnto = 'hangar';

			$amount = (int) $amount;

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			$weapons = new ME_Weapons;
			$weapons->get_weapons($ship->f("ship_id"));

			$hardpoints_allocated = 0;

			if ( $weapons->f("weapon_1_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}

			if ( $weapons->f("weapon_2_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}

			if ( $weapons->f("weapon_3_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}

			if ( $weapons->f("weapon_4_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}

			if ( $weapons->f("weapon_5_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}

			if ( $weapons->f("weapon_6_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}
	
			if ( $weapons->f("weapon_7_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}

			if ( $weapons->f("weapon_8_id") <> 0 ) {
			  $hardpoints_allocated = $hardpoints_allocated + 1;
			}			

      if ( $hardpoints_allocated + $amount > $ship->f("hardpoints") ) {
        $error = 17;
        break;
      }

			$db = new ME_DB;

			if ( $source == 'shared' ) {
				$planetary_weapons = get_planetary_weapons($db_p);					
			} else {
				$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				$db->next_record();
			
				$planetary_weapons = get_planetary_weapons($db);		
			}

			if ( $planetary_weapons[$weapon_type] < $amount ) {
				$error = 18;
				break;
     	}

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}

      $db->query("SELECT * from weapons where name = '$weapon_type'");
      $db->next_record();

			if ( $db->f("restrictions") == 2 and $player->f("alignment") > -200 ) {
				$error = 20;
				break;
			}

			if ( $db->f("restrictions") == 1 and $player->f("alignment") < 200 ) {
				$error = 20;
				break;
			}

			for ($i = 1; $i <= $amount; $i++) {
	      add_weapon($db->f("weapon_id"), $weapon_type, $weapons);				

				$weapons = new ME_Weapons;
				$weapons->get_weapons($ship->f("ship_id"));
			}

			$planetary_weapons[$weapon_type] = $planetary_weapons[$weapon_type] - $amount;
			$weapons_temp = array();

			while (list($key, $val) = each($planetary_weapons)) {
				if ( $val > 0 ) {
					array_push($weapons_temp, $key);
					array_push($weapons_temp, $val);
				}
			}		
		
			$new_weapons = implode(",", $weapons_temp);

			if ( $source == 'shared' ) {
				$db_p_u = new ME_DB;
				$db_p_u->query("update planets set ship_weapons = '$new_weapons' where planet_id = '$planet_id'");	
			} else {
				$db_p_u = new ME_DB;
				$db_p_u->query("update planet_merchant_storage set ship_weapons = '$new_weapons' where planet_id = '$planet_id' and player_id = '$player_id'");			
			}

			break;

		case "store_weapon_x":
			$amount = (int) $amount;
			$returnto = "hangar";

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}

			$db = new ME_DB;

			if ( $source == 'shared' ) {
				$planetary_weapons = get_planetary_weapons($db_p);
			} else {				
				$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				$db->next_record();
			
				$planetary_weapons = get_planetary_weapons($db);
			}			

			if ( $amount > $planetary_weapons[$weapon_type] ) {
				$error = 7;
				break;
     	}

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $cargo->Open_holds < $amount ) {
				$error = 8;
				break;    				
			}

			$db->query("SELECT * from weapons where name = '$weapon_type'");
			$db->next_record();								

			$new_weapons = $cargo->Current_cargo[$weapon_type]['amount'] + $amount;
				
			$cargo->set_good($weapon_type, 3, $new_weapons);
			$cargo->save();						

			$planetary_weapons[$weapon_type] = $planetary_weapons[$weapon_type] - $amount;
			$weapons_temp = array();

			while (list($key, $val) = each($planetary_weapons)) {
				if ( $val > 0 ) {
					array_push($weapons_temp, $key);
					array_push($weapons_temp, $val);
				}
			}		
		
			$new_weapons = implode(",", $weapons_temp);

			if ( $source == 'shared' ) {
				$db_p_u = new ME_DB;
				$db_p_u->query("update planets set ship_weapons = '$new_weapons' where planet_id = '$planet_id'");	
			} else {
				$db_p_u = new ME_DB;
				$db_p_u->query("update planet_merchant_storage set ship_weapons = '$new_weapons' where planet_id = '$planet_id' and player_id = '$player_id'");			
			}
			
			break;		

		case "unload_installed_weapon":
			$id = (int) $id;

			$returnto = "hangar";					
			
			$weapons = new ME_Weapons;
			$weapons->get_weapons($ship->f("ship_id"));

			if ( $weapons->Current_weapons[$id] <> $weapon_id ) {
        $error = 3;
        break;
      }

			$db = new ME_DB;

			if ( isset($unload_installed_weapon_shared_x) ) {
				$planetary_weapons = get_planetary_weapons($db_p);
			} else {				
				$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				$db->next_record();
			
				$planetary_weapons = get_planetary_weapons($db);
			}													
						
			if ( $planetary_weapons[$weapon_type] + 1 > 10 ) {
 	 	  	$error = 19;
				break;
			}

			$planetary_weapons[$weapon_type] = $planetary_weapons[$weapon_type] + 1;
			$weapons_temp = array();

			while (list($key, $val) = each($planetary_weapons)) {
				if ( $val > 0 ) {
					array_push($weapons_temp, $key);
					array_push($weapons_temp, $val);
				}
			}		
		
			$new_weapons = implode(",", $weapons_temp);

			$db_p_u = new ME_DB;

			if ( isset($unload_installed_weapon_shared_x) ) {
				$db_p_u->query("update planets set ship_weapons = '$new_weapons' where planet_id = '$planet_id'");
			} else {				
				$db_p_u->query("update planet_merchant_storage set ship_weapons = '$new_weapons' where planet_id = '$planet_id' and player_id = '$player_id'");
			}					

			set_weapon_id_and_name($id, $weapons);

			break;

		case "unload_stored_weapon":
			$amount = (int) $amount;

			$returnto = "hangar";			

			if ( $amount <= 0 ) {
				$error = 9;
				break;
			}						

			$cargo = new ME_Cargo;
			$cargo->get_cargo($player_id);

			if ( $cargo->Current_cargo[$weapon_type]['amount'] < $amount ) {
				$error = 13;
				break;
			}			

			$db = new ME_DB;
			
			if ( isset($unload_stored_weapon_shared_x) ) {
				$planetary_weapons = get_planetary_weapons($db_p);
			} else {				
				$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
				$db->next_record();
			
				$planetary_weapons = get_planetary_weapons($db);
			}				
			
			if ( $planetary_weapons[$weapon_type] + $amount > 10 ) {
 	 	  	$error = 19;
				break;
			}

			$new_weapons = $cargo->Current_cargo[$weapon_type]['amount'] - $amount;
				
			$cargo->set_good($weapon_type, 3, $new_weapons);
			$cargo->save();
			
			$planetary_weapons[$weapon_type] = $planetary_weapons[$weapon_type] + $amount;
			$weapons_temp = array();

			while (list($key, $val) = each($planetary_weapons)) {
				if ( $val > 0 ) {
					array_push($weapons_temp, $key);
					array_push($weapons_temp, $val);
				}
			}		
		
			$new_weapons = implode(",", $weapons_temp);

			$db_p_u = new ME_DB;

			if ( isset($unload_stored_weapon_shared_x) ) {
				$db_p_u->query("update planets set ship_weapons = '$new_weapons' where planet_id = '$planet_id'");
			} else {				
				$db_p_u->query("update planet_merchant_storage set ship_weapons = '$new_weapons' where planet_id = '$planet_id' and player_id = '$player_id'");
			}
			
			break;

		case "fire_disruptor_missile":
			$returnto = "attack";

			if ( $db_p->f("owner_id") <> $player->f("player_id") and $db_p->f("alliance_access_military") == 'f' ) {
				$error = 25;
				break;
			}

			if ( $db_p->f("disruptor_missile_current") <= 0 ) {
				$error = 23;
				break;
			}

			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			$db = new ME_DB;
			$this_sector_id = $db_p->f("sector_id");
			$db->query("select * from sectors where sector_id = '$this_sector_id'");
			$db->next_record();
			$this_map_id = $db->f("map_id");
			$this_xpos = $db->f("xpos");
			$this_ypos = $db->f("ypos");
			$this_public_sector_id = $db->f("public_sector_id");

			$db->query("select * from sectors where public_sector_id = '$disruptor_missile_sector' and map_id = '$this_map_id'");
			$db->next_record();
			$target_sector_id = $db->f("sector_id");

			$db->query("select * from planets where sector_id = '$target_sector_id'");
			$db->next_record();

			$target_planet_id = $db->f("planet_id");
			$target_alliance_id = $db->f("alliance_id");
			$target_shields = $db->f("shieldcurrent");
			$owner_id = $db->f("owner_id");
		
			if ( $db->nf() == 0 ) {
				$error = 22;
				break;
			}			

			if ( $target_sector_id == $this_sector_id ) {
				$error = 13;
				break;
			}

			$map_sql = "select * from sectors where ";
		
			$merchants = array();
			$sectors = array();

			$counter = 1;
		
			$y_bound = 4;
			$x_bound = -4;
			$search_width = 9;
			$sector_limit = 82;		

			$y = $y_bound;
			for ($i = 1; $i <= $search_width; $i++) {
				$x = $x_bound;
				for ($j = 1; $j <= $search_width; $j++) {
					$map_sql = $map_sql . "( map_id = " . $this_map_id . " and xpos = " . ($this_xpos + $x) . " and ypos = " . ($this_ypos + $y) . " )";
					$counter++;

					if ( $counter <> $sector_limit ) {
						$map_sql = $map_sql . " or ";
					}

					$x = $x + 1;
				}
			
				$y = $y - 1;
			}				
																
			$query = $map_sql;
			$db->query($query);

			$surrounding_sectors = array();

			while ( $db->next_record() ) {
				array_push($surrounding_sectors, $db->f("public_sector_id"));
			}

			if ( !in_array($disruptor_missile_sector, $surrounding_sectors) ) {
				$error = 21;
				break;
			}								

			$missile_hit = 0;

			if ( $target_shields > 0 ) {
				$num = rand(1,100);	

				if ( $num <= 75 ) {
					if ( $target_shields < 250 ) {
						$db->query("update planets set shieldcurrent = 0 where sector_id = '$target_sector_id'");
					} else {
						$new_shields = $target_shields - 250;

						$db->query("update planets set shieldcurrent = '$new_shields' where sector_id = '$target_sector_id'");
					}
			
					$missile_hit = 1;
				}
			}

			$new_disruptor_missiles = $db_p->f("disruptor_missile_current") - 1;
			$db->query("update planets set disruptor_missile_current = '$new_disruptor_missiles' where planet_id = '$planet_id'");

			$date = time();
			
			if ( $owner_id ) {
				$message = "Your planet in sector " . $disruptor_missile_sector . " was hit by a Disruptor Missile that was fired from sector " . $this_public_sector_id . ".";

				$query = "select player_id, message_id from messages where player_id = '$owner_id' and planetary = 't' order by message_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 50 ) {
					$message_id = $db->f("message_id");

					$query = "delete from messages where message_id = '$message_id'";
					$db->query($query);
				}  					

				$query = "insert into messages (player_id, message, toplayer, planetary, date_integer)
					values ('$owner_id', '$message', 'Planet Defense', 't', '$date')";
				$db->query($query);
			}

			$query = sprintf("insert into attack_logs (attacker_types, attacker_ids, attacker_imperial_protections, attacker_newbie_protections, defender_types, defender_ids, defender_imperial_protections, defender_newbie_protections, date, defender_alliance_id, map_id, public_sector_id, attacker_name)
				values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
			'p',
			$db_p->f("planet_id"),
		  '',
		  '',
			'p',
			$target_planet_id,
		  '',
		  '',
			$date,
			$target_alliance_id,
			$this_map_id,
			$disruptor_missile_sector,
			addslashes($player->f("name")) . " launched a Disruptor Missile from sector " . $this_public_sector_id);
			$db->query($query);

			break;

		case "alliance_access_x":
			$returnto = "ownership";
			
			if ( $db_p->nf() == 0 ) {
				$error = 5;
				break;
			}

			if ( $db_p->f("owner_id") <> $player->f("player_id") ) {
				$error = 7;
				break;
			}

			if ( $stockpile == 1 ) {
				$alliance_access_stockpile = 't';
			} elseif ( $stockpile == 2 ) {
				$alliance_access_stockpile = 'f';
			}		

			if ( $construction == 1 ) {
				$alliance_access_construction = 't';
			} elseif ( $construction == 2 ) {
				$alliance_access_construction = 'f';
			}	

			if ( $military == 1 ) {
				$alliance_access_military = 't';
			} elseif ( $military == 2 ) {
				$alliance_access_military = 'f';
			}	
			
			$db_p_u = new ME_DB;
			$db_p_u->query("update planets set alliance_access_stockpile = '$alliance_access_stockpile', alliance_access_construction = '$alliance_access_construction', alliance_access_military = '$alliance_access_military' where planet_id = '$planet_id'");

			break;

		case "scuttle_x":
			$returnto = "hangar";

			$db = new ME_DB;		
			$id = (int) $id;
			$db->query("SELECT * from ships_storage where ship_storage_id = '$id' and player_id = '$player_id' and planet_id = '$planet_id'");
			$db->next_record();
		
			if ( $db->nf() == 0 ) {
				$returnto = "hangar";
				$error = 5;
				break;
			}		

			$db->query("delete from ships_storage where ship_storage_id = '$id' and player_id = '$player_id' and planet_id = '$planet_id'");
	}
}

if ( $error ) {
	if ($returnto == "defenses")  {
		$newurl = $sess->url(URL . "planet_defenses.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "construction")  {
		$newurl = $sess->url(URL . "planet_construction.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "ownership")  {
		$newurl = $sess->url(URL . "planet_ownership.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "stockpile")  {
		$newurl = $sess->url(URL . "planet_stockpile.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "hangar")  {
		$newurl = $sess->url(URL . "planet_hangar.php?error=$error");
		header("Location: $newurl");	
	} elseif ($returnto == "attack")  {
		$newurl = $sess->url(URL . "planet_attack.php?error=$error");
		header("Location: $newurl");	
	}
} else {
	if ($returnto == "construction")  {
		$newurl = $sess->url(URL . "planet_construction.php");
		header("Location: $newurl");	
	} elseif ($returnto == "defenses")  {
		$newurl = $sess->url(URL . "planet_defenses.php");
		header("Location: $newurl");	
	} elseif ($returnto == "ownership")  {
		$newurl = $sess->url(URL . "planet_ownership.php");
		header("Location: $newurl");	
	} elseif ($returnto == "stockpile")  {
		$newurl = $sess->url(URL . "planet_stockpile.php");
		header("Location: $newurl");	
	} elseif ($returnto == "hangar")  {
		$newurl = $sess->url(URL . "planet_hangar.php");
		header("Location: $newurl");	
	} elseif ($returnto == "attack")  {
		if ( $trifocus_attack_id > 0 ) {
			$newurl = $sess->url(URL . "planet_attack.php") . "?trifocus_id=" . $trifocus_attack_id;
			header("Location: $newurl");	
		} elseif ( isset($missile_hit) ) {
			$newurl = $sess->url(URL . "planet_attack.php?missile_hit=" . $missile_hit);
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "planet_attack.php");
			header("Location: $newurl");	
		}
	}
}

page_close();
?>
