<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./lib/technology.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

$db_t = new ME_DB;
$db_t->query("SELECT * from locations where sector_id = '$sector_id' and type='Technology'");
$db_t->next_record();

$options = $db_t->f("options");	
$dealer_tech = array();
$dealer_tech = explode(",", $options);

$tech_found = 0;

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "store_tech":
			$amount = (int) $amount;
			$tech_type = (int) $tech_type;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == $tech_type ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $tech_type == 1 or $tech_type == 2 or $tech_type == 3 or $tech_type == 8 or $tech_type == 9 or $tech_type == 10 or $tech_type == 17 ) {
				if ( $amount <= 0 ) {
					$error = 11;
					break;
				}			
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '$tech_type'");
			$db->next_record();
			$tech_name = $db->f("name");

			if ( $tech_type == 1 or $tech_type == 2 or $tech_type == 3 or $tech_type == 8 or $tech_type == 9 or $tech_type == 10 or $tech_type == 17 ) {
				if ( $amount * $db->f("cost") > $player->f("credits") ) {
					$error = 5;
					break;
				} else {
					if ( $cargo->Open_holds < $amount ) {
						$error = 3;
						break;    				
					} else {
						$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
						$new_tech = $cargo->Current_cargo[$tech_name]['amount'] + $amount;						
					}
				}
			} else {
				if ( $db->f("cost") > $player->f("credits") ) {
					$error = 5;
					break;
				} else {
					if ( $cargo->Open_holds < 1 ) {
						$error = 3;
						break;    				
					} else {
						$new_credits = $player->f("credits") - ($db->f("cost"));
						$new_tech = $cargo->Current_cargo[$tech_name]['amount'] + 1;
					}
				}
			}
				
			$cargo->set_good($tech_name, 2, $new_tech);
			$cargo->save();

			$player->set_credits($new_credits);
			$player->save();
			
			break;

		case "sell_stored_tech":
			$amount = (int) $amount;
			$tech_type = (int) $tech_type;
			$returnto = "tech_dealer";			
			
			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}			

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '$tech_type'");
			$db->next_record();
			$tech_name = $db->f("name");
						
			$new_credits = $player->f("credits") + (($db->f("cost") * $amount) / 2);

			if ( $cargo->Current_cargo[$tech_name]['amount'] < $amount ) {
				$error = 14;
				break;
			}

			$new_tech = $cargo->Current_cargo[$tech_name]['amount'] - $amount;
				
			$cargo->set_good($tech_name, 2, $new_tech);
			$cargo->save();

			$player->set_credits($new_credits);
			$player->save();
			
			break;

		case "purchase_tech_1":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 1 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_shields = $ship->f("shieldcurrent");
      $max_shields = $ship->f("shieldmax");

			if ( $current_shields + $amount > $max_shields ) {
      	$error = 1;
				break;	
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '1'");
			$db->next_record();
		
			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_shields = $ship->f("shieldcurrent") + $amount;
			$ship->set_shieldcurrent($new_shields);
			$ship->save();
			break;

		case "purchase_tech_2":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 2 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_armor = $ship->f("armorcurrent");
      $max_armor = $ship->f("armormax");

			if ( $current_armor + $amount > $max_armor ) {
      	$error = 2;
				break;	
			}
		
			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '2'");
			$db->next_record();

			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

      $new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_armor = $ship->f("armorcurrent") + $amount;
			$ship->set_armorcurrent($new_armor);
			$ship->save();
			break;

		case "purchase_tech_3":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 3 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_cargo = $ship->f("cargocurrent");
      $max_cargo = $ship->f("cargomax");

			if ( $current_cargo + $amount > $max_cargo ) {
      	$error = 3;
				break;	
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '3'");
			$db->next_record();
		
			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_cargo = $ship->f("cargocurrent") + $amount;
			$ship->set_cargocurrent($new_cargo);
			$ship->save();
			break;

		case "purchase_tech_4":			
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 4 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			$type_id = $ship->f("type_id");
			
			$db = new ME_DB;
			$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
			$db->next_record();

			if ( $db->f("illusion") == 'f' ) {
				$error = 4;
				break;		
			}
		
			if ( $ship->f("illusion") ) {
				$error = 12;
				break;		
			}
			
			$db->query("SELECT * from technology_types where technology_type_id = '4'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_illusion($technology->f("illusion") + 1);		
			$technology->save();

			break;

		case "purchase_tech_5":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 5 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			$type_id = $ship->f("type_id");
			
			$db = new ME_DB;
			$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
			$db->next_record();

			if ( $db->f("scanner") == 'f' ) {
				$error = 4;
				break;		
			}

			if ( $ship->f("scanner") ) {
				$error = 12;
				break;		
			}
			
			$db->query("SELECT * from technology_types where technology_type_id = '5'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_scanner($technology->f("scanner") + 1);		
			$technology->save();

			break;

		case "purchase_tech_6":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 6 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			$type_id = $ship->f("type_id");
			
			$db = new ME_DB;
			$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
			$db->next_record();

			if ( $db->f("jump") == 'f' ) {
				$error = 4;
				break;		
			}
			
			if ( $ship->f("jump") ) {
				$error = 12;
				break;		
			}
			
			$db->query("SELECT * from technology_types where technology_type_id = '6'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_jump($technology->f("jump") + 1);		
			$technology->save();

			break;

		case "purchase_tech_7":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 7 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			$type_id = $ship->f("type_id");
			
			$db = new ME_DB;
			$db->query("SELECT * from ship_types where ship_type_id = '$type_id'");
			$db->next_record();

			if ( $db->f("cloak") == 'f' ) {
				$error = 4;
				break;		
			}
			
			if ( $ship->f("cloak") ) {
				$error = 12;
				break;		
			}

			$db->query("SELECT * from technology_types where technology_type_id = '7'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_cloak($technology->f("cloak") + 1);
			$technology->save();

			break;

		case "purchase_tech_8":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 8 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_mines = $ship->f("minescurrent");
      $max_mines = $ship->f("minesmax");

			if ( $current_mines + $amount > $max_mines ) {
      	$error = 8;
				break;	
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '8'");
			$db->next_record();
		
			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_mines = $ship->f("minescurrent") + $amount;
			$ship->set_minescurrent($new_mines);
			$ship->save();
			break;

		case "purchase_tech_9":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 9 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_combat = $ship->f("combatcurrent");
      $max_combat = $ship->f("combatmax");

			if ( $current_combat + $amount > $max_combat ) {
      	$error = 9;
				break;	
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '9'");
			$db->next_record();
		
			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_combat = $ship->f("combatcurrent") + $amount;
			$ship->set_combatcurrent($new_combat);
			$ship->save();
			break;

		case "purchase_tech_10":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 10 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_scout = $ship->f("scoutcurrent");
      $max_scout = $ship->f("scoutmax");

			if ( $current_scout + $amount > $max_scout ) {
      	$error = 10;
				break;	
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '10'");
			$db->next_record();
		
			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_scout = $ship->f("scoutcurrent") + $amount;
			$ship->set_scoutcurrent($new_scout);
			$ship->save();
			break;

	case "purchase_tech_11":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 11 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("tracking") + 1 > 4 ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '11'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_tracking($technology->f("tracking") + 1);		
			$technology->save();

			break;

		case "purchase_tech_12":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 12 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("deep_scanner") + 1 > 4  ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '12'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_deep_scanner($technology->f("deep_scanner") + 1);		
			$technology->save();

			break;

		case "purchase_tech_17":
			$amount = (int) $amount;
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 17 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}

			if ( $amount <= 0 ) {
				$error = 11;
				break;
			}

			$current_power = $ship->f("powercurrent");
      $max_power = $ship->f("powermax");

			if ( $current_power + $amount > $max_power ) {
      	$error = 10;
				break;	
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '17'");
			$db->next_record();
		
			if ( $amount * $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}

			$new_credits = $player->f("credits") - ($db->f("cost") * $amount);
			$player->set_credits($new_credits);
			$player->save();

			$new_power = $ship->f("powercurrent") + $amount;
			$ship->set_powercurrent($new_power);
			$ship->save();
			break;

		case "purchase_tech_13":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 13 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("targeting_computer") + 1 > 4  ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '13'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_targeting_computer($technology->f("targeting_computer") + 1);		
			$technology->save();

			break;

		case "purchase_tech_14":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 14 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("plasma_booster") + 1 > 4  ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '14'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_plasma_booster($technology->f("plasma_booster") + 1);		
			$technology->save();

			break;

		case "purchase_tech_15":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 15 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("tractor_beam") + 1 > 4  ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '15'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_tractor_beam($technology->f("tractor_beam") + 1);
			$technology->save();

			break;

		case "purchase_tech_16":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 16 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("active_screens") + 1 > 4 ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '16'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_active_screens($technology->f("active_screens") + 1);		
			$technology->set_screensmax(50);	
			$technology->save();

			break;

		case "purchase_tech_18":
			$returnto = "tech_dealer";

			while (list($key, $val) = each($dealer_tech)) {
				if ( $val == 18 ) {
					$tech_found = 1;
				}
			}

			if ( !$tech_found ) {
				$error = 6;
				break;
			}			

			if ( $ship->f("trifocus_plasma") + 1 > 4 ) {
				$error = 12;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '18'");
			$db->next_record();
		
			if ( $db->f("cost") > $player->f("credits") ) {
				$error = 5;
				break;
			}
		
			$new_credits = $player->f("credits") - $db->f("cost");
			$player->set_credits($new_credits);
			$player->save();
			
			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_trifocus_plasma($technology->f("trifocus_plasma") + 1);		
			$technology->save();

			break;

		case "sell_tech_4":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("illusion") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '4'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_illusion($technology->f("illusion") - 1);
			$technology->save();

			break;

		case "sell_tech_5":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("scanner") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '5'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_scanner($technology->f("scanner") - 1);
			$technology->save();

			break;

		case "sell_tech_6":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("jump") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '6'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_jump($technology->f("jump") - 1);
			$technology->save();

			break;

		case "sell_tech_7":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("cloak") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '7'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_cloak($technology->f("cloak") - 1);
			$technology->save();

			break;

		case "sell_tech_11":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("tracking") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '11'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_tracking($technology->f("tracking") - 1);		
			$technology->save();

			break;

		case "sell_tech_12":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("deep_scanner") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '12'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_deep_scanner($technology->f("deep_scanner") - 1);		
			$technology->save();

			break;

		case "sell_tech_13":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("targeting_computer") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '13'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_targeting_computer($technology->f("targeting_computer") - 1);
			$technology->save();

			break;

		case "sell_tech_14":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("plasma_booster") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '14'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_plasma_booster($technology->f("plasma_booster") - 1);		
			$technology->save();

			break;

		case "sell_tech_15":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("tractor_beam") ) {
				$error = 13;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '15'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));
			$technology->set_tractor_beam($technology->f("tractor_beam") - 1);
			$technology->save();

			break;

		case "sell_tech_16":			
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("active_screens") ) {
				$error = 15;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '16'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_active_screens($technology->f("active_screens") - 1);		
			$technology->save();

			break;

		case "sell_tech_18":
			$returnto = "tech_dealer";					
		
			if ( !$ship->f("trifocus_plasma") ) {
				$error = 15;
				break;		
			}

			$db = new ME_DB;
			$db->query("SELECT * from technology_types where technology_type_id = '18'");
			$db->next_record();					

			$new_credits = $player->f("credits") + ($db->f("cost") / 2);
			$player->set_credits($new_credits);
			$player->save();

			$technology = new ME_Technology;
			$technology->get_technology($ship->f("ship_id"));	
			$technology->set_trifocus_plasma($technology->f("trifocus_plasma") - 1);		
			$technology->save();

			break;
	}
}

if ( $error ) {
	if ($returnto == "tech_dealer")  {
		$newurl = $sess->url(URL . "tech_dealer.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "tech_dealer")  {
		$newurl = $sess->url(URL . "tech_dealer.php");
		header("Location: $newurl");	
	}
}

page_close();
?>