<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Cargo extends ME_DB {	
	var $Ship_id = 0;
	var $Player_id = 0;
	var $Cargomax = 0;
	var $Cargocurrent = 0;	
	var $Cargo = "";		
  var $Open_holds = 0;
	var $Current_cargo = array();

  function get_cargo($id) {
		$this->connect();
		$query = sprintf("select player_id, ship_id, cargocurrent, cargomax, cargo from ships where player_id = '%s'", $id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
    }

    $this->next_record();
  	$this->Player_id = $id;
		$this->Ship_id = $this->f("ship_id");
		$this->Cargomax = $this->f("cargomax");
  	$this->Cargocurrent = $this->f("cargocurrent");

		$cargo_temp = explode(",", $this->f("cargo"));		
		$t_amt = 0;

		for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 3) {
			$this->Current_cargo[$cargo_temp[$i]]['type'] = $cargo_temp[$i + 1];
			$this->Current_cargo[$cargo_temp[$i]]['amount'] = $cargo_temp[$i + 2];			

			$t_amt = $t_amt + $cargo_temp[$i + 2];
		}		

		$this->Open_holds = $this->f("cargocurrent") - $t_amt;

  	return $this->Query_ID;
  }

  function save() {
		$cargo_temp = array();
		while (list($key, $val) = each($this->Current_cargo)) {								
			if ( $val['amount'] > 0 ) {
				array_push($cargo_temp, $key);
				array_push($cargo_temp, $val['type']);			
				array_push($cargo_temp, $val['amount']);
			}
		}		
		
		$this->Cargo = implode(",", $cargo_temp);
		$db = new ME_DB;
		
		$query = sprintf("update ships set cargocurrent = '%s', cargomax = '%s', cargo = '%s' where
			ship_id = '%s'", $this->Cargocurrent, $this->Cargomax, $this->Cargo, $this->Ship_id);
		
		$db->query($query);
	}

  function set_cargomax($n) {
		$this->Cargomax = $n;
  }

  function set_cargocurrent($n) {
		$this->Cargocurrent = $n;
  }

	function delete_cargo() {
		$this->Current_cargo = array();		
	}

	function set_good($m, $n, $o) {
		$this->Current_cargo[$m]['type'] = $n;
		$this->Current_cargo[$m]['amount'] = $o;		
  }		
}
?>
