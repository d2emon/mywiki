
def add_player_turns():
	import math
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT game_id, player_id, turns from players where turns < 850"
	q = pgcnx.query(qrystr)
	res = q.getresult()

	qrystr = "begin transaction"
	pgcnx.query(qrystr)

	# loop through all the players
	for value in range(len(res)):
		q_2 = pgcnx.get('games', res[value][q.fieldnum('game_id')], 'game_id')
		rate = q_2['turnrate']

	 	currentturns = res[value][q.fieldnum('turns')]

	 	if (currentturns + 18) >= 850:
 			playerturns = 850
 		else:
			playerturns = currentturns + 18
	 	
		try:
	  		#update the player record
			qrystr = "update players set turns = '%d' where player_id = '%d'" % (playerturns, res[value][q.fieldnum('player_id')])
			pgcnx.query(qrystr)
		except:
                       	pass

  	qrystr = "commit transaction"
	pgcnx.query(qrystr) 

