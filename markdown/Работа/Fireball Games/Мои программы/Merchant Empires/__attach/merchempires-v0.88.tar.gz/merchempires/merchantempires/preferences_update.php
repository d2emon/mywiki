<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
include("./merchantempiresdefines.php");
$sess->register("user_ignore_newbie");

include("./lib/player_config.php");

$error = 0;

$db = new ME_DB;
$returnto = "preferences";

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "update_password":
			if (empty($password) || empty($verify)) {
				$error = 1;
				break;
			}
      			
			if (!strcmp($password,$verify) == 0) {
				$error = 2;
				break;
			}
			
			if ( strlen($password) > 10 ) {
				$error = 3;
				break;
			}

			$db = new ME_DB;
			$query = sprintf("update auth_user set password = '%s' where user_id = '%s'", $password, $user->id);
			$db->query($query);
			break;

		case "update_email":
			if (empty($email)) {
				$error = 1;
				break;
			}
			
			if ( stristr($email, ';') ) {
				$error = 4;
				break;			
			}

			$db = new ME_DB;
			$query = sprintf("update auth_user set email = '%s' where user_id = '%s'", $email, $user->id);
			$db->query($query);
			break;

		case "update_player_config":
			$player_config = new ME_Player_config;
			$player_config->get_player_config($player_id);			

			if ( $screen == 1 ) {
				$player_config->set_post_trade_screen('local_map');
			} elseif ( $screen == 2 ) {
				$player_config->set_post_trade_screen('current_sector');
			}	

			if ( $ignore_newbie == 1 ) {
				$player_config->set_ignore_newbie('t');
			} elseif ( $ignore_newbie == 2 ) {
				$player_config->set_ignore_newbie('f');
			}	

			if ( $group_combat_forces == 1 ) {
				$player_config->set_group_combat_forces('t');
			} elseif ( $group_combat_forces == 2 ) {
				$player_config->set_group_combat_forces('f');
			}

			if ( $group_combat_planets == 1 ) {
				$player_config->set_group_combat_planets('t');
			} elseif ( $group_combat_planets == 2 ) {
				$player_config->set_group_combat_planets('f');
			}

			if ( $group_combat_ships == 1 ) {
				$player_config->set_group_combat_ships('t');
			} elseif ( $group_combat_ships == 2 ) {
				$player_config->set_group_combat_ships('f');
			}	

			if ( $group_map_size == 1 ) {
				$player_config->set_map_size(1);
			} elseif ( $group_map_size == 2 ) {
				$player_config->set_map_size(2);
			}	

			$player_config->save();						
			break;

		case "update_post_trade":
			$player_config = new ME_Player_config;
			$player_config->get_player_config($player_id);			

			if ( $screen == 1 ) {
				$player_config->set_post_trade_screen('local_map');
			} elseif ( $screen == 2 ) {
				$player_config->set_post_trade_screen('current_sector');
			}	

			$player_config->save();						
			break;
	}
}

if ( $error ) {
	if ($returnto == "preferences")  {
		$newurl = $sess->url(URL . "preferences.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "preferences")  {
		$newurl = $sess->url(URL . "preferences.php");
		header("Location: $newurl");	
	}
}

page_close();
?>