
def delete_attack_logs():
	import time
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb, postmerchhost, user=postmerchuser, passwd=postmerchpass)
	qrystr = "delete from attack_logs where date < '%d'" % (time.time() - 1000000)
	q = pgcnx.query(qrystr) 
