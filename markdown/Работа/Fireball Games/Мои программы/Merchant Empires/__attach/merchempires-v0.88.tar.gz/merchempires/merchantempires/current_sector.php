<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function has_bottom_exit($exits, $xpos, $ypos)  {
	$qypos = $ypos - 1;
	$str = $xpos . ":" . $qypos;

	if (strpos ("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_top_exit($exits, $xpos, $ypos)  {
	$qypos = $ypos + 1;
	$str = $xpos . ":" . $qypos;
		
	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_right_exit($exits, $xpos, $ypos)  {
	$qxpos = $xpos + 1;
	$str = $qxpos . ":" . $ypos;

	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_left_exit($exits, $xpos, $ypos)  {
	$qxpos = $xpos - 1;
	$str = $qxpos . ":" . $ypos;

	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector = new ME_Sector;
$sector->get_sector($player_id);

?>

<html><head><title>Merchant Empires: Current Sector</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>

<script>
<!--
     NS4 = (document.layers);
     IE4 = (document.all);
    ver4 = (NS4 || IE4);
	 IE5 = (IE4 && navigator.appVersion.indexOf("5.")!=-1);
   isMac = (navigator.appVersion.indexOf("Mac") != -1);
  isMenu = (NS4 || (IE4 && !isMac) || (IE5 && isMac));

//-->
</script>
<script>
<!--
if (isMenu) {
menuVersion = 3;
menuWidth = 120;
childOverlap = 20;
childOffset = 5;
perCentOver = null;
secondsVisible = .5;
fntCol = "#cccccc";
fntSiz = "10";
fntBold = false;
fntItal = false;
fntFam = "Arial,sans-serif";
backCol = "black";
overCol = "#000033";
overFnt = "#cccccc";
borWid = 1;
borCol = "#003399";
borSty = "solid";
itemPad = 3;
imgSrc = "./images/tri.gif";
imgSiz = 10;
separator = 1;
separatorCol = "black";
isFrames = false;
keepHilite = true;
clickStart = false;
clickKill = true;
}
//-->
</script>

<script>

HM_Array1 = [
[120,200,135,"black","white","#3399FF","#55BBFF","#0000FF","#000088",,,,,,,,],
["Experts","http://www.webreference.com/experts/",1,0,1],
["Contents","http://www.webreference.com/index2.html",1,0,0],
["Services","http://www.webreference.com/index2.html",1,0,0],
["About","http://www.webreference.com/about.html",1,0,0]
]

HM_Array1_1 = [
[],
["3-D Animation","http://www.webreference.com/3d/",1,0,0],
["Design","http://www.webreference.com/dlab/",1,0,0],
["DHTML","http://www.webreference.com/dhtml/",1,0,1],
["Internet","http://www.webreference.com/outlook/",1,0,0],
["JavaScript","http://www.webreference.com/js/",1,0,0]
]

HM_Array1_1_3 = [
[],
["Columns","http://www.webreference.com/dhtml/",1,0,0],
["Diner","http://www.webreference.com/dhtml/diner/",1,0,0],
["Dynomat","http://www.webreference.com/dhtml/dynomat/",1,0,0]
]

HM_Array2 = [
[150,,,"black","green","#2D9B83","#4BB9A1","black","black",,,,,,,,],
["Experts","http://www.webreference.com/experts/",1,0,1],
["Contents","http://www.webreference.com/index2.html",1,0,0]
]

HM_Array2_1 = [
[],
["3-D Animation","http://www.webreference.com/3d/",1,0,0],
["Design","http://www.webreference.com/dlab/",1,0,0],
["DHTML","http://www.webreference.com/dhtml/",1,0,0],
["Internet","http://www.webreference.com/outlook/",1,0,0],
["JavaScript","http://www.webreference.com/js/",1,0,0]
]

HM_Array3 = [
[180,,,,,,,,,,,,,,,,],
["Experts","http://www.we\'breference.com/experts/",1,0,0],
["Contents","http://www.webreference.com/index2.html",1,0,1]
]

HM_Array3_2 = [
[],
["Features","http://www.webreference.com/articles.html",1,0,0],
["Forum","http://www.webreference.com/cgi-bin/Ultimate.cgi?action=intro",1,0,0],
["How-to","http://www.webreference.com/dev/",1,0,0],
["New","http://www.webreference.com/headlines/",1,0,0],
["Hot Sites","http://www.webreference.com/hot/",1,0,0]
]

HM_Array4 = [
[200,,,"black","white","#F84130","#FF5F4E","#9A0E20","white",,,,,,,,],
["Experts","http://www.webreference.com/experts/",1,0,0],
["Services","http://www.webreference.com/index2.html",1,0,1]
]

HM_Array4_2 = [
[],
["Domains","http://www.webreference.com/services/dns/",1,0,0],
["Graphics","http://www.webreference.com/services/gw/",1,0,0],
["Jobs","http://www.webreference.com/jobs/",1,0,0],
["Reference","http://www.webreference.com/services/reference/",1,0,0],
["ROADMAP","http://www.webreference.com/roadmap/",1,0,0],
["Search","http://www.webreference.com/cgi-bin/search.cgi",1,0,0],
["Validation","http://www.webreference.com/services/validation/",1,0,0],
["Cool Sites","http://www.coolcentral.com",1,0,0]
]

arMenu1 = new Array(
"",
"","",
"","",
"","",
"","",
"Scout Drones","/",1,
"Mines","/",1,
"Combat Drones","/",1

<?php
if ( $ship->f("cloak") ) {
	if ( $ship->f("cloak_active") == 't' ) {
		echo ',"Cloak Deactivate","' . $sess->url(URL . "current_sector_action_update.php") . "?action=cloak_de-activate" . '",0';
	} else {
		echo ',"Cloak Activate","' . $sess->url(URL . "current_sector_action_update.php") . "?action=cloak_activate" . '",0';
	}	
}

if ( $ship->f("deep_scanner") ) {	
	echo ',"Deep Scan","' . $sess->url(URL . "current_sector_action_update.php") . "?action=deep_scan" . '",0';
}
?>
)

arMenu1_1 = new Array(
"Drop All","<?php echo $sess->url(URL . "current_sector_action_update.php") . "?action=s_d_a"; ?>",0,
"Take All","<?php echo $sess->url(URL . "current_sector_action_update.php") . "?action=s_t_a"; ?>",0
)

arMenu1_2 = new Array(
"Drop All","<?php echo $sess->url(URL . "current_sector_action_update.php") . "?action=m_d_a"; ?>",0,
"Take All","<?php echo $sess->url(URL . "current_sector_action_update.php") . "?action=m_t_a"; ?>",0
)

arMenu1_3 = new Array(
"Drop All","<?php echo $sess->url(URL . "current_sector_action_update.php") . "?action=c_d_a"; ?>",0,
"Take All","<?php echo $sess->url(URL . "current_sector_action_update.php") . "?action=c_t_a"; ?>",0
)

//-->
</script>

<script>
<!--
if (isMenu) {
document.write("<script language='JavaScript1.2' SRC='./scripts/hierMenus.js' TYPE='text/javascript'><\/script>");
}
//-->
</script>

</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "currentsector");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$db = new ME_DB;
$db_2 = new ME_DB;

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $ship->f("sector_id") <> 0 ) {
?>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr><?php
			
	echo "<td width=90 valign=top align=right class=clsNrmTxt><img border=0 src='./images/map";
	echo $sector->f("map_id") . "/navmenu" . $ship->f("sector_id")	. ".png' usemap='#navmenu'>";
	echo "<map name='navmenu'>";

	#bottom
	$s2 = new ME_Sector;
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") - 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=40,58,68,85 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	#top
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") + 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=40,2,68,29 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	#right
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") + 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=69,30,97,57 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	#left
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") - 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=11,30,39,57 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	echo "</map></td>";
	
	echo "<td width=270 class=clsNrmTxt valign=top>";
	
	echo "<table width=260><tr><td align=center>";	
	echo "<br><font color=#3333FF face=helvetica size=5>SECTOR " . $sector->f("public_sector_id");	
	echo "</td></tr><tr><td align=right>";
		
	echo "<table cellPadding=0 cellSpacing=0><tr><td align=center>";
	if ( $follow_course == 1 ) {
		$map_id = $sector->f("map_id");
		$xpos = $sector->f("xpos");
		$ypos = $sector->f("ypos");
		$query = "select player_id, course from ships where player_id = '$player_id'";
		$db->query($query);
		$db->next_record();

		$course = array();
		$course = explode(",", $db->f("course"));		
		$count = 0;

		while (list($key, $val) = each($course)) {
			$xpos = substr( $val, 0, strpos($val, ":") );		
			$ypos =  substr( $val, strpos($val, ":") + 1 );

			$query = "select * from sectors where xpos = '$xpos' and ypos = '$ypos' and map_id = '$map_id'";
			$db->query($query);
			$db->next_record();								

			$count = $count + 1;

			if ( $count == 2 ) {
				$move = $db->f("sector_id");
			}		
		}

		echo "<a href=" . URL . "move_to_sector.php?move=" . $move . "&returnto=currentsector&follow_course=1>";

		echo "<img alt='Follow Course' border=0 src='./images/submenu/currentsectorfollow-off.png'></a>";		
	} else {
  	echo "<br>";
	}

	echo "</td></tr><tr><td align=center>";
	echo "<a href='javascript:void(0)' onMouseOver=popUp('elMenu1',event) onMouseOut=popDown('elMenu1') onClick='return false'><img border=0 src='./images/submenu/currentsectoractions-off.png'></a>";
	echo "<a href=";
	echo $sess->url(URL . "current_sector_plot.php");
	echo "><img alt='Plot a Course' border=0 src='./images/submenu/currentsectorplot-off.png'>";
	echo "</td></tr></table></td></tr></table>";
	
	echo "</td><td width=90 valign=top align=right class=clsNrmTxt><img border=0 src='./images/map";
	echo $sector->f("map_id") . "/scanmenu" . $ship->f("sector_id")	. ".png' usemap='#scanmenu'>";
	echo "<map name='scanmenu'>";

	#bottom
	$s2 = new ME_Sector;
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") - 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=40,58,68,85 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	#top
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") + 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=40,2,68,29 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	#right
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") + 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=69,30,97,57 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	#left
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") - 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=11,30,39,57 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	echo "</map>";
	echo "</td></tr></table></td></tr></table><br>";
	
	if ( $player->f("success_offer") <> 0 ) {
?>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 class=clsNrmTxt align=left valign=middle>
						<table border=0>
            	<tr>
								<td class=clsNrmTxt align=left colspan=6><?php

		echo "Your offer of " . $player->f("success_offer") . " credits for " . $player->f("success_amount") . " unit(s)";
		echo " of " . $player->f("success_type") . " was accepted.";

		if ( $player->f("success_experience") > 0 ) {
			echo "<br>Your trading skills have earned you " . $player->f("success_experience") . " experience points.";
		}

?>													
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

		$db->query("update players set success_offer = '0',	success_amount = '0',
			success_type = '' where player_id = '$player_id'");
	}


# display port

	$color_1 = "003399";
	$color_2 = "000033";

	$query = sprintf("SELECT * from ports where sector_id = '%s'", $sector->f("sector_id"));
	$db->query($query);
	$db->next_record();
	if ( $db->nf() > 0 ) {
?>
	<table border=0 cellPadding=0 cellSpacing=0 width=450>
		<tr>
			<td bgColor=#<?php echo $color_1?>>
				<table border=0 cellpadding=5 cellspacing=1 cols=2 width=100%>
					<tr>
						<td bgColor=#<?php echo $color_2?>>Port</td>
						<td bgColor=#<?php echo $color_2?>>Actions</td>
					</tr><?php
	
		echo "<tr>";		
		echo "<td class=clsNrmTxt> ";
	
		echo "<a href=";
		echo $sess->url(URL . "send_messages_council.php");
		echo "?id=" . $db->f("government") . ">";

		switch ($db->f("government")) {
			case "1":
				$race = 'Human';
				break;
			case "2":
				$race = 'Kushun';
				break;
			case "3":
				$race = 'Psilon';
				break;
			case "4":
				$race = 'Taiidan';
				break;
			case "5":
				$race = 'Bulrathi';
				break;
			case "6":
				$race = 'Thevien';
				break;
			case "7":
				$race = 'Ferenge';
				break;
		}

		echo $race . "</a> Port " . $sector->f("public_sector_id") . " (Level " . $db->f("level") . ")<br>";
	
		$query = sprintf("SELECT * from goods where port_id = '%s' and buyorsell = 'buy' order by marketvalue", $db->f("port_id"));
		$db_2->query($query);

		echo "Buy: ";

		while ( $db_2->next_record() ) {
			if ( $db_2->f("type") == "Biochemicals" ) {
				echo "<img alt='Biochemicals' src='./images/goods/biochemicals.png'>";
			}
		
			if ( $db_2->f("type") == "Food" ) {
				echo "<img alt='Food' src='./images/goods/food.png'>";
			}

			if ( $db_2->f("type") == "Ore" ) {
				echo "<img alt='Ore' src='./images/goods/ore.png'>";
			}

			if ( $db_2->f("type") == "Precious Metals" ) {
				echo "<img alt='Precious Metals' src='./images/goods/precious_metals.png'>";
			}

			if ( $db_2->f("type") == "Slaves" ) {
				if ( $player->f("alignment") < -100 ) {
					echo "<img alt='Slaves' src='./images/goods/slaves.png'>";
				}
			}

			if ( $db_2->f("type") == "Textiles" ) {
				echo "<img alt='Textiles' src='./images/goods/textiles.png'>";
			}

			if ( $db_2->f("type") == "Machinery" ) {
				echo "<img alt='Machinery' src='./images/goods/machinery.png'>";
			}

			if ( $db_2->f("type") == "Circuitry" ) {
				echo "<img alt='Circuitry' src='./images/goods/circuitry.png'>";
			}

			if ( $db_2->f("type") == "Weapons" ) {
				if ( $player->f("alignment") < -100 ) {
					echo "<img alt='Weapons' src='./images/goods/weapons.png'>";
				}
			}

			if ( $db_2->f("type") == "Computers" ) {
				echo "<img alt='Computers' src='./images/goods/computers.png'>";
			}

			if ( $db_2->f("type") == "Luxury Items" ) {
				echo "<img alt='Luxury Items' src='./images/goods/luxury_items.png'>";
			}

			if ( $db_2->f("type") == "Narcotics" ) {
				if ( $player->f("alignment") < -100 ) {
					echo "<img alt='Narcotics' src='./images/goods/narcotics.png'>";
				}
			}
		}
	
		$query = sprintf("SELECT * from goods where port_id = '%s' and buyorsell = 'sell' order by marketvalue", $db->f("port_id"));
		$db_2->query($query);

		echo "<br>Sell: ";

		while ( $db_2->next_record() ) {
			if ( $db_2->f("type") == "Biochemicals" ) {
				echo "<img alt='Biochemicals' src='./images/goods/biochemicals.png'>";
			}
		
			if ( $db_2->f("type") == "Food" ) {
				echo "<img alt='Food' src='./images/goods/food.png'>";
			}

			if ( $db_2->f("type") == "Ore" ) {
				echo "<img alt='Ore' src='./images/goods/ore.png'>";
			}

			if ( $db_2->f("type") == "Precious Metals" ) {
				echo "<img alt='Precious Metals' src='./images/goods/precious_metals.png'>";
			}

			if ( $db_2->f("type") == "Slaves" ) {
				if ( $player->f("alignment") < -100 ) {
					echo "<img alt='Slaves' src='./images/goods/slaves.png'>";
				}
			}

			if ( $db_2->f("type") == "Textiles" ) {
				echo "<img alt='Textiles' src='./images/goods/textiles.png'>";
			}

			if ( $db_2->f("type") == "Machinery" ) {
				echo "<img alt='Machinery' src='./images/goods/machinery.png'>";
			}

			if ( $db_2->f("type") == "Circuitry" ) {
				echo "<img alt='Circuitry' src='./images/goods/circuitry.png'>";
			}

			if ( $db_2->f("type") == "Weapons" ) {
				if ( $player->f("alignment") < -100 ) {
					echo "<img alt='Weapons' src='./images/goods/weapons.png'>";
				}
			}

			if ( $db_2->f("type") == "Computers" ) {
				echo "<img alt='Computers' src='./images/goods/computers.png'>";
			}

			if ( $db_2->f("type") == "Luxury Items" ) {
				echo "<img alt='Luxury Items' src='./images/goods/luxury_items.png'>";
			}

			if ( $db_2->f("type") == "Narcotics" ) {
				if ( $player->f("alignment") < -100 ) {
					echo "<img alt='Narcotics' src='./images/goods/narcotics.png'>";
				}
			}
		}

		echo "</td><td valign=top class=clsNrmTxt><a href=";
		$sess->purl(URL . "port.php");
		echo ">Trade</a></td>";

		echo "</tr></table><td></tr></table><br>";
	
		if ( $color_1 == "003399" ) {
			$color_1 = "993300";
	 		$color_2 = "330000";
		} else {
			$color_1 = "003399";
	 		$color_2 = "000033";
		}
	}

# display locations

	$query = sprintf("SELECT location_id, type, name, options from locations where sector_id = '%s'", $sector->f("sector_id"));
	$db->query($query);
	if ( $db->nf() > 0 ) {
?>
	<table border=0 cellPadding=0 cellSpacing=0 width=450>
		<tr>
			<td bgColor=#<?php echo $color_1?>>
				<table border=0 cellpadding=5 cellspacing=1 cols=2 width=100%>
					<tr>
						<td bgColor=#<?php echo $color_2?>>Locations</td>
						<td bgColor=#<?php echo $color_2?>>Actions</td>
					</tr><?php

		while( $db->next_record() ) {
			printf("<tr>");
			
			if ( $db->f("type") == "Shipdealer" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/shipdealer.png'>&nbsp;%s</td>", $db->f("name"));				
			} elseif ( $db->f("type") == "Technology" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/hardware.png'>&nbsp;%s</td>", $db->f("name"));			
			} elseif ( $db->f("type") == "Weapons") {
				printf("<td class=clsNrmTxt><img src='./images/locations/weapons.png'>&nbsp;%s</td>", $db->f("name"));						
			} elseif ( $db->f("type") == "Bar" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/bar.png'>&nbsp;%s</td>", $db->f("name"));						
			} elseif ( $db->f("type") == "Bank" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/bank.png'>&nbsp;%s</td>", $db->f("name"));						
			} elseif ( $db->f("type") == "Government" ) {
				switch ($db->f("options")) {
					case "1":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_1.png'>&nbsp;%s</td>", $db->f("name"));				
						break;
					case "2":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_2.png'>&nbsp;%s</td>", $db->f("name"));								
						break;
					case "3":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_3.png'>&nbsp;%s</td>", $db->f("name"));				
						break;
					case "4":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_4.png'>&nbsp;%s</td>", $db->f("name"));					
						break;
					case "5":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_5.png'>&nbsp;%s</td>", $db->f("name"));				
						break;
					case "6":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_6.png'>&nbsp;%s</td>", $db->f("name"));					
						break;
					case "7":
						printf("<td class=clsNrmTxt><img src='./images/locations/government_7.png'>&nbsp;%s</td>", $db->f("name"));				
						break;
					default:
						printf("<td class=clsNrmTxt><img src='./images/locations/government_1.png'>&nbsp;%s</td>", $db->f("name"));						
						break;
				}				
			} elseif ( $db->f("type") == "Underground" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/underground.png'>&nbsp;%s</td>", $db->f("name"));						
			} elseif ( $db->f("type") == "Authority" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/beacon.png'>&nbsp;%s</td>", $db->f("name"));			
			}	elseif ( $db->f("type") == "Starbase" ) {
				printf("<td class=clsNrmTxt><img src='./images/locations/starbase.png'>&nbsp;%s</td>", $db->f("name"));			
			}		

			if ( $db->f("type") == "Shipdealer" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "ship_dealer.php");
				printf("'>Enter</a>");
			
			} elseif ( $db->f("type") == "Technology" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "tech_dealer.php");
				printf("'>Enter</a></td>");
			
			} elseif ( $db->f("type") == "Weapons") {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "weapons_dealer.php");
				printf("'>Enter</a></td>");
			
			} elseif ( $db->f("type") == "Bar" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "bar.php");
				printf("'>Enter</a></td>");
			
			} elseif ( $db->f("type") == "Bank" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "bank_enter.php");
				printf("'>Enter</a></td>");
			
			} elseif ( $db->f("type") == "Government" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "government.php");
				printf("'>Enter</a></td>");
			
			} elseif ( $db->f("type") == "Underground" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "underground.php");
				printf("'>Enter</a></td>");
			
			} elseif ( $db->f("type") == "Authority" ) {
				printf("<td class=clsNrmTxt>&nbsp;</td>");
			
			} elseif ( $db->f("type") == "Starbase" ) {
				printf("<td class=clsNrmTxt><a href='");
				$sess->purl(URL . "starbase_dock.php");
				printf("'>Dock</a></td>");			
			}

		}

		echo "</tr></table><td></tr></table><br>";
	
		if ( $color_1 == "003399" ) {
			$color_1 = "993300";
 			$color_2 = "330000";
		} else {
			$color_1 = "003399";
 			$color_2 = "000033";
		}
	}

#display planets

	$query = sprintf("SELECT planet_id, sector_id, name from planets where sector_id = '%s'", $sector->f("sector_id"));
	$db->query($query);
	if ( $db->nf() > 0 ) {
?>
	<table border=0 cellPadding=0 cellSpacing=0 width=450>
		<tr>
			<td bgColor=#<?php echo $color_1?>>
				<table border=0 cellpadding=5 cellspacing=1 cols=2 width=100%>
					<tr>
						<td bgColor=#<?php echo $color_2?>>Planet</td>
						<td bgColor=#<?php echo $color_2?>>Actions</td>
					</tr><?php

		while($db->next_record()) {
			echo "<tr><td class=clsNrmTxt>" . htmlentities($db->f("name")) . "</td><td class=clsNrmTxt><a href=planet_orbit.php>Orbit</a></td>";
	}

	echo "</tr></table><td></tr></table><br>";
	
		if ( $color_1 == "003399" ) {
			$color_1 = "993300";
 			$color_2 = "330000";
		} else {
			$color_1 = "003399";
 			$color_2 = "000033";
		}
	}

#display warps

	$query = sprintf("SELECT warp_id, sector_id from warps where sector_id = '%s'", $sector->f("sector_id"));
	$db->query($query);
	if ( $db->nf() > 0 ) {
?>
	<table border=0 cellPadding=0 cellSpacing=0 width=450>
		<tr>
			<td bgColor=#<?php echo $color_1?>>
				<table border=0 cellpadding=5 cellspacing=1 cols=2 width=100%>
					<tr>
						<td bgColor=#<?php echo $color_2?>>Warp</td>
						<td bgColor=#<?php echo $color_2?>>Actions</td>
					</tr><?php

		while($db->next_record()) {
			echo "<tr><td class=clsNrmTxt><img src='./images/misc/warp.png'>&nbsp;Inter-Galaxy Warp</td>";
			echo "<td class=clsNrmTxt><a href=warp.php>Enter</a></td>";			
		}

		echo "</tr></table><td></tr></table><br>";
	
		if ( $color_1 == "003399" ) {
			$color_1 = "993300";
	 		$color_2 = "330000";
		} else {
			$color_1 = "003399";
	 		$color_2 = "000033";
		}
	}

	#display merchants

	$query = sprintf("SELECT ships.sector_id, ships.player_id, ship_technology.player_id, ship_technology.cloak, ship_technology.cloak_active from ships, ship_technology where ships.sector_id = '%s' and ships.player_id <> '%s' and ships.player_id = ship_technology.player_id", $sector->f("sector_id"), $player->f("player_id"));
	$db->query($query);
	$found_visible_merchant = 0;

	while( $db->next_record() and !$found_visible_merchant ) {
		if ( $db->f("player_id") <> $player_id ) {			
			$query = sprintf("SELECT player_id, name, public_player_id, experience, level from players where player_id = '%s'", $db->f("player_id"));
			$db_2->query($query);
	   	$db_2->next_record();

			if ( ($db->f("cloak") and $db->f("cloak_active") == 't' and $db_2->f("level") < $player->f("level")) or ( $db->f("cloak_active") == 'f' ) ) {
				$found_visible_merchant = 1;
			}
		}
	}

	if ( $found_visible_merchant ) {
		$query = sprintf("SELECT ships.*, ship_weapons.*, ship_technology.* from ships, ship_weapons, ship_technology where ships.sector_id = '%s' and ships.player_id <> '%s' and ship_weapons.player_id = ships.player_id and ship_technology.player_id = ships.player_id", $sector->f("sector_id"), $player->f("player_id"));
		$db->query($query);

		echo "<table border=0 cellPadding=0 cellSpacing=0 width=450><tr>";
		echo "<td bgColor=#" . $color_1 . "><table border=0 cellpadding=5 cellspacing=1 cols=2 width=100%>";
		echo "<tr><td bgColor=#" . $color_2 . ">Merchants</td><td bgColor=#" . $color_2 . ">Actions</td></tr>";

		while( $db->next_record() ) {	
			$query = sprintf("SELECT player_id, name, public_player_id, experience, level, alliance_id, newturnsleft from players where player_id = '%s'", $db->f("player_id"));
			$db_2->query($query);
	   	$db_2->next_record();

			if ( ($db->f("cloak") and $db->f("cloak_active") == 't' and $db_2->f("level") < $player->f("level")) or ( $db->f("cloak_active") == 'f' ) ) {
				echo "<tr><td class=clsNrmTxt><a href=merchant_search_results.php?action=merchant_id&criteria=" . $db_2->f("public_player_id") . ">";

				if ( $db_2->f("newturnsleft") > 0 ) {
					echo "<font color=#3333FF>";
				}

				echo $db_2->f("name") . "</font></a><br>";

				if ( $db->f("illusion") and $db->f("illusion_active") == 't' ) {
					echo $db->f("illusion_type");
					$offense = $db->f("illusion_attack");				
					$defense = $db->f("illusion_defense");
					echo  "&nbsp;(" . $offense . "/" . $defense . ")<br>";
				} else {
					echo $db->f("type");

					$combined_damage = get_combined_damage($db);

					if ( (int) (($combined_damage / 40) + ($db->f("combatcurrent") / 50)) < 1 ) {
						$offense = 1;
					} else {
						$offense = (int) (($combined_damage / 40) + ($db->f("combatcurrent") / 50));
					}

					if ( (int) (($db->f("shieldcurrent") + $db->f("armorcurrent") + ($db->f("combatcurrent") * 3)) / 100)  < 1 ) {
						$defense = 1;
					} else {
						$defense = (int) (($db->f("shieldcurrent") + $db->f("armorcurrent") + ($db->f("combatcurrent") * 3)) / 100);
					}
	
					echo  "&nbsp;(" . $offense . "/" . $defense . ")<br>";
				}

				if ( $db->f("cloak") and $db->f("cloak_active") == 't' ) {
					echo "Cloaked";
				}

				echo "</td><td class=clsNrmTxt><a href=current_sector_examine_merchant.php?id=" . $db_2->f("player_id") . ">Examine</a>";

				if ( $db_2->f("alliance_id") <> $player->f("alliance_id") or $db_2->f("alliance_id") == 0 ) {
					echo " / <a href=attack.php?id=" . $db_2->f("player_id") . "&type=s&refer=current>Attack</a>";
				}

				if ( $ship->f("tracking") ) {
					echo " / <a href=ship_technology_update.php?track_target=" . $db_2->f("public_player_id") . "&action=merchantid&merchant_action=track_merchant&track=Lock>Track</a>";
				}

				if ( $ship->f("tractor_beam") ) {
					if ( $db->f("cargomax") <= 250 and $db->f("shieldmax") + $db->f("armormax") < 500 ) {
						echo " / <a href=ship_technology_update.php?tow_target=" . $db_2->f("public_player_id") . "&action=merchantid&merchant_action=tow_merchant>Tow</a>";

						if ( $ship->f("tractor_beam_player_id") == $db->f("player_id") and $ship->f("tractor_beam_time") > time() ) {								
							echo "Tractor Beam locked in " . $ship->f("tractor_beam_time") - time() . " seconds.";
						}
					} else {
						if ( $ship->f("cargomax") <= 250 and $ship->f("shieldmax") + $ship->f("armormax") < 750 ) {
							// nothing
						} else {
							echo " / <a href=ship_technology_update.php?tow_target=" . $db_2->f("public_player_id") . "&action=merchantid&merchant_action=tow_merchant>Tow</a>";

							if ( $ship->f("tractor_beam_player_id") == $db->f("player_id") and $ship->f("tractor_beam_time") > time() ) {		
								echo "<br>Tractor Beam locked in " . (string) ($ship->f("tractor_beam_time") - time()) . " seconds.";
							}
						}
					}					
				}

				echo "</td></tr>";
			}
		}

		echo "</tr></table><td></tr></table><br>";

		if ( $color_1 == "003399" ) {
			$color_1 = "993300";
	 		$color_2 = "330000";
		} else {
			$color_1 = "003399";
	 		$color_2 = "000033";
		}
	}

#display forces

	$query = sprintf("SELECT * from forces where sector_id = '%s'", $sector->f("sector_id"));
	$db->query($query);

	if ( $db->nf() > 0 ) {

?>
	<table border=0 cellPadding=0 cellSpacing=0 width=450>
		<tr>
			<td bgColor=#<?php echo $color_1?>>
				<table border=0 cellpadding=5 cellspacing=1 cols=2 width=100%>
					<tr>
						<td bgColor=#<?php echo $color_2?>>Forces</td>
						<td bgColor=#<?php echo $color_2?>>Details</td>
					</tr><?php

	while ( $db->next_record() ) {	
		echo "<tr><td valign=top class=clsNrmTxt>";
		echo "Owner: <a href=merchant_search_results.php?action=merchant_id&criteria=" . $db->f("public_player_id") . ">" . $db->f("player_name") . "</a><br>";

		if ( $db->f("alliance_id") <> 0 ) {
			echo "Alliance: <a href=alliance.php?alliance_id=" . $db->f("alliance_id") . ">" . $db->f("alliance_name") . "</a>";
		}

		if ( $db->f("player_id") == $player_id ) {
			echo "<br>Expiration: <span class=clsNrmTxtWht>" . date ("m/d/y H:i:s", $db->f("expiration")) . "</span>";
			echo "<br><br><center><a href=ship_forces.php>Examine</a>";
		
			if ( $db->f("alliance_id") == $player->f("alliance_id") or $db->f("player_id") == $player->f("player_id") ) {
				echo "&nbsp;<a href=current_sector_action_update.php?action=refresh_forces&id=" . $db->f("forces_id") . ">Refresh</a>";
			}
		} elseif ( $db->f("alliance_id") <> $player->f("alliance_id") or $db->f("alliance_id") == 0 ) {
			echo "<br><br><center><a href=attack.php?id=" . $db->f("forces_id") . "&type=f&refer=current>Attack</a>";
		}

		echo "</td><td class=clsNrmTxt><table><tr>";
		echo "<td class=clsNrmTxt>Mines:&nbsp;&nbsp;</td><td class=clsNrmTxtWht>" . $db->f("mine");

		if ( ( $db->f("alliance_id") == $player->f("alliance_id") and $db->f("alliance_id") <> 0 ) or (  $db->f("player_id") == $player_id ) ) {
			echo "&nbsp;&nbsp;<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=add&amount=1&type=1>[+]</a>";			
			echo "&nbsp<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=sub&amount=1&type=1>[-]</a>";		
			
			echo "&nbsp;&nbsp;&nbsp;<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=add&amount=5&type=1>[+5]</a>";
			echo "&nbsp<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=sub&amount=5&type=1>[-5]</a>";
		}

		echo "</td></tr><tr>";
		echo "<td class=clsNrmTxt>Combat Drones:&nbsp;&nbsp;</td><td class=clsNrmTxtWht>" . $db->f("combat");

		if ( ( $db->f("alliance_id") == $player->f("alliance_id") and $db->f("alliance_id") <> 0 ) or ( $db->f("player_id") == $player_id ) ) {
			echo "&nbsp;&nbsp;<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=add&amount=1&type=2>[+]</a>";
			echo "&nbsp<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=sub&amount=1&type=2>[-]</a>";			
			
			echo "&nbsp;&nbsp;&nbsp;<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=add&amount=5&type=2>[+5]</a>";
			echo "&nbsp<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=sub&amount=5&type=2>[-5]</a>";
		}

		echo "</td></tr><tr>";
		echo "<td class=clsNrmTxt>Scout Drones:&nbsp;&nbsp;</td><td class=clsNrmTxtWht>" . $db->f("scout");
	
		if ( ( $db->f("alliance_id") == $player->f("alliance_id") and $db->f("alliance_id") <> 0 ) or ( $db->f("player_id") == $player_id ) ) {
			echo "&nbsp;&nbsp;<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=add&amount=1&type=3>[+]</a>";
			echo "&nbsp<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=sub&amount=1&type=3>[-]</a>";	
			
			echo "&nbsp;&nbsp;&nbsp;<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=add&amount=5&type=3>[+5]</a>";
			echo "&nbsp<a href=current_sector_forces_update.php?id=" . $db->f("forces_id") ."&action=sub&amount=5&type=3>[-5]</a>";
		}

		echo "</td></tr></table></td>";
	}	

	echo "</tr></table><td></tr></table><br>";

		if ( $color_1 == "003399" ) {
			$color_1 = "993300";
	 		$color_2 = "330000";
		} else {
			$color_1 = "003399";
	 		$color_2 = "000033";
		}
	}
} else {
	#landed on planet, don't allow viewing of sector 0
	$error = 5;
}
	
if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");	

	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to no open capacity.");	
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to no forces present.");	
	} elseif ($error == 3) {
		$db->add_parameter("message", "Forces not owned by current player.");	
	} elseif ($error == 4) {
		$db->add_parameter("message", "Movement is not possible. Your merchant has no turns.");	
	} elseif ($error == 5) {
		$db->add_parameter("message", "The current sector cannot be viewed when your merchant has landed on a planet.");	
	} elseif ($error == 6) {
		$db->add_parameter("message", "Your merchant has insufficient credits to pay the docking fee.");	
	} elseif ($error == 7) {
		$db->add_parameter("message", "Your alignment prevents you from entering an Imperial Starbase.");	
	} elseif ($error == 8) {
		$db->add_parameter("message", "You do not qualify for Imperial Protection.");	
	} elseif ($error == 9) {
		$db->add_parameter("message", "Sector force capacity has been reached.");	
	} elseif ($error == 10) {
		$db->add_parameter("message", "Command not processed due to insufficient forces in sector.");	
	} elseif ($error == 11) {
		$db->add_parameter("message", "Invalid value entered.");	
	} elseif ($error == 16) {
		$db->add_parameter("message", "Ship powerplant overloaded.");	
	} elseif ($error == 17) {
		$db->add_parameter("message", "Forces cannot be placed in a sector that contains a location.");	
	} elseif ($error == 18) {
		$db->add_parameter("message", "Command not processed due to no forces available for deployment.");	
	} elseif ($error == 19) {
		$db->add_parameter("message", "You can only refresh forces that belong to you or your alliance.");	
	} elseif ($error == 20) {
		$db->add_parameter("message", "You can only refresh forces that are in the current sector.");	
	} elseif ($error == 21) {
		$db->add_parameter("message", "Command not processed due to insufficient forces available.");	
	}

	echo $db->get_transform("./xslt/message_box.xslt", "");			

}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

unset($db);
unset($db_2);

page_close();
?>