<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Current Sector</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector = new ME_Sector;
$sector->get_sector($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=170 align=middle valign=center bgColor=#000000>
						<font color=#3333FF face=arial,helvetica,swiss size=5>SECTOR SCAN <?php

$id = (int) $id;

$db = new ME_DB;
$query = sprintf("SELECT * from sectors where sector_id = '%s'", $id);
$db->query($query);
$db->next_record();

echo $db->f("public_sector_id");
?>
						</font>
						<br>
					</td>					
				</tr>
			</table>
		</td>
	</tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=170 bgColor=#000000>
						<font color=#3333FF face=arial,helvetica,swiss size=3>
							Scanners detect:</font><br><?php

if ( $ship->f("scanner") ) {
	$db = new ME_DB;
	$query = sprintf("SELECT ships.player_id, ships.sector_id, ship_technology.player_id, ship_technology.cloak, ship_technology.cloak_active from ships, ship_technology where ships.sector_id = '%s' and ship_technology.player_id = ships.player_id", $id);
	$db->query($query);

	$nonallied = 0;
	$allied = 0;
	$db_2 = new ME_DB;

	while ( $db->next_record() ) {
		$query = sprintf("SELECT player_id, name, public_player_id, experience, level, alliance_id from players where player_id = '%s'", $db->f("player_id"));
		$db_2->query($query);
		$db_2->next_record();

		if ( ($db->f("cloak") and $db->f("cloak_active") == 't' and $db_2->f("level") < $player->f("level")) or ( $db->f("cloak_active") == 'f' ) ) {	
			
			srand((double)microtime()*1000000);
	
			if ( $db_2->f("alliance_id") <> $player->f("alliance_id") or $player->f("alliance_id") == 0 ) {
				$nonallied = $nonallied + 1;

				if ( rand(1,11) <= 3 ) {
	 	   		$nonallied = $nonallied + 1;
				}
			} else {
				$allied = $allied + 1;

				if ( rand(1,11) <= 2 ) {
					$allied = $allied + 1;
				}
			}
		}
	}

	echo "<table><tr>";
	echo "<td><font color=#cccccc  face=arial,helvetica,swiss size=2>Estimated non-allied ships: </font></td><td><font color=#cccccc  face=arial,helvetica,swiss size=2>" . $nonallied . "</font></td>";
	echo "<tr></tr>";
	echo "<td><font color=#cccccc  face=arial,helvetica,swiss size=2>Estimated allied ships: </font></td><td><font color=#cccccc  face=arial,helvetica,swiss size=2>" . $allied . "</font></td>";
	echo "</tr></table>";

	$query = sprintf("SELECT * from forces where sector_id = '%s'", $id);
	$db->query($query);

	$nonallied_drones = 0;
	$allied_drones = 0;
	$nonallied_mines = 0;
	$allied_mines = 0;

	while ( $db->next_record() ) {
		$query = sprintf("SELECT player_id, alliance_id from players where player_id = '%s'", $db->f("player_id"));
		$db_2->query($query);
	  $db_2->next_record();
	  srand((double)microtime()*1000000);

		if ( $db_2->f("alliance_id") <> $player->f("alliance_id") or ($player->f("alliance_id") == 0 and $db->f("player_id") == $player->f("player_id")) ) {
			$nonallied_drones = $nonallied_drones + $db->f("combat") + $db->f("scout");
			$nonallied_mines = $nonallied_mines + $db->f("mine");

			if ( rand(1,11) <= 3 ) {
				$nonallied_drones = $nonallied_drones + 1;
				$nonallied_mines = $nonallied_mines + 1;
			}
		} elseif ( $db_2->f("alliance_id") == $player->f("alliance_id") or $db->f("player_id") == $player->f("player_id") ) {
			$allied_drones = $allied_drones + $db->f("combat") + $db->f("scout");
			$allied_mines = $allied_mines + $db->f("mine");

			if ( rand(1,11) <= 2 ) {
				$allied_drones = $allied_drones + 1;
				$allied_mines = $allied_mines + 1;
			}
		}
	}

	echo "<table><tr>";
	echo "<td><font color=#cccccc  face=arial,helvetica,swiss size=2>Estimated non-allied drones: </font></td><td><font color=#cccccc  face=arial,helvetica,swiss size=2>" . $nonallied_drones . "</font></td>";
	echo "<tr></tr>";
	echo "<td><font color=#cccccc  face=arial,helvetica,swiss size=2>Estimated allied drones: </font></td><td><font color=#cccccc  face=arial,helvetica,swiss size=2>" . $allied_drones . "</font></td>";
	echo "</tr></table>";
	echo "<table><tr>";
	echo "<td><font color=#cccccc  face=arial,helvetica,swiss size=2>Estimated non-allied mines: </font></td><td><font color=#cccccc  face=arial,helvetica,swiss size=2>" . $nonallied_mines . "</font></td>";
	echo "<tr></tr>";
	echo "<td><font color=#cccccc  face=arial,helvetica,swiss size=2>Estimated allied mines: </font></td><td><font color=#cccccc  face=arial,helvetica,swiss size=2>" . $allied_mines . "</font></td>";
	echo "</tr></table>";
} else {
	echo "<br><font color=#cccccc  face=arial,helvetica,swiss size=2>&nbsp;Your ship's scanner cannot scan beyond the current sector.</font>";
}
?>
						<br>
					</td>					
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to no open capacity.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to no forces present.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "Forces not owned by current player.");
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");	
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>