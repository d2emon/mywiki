<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/relations.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Underground</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$sector_id = $ship->f("sector_id");
$db = new ME_DB_Xml;
$db->query("select * from locations where sector_id = '$sector_id' and type='Underground'");
$db->next_record();

?>
</td>
<td valign=top align=left width=0>&nbsp;</td>
<td valign=top width=500><?php

if ( $player->f("alignment") < 100 ) {	
	$db->add_parameter("current_screen", "underground");
	echo $db->get_transform("./xslt/menu_top_underground.xslt", $db->get_xml());
?>

<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top>
									<font color=#3333FF face=arial,helvetica,swiss size=3><b>Top Bounties</font></b>
									<font  color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;<?php

	$db = new ME_DB;
	$db->query("select * from underground_bounties where game_id = '$game_id' order by amount desc");

	echo "<table cellspacing=5>";
	while ( $db->next_record() ) {
		echo "<tr>";
		echo "<td><font color=#cccccc face=arial,helvetica,swiss size=3>" . htmlentities($db->f("player_target_name")) . "</td><td>" . $db->f("amount") . "&nbsp;&nbsp;&nbsp;<font  color=#cccccc face=arial,helvetica,swiss size=3>(placed by " . htmlentities($db->f("player_place_name")) . ")<br></td>";	
		echo "</tr>";
	}

	echo "</table>";
?>
									</font>
								</td>
							</tr>
							<tr>
								<td valign=top><?php

	if ( $player->f("deputy_or_underground") == 'f' and $player->f("alignment") > -100 ) {
		echo "<font color=#3333FF face=arial,helvetica,swiss size=3><br><b>Join the Underground</font></b><br>";
		echo "<font  color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;";
		echo "&nbsp;<br><font  color=#cccccc face=arial,helvetica,swiss size=2>Becoming a member of the Underground means that you are
		declaring yourself as an evil player.  Your alignment will change to -150.  You may join the ranks of the Underground
		only once per game.<br></font>";
		echo "<form action=";
		echo $sess->url(URL . "underground_update.php");
		echo " method=post>";
		echo "<input type=submit name=criminalize value='Join'>";
		echo "</form>";
	}
?>
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $error ) {
		$db = new ME_DB_Xml;
		$db->add_parameter("title", "Error");			
		
		if ($error == 1) {
			$db->add_parameter("message", "Command not processed due to insufficient alignment.");
		} elseif ($error == 2) {
			$db->add_parameter("message", "Command not processed due to insufficient credits.");
		} elseif ($error == 3) {
			$db->add_parameter("message", "Command not processed due to no bounties on record.");
		} elseif ($error == 6) {
			$db->add_parameter("message", "Current sector does not contain an underground.");
		}
			
		echo $db->get_transform("./xslt/message_box.xslt", "");						
	}
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Warning");
	$db->add_parameter("message", "Your alignment prevents you from accessing this location.");
	echo $db->get_transform("./xslt/message_box.xslt", "");		
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>