<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Ship Dealer Examine</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

if ( !isset($id) ) { $id = $ship->f("type_id"); }

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<center><font color=#3333FF face=arial,helvetica,swiss size=5>SHIP DETAILS</font></center>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$current_id = $ship->f("type_id");
$db = new ME_DB;
$db->query("select * from ship_types where ship_type_id = '$current_id'");
$db->next_record();

$id = (int) $id;
$db_2 = new ME_DB;
$db_2->query("select * from ship_types where ship_type_id = '$id'");
$db_2->next_record();

?>

<table border=0 cellPadding=0 cellSpacing=0 width=400>
	<tr>
		<td bgColor=#003399>
			<table BORDER=0 cellpadding=5 cellspacing=1 COLS=2 WIDTH=100%>
				<tr>
					<td bgColor=#000033>
						&nbsp;
					</td>
					<td bgColor=#000033>
						<FONT color=#ffffff  face=arial,helvetica,swiss size=3>
						<?php echo $db->f("name"); ?></font>
					</td>
					<td bgColor=#000033>
						<FONT color=#ffffff  face=arial,helvetica,swiss size=3>
						<?php echo $db_2->f("name"); ?></font>
					</td>
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Turns Per Sector
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("turns_per_sector"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("turns_per_sector"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Shields
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("shieldmax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("shieldmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Armor
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("armormax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("armormax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Cargo Holds
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("cargomax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("cargomax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Power Plant
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("powermax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("powermax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Combat Drones
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("combatmax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("combatmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Scout Drones
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("scoutmax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("scoutmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Max Mines
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("minesmax"); ?>
 					</td>	
					<td class=clsNrmTxt>
						<?php echo $db_2->f("minesmax"); ?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Hardpoints
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("hardpoints"); ?>
 					</td>
					<td class=clsNrmTxt>
						<?php echo $db_2->f("hardpoints"); ?>
 					</td>	
				</tr>		
				<tr>
					<td class=clsNrmTxt>
						Level
		      </td>
					<td class=clsNrmTxt>
						<?php echo $db->f("experience_level"); ?>
 					</td>
					<td class=clsNrmTxt>
						<?php echo $db_2->f("experience_level"); ?>
 					</td>	
				</tr>				
				<tr>
					<td class=clsNrmTxt>
						Scanner Capable?
		      </td>
					<td class=clsNrmTxt><?php

if ( $db->f("scanner") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
					<td class=clsNrmTxt><?php

if ( $db_2->f("scanner") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Illusion Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("illusion") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
					<td class=clsNrmTxt><?php
if ( $db_2->f("illusion") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Jump Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("jump") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
					<td class=clsNrmTxt><?php
if ( $db_2->f("jump") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Galaxy Jump Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("galaxy_jump") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
					<td class=clsNrmTxt><?php
if ( $db_2->f("galaxy_jump") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td class=clsNrmTxt>
						Cloak Capable?
		      </td>
					<td class=clsNrmTxt><?php
if ( $db->f("cloak") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
					<td class=clsNrmTxt><?php
if ( $db_2->f("cloak") == 't' ) {
	echo "Yes";
} else {
  echo "No";
};
?>
 					</td>	
				</tr>
				<tr>
					<td colspan=3 class=clsNrmTxt><?php

if ( $player->f("race_number") <> $db_2->f("race") and $db_2->f("race") <> 0 ) {
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3>You may not purchase this ship type due to your race.<br></font><br>";	
}

?>
						<font color=#3333FF face=arial,helvetica,swiss size=3>Items that will transfer</font><br><?php

if ( $ship->f("shieldcurrent") > 0 and $db_2->f("shieldmax") > 0 ) {
	if ( $db_2->f("shieldmax") < $ship->f("shieldcurrent") ) {
		echo $db_2->f("shieldmax") . " shields<br>";	
	} else {
		echo $ship->f("shieldcurrent") . " shields<br>";	
	}
}

if ( $ship->f("armorcurrent") > 0 and $db_2->f("armormax") > 0 ) {
	if ( $db_2->f("armormax") < $ship->f("armorcurrent") ) {
		echo $db_2->f("armormax") . " armor<br>";		
	} else {
		echo $ship->f("armorcurrent") . " armor<br>";		
	}
}

if ( $ship->f("powercurrent") > 0 and $db_2->f("powermax") > 0 ) {
	if ( $db_2->f("powermax") < $ship->f("powercurrent") ) {
		echo $db_2->f("powermax") . " power plant<br>";		
	} else {
		echo $ship->f("powercurrent") . " power plant<br>";		
	}
}

if ( $ship->f("minescurrent") > 0 and $db_2->f("minesmax") > 0 ) {
	if ( $db_2->f("minesmax") < $ship->f("minescurrent") ) {
		echo $db_2->f("minesmax") . " mines<br>";		
	} else {
		echo $ship->f("minescurrent") . " mines<br>";		
	}	
}

if ( $ship->f("combatcurrent") > 0 and $db_2->f("combatmax") > 0 ) {
	if ( $db_2->f("combatmax") < $ship->f("combatcurrent") ) {
		echo $db_2->f("combatmax") . " combat drones<br>";		
	} else {
		echo $ship->f("combatcurrent") . " combat drones<br>";		
	}	
}

if ( $ship->f("scoutcurrent") > 0 and $db_2->f("scoutmax") > 0 ) {
	if ( $db_2->f("scoutmax") < $ship->f("scoutcurrent") ) {
		echo $db_2->f("scoutmax") . " scout drones<br>";		
	} else {
		echo $ship->f("scoutcurrent") . " scout drones<br>";		
	}	
}

if ( $ship->f("cargocurrent") > 0 and $db_2->f("cargomax") > 0 ) {
	if ( $db_2->f("cargomax") < $ship->f("cargocurrent") ) {
		echo $db_2->f("cargomax") . " cargo holds<br>";		
	} else {
		echo $ship->f("cargocurrent") . " cargo holds<br>";		
	}	
}

if ( $db_2->f("scanner") == 'true' and $ship->f("scanner") ) {
	echo "Scanners<br>";		
}

if ( $db_2->f("illusion") == 'true' and $ship->f("illusion") ) {
	echo "Illusion Generator<br>";		
}

if ( $db_2->f("jump") == 'true' and $ship->f("jump") ) {
	echo "Jump Drive<br>";		
}

if ( $db_2->f("cloak") == 'true' and $ship->f("cloak") ) {
	echo "Cloaking Device<br>";	
}

if ( $db->f("hardpoints") < $ship->f("hardpoints") ) {

}

?>
					  <font color=#3333FF face=arial,helvetica,swiss size=3><br>Items that will not transfer</font><br><?php

if ( $ship->f("shieldcurrent") > 0 ) {
	if ( $db_2->f("shieldmax") < $ship->f("shieldcurrent") ) {
		echo $ship->f("shieldcurrent") - $db_2->f("shieldmax") . " shields<br>";		
	}
}

if ( $ship->f("armorcurrent") > 0 ) {
	if ( $db_2->f("armormax") < $ship->f("armorcurrent") ) {
		echo $ship->f("armorcurrent") - $db_2->f("armormax") . " armor<br>";			
	}
}

if ( $ship->f("powercurrent") > 0 ) {
	if ( $db_2->f("powermax") < $ship->f("powercurrent") ) {
		echo $ship->f("powercurrent") - $db_2->f("powermax") . " power plant<br>";			
	}
}

if ( $ship->f("minescurrent") > 0 ) {
	if ( $db_2->f("minesmax") < $ship->f("minescurrent") ) {
		echo $ship->f("minescurrent") - $db_2->f("minesmax") . " mines<br>";		
	}	
}

if ( $ship->f("combatcurrent") > 0 ) {
	if ( $db_2->f("combatmax") < $ship->f("combatcurrent") ) {
		echo $ship->f("combatcurrent") - $db_2->f("combatmax") . " combat drones<br>";		
	}	
}

if ( $ship->f("scoutcurrent") > 0 ) {
	if ( $db_2->f("scoutmax") < $ship->f("scoutcurrent") ) {
		echo $ship->f("scoutcurrent") - $db_2->f("scoutmax") . " scout drones<br>";	
	}	
}

if ( $ship->f("cargocurrent") > 0 ) {
	if ( $db_2->f("cargomax") < $ship->f("cargocurrent") ) {
		echo $ship->f("cargocurrent") - $db_2->f("cargomax") . " cargo holds<br>";		
	}
}

if ( $db_2->f("scanner") == 'false' and $ship->f("scanner") ) {
	echo "Scanners<br>";		
}

if ( $db_2->f("illusion") == 'false' and $ship->f("illusion") ) {
	echo "Illusion Generator<br>";		
}

if ( $db_2->f("jump") == 'false' and $ship->f("jump") ) {
	echo "Jump Drive<br>";		
}

if ( $db_2->f("cloak") == 'false' and $ship->f("cloak") ) {
	echo "Cloaking Device<br>";	
}

?>
						<br><table cellspacing=3>
							<tr>
								<td class=clsNrmTxt>
									New Ship Cost
								</td>
								<td><?php

echo $db_2->f("cost");
?>
								</td>
							</tr>
							<tr>
								<td class=clsNrmTxt>
									Current Ship Resale Value
								</td>
								<td><?php

$resale = (int) ($db->f("cost") / 2);
echo $resale;
?>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<hr>
								</td>
							</tr>
							<tr>
								<td class=clsNrmTxt>
									Final Cost
								</td>
								<td><?php

if ( $db_2->f("cost") - $resale < 0 ) {
	echo "0";
} else {
	echo $db_2->f("cost") - $resale;
}
?>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<br><center><form action=<?php

echo $sess->url(URL . "ship_dealer_update.php");
echo " method=post>";
echo "<input type=hidden name=id value=" . $db_2->f("ship_type_id") . ">";
echo "<input type=submit name=trade_ship value=Trade>";
?>
									</form></center>
								</td>
							</tr>
							<tr>
								<td class=clsNrmTxt><br><br>
									New Ship Cost
								</td>
								<td><br><br><?php

echo $db_2->f("cost");
?>
								</td>
							</tr>
							<tr>
								<td class=clsNrmTxt>
									Delivery Cost
								</td>
								<td><?php

$delivery = 250000;
echo $delivery;
?>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<hr>
								</td>
							</tr>
							<tr>
								<td class=clsNrmTxt>
									Final Cost
								</td>
								<td><?php

echo $db_2->f("cost") + $delivery;
?>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<br><center>
                  <form action=<?php

echo $sess->url(URL . "ship_dealer_update.php");
echo " method=post>";
echo "<input type=hidden name=id value=" . $db_2->f("ship_type_id") . ">";
echo "<input type=submit name=deliver_ship value=Deliver>";
echo "&nbsp;Sector: <input type=textbox size=10 name=delivery_sector_id>";
?>
									</form>
									</center>
								</td>
							</tr>
						</table>
		      </td>
				</tr>
				<tr>
					<td colspan=3 bgColor=#000000>
						<center><a href=<?php

echo $sess->url(URL . "ship_dealer.php");
echo ">Return to Ship Dealer</a>";
?>

						&nbsp;
						<a href=<?php

echo $sess->url(URL . "local_map.php");
echo ">Leave Ship Dealer</a>";

?>
					</a></center>
		      </td>
				</tr>
			</table>
		<td>
  </tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");		
		
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to insufficient credits.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to cheat attempt.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "You may not purchase this ship type due to your race.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "There is no planet in that sector.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "Requested ship type not found.");
	} elseif ($error == 6) {
		$db->add_parameter("message", "Planet in requested delivery sector is not owned or allied to you.");
	} elseif ($error == 7) {
		$db->add_parameter("message", "The hangar in the requested delivery sector cannot hold more ships.");
	} elseif ($error == 8) {
		$db->add_parameter("message", "Command not processed due to insufficient merchant experience.");
	} elseif ($error == 9) {
		$db->add_parameter("message", "Your alignment prevents purchase of that ship type.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
