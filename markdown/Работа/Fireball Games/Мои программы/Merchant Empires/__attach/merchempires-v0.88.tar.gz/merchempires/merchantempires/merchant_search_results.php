<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Merchant Search Results</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "merchant");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "merchant_search");	
echo $db->get_transform("./xslt/menu_top_merchant.xslt", "");

$game_id = $player->f("game_id");
$results_found = 0;

$db = new ME_DB;

if ( $action == "merchantname" )  {

	if ( stristr($criteria, ';') ) {
		$error = "Illegal character.";
		break;			
	} else {
		$db->query("select player_id, public_player_id, experience, name, game_id, race, alliance_name from players where name like '%$criteria%' and game_id = '$game_id'");
	}
				
	if ( $db->nf() > 0 ) {
		$results_found = 1;
?>				
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td width=200 class=clsHedTxt id=blu1><center>Name</center></td>
					<td class=clsHedTxt id=blu1><center>Race</center></td>
					<td class=clsHedTxt id=blu1><center>Alliance</center></td>
					<td class=clsHedTxt id=blu1><center>Experience</center></td>
					<td class=clsHedTxt id=blu1><center>Online</center></td>
					<td class=clsHedTxt id=blu1><center>Options</center></td>
				</tr><?php
				
		while ( $db->next_record() )  {
			echo "<tr>";
    	echo "<td class=clsNrmTxt>";
			echo $db->f("name") . " (" . $db->f("public_player_id") . ")";
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo $db->f("race");
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo $db->f("alliance_name");
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo $db->f("experience");
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			
			$db_a = new ME_DB;
			$query = sprintf("SELECT * from active_sessions where player_id = '%s'", $db->f("player_id"));
			$db_a->query($query);

			if ( $db_a->nf() > 0 ) {
				echo "Yes";
			} else {
				echo "No";
			}

			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo "<a href=" . $sess->url(URL . "send_messages_merchant.php") . "?merchant=" . $db->f("public_player_id");
			echo ">Send Message</a>";
			echo "</td>";
			echo "</tr>";
		}
?>
			</table>
		<td>
  </tr>
</table><?php

	}
} else {
	$criteria = (int) $criteria;

 	$db->query("select player_id, public_player_id, experience, name, game_id, race, alliance_name from players where public_player_id = '$criteria' and game_id = '$game_id'");
	if ( $db->nf() > 0 ) {
		$results_found = 1;
?>				
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td width=200 class=clsHedTxt id=blu1><center>Name</center></td>
					<td class=clsHedTxt id=blu1><center>Race</center></td>
					<td class=clsHedTxt id=blu1><center>Alliance</center></td>
					<td class=clsHedTxt id=blu1><center>Experience</center></td>
					<td class=clsHedTxt id=blu1><center>Online</center></td>
					<td class=clsHedTxt id=blu1><center>Options</center></td>
				</tr><?php
		while ( $db->next_record() )  {
	 		echo "<tr>";
   		echo "<td class=clsNrmTxt>";
			echo $db->f("name") . " (" . $db->f("public_player_id") . ")";
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo $db->f("race");
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo $db->f("alliance_name");
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo $db->f("experience");
			echo "</td>";
			echo "<td class=clsNrmTxt>";
			
			$db_a = new ME_DB;
			$query = sprintf("SELECT * from active_sessions where player_id = '%s'", $db->f("player_id"));
			$db_a->query($query);

			if ( $db_a->nf() > 0 ) {
				echo "Yes";
			} else {
				echo "No";
			}

			echo "</td>";
			echo "<td class=clsNrmTxt>";
			echo "<a href=" . $sess->url(URL . "send_messages_merchant.php") . "?merchant=" . $db->f("public_player_id");
			echo ">Send Message</a>";
			echo "</td>";
			echo "</tr>";
		}
?>
			</table>
		<td>
  </tr>
</table><?php
	}
}

if ( $results_found == 0 )  {
?>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=7 cellSpacing=1 width=500>
				<tr>
					<td width=500 class=clsNrmTxt align=left valign=middle>
						No merchants were found matching your search criteria.
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}

?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
