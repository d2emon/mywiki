<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/
	
page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/sector.php");
include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function get_player_map($map_id, $player)  {
	$player_id = $player->f("player_id");

	$db = new ME_DB;

	if ( $player->f("alliance_id") <> 0 ) {	
		$query = sprintf("SELECT * from alliance_maps where alliance_id = '%s'", $player->f("alliance_id"));
	} else {
		$query = sprintf("SELECT * from player_maps where player_id = '%s'", $player_id);
	}	

	$db->query($query);
	$db->next_record();

	if ( $db->f("map_1_id") == $map_id ) {
		return $db->f("map_1");			
	} elseif ( $db->f("map_2_id") == $map_id ) {
		return $db->f("map_2");				
	} elseif ( $db->f("map_3_id") == $map_id ) {
		return $db->f("map_3");				
	} elseif ( $db->f("map_4_id") == $map_id ) {
		return $db->f("map_4");				
	} elseif ( $db->f("map_5_id") == $map_id ) {
		return $db->f("map_5");				
	} elseif ( $db->f("map_6_id") == $map_id ) {
		return $db->f("map_6");	
	} elseif ( $db->f("map_7_id") == $map_id ) {
		return $db->f("map_7");	
	} elseif ( $db->f("map_8_id") == $map_id ) {
		return $db->f("map_8");	
	} elseif ( $db->f("map_9_id") == $map_id ) {
		return $db->f("map_9");	
	} elseif ( $db->f("map_10_id") == $map_id ) {
		return $db->f("map_10");	
	}			
}

function has_bottom_exit($exits, $xpos, $ypos)  {
	$qypos = $ypos - 1;
	$str = $xpos . ":" . $qypos;

	if (strpos ("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_top_exit($exits, $xpos, $ypos)  {
	$qypos = $ypos + 1;
	$str = $xpos . ":" . $qypos;
		
	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_right_exit($exits, $xpos, $ypos)  {
	$qxpos = $xpos + 1;
	$str = $qxpos . ":" . $ypos;

	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_left_exit($exits, $xpos, $ypos)  {
	$qxpos = $xpos - 1;
	$str = $qxpos . ":" . $ypos;

	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function computebuygoods($sector_id)  {
	$db = new ME_DB;
	$query = sprintf("SELECT sector_id, type, buyorsell from goods where sector_id = '%s' and buyorsell = 'buy'", $sector_id);
	$db->query($query);
	
	$buygoods = array("circuitry" => "false", "computers" => "false", "food" => "false", "luxuryitems" => "false",
		"machinery" => "false", "narcotics" => "false", "ore" => "false",	"preciousmetals" => "false", "slaves" => "false",
		"textiles" => "false", "weapons" => "false", "biochemicals" => "false");
	
	while ($db->next_record())  {
		if ($db->f("type") == "Circuitry")  {
			$buygoods["circuitry"] = "true";
		} elseif ($db->f("type") == "Computers")  {
			$buygoods["computers"] = "true";
		} elseif ($db->f("type") == "Food")  {
			$buygoods["food"] = "true";
		} elseif ($db->f("type") == "Luxury Items")  {
			$buygoods["luxuryitems"] = "true";
		} elseif ($db->f("type") == "Machinery")  {
			$buygoods["machinery"] = "true";
		} elseif ($db->f("type") == "Narcotics")  {
		 $buygoods["narcotics"] = "true";
		} elseif ($db->f("type") == "Ore")  {
			$buygoods["ore"] = "true";
		} elseif ($db->f("type") == "Precious Metals")  {
			$buygoods["preciousmetals"] = "true";
		} elseif ($db->f("type") == "Slaves")  {
			$buygoods["slaves"] = "true";
		} elseif ($db->f("type") == "Textiles")  {
			$buygoods["textiles"] = "true";
		} elseif ($db->f("type") == "Weapons")  {
			$buygoods["weapons"] = "true";
		} elseif ($db->f("type") == "Biochemicals")  {
			$buygoods["biochemicals"] = "true";
		}
	}
		
	return $buygoods;
}

function buygoodit($buygoods, $sector_id)  {
	# only 4 locations allowed in one sector

	$num_buygoods = 0;
	$ybuytop = 49;
	$ybuyright = $ybuytop + 15;
	
	if ($buygoods["circuitry"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["computers"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["food"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["luxuryitems"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["machinery"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["narcotics"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["ore"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["preciousmetals"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["slaves"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["textiles"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["weapons"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

	if ($buygoods["biochemicals"] == "true") {
		$num_buygoods = $num_buygoods + 1;
  }

  if ($num_buygoods == 1) {
		printf("<AREA alt='Port' coords=9," . $ybuytop . ",24," . $ybuyright . " href=" . URL . "port.php>");
	} elseif ($num_buygoods == 2) {
		printf("<AREA alt='Port' coords=9," . $ybuytop . ",39," . $ybuyright . " href=" . URL . "port.php>");
	} elseif ($num_buygoods == 3) {
		printf("<AREA alt='Port' coords=9," . $ybuytop . ",53," . $ybuyright . " href=" . URL . "port.php>");
	} elseif ($num_buygoods == 4) {
		printf("<AREA alt='Port' coords=9," . $ybuytop . ",68," . $ybuyright . " href=" . URL . "port.php>");
  }
}

function computesellgoods($sector_id)  {
	$db = new ME_DB;
	$query = sprintf("SELECT sector_id, type, buyorsell from goods where sector_id = '%s' and buyorsell = 'sell'", $sector_id);
	$db->query($query);
	
	$sellgoods = array("circuitry" => "false", "computers" => "false", "food" => "false", "luxuryitems" => "false",
		"machinery" => "false", "narcotics" => "false", "ore" => "false",	"preciousmetals" => "false", "slaves" => "false",
		"textiles" => "false", "weapons" => "false", "biochemicals" => "false");
	
	while ($db->next_record())  {
		if ($db->f("type") == "Circuitry")  {
			$sellgoods["circuitry"] = "true";
		} elseif ($db->f("type") == "Computers")  {
			$sellgoods["computers"] = "true";
		} elseif ($db->f("type") == "Food")  {
			$sellgoods["food"] = "true";
		} elseif ($db->f("type") == "Luxury Items")  {
			$sellgoods["luxuryitems"] = "true";
		} elseif ($db->f("type") == "Machinery")  {
			$sellgoods["machinery"] = "true";
		} elseif ($db->f("type") == "Narcotics")  {
		 $sellgoods["narcotics"] = "true";
		} elseif ($db->f("type") == "Ore")  {
			$sellgoods["ore"] = "true";
		} elseif ($db->f("type") == "Precious Metals")  {
			$sellgoods["preciousmetals"] = "true";
		} elseif ($db->f("type") == "Slaves")  {
			$sellgoods["slaves"] = "true";
		} elseif ($db->f("type") == "Textiles")  {
			$sellgoods["textiles"] = "true";
		} elseif ($db->f("type") == "Weapons")  {
			$sellgoods["weapons"] = "true";
		} elseif ($db->f("type") == "Biochemicals")  {
			$sellgoods["biochemicals"] = "true";
		}
	}

	return $sellgoods;
}

function sellgoodit($sellgoods, $sector_id)  {
	# only 4 locations allowed in one sector

	$num_sellgoods = 0;
	$yselltop = 66;
	$ysellright = $yselltop + 15;
	
	if ($sellgoods["circuitry"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["computers"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["food"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["luxuryitems"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["machinery"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["narcotics"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["ore"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["preciousmetals"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["slaves"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["textiles"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["weapons"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

	if ($sellgoods["biochemicals"] == "true") {
		$num_sellgoods = $num_sellgoods + 1;
  }

  if ($num_sellgoods == 1) {
		printf("<AREA alt='Port' coords=9," . $yselltop . ",24," . $ysellright . " href=" . URL . "port.php>");
	} elseif ($num_sellgoods == 2) {
		printf("<AREA alt='Port' coords=9," . $yselltop . ",39," . $ysellright . " href=" . URL . "port.php>");
	} elseif ($num_sellgoods == 3) {
		printf("<AREA alt='Port' coords=9," . $yselltop . ",53," . $ysellright . " href=" . URL . "port.php>");
	} elseif ($num_sellgoods == 4) {
		printf("<AREA alt='Port' coords=9," . $yselltop . ",68," . $ysellright . " href=" . URL . "port.php>");
  }
}

function computelocations($sector_id)  {
	$db = new ME_DB;
	$query = sprintf("SELECT sector_id, type, name from locations where sector_id = '%s' order by type",  $sector_id);
	$db->query($query);
	
	$locations = array("shipdealer" => "false", "bank" => "false", "bar" => "false", "government" => "false",
		"technology" => "false", "underground" => "false", "weapons" => "false", "authority" => "false",
		"starbase" => "false" );
	
	while ($db->next_record())  {
	  if ($db->f("type") == "Shipdealer")  {
	  	$locations["shipdealer"] = "true";
	  } elseif ($db->f("type") == "Bank")  {
	  	$locations["bank"] = "true";
	  } elseif ($db->f("type") == "Bar")  {
	  	$locations["bar"] = "true";
	  } elseif ($db->f("type") == "Government")  {
	  	$locations["government"] = "true";
	  } elseif ($db->f("type") == "Technology")  {
	  	$locations["technology"] = "true";
	  } elseif ($db->f("type") == "Underground")  {
	  	$locations["underground"] = "true";
	  } elseif ($db->f("type") == "Weapons")  {
	  	$locations["weapons"] = "true";
	  } elseif ($db->f("type") == "Authority")  {
	  	$locations["authority"] = "true";
	  } elseif ($db->f("type") == "Starbase")  {
	  	$locations["starbase"] = "true";
	  }
	}
	
	return $locations;
}

function locationit($locations, $sector_id)  {
	# only 4 locations allowed in one sector

	$ylocationtop = 23;
	$ylocationbot = $ylocationtop + 16;
	$num_locations = 0;
	
	if ($locations["shipdealer"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Ship Dealer' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "ship_dealer.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Ship Dealer' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "ship_dealer.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Ship Dealer' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "ship_dealer.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Ship Dealer' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "ship_dealer.php>");
		}
		
		$num_locations = $num_locations + 1;
	}
	
	if ($locations["technology"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Tech Dealer' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "tech_dealer.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Tech Dealer' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "tech_dealer.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Tech Dealer' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "tech_dealer.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Tech Dealer' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "tech_dealer.php>");
		}
		
		$num_locations = $num_locations + 1;
	}

	if ($locations["bank"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Bank' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "bank_enter.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Bank' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "bank_enter.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Bank' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "bank_enter.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Bank' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "bank_enter.php>");
		}
		
		$num_locations = $num_locations + 1;
	}
	
	if ($locations["government"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Government' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "government.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Government' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "government.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Government' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "government.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Government' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "government.php>");
		}
		
		$num_locations = $num_locations + 1;
	}
	
	if ($locations["bar"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Bar' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "bar.php?id=" . $sector_id . ">");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Bar' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "bar.php?id=" . $sector_id . ">");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Bar' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "bar.php?id=" . $sector_id . ">");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Bar' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "bar.php?id=" . $sector_id . ">");
		}
		
		$num_locations = $num_locations + 1;
	}
	
	if ($locations["underground"] == "true")  {
		if ($num_locations == 0) {
		printf("<AREA alt='Underground' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "underground.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Underground' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "underground.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Underground' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "underground.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Underground' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "underground.php>");
		}
		
		$num_locations = $num_locations + 1;
	}
	
	if ($locations["weapons"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Weapons Dealer' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "weapons_dealer.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Weapons Dealer' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "weapons_dealer.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Weapons Dealer' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "weapons_dealer.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Weapons Dealer' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "weapons_dealer.php>");
		}
		
		$num_locations = $num_locations + 1;
	}
	
	if ($locations["authority"] == "true")  {	
		$num_locations = $num_locations + 1;
	}

	if ($locations["starbase"] == "true")  {
		if ($num_locations == 0) {
			printf("<AREA alt='Starbase' coords=3," . $ylocationtop . ",19," . $ylocationbot . " href=" . URL . "starbase_dock.php>");
		} elseif ($num_locations == 1) {
			printf("<AREA alt='Starbase' coords=18," . $ylocationtop . ",34," . $ylocationbot . " href=" . URL . "starbase_dock.php>");
		} elseif ($num_locations == 2) {
			printf("<AREA alt='Starbase' coords=34," . $ylocationtop . ",50," . $ylocationbot . " href=" . URL . "starbase_dock.php>");
		} elseif ($num_locations == 3) {
			printf("<AREA alt='Starbase' coords=50," . $ylocationtop . ",66," . $ylocationbot . " href=" . URL . "starbase_dock.php>");
		}
		
		$num_locations = $num_locations + 1;
	}
}

function planetit($sector_id)  {
  $db = new ME_DB;
	$query = sprintf("SELECT sector_id, planet_id from planets where sector_id = '%s'",  $sector_id);
	$db->query($query);
  $db->next_record;

	if ($db->nf()>0)  {
		printf("<AREA  alt='Orbit Planet' coords=41,4,57,20 href=" . URL . "planet_orbit.php>");	
	}
}

function warpit($sector_id)  {
  $db = new ME_DB;
	$query = sprintf("SELECT warp_id, sector_id from warps where sector_id = '%s'",  $sector_id);
	$db->query($query);
  $db->next_record;

	if ($db->nf()>0)  {
		printf("<area alt='Warp' coords=58,4,73,19 href=" . URL . "warp.php>");	
	}
}

?>

<html><head><title>Merchant Empires: Local Map</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=125 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$player_config = new ME_Player_config;
$player_config->get_player_config($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "localmap");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$db = new ME_DB;
$db_2 = new ME_DB;

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $ship->f("sector_id") <> 0 ) {
	echo "<center><font color=#cccccc face=arial,helvetica,swiss size=2>Local map of the known&nbsp;";

	$s1 = new ME_Sector;
	$s1->get_sector($player_id);	

	$query = sprintf("select map_id, description from maps where map_id = '%s'", $s1->f("map_id"));
	$db->query($query);
	$db->next_record();
	echo $db->f("description");

	$sectors = get_player_map($s1->f("map_id"), $player);
	$visible_sectors = array();
	$visible_sectors = explode(",", $sectors);
	
	$map_sql = "select * from sectors where ";

	if ( $player_config->f("map_size") == 1 ) {
		$y_size = 2;
		$x_size = -2;
		$map_width = 5;		
	} elseif ( $player_config->f("map_size") == 2 ) {
		$y_size = 3;
		$x_size = -3;
		$map_width = 7;		
	}
	
	$map_sql = "select * from sectors where (map_id = " . $s1->f("map_id") . " and xpos >= " . ($s1->f("xpos") + $x_size) . " and xpos <= " . ($s1->f("xpos") + ($x_size * -1)) . " and ypos <= " . ($s1->f("ypos") + $y_size) . " and ypos >= " . ($s1->f("ypos") - $y_size)  . " )";

	$db->query($map_sql);
	$galaxy = array();

	while ( $db->next_record() ) {
		$galaxy[$db->f("xpos") . "," . $db->f("ypos")][0] = $db->f("xpos");
		$galaxy[$db->f("xpos") . "," . $db->f("ypos")][1] = $db->f("ypos");
		$galaxy[$db->f("xpos") . "," . $db->f("ypos")][2] = $db->f("sector_id");
		$galaxy[$db->f("xpos") . "," . $db->f("ypos")][3] = $db->f("public_sector_id");
		$galaxy[$db->f("xpos") . "," . $db->f("ypos")][4] = $db->f("map_id");
		$galaxy[$db->f("xpos") . "," . $db->f("ypos")][5] = $db->f("image_version");
	}
	
	echo "</font></center><br><table cols=5 border=0 width=490 cellPadding=1 cellSpacing=0>";

	$db_f = new ME_DB;

	$y = $y_size;
	for ($i = 1; $i <= $map_width; $i++) {
		$x = $x_size;
		echo "<tr>";
		for ($j = 1; $j <= $map_width; $j++) {
		  $str = ($s1->f("xpos") + $x) . "," . ($s1->f("ypos") + $y);
			
			echo "<td>";

			# if the table cell contains a map sector, print the contents
			if ($galaxy[$str][2] != 0)  {
				$status = array("redbox" => "false", "yellowbox" => "false");
			
				if ( $player->f("alignment") < -100 ) {
					$query = sprintf("SELECT sector_id, type from goods where sector_id = '%s' and (type='Narcotics' or type='Weapons' or type='Slaves')", $galaxy[$str][2]);
					$db->query($query);

					$contra_found = 0;
	
					if ( $db->nf() > 0 ) {
						$contra_found = 1;
					}
				} else {
					$contra_found = 0;
				}

				# determine if the sector is an exit sector from the current sector, or if the
				# sector is the current sector
				if  ( $galaxy[$str][0] == $s1->f("xpos") + 1
					and  $galaxy[$str][1] == $s1->f("ypos")
					and has_right_exit($s1->f("exits"), $s1->f("xpos"), $s1->f("ypos")) ) {
					$status["yellowbox"] = "true";
				} elseif ( $galaxy[$str][0] == $s1->f("xpos") - 1
					and $galaxy[$str][1] == $s1->f("ypos")
					and has_left_exit($s1->f("exits"), $s1->f("xpos"), $s1->f("ypos")) ) {
					$status["yellowbox"] = "true";	
				} elseif ( $galaxy[$str][0] == $s1->f("xpos")
					and $galaxy[$str][1] == $s1->f("ypos") + 1
					and has_top_exit($s1->f("exits"), $s1->f("xpos"), $s1->f("ypos")) )  {
					$status["yellowbox"] = "true";	
				} elseif ( $galaxy[$str][0] == $s1->f("xpos")
					and $galaxy[$str][1] == $s1->f("ypos") - 1
		 		 	and has_bottom_exit($s1->f("exits"), $s1->f("xpos"), $s1->f("ypos")) ) {
					$status["yellowbox"] = "true";	
				} elseif ( $galaxy[$str][0] == $s1->f("xpos")
					and $galaxy[$str][1] == $s1->f("ypos") )  {
					$status["redbox"] = "true";
				}

				if ( $status["yellowbox"] == "true" )  {
					if ( in_array($galaxy[$str][2], $visible_sectors) )  {        						
						if ( $ship->f("scanner") ) {
							$query = sprintf("select ships.player_id, ships.sector_id, ship_technology.cloak, ship_technology.cloak_active from ships, ship_technology where ships.sector_id = %s and ships.player_id <> '%s' and ships.player_id = ship_technology.player_id", $galaxy[$str][2], $player_id);
							$db->query($query);

							$found_visible_merchant = 0;					
					
							while( $db->next_record() and !$found_visible_merchant ) {									
									if ( $player_config->f("ignore_newbie") == 'f' ) {
										$query = sprintf("SELECT player_id, name, public_player_id, experience, level from players where player_id = '%s'", $db->f("player_id"));
									} else {
										$query = sprintf("SELECT player_id, name, public_player_id, experience, level, newturnsleft from players where player_id = '%s' and newturnsleft = 0", $db->f("player_id"));
									}

									$db_2->query($query);
							   	$db_2->next_record();
									
									if ( $db_2->nf() > 0 ) {
										if ( ($db->f("cloak") and $db->f("cloak_active") == 't' and $db_2->f("level") < $player->f("level")) or ( $db->f("cloak_active") == 'f' ) ) {
											$found_visible_merchant = 1;
										}
									}
							}
							
							$query = sprintf("select * from forces where sector_id = %s", $galaxy[$str][2]);
							$db_f->query($query);

							# sector has forces and merchants
							if ( $found_visible_merchant and $db_f->nf() > 0 ) {
								if ( $contra_found ) {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
										"/yellow-minedrone-withmerchant-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
										. $galaxy[$str][2] . "'>");
								} else {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
										"/yellow-minedrone-withmerchant" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
										. $galaxy[$str][2] . "'>");
								}
							#sector has merchants and no forces
							} elseif ( $found_visible_merchant and $db_f->nf() == 0 ) {
								if ( $contra_found ) {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
										"/yellow-merchant-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
										. $galaxy[$str][2] . "'>");
								} else {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
									"/yellow-merchant" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
									. $galaxy[$str][2] . "'>");
								}
							# sector has forces and no merchants
							} elseif ( $found_visible_merchant <> 1 and $db_f->nf() > 0 ) {
								if ( $contra_found ) {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
										"/yellow-minedrone-nomerchant-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
										. $galaxy[$str][2] . "'>");
								} else {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
										"/yellow-minedrone-nomerchant" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
										. $galaxy[$str][2] . "'>");
								}
							# sector has no forces and no merchants
							} else {
								if ( $contra_found ) {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] . "/blankyellowbox-evil"
										. $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#" . $galaxy[$str][2] . "'>");
								} else {
									printf("<img border=0 src='./images/map" . $galaxy[$str][4] . "/blankyellowbox"
										. $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#" . $galaxy[$str][2] . "'>");
								}
							}
						} else {
							if ( $contra_found ) {
								printf("<img border=0 src='./images/map" . $galaxy[$str][4] . "/blankyellowbox-evil"
									. $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#" . $galaxy[$str][2] . "'>");
							} else {
								printf("<img border=0 src='./images/map" . $galaxy[$str][4] . "/blankyellowbox"
									. $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#" . $galaxy[$str][2] . "'>");
							}
						}
					} else {
						printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
							"/unexplored-yellow" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#" . $galaxy[$str][2] . "'>");
					}

					printf("<map name='" . $galaxy[$str][2] . "'>");
					printf("<area alt='Move to sector " . $galaxy[$str][3] . "' coords=0,0,30,20 href=" . URL . "move_to_sector.php?move=" . $galaxy[$str][2] . "></map>");
					
				} elseif ( $status["redbox"] == "true" )  {
					$query = sprintf("select ships.player_id, ships.sector_id, ship_technology.cloak, ship_technology.cloak_active from ships, ship_technology where ships.sector_id = %s	and ships.player_id <> '%s' and ships.player_id = ship_technology.player_id", $galaxy[$str][2], $player_id);
					$db->query($query);

					$query = sprintf("select * from forces where sector_id = %s", $galaxy[$str][2]);
					$db_f->query($query);

					$found_visible_merchant = 0;					
					
					while( $db->next_record() and !$found_visible_merchant ) {						
						if ( $player_config->f("ignore_newbie") == 'f' ) {
							$query = sprintf("SELECT player_id, name, public_player_id, experience, level from players where player_id = '%s'", $db->f("player_id"));
						} else {
							$query = sprintf("SELECT player_id, name, public_player_id, experience, level, newturnsleft from players where player_id = '%s' and newturnsleft = 0", $db->f("player_id"));
						}
						
						$db_2->query($query);
						$db_2->next_record();

						if ( $db_2->nf() > 0 ) {
							if ( ($db->f("cloak") and $db->f("cloak_active") == 't' and $db_2->f("level") < $player->f("level")) or ( $db->f("cloak_active") == 'f' ) ) {
								$found_visible_merchant = 1;
							}
						}
					}

					# sector has forces and merchants
					if ( $found_visible_merchant and $db_f->nf() > 0 ) {
						if ( $contra_found ) {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/minedrone-withmerchant-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");
						} else {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/minedrone-withmerchant" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");			
						}
					# sector has merchants and no forces
					} elseif ( $found_visible_merchant and $db_f->nf() == 0 ) {
						if ( $contra_found ) {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/merchant-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");
						} else {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/merchant" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");			
						}
					# sector has forces and no merchants
					} elseif ( $found_visible_merchant <> 1 and $db_f->nf() > 0 ) {
						if ( $contra_found ) {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/minedrone-nomerchant-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");
						} else {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/minedrone-nomerchant" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");			
						}
				# sector has no forces and no merchants
					} else {
						if ( $contra_found ) {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/blankredbox-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");
						} else {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/blankredbox" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png' usemap='#"
								. $galaxy[$str][2] . "'>");			
						}
					}
					
					printf("<map name='" . $galaxy[$str][2] . "'>");
				
					#compute buy goods
					$buygoods = computebuygoods($galaxy[$str][2]);
					buygoodit($buygoods, $galaxy[$str][2]);
				
					#compute sell goods
					$sellgoods = computesellgoods($galaxy[$str][2]);
					sellgoodit($sellgoods, $galaxy[$str][2]);
	
					# compute locations
					$locations = computelocations($galaxy[$str][2]);
					locationit($locations, $galaxy[$str][2]);
				
					# planets
					planetit($galaxy[$str][2]);
    	
					# warps
					warpit($galaxy[$str][2]);
				
					printf("<area alt='Current Sector' coords=0,0,20,20 href=" . URL . "current_sector.php></map>");
				} elseif ( $status["redbox"] == 'false'
				and $status["yellowbox"] == "false" )  {
					if ( in_array($galaxy[$str][2], $visible_sectors) )  {
						if ( $contra_found ) {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/blank-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
						} else {
							printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/blank" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
						}
					} else {
						printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
							"/unexplored" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
					}
				}

			} else {
				printf("<img src='./images/blanksector.png'>");
			}
	    echo "\n</td>";
			$x = $x + 1;
		}
		printf("</tr>");
		$y = $y - 1;
	}
?>

</table><?php

	if ( $player->f("success_offer") <> 0 ) {
?>
<br>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=490>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#cccccc face=arial,helvetica,swiss size=3> <?php

		echo "Your offer of </font>" . $player->f("success_offer") . "<font color=#cccccc face=arial,helvetica,swiss size=3> credits for </font>" . $player->f("success_amount") . "<font color=#cccccc face=arial,helvetica,swiss size=3> unit(s)";
		echo " of " . $player->f("success_type") . " was accepted.";

		if ( $player->f("success_experience") > 0 ) {
			echo "<br>Your trading skills have earned you </font>" . $player->f("success_experience") . "<font color=#cccccc face=arial,helvetica,swiss size=3> experience points.</font>";
		}

?>				
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

		$db->query("update players set success_offer = '0',	success_amount = '0',
			success_type = '' where player_id = '$player_id'");

	}

} else {
	$error = 5;
	#landed on planet
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 4) {
		$db->add_parameter("message", "Movement is not possible. Your merchant has no turns.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "The local map cannot be viewed when your merchant has landed on a planet.");			
	} elseif ($error == 16) {
		$db->add_parameter("message", "You cannot target forces upon yourself.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td vAlign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

unset($db);
unset($db_2);

page_close();
?>