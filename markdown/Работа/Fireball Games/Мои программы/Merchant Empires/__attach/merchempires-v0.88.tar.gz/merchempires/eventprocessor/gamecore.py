
""" This file is part of Merchant Empires
    Copyright (C) 2000 Bryan Brunton (bryan@dunsinane.net)

    This is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this library; see the file COPYING If not, write to
    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
    Boston, MA 02111-1307, USA.
"""

# gamecore.py
#
# datatypes and constants

import game, time
import logger

RUNNING = 1
FINISH = 2
QUIT = 0

# scheduler - calls events

class Scheduler:
	def __init__(self):
		self.events = {}
		self.log = logger.file_logger ('/var/log/merchantempires.log')
	
	def __str__(self):
		pass
		
	def addevent(self, name, event):
		self.events[name] = event
	
	def report(self):
		if not self.events: return
	
		print "\nScheduler Status Report -- " + str(len(self.events)) + " event(s) queued\n"
		print "Current time \t\t" + time.strftime('%H' + ':' + '%M', time.localtime(time.time())) + "\t" + str(time.time()) 
		print ""
		print "NAME" + "\t\t\t" + "TIME" + "\t" + "TIME_STAMP" + "\t" + "INTERVAL" 
		for key in self.events.keys():
			e = self.events[key]
  			print str(e.name) + "\t\t" + str(e.time) + "\t" + str(e.time_stamp) + "\t" + str(e.interval)

		print "Enter (r) to see report, (q) to quit: "	

	def report_2(self):
		if not self.events: return
	
		text = "\nScheduler Status Report -- " + str(len(self.events)) + " event(s) queued\n"
		text = text + "Current time \t\t" + time.strftime('%H' + ':' + '%M', time.localtime(time.time())) + "\t" + str(time.time()) 
		text = text + "\n\n"
		text = text + "NAME" + "\t\t\t" + "TIME" + "\t" + "TIME_STAMP" + "\t" + "INTERVAL" + "\n" 
		for key in self.events.keys():
			e = self.events[key]
  			text = text + str(e.name) + "\t\t" + str(e.time) + "\t" + str(e.time_stamp) + "\t" + str(e.interval) + "\n"

		return text
	
	def update(self):
		if not self.events: return
		
		for key in self.events.keys():
			e = self.events[key]
			
			#print str(e.time_stamp) + " " + str(time.time());
			if e.time_stamp <= time.time():
				eventtime = e.time

				try:
					#pass
					e.perform()
				except:
					self.log.log('Error performing ' + str(e.name) + '\n Scheduled for ' + str(e.time))

				e.resetinterval()

		#print "----"
# event - keeps an event that needs to be executed

class Event:
	def __init__(self,name=None,event_time=None,interval=None):
		import time

		self.name = name
		self.time = event_time
		self.interval = interval

		if self.interval == "H":
			minute = int(event_time[3:])
			mytime = (time.localtime(time.time())[0],time.localtime(time.time())[1],time.localtime(time.time())[2],
				time.localtime(time.time())[3],minute,time.localtime(time.time())[5],time.localtime(time.time())[6],
				time.localtime(time.time())[7],	time.localtime(time.time())[8])	
				
			self.time_stamp = time.mktime(mytime)

			# schedule the event for the future if its in the past
			if self.time_stamp < time.time():
				self.time_stamp = self.time_stamp + 3600

			self.time = time.strftime('%H' + ':' + '%M', time.localtime(self.time_stamp))

		elif self.interval == "D":
			hour = int(event_time[:2])
			minute = int(event_time[3:])

			mytime = (time.localtime(time.time())[0],time.localtime(time.time())[1],time.localtime(time.time())[2],
				hour,minute,time.localtime(time.time())[5],time.localtime(time.time())[6],
				time.localtime(time.time())[7],	time.localtime(time.time())[8])	

			self.time_stamp = time.mktime(mytime)

			# schedule the event for the future if its in the past
			if self.time_stamp < time.time():
				self.time_stamp = self.time_stamp + 86400

			self.time = time.strftime('%H' + ':' + '%M', time.localtime(self.time_stamp))	

		elif self.interval == "M":			
			minute = time.localtime(time.time())[4] + 1

			if minute == 60:
				minute = 0

			mytime = (time.localtime(time.time())[0],time.localtime(time.time())[1],time.localtime(time.time())[2],
				time.localtime(time.time())[3],minute,time.localtime(time.time())[5],time.localtime(time.time())[6],
				time.localtime(time.time())[7],	time.localtime(time.time())[8])	
				
			self.time_stamp = time.mktime(mytime)

			self.time = time.strftime('%H' + ':' + '%M', time.localtime(self.time_stamp))
		
	def __str__ (self):
		return self.name
	
	def resetinterval(self):
		if self.interval == "H":
			self.time_stamp = self.time_stamp + 3600
			self.time = time.strftime('%H' + ':' + '%M', time.localtime(self.time_stamp))
		elif self.interval == "D":
			self.time_stamp = self.time_stamp + 86400
			self.time = time.strftime('%H' + ':' + '%M', time.localtime(self.time_stamp))		
		elif self.interval == "M":
			self.time_stamp = self.time_stamp + 60
			self.time = time.strftime('%H' + ':' + '%M', time.localtime(self.time_stamp))		

	def perform(self):
		pass
