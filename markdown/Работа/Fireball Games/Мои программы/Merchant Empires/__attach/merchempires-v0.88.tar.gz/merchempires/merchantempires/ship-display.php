<?php

function display_technology_old_ns($technology, $section, $URL) {	
	while (list($key, $val) = each($technology)) {
		echo "<span class=clsNrmTxt>" . "<a href=" . $URL . ">" . $key . "</a>: </span>";		
		echo $val . "<br>";
	}	
}

function display_technology($technology, $section, $URL, $ship) {
	for ($i = 1; $i <= 5; $i++) {
		echo "<td width=20 class=clsNrmTxt id=red1>";
		list($key, $val) = each($technology);

		if ( $key ) {
			echo "<a href=" . $URL;			
			echo ">";
				
			if ( $key == 'CD' ) {
				if ( $ship->f("cloak_active") == 't' and $ship->f("cloak") ) {
					echo "<font color=green>" . $key . "</font></a>";				
				} else {
					echo "<font color=red>" . $key . "</font></a>";									
				}
			} else {
				echo $key . "</a>";
			}
		} else {
			echo "&nbsp;";
		}

		echo "</td>";		
	}

	echo "</tr><tr>";

	reset($technology);

	for ($i = 1; $i <= 5; $i++) {		
		list($key, $val) = each($technology);

		if ( $val ) {
			echo "<td class=clsNrmTxt>";
    		echo $val;
		} else {
			echo "<td class=clsNrmTxtBld id=red1>";
			echo "00";
		}

		echo "</td>";		
	}
}

echo "<table cellPadding=0 cellSpacing=0 width=145 valign=top><tr><td vAlign=top width=100%>";
echo "<table border=0 cellPadding=0 cellSpacing=0 width=100%><tr><td bgColor=#993300>";
echo "<table border=0 cellPadding=4 cellSpacing=1 width=100%><tr><td class=clsHedTxt id=red1><a href=";
echo $sess->url(URL . "ship_details.php") . ">" . $ship->f("type") . "</a>";
echo "<br></td></tr><tr><td class=clsNrmTxtWht>";
echo "<span class=clsNrmTxt>Rating: </span>";

if ( (int) (($ship->combined_damage / 40) + ($ship->f("combatcurrent") / 50)) < 1 ) {
	$offense = 1;
} else {
	$offense = (int) (($ship->combined_damage / 40) + ($ship->f("combatcurrent") / 50));
}

if ( (int) (($ship->f("shieldcurrent") + $ship->f("armorcurrent") + ($ship->f("combatcurrent") * 3)) / 100)  < 1 ) {
	$defense = 1;
} else {
	$defense = (int) (($ship->f("shieldcurrent") + $ship->f("armorcurrent") + ($ship->f("combatcurrent") * 3)) / 100);
}

echo  $offense . "/" . $defense .  "<br>";
echo "<span class=clsNrmTxt>Shields: </span>";
echo $ship->f("shieldcurrent") . "/" . $ship->f("shieldmax") . "<br>";
echo "<span class=clsNrmTxt>Armor: </span>";
echo $ship->f("armorcurrent") . "/" . $ship->f("armormax") . "<br>";
echo "<span class=clsNrmTxt>Power: </span>";
echo $ship->f("powercurrent") . "/" . $ship->f("powermax") . "<br>";

if ( $ship->f("sector_id") <> 0 ) {
	echo "<span class=clsNrmTxt>Current Sector: </span>" . $ship->f("public_sector_id") . "<br>";
}

$technology = array();

for ($i = 1; $i <= $ship->f("cloak"); $i++) {	
	if ( $i == 1 ) {
		$technology['CD'] = 10;	
	} else {
		$technology['CD'] = $technology['CD'] + 0;	
	}
}

for ($i = 1; $i <= $ship->f("illusion"); $i++) {	
	if ( $i == 1 ) {
		$technology['IG'] = 10;	
	} else {
		$technology['IG'] = $technology['IG'] + 0;	
	}
}

for ($i = 1; $i <= $ship->f("jump"); $i++) {	
	if ( $i == 1 ) {
		$technology['JD'] = 10;	
	} else {
		$technology['JD'] = $technology['JD'] + 0;	
	}
}

for ($i = 1; $i <= $ship->f("scanner"); $i++) {	
	if ( $i == 1 ) {
		$technology['SC'] = 5;	
	} else {
		$technology['SC'] = $technology['SC'] + 0;	
	}
}

for ($i = 1; $i <= $ship->f("tractor_beam"); $i++) {	
	if ( $i == 1 ) {
		$technology['TB'] = 25;	
	} else {
		$technology['TB'] = $technology['TB'] + 15;
	}
}

for ($i = 1; $i <= $ship->f("tracking"); $i++) {	
	if ( $i == 1 ) {
		$technology['TD'] = 15;	
	} else {
		$technology['TD'] = $technology['TD'] + 5;
	}
}

for ($i = 1; $i <= $ship->f("deep_scanner"); $i++) {	
	if ( $i == 1 ) {
		$technology['DS'] = 25;	
	} else {
		$technology['DS'] = $technology['DS'] + 15;	
	}
}

for ($i = 1; $i <= $ship->f("targeting_computer"); $i++) {	
	if ( $i == 1 ) {
		$technology['TC'] = 25;	
	} else {
		$technology['TC'] = $technology['TC'] + 15;	
	}
}

for ($i = 1; $i <= $ship->f("plasma_booster"); $i++) {	
	if ( $i == 1 ) {
		$technology['PB'] = 25;	
	} else {
		$technology['PB'] = $technology['PB'] + 15;	
	}
}

for ($i = 1; $i <= $ship->f("trifocus_plasma"); $i++) {	
	if ( $i == 1 ) {
		$technology['TP'] = 25;	
	} else {
		$technology['TP'] = $technology['TP'] + 15;	
	}
}

for ($i = 1; $i <= $ship->f("active_screens"); $i++) {	
	if ( $i == 1 ) {
		$technology['AS'] = 25;	
	} else {
		$technology['AS'] = $technology['AS'] + 15;	
	}
}

for ($i = 1; $i <= $ship->f("battle_systems_computer"); $i++) {	
	if ( $i == 1 ) {
		$technology['BC'] = 40;	
	} else {
		$technology['BC'] = $technology['BC'] + 15;	
	}
}

if ( $ship->f("active_screens") ) {
	echo "<span class=clsNrmTxt>Screens: </span>" . $ship->f("screenscurrent") . "/" . $ship->f("screensmax") . "<br>";
}

if ( count($technology) > 0 ) {
	if ( strpos($HTTP_USER_AGENT, "zilla/4") and !(strpos($HTTP_USER_AGENT, "MSIE")) ) {
		echo "<br>";
		display_technology_old_ns($technology, 1, $sess->url(URL . "ship_technology.php"));
	} else {
		echo "<br><table cellPadding=1 cellSpacing=0 width=82 align=top><tr><td vAlign=top>";
		echo "<table border=0 cellPadding=0 cellSpacing=0 width=80><tr><td bgColor=#993300>";
		echo "<table cellPadding=3 cellSpacing=1 border=0 width=80><tr>";

		display_technology($technology, 1, $sess->url(URL . "ship_technology.php"), $ship);

		echo "</tr></table></td></tr></table></td></tr></table>";
	}
}

if ( $ship->f("tracking_player_id") <> 0 and $ship->f("tracking") ) {
	$trackable = 1;

	$db = new ME_DB;
	$tracked_player_id = $ship->f("tracking_player_id");
	$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id, players.player_id, players.name from ships, sectors, players where ships.player_id = '$tracked_player_id' and ships.sector_id = sectors.sector_id and ships.player_id = players.player_id");
	$db->next_record();

	$tracked_sector_id = $db->f("public_sector_id");
	$tracked_map_id = $db->f("map_id");
	$tracked_player_name = stripslashes($db->f("name"));

	if ( $ship->f("tracking_locked") == 'f' or $ship->f("sector_id") == 0 ) {
		$trackable = 0;
	} else {		
		$db->query("select ships.player_id, ships.public_sector_id, ships.sector_id, sectors.sector_id, sectors.xpos, sectors.ypos, sectors.map_id from ships, sectors where ships.player_id = '$player_id' and ships.sector_id = sectors.sector_id");
		$db->next_record();

		$player_xpos = $db->f("xpos");
		$player_ypos = $db->f("ypos");
		$player_map_id = $db->f("map_id");	
	}

	if ( $tracked_map_id <> $player_map_id ) {
		$trackable = 0;
	}

	echo "<br><span class=clsNrmTxt>Tracking: </span>" . $tracked_player_name . "<br>";
	echo "<span class=clsNrmTxt>Location: </span>";

	if ( $trackable and $ship->f("tracking_locked") == 't' ) {
		$player_map_id = $db->f("map_id");					

		$map_sql = "select * from sectors where ";

		$counter = 1;
		
		if ( $ship->f("tracking") == 1 ) {
			$y_bound = 2;
			$x_bound = -2;
			$search_width = 5;
			$sector_limit = 26;
		} elseif ( $ship->f("tracking") == 2 ) {
			$y_bound = 3;
			$x_bound = -3;
			$search_width = 7;
			$sector_limit = 50;
		} elseif ( $ship->f("tracking") == 3 ) {
			$y_bound = 4;
			$x_bound = -4;
			$search_width = 9;
			$sector_limit = 82;
		} elseif ( $ship->f("tracking") == 4 ) {
			$y_bound = 5;
			$x_bound = -5;
			$search_width = 11;
			$sector_limit = 122;
		}		

		$y = $y_bound;
		for ($i = 1; $i <= $search_width; $i++) {
			$x = $x_bound;
			for ($j = 1; $j <= $search_width; $j++) {
				$map_sql = $map_sql . "( map_id = " . $player_map_id . " and xpos = " . ($player_xpos + $x) . " and ypos = " . ($player_ypos + $y) . " )";
				$counter++;

				if ( $counter <> $sector_limit ) {
					$map_sql = $map_sql . " or ";
				}

				$x = $x + 1;
			}
			
			$y = $y - 1;
		}				
											
		$query = $map_sql;
		$db->query($query);

		$surrounding_sectors = array();

		while ( $db->next_record() ) {
			array_push($surrounding_sectors, $db->f("public_sector_id"));
		}

		if ( !in_array($tracked_sector_id, $surrounding_sectors) ) {
			$db->query("update ship_technology set tracking_locked = 'f' where player_id = '$player_id'");			
			echo "---<br>";
		} else {
			echo $tracked_sector_id . "<br>";	
		}
	} else {
		$db->query("update ship_technology set tracking_locked = 'f' where player_id = '$player_id'");				
		echo "---<br>";
	}
}

echo "</span><br><a href=";
echo $sess->url(URL . "ship_forces.php");
echo ">Forces</a><br>";
echo "<span class=clsNrmTxt>Mines: </span>";
echo $ship->f("minescurrent") . "/" . $ship->f("minesmax") . "<br>";
echo "<span class=clsNrmTxt>Combat: </span>";
echo $ship->f("combatcurrent") . "/" . $ship->f("combatmax") . "<br>";
echo "<span class=clsNrmTxt>Scouts: </span>";
echo $ship->f("scoutcurrent") . "/" . $ship->f("scoutmax") . "<br><br>";

echo "<a href=" . $sess->url(URL . "ship_cargo.php");
echo ">Cargo Holds</a>&nbsp;";
echo $ship->f("cargocurrent") . "/" . $ship->f("cargomax") . "<br>";
echo $ship->display_cargo();

echo "<a href=" . $sess->url(URL . "ship_weapons.php");
echo ">Weapons</a><br>";

echo $ship->display_weapons();

echo "</td></tr></table></td></tr></table></td></tr></table>";

?>