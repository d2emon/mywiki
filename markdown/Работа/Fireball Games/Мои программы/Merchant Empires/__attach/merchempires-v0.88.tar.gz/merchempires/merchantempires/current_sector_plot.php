<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function has_bottom_exit($exits, $xpos, $ypos)  {
	$qypos = $ypos - 1;
	$str = $xpos . ":" . $qypos;

	if (strpos ("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_top_exit($exits, $xpos, $ypos)  {
	$qypos = $ypos + 1;
	$str = $xpos . ":" . $qypos;
		
	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_right_exit($exits, $xpos, $ypos)  {
	$qxpos = $xpos + 1;
	$str = $qxpos . ":" . $ypos;

	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

function has_left_exit($exits, $xpos, $ypos)  {
	$qxpos = $xpos - 1;
	$str = $qxpos . ":" . $ypos;

	if (strpos("." . $exits, $str))  {
		return 1;
	} else {
		return 0;
	}
}

?>

<html><head><title>Merchant Empires: Current Sector</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector = new ME_Sector;
$sector->get_sector($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "currentsector");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $ship->f("sector_id") <> 0 ) {
?>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=270 bgColor=#000000 valign=top><?php
	
	echo "<table width=260><tr><td align=center>";	
	echo "<br><font color=#3333FF face=arial,helvetica,swiss size=5>SECTOR " . $sector->f("public_sector_id");	
	echo "</td></tr><tr><td align=right><br>";		
	echo "<img alt='Plot a Course' border=0 src='./images/submenu/currentsectorplot-on.png'>";
	echo "</td></tr></table>";
?>						
						</font>						
					</td>
					<td width=90 valign=top align=right bgColor=#000000>
						<img border=0 src='./images/map<?php

	echo $sector->f("map_id") . "/navmenu" . $ship->f("sector_id")	. ".png' usemap='#navmenu'>";
	echo "<map name='navmenu'>";

	#bottom
	$s2 = new ME_Sector;
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") - 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=40,58,68,85 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	#top
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") + 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=40,2,68,29 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	#right
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") + 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=69,30,97,57 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	#left
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") - 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Move to Sector' coords=11,30,39,57 href=" . URL . "move_to_sector.php?move=" . $s2->f("sector_id") . "&returnto=currentsector>";
	}

	echo "</map>";
?>
					</td>
					<td width=90 valign=top align=right bgColor=#000000>
						<img border=0 src='./images/map<?php

	echo $sector->f("map_id") . "/scanmenu" . $ship->f("sector_id")	. ".png' usemap='#scanmenu'>";
	echo "<map name='scanmenu'>";

	#bottom
	$s2 = new ME_Sector;
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") - 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=40,58,68,85 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	#top
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos"), $sector->f("ypos") + 1);

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=40,2,68,29 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	#right
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") + 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=69,30,97,57 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	#left
	$s2->get_offset_sector($sector->f("map_id"), $sector->f("xpos") - 1, $sector->f("ypos"));

	if ($s2->f("sector_id") != 0)  {
		echo "<area alt='Scan Sector' coords=11,30,39,57 href=" . URL . "current_sector_scan.php?id=" . $s2->f("sector_id") . ">";
	}

	echo "</map>";
?>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td class=clsNrmTxt>&nbsp;<?php


	if ( $action == 'read_course' ) {
		$db = new ME_DB;

		$sector_id = $ship->f("sector_id");
		$query = "select * from sectors where sector_id = '$sector_id'";
		$db->query($query);
		$db->next_record();
		$map_id = $db->f("map_id");

		$query = "select player_id, course from ships where player_id = '$player_id'";
		$db->query($query);
		$db->next_record();

		echo "<form action=";
		echo $sess->url(URL . "move_to_sector.php");
		echo " method=post>";

		echo "<font color=##3333FF  face=arial,helvetica,swiss size=4>&nbsp;<b>Plotted Course:</b><br><br></font>";
		echo "&nbsp;&nbsp;";

		$course = array();
		$course = explode(",", $db->f("course"));				
		$count = 0;

		while (list($key, $val) = each($course)) {
			$xpos = substr( $val, 0, strpos($val, ":") );		
			$ypos =  substr( $val, strpos($val, ":") + 1 );

			$query = "select * from sectors where xpos = '$xpos' and ypos = '$ypos' and map_id = '$map_id'";
			$db->query($query);
			$db->next_record();								

			$count = $count + 1;

			if ( $count == 2 ) {
				$move = $db->f("sector_id");
			}

			if ( $count <> count($course) ) {
				echo $db->f("public_sector_id") . " -> ";
			} else {
				echo $db->f("public_sector_id");
			}
		}

		echo "<input type=hidden name=move value=" . $move . ">";	
		echo "<input type=hidden name=returnto value=currentsector>";		
		echo "<input type=hidden name=follow_course value=1>";				
		echo "<br><br>&nbsp;&nbsp;<input border=0 type=image src='./images/form/follow-off.png' name=follow>";
		echo "</form>";
	} else {
		echo "<form action=";
		echo $sess->url(URL . "current_sector_plot_update.php");
		echo " method=post>";
		echo "<table cellspacing=2>";
		echo "<tr><td class=clsNrmTxt>";
		echo "Destination Sector:<br><br>";
		echo "</td></tr><tr><td>";
		echo "&nbsp;&nbsp;<input type=text size=10 name=target><br>";	
		echo "<br>&nbsp;&nbsp;<input border=0 type=image src='./images/form/plot-off.png' name=plot>";	
		echo "</form></td></tr></table>";
	}

?>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table><br><?php

} else {
	#landed on planet, don't allow viewing of sector 0
	$error = 5;
}
	
if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due no destination entered.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to invalid destination sector.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "Plotting a course to a different galaxy is not possible.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "Plotting a course to your current location is not possible");			
	} elseif ($error == 5) {
		$db->add_parameter("message", "The current sector cannot be viewed when your merchant has landed on a planet.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "A course cannot be plotted to an unexplored sector.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");	
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>