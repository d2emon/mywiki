<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: View Messages</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "viewmessages");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>
<form name="form_delete_messages" action="messages_update.php" method="post"><?php

$db = new ME_DB_Xml;
$db->add_parameter("current_screen", "view_messages");
echo $db->get_transform("./xslt/menu_top_view_messages.xslt", "");

$db = new ME_DB;
$db->query("select * from messages where player_id = '$player_id' and read = 'f' and scout = 'f' and planetary = 'f' and battle = 'f' order by date_integer desc");

if ( $db->nf() == 0 ) {
	$query = sprintf("SELECT * from messages where player_id = '%s' and scout = 'f' and planetary = 'f' and battle = 'f' order by date_integer desc", $player_id);
	$db->query($query);
} else {
	$db_2 = new ME_DB;
	$db_2->query("update messages set read = 't' where player_id = '$player_id' and scout = 'f' and planetary = 'f' and battle = 'f'");
}

# counter variable for the marked messages array that is posted in the following form
$x = 0;

$color_3 = "#993300";
$color_4 = "#330000";
$color_1 = "#003399";
$color_2 = "#000033";
$fcolor_1 = "#3333FF";
$fcolor_2 = "#993300";
$toggle = 1;

if ($db->nf()>0) {
	while( $db->next_record() ) {
		echo "<table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=";

		if ($toggle == 1) {
			echo $color_1;
		} else {
			echo $color_3;
		}

		echo "><table border=0 cellPadding=1 cellSpacing=1 width=500><tr><td width=33% bgColor=";

		if ($toggle == 1) {
			echo $color_2;
		} else {
			echo $color_4;
		}

		echo "><font color=";

		if ($toggle == 1) {
			echo $fcolor_1;
		} else {
			echo $fcolor_2;
		}

		echo " face=helvetica size=2>&nbsp;From:&nbsp;</font>";
		echo "<font color=#ccccc face=helvetica size=2>";

		if ( $db->f("fromplayer_id") > 0 ) {
			echo "<a href=" . $sess->url(URL . "send_messages_merchant.php") . "?merchant=" . $db->f("fromplayer_id") . "&reply=" . $db->f("message_id") . ">";
			echo stripslashes($db->f("fromplayer")) . "</a>";
			echo  " (" . $db->f("fromplayer_id") . ")";
		} else {	
			echo stripslashes($db->f("fromplayer")) . "</a>";	
		}

		echo "</font></td><td width=33% bgColor=";

		if ($toggle == 1) {
			echo $color_2;
		} else {
			echo $color_4;
		}

		echo "><font color=";

		if ($toggle == 1) {
			echo $fcolor_1;
		} else {
			echo $fcolor_2;
		}

		echo " face=helvetica size=2>&nbsp;To:&nbsp;</font>";
		echo "<font color=#ccccc face=helvetica size=2>";
		echo stripslashes($db->f("toplayer"));

		echo "</font></td><td width=33% bgColor=";

		if ($toggle == 1) {
			echo $color_2;
		} else {
			echo $color_4;
		}

		echo "><font color=";

		if ($toggle == 1) {
			echo $fcolor_1;
		} else {
			echo $fcolor_2;
		}

		echo " face=helvetica size=2>&nbsp;Date:&nbsp;</font>";
		echo "<font color=#ccccc face=helvetica size=1>";
		echo date ("H:i:s m/d/y",  $db->f("date_integer"));
		echo "</font></td><td align=right bgColor=";

		if ($toggle == 1) {
			echo $color_2;
		} else {
			echo $color_4;
		}

		echo "><input name=delete[$x] type=checkbox value=";
		echo $db->f("message_id");
		echo "></td></tr><tr><td class=clsNrmTxt colSpan=4><br>";

		echo nl2br(htmlentities($db->f("message")));

		echo "</td></tr></table></td></tr></table><br>";

		$x = $x + 1;
		if ( $toggle == 1 ) {
			$toggle = 2;
		} else {
			$toggle = 1;
		}
	}	
}
echo "<input type=hidden name=total_messages value=" . $x . ">";
?>

</form>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>