<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/sector.php");
include("./lib/ship.php");
include("./lib/weapons.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$s1 = new ME_Sector;
$s1->get_sector($player_id);
$sector_id = $s1->f("sector_id");
?>

<html><head><title>Merchant Empires: Weapons Dealer</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
  <tr>
    <td bgColor=#993300>
      <table border=0 cellPadding=5 cellSpacing=1 width=500>
        <tr>
          <td width=500 bgColor=#000000 align=left valign=middle>
            <table border=0>
              <tr>
                <td align=left colspan=6>
                  <font color=#3333FF face=arial,helvetica,swiss size=5><?php
$db = new ME_DB;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Weapons'");
$db->next_record();
echo $db->f("name");
?>
                </font>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br><?php

$options = $db->f("options");  
$dealer_weapons = array();
$dealer_weapons = explode(",", $options);

$weapons = new ME_Weapons;
$weapons->get_weapons($ship->f("ship_id"));
?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
  <tr>
    <td bgColor=#003399>
      <table border=0 cellpadding=2 cellspacing=1 width=500>
        <tr>
          <td colspan=6 align=center class=clsHedTxt id=blu1>
          Buy Weapons
          </td>
        </tr>
        <tr>
          <td width=110 align=center class=clsHedTxt id=blu1>
          Item
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Cost
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Shield Damage
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Armor Damage
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Accuracy
          </td>
          <td width=110 align=center class=clsHedTxt id=blu1>
          Action
          </td>
        </tr><?php

while (list($key, $val) = each($dealer_weapons)) {
  $db = new ME_DB;
  $db->query("select weapon_id, name, cost, shield_damage, armor_damage, accuracy from weapons where weapon_id = '$val'");
  $db->next_record();

  echo "<tr>";
  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("name");
  echo "</td>";
  
  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("cost");
  echo "</td>";
  
  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("shield_damage");
  echo "</td>";

  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("armor_damage");
  echo "</td>";

  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("accuracy");
  echo "</td>";

	echo "<form action=";
	echo $sess->url(URL . "weapons_dealer_update.php");
	echo " method=post>";

  echo "<td align=center class=clsNrmTxt>";
  echo "<input type=submit name=purchase_weapon_" . $db->f("weapon_id") . " value=Buy>";
	echo "<input type=submit name=store_weapon value=Store>";
	echo "<input type=hidden name=id value=" . $db->f("weapon_id") . ">";
  echo "</td></form>";

  echo "</tr>";
}
?>
      </table>
    <td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
  <tr>
    <td bgColor=#003399>
      <table border=0 cellpadding=2 cellspacing=1 width=500>
        <tr>
          <td colspan=6 align=center class=clsHedTxt id=blu1>
          Sell Weapons
          </td>
        </tr>
        <tr>
          <td width=110 align=center class=clsHedTxt id=blu1>
          Item
          </td>
          <td width=70 align=center class=clsHedTxt id=blu1>
          Offer
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Shield Damage
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Armor Damage
          </td>
          <td width=60 align=center class=clsHedTxt id=blu1>
          Accuracy
          </td>
          <td width=120 align=center class=clsHedTxt id=blu1>
          Action
          </td>
        </tr><?php

while (list($key, $val) = each($weapons->Current_weapons)) {
  $db = new ME_DB;
  $db->query("select weapon_id, name, cost, shield_damage, armor_damage, accuracy from weapons where weapon_id = '$val'");
  $db->next_record();

  echo "<tr>";
  echo "<form action=";
  echo $sess->url(URL . "weapons_dealer_update.php");
  echo " method=post>";

  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("name");
  echo "</td>";
  
  echo "<td align=center class=clsNrmTxt>";
  echo (int) ($db->f("cost") / 3);
  echo "</td>";

  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("shield_damage");
  echo "</td>";

  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("armor_damage");
  echo "</td>";

  echo "<td align=center class=clsNrmTxt>";
  echo $db->f("accuracy");
  echo "</td>";

  echo "<td align=center class=clsNrmTxt>";
  echo "<input type=submit name=sell_weapon_" . $db->f("weapon_id") . "  value=Sell>";	
  echo "<input type=hidden name=id value=" . $key . ">";
  echo "</center></font></td>";

  echo "</form></tr>";
}
?>
        <tr>
          <td colspan=6 bgColor=#000000>
            <br><center><a href=<?php

echo $sess->url(URL . "local_map.php");
echo ">Leave Weapons Dealer</a></center><br>";
?>

          </td>
        </tr>
      </table>
    <td>
  </tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");		
		
	if ($error == 1) {
		$db->add_parameter("message", "Command not processed due to insufficient credits.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient hardpoints.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "Command not processed due to cheat attempt.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "No weapons shop in the current sector offers that weapon.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "The current sector does not contain a weapons shop.");
	} elseif ($error == 6) {
		$db->add_parameter("message", "Your merchant is not of sufficient good alignment to purchase that weapon.");
	} elseif ($error == 7) {
		$db->add_parameter("message", "Your merchant is not of sufficient evil alignment to purchase that weapon.");
	} elseif ($error == 8) {
		$db->add_parameter("message", "Command not processed due to insufficient cargo capacity.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>