
def delete_star_gates():
	import time
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb, postmerchhost, user=postmerchuser, passwd=postmerchpass)
	qrystr = "update planets set star_gate = 'f', star_gate_sector_id = 0, star_gate_public_sector_id = 0 where star_gate_build_time < '%d' and star_gate_build_time <> 0" % (time.time() - 100800)
	q = pgcnx.query(qrystr) 
