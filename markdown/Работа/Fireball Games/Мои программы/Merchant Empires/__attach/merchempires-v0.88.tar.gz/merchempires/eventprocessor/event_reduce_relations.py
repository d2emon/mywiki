
def reduce_relations():
	import whrandom
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb, postmerchhost, user=postmerchuser, passwd=postmerchpass)
	qrystr = "SELECT player_id, relationrace_1, relationrace_2, relationrace_3, relationrace_4, relationrace_5, relationrace_6,	\
		relationrace_7 from players where relationrace_1 > 425 or relationrace_2 > 425 or relationrace_3 > 425 or relationrace_4 > 425 or	\
		relationrace_5 > 425 or relationrace_6 > 425 or relationrace_7 > 425"
	q = pgcnx.query(qrystr)
	res = q.getresult()

	for value in range(len(res)):
		relationrace_1 = res[value][q.fieldnum('relationrace_1')]
		relationrace_2 = res[value][q.fieldnum('relationrace_2')]
		relationrace_3 = res[value][q.fieldnum('relationrace_3')]
		relationrace_4 = res[value][q.fieldnum('relationrace_4')]
		relationrace_5 = res[value][q.fieldnum('relationrace_5')]
		relationrace_6 = res[value][q.fieldnum('relationrace_6')]
		relationrace_7 = res[value][q.fieldnum('relationrace_7')]
		player_id = res[value][q.fieldnum('player_id')]

		num = whrandom.randint(1,2)

		if relationrace_1 > 425 and num == 1:
			relationrace_1 = relationrace_1 - 2
			qrystr = "update players set relationrace_1 = '%d' where player_id = '%d'" % (relationrace_1, player_id)
			pgcnx.query(qrystr)

		if relationrace_2 > 425 and num == 1:
			relationrace_2 = relationrace_2 - 2
			qrystr = "update players set relationrace_2 = '%d' where player_id = '%d'" % (relationrace_2, player_id)
			pgcnx.query(qrystr)

		if relationrace_3 > 425 and num == 1:
			relationrace_3 = relationrace_3 - 2
			qrystr = "update players set relationrace_3 = '%d' where player_id = '%d'" % (relationrace_3, player_id)
			pgcnx.query(qrystr)

		if relationrace_4 > 425 and num == 1:
			relationrace_4 = relationrace_4 - 2
			qrystr = "update players set relationrace_4 = '%d' where player_id = '%d'" % (relationrace_4, player_id)
			pgcnx.query(qrystr)

		if relationrace_5 > 425 and num == 1:
			relationrace_5 = relationrace_5 - 2
			qrystr = "update players set relationrace_5 = '%d' where player_id = '%d'" % (relationrace_5, player_id)
			pgcnx.query(qrystr)

		if relationrace_6 > 425 and num == 1:
			relationrace_6 = relationrace_6 - 2
			qrystr = "update players set relationrace_6 = '%d' where player_id = '%d'" % (relationrace_6, player_id)
			pgcnx.query(qrystr)

		if relationrace_7 > 425 and num == 1:
			relationrace_7 = relationrace_7 - 2
			qrystr = "update players set relationrace_7 = '%d' where player_id = '%d'" % (relationrace_7, player_id)
			pgcnx.query(qrystr) 
