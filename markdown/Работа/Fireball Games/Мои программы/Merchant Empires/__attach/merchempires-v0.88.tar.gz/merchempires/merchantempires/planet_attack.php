<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Planet Attack</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
	
$db_p = new ME_DB_Xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();
	
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {
	$db_p->add_parameter("current_screen", "planet_attack");	
	echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());

if ( isset($missile_hit) ) {
	echo "<table border=0 cellPadding=0 cellSpacing=0 width=490><tr><td bgColor=#993300>";
	echo "<table border=0 cellPadding=5 cellSpacing=1 width=500><tr><td class=clsHedTxt id=red1>";
	echo "Disruptor Missile Results</td></tr><tr><td class=clsNrmTxt>";

	if ( $missile_hit ) {
		echo "<br>Target planet was hit.<br>";
	} else {
		echo "<br>Target planet was missed.<br>";
	}

	echo "<br><br></td></tr></table></td></tr></table><br>";
}

if ( $trifocus_id > 0 and !($error) ) {
	$trifocus_id = (int) $trifocus_id;

	$db = new ME_DB;
	$db->query("select * from trifocus_attacks where trifocus_attack_id = '$trifocus_id'");
	$db->next_record();

	if ( $db->nf() > 0 and $db->f("player_id") == $player->f("player_id") ) {
		echo "<table border=0 cellPadding=0 cellSpacing=0 width=490><tr><td bgColor=#993300>";
		echo "<table border=0 cellPadding=5 cellSpacing=1 width=500><tr><td class=clsHedTxt id=red1>";
		echo "Tri-Focus Plasma Results</td></tr><tr><td class=clsNrmTxt>";

		if ( $db->f("merchant_hit") == 't' ) {
			echo "<br>Target merchant was hit.<br>";
		} else {
			echo "<br>Target merchant was missed.<br>";
		}

		if ( $db->f("merchant_killed") == 't' ) {
			echo "Target merchant was killed.<br>";
		}

		echo "<br><br></td></tr></table></td></tr></table><br>";

		$db_d = new ME_DB_Tran;
		$db_d->begin_transaction();
		$db_d->query("delete from trifocus_attacks where trifocus_attack_id = '$trifocus_id'");
		$db_d->end_transaction();	
	}
}
?>

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
		<td bgColor=#003399>
			<table cols=5 border=0 cellpadding=5 cellspacing=1 width=490>
				<tr>
					<td bgColor=#000000><?php

	if ( $db_p->f("trifocus_plasma") == 't' ) {
		echo "<form name=form_trifocus action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<table cellspacing=2>";
		echo "<tr><td>";
		echo "<font color=#3333FF face=arial,helvetica,swiss size=3>";
		echo "Tri-Focus Plasma";
		echo "</font><br></td></tr><tr><td class=clsNrmTxt>";
		echo "&nbsp;Input target merchant:<br>";
		echo "</td></tr><tr><td>";
		echo "&nbsp;<input type=textbox name=trifocus_target size=14><br>";
		echo "</td></tr><tr><td class=clsNrmTxt>";
		echo "&nbsp;Input target sector:<br>";
		echo "</td></tr><tr><td>";
		echo "&nbsp;<input type=textbox name=trifocus_sector size=14><br>";
		echo "</td></tr><tr><td class=clsNrmTxt>";		

		if ( $db_p->f("trifocus_fire_time") > time() - 60 ) {
			echo "&nbsp;That weapon will be prepared to fire in " . (string) ($db_p->f("trifocus_fire_time") + 60 - time()) . " seconds.";
		} else {
			echo "&nbsp;<a href='javascript:document.form_trifocus.submit()'><img border=0  src='./images/form/fire-off.png'></a><br>";
			echo "<input type=hidden name=trifocus_fire value=Fire>";
		}		

		echo "</td></tr></table></form>";
	}

	if ( $db_p->f("disruptor_missile_current") > 0 ) {
		echo "<form name=form_disruptor_missile action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<table cellspacing=2>";
		echo "<tr><td>";
		echo "<font color=#3333FF face=arial,helvetica,swiss size=3>";
		echo "Disruptor Missile";
		echo "</font><br></td></tr><tr><td class=clsNrmTxt>";
		echo "&nbsp;Stockpile: " . $db_p->f("disruptor_missile_current") . " missile(s)<br>";		
		echo "&nbsp;Input target sector:<br>";
		echo "</td></tr><tr><td>";
		echo "&nbsp;<input type=textbox name=disruptor_missile_sector size=14><br>";
		echo "</td></tr><tr><td class=clsNrmTxt>";

		echo "<a href='javascript:document.form_disruptor_missile.submit()'><img border=0  src='./images/form/fire-off.png'></a><br>";
		echo "<input type=hidden name=fire_disruptor_missile value=Fire>";
		echo "</td></tr></table></form>";		

	}
?>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table>
<?php

} else {
	$error = 8;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Your ship has no cloaking device.");		
	} elseif ($error == 3) {
		$db->add_parameter("message", "Attack and defense values must be greater than 0.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "Command not processed due to insufficient turns.");			
	} elseif ($error == 10) {
		$db->add_parameter("message", "Your planet does not have that technology installed.");			
	} elseif ($error == 11) {
		$db->add_parameter("message", "A merchant with that name or ID does not exist.");			
	} elseif ($error == 12) {
		$db->add_parameter("message", "Target merchant cannot be found in the current sector.");			
	} elseif ($error == 13) {
		$db->add_parameter("message", "Command not processed due to invalid value.");			
	} elseif ($error == 14) {
		$db->add_parameter("message", "That technology cannot be used while your ship is cloaked.");			
	} elseif ($error == 15) {
		$db->add_parameter("message", "Error occurred while performing a deep sector scan.");			
	} elseif ($error == 17) {
		$db->add_parameter("message", "There will be a short delay before that weapon is prepared to fire.");			
	} elseif ($error == 18) {
		$db->add_parameter("message", "The target merchant cannot be found in that sector.");			
	} elseif ($error == 19) {
		$db->add_parameter("message", "The target merchant is out of weapon range.");			
	} elseif ($error == 20) {
		$db->add_parameter("message", "The target merchant is currently under Protection.");			
	} elseif ($error == 21) {
		$db->add_parameter("message", "Target planet out of range.");			
	} elseif ($error == 22) {
		$db->add_parameter("message", "No planet found in target sector.");			
	} elseif ($error == 23) {
		$db->add_parameter("message", "Command not processed due to insufficient supply of disruptor missiles.");			
	} elseif ($error == 24) {
		$db->add_parameter("message", "That weapon cannot be used while your merchant is under newbie protection.");			
	} elseif ($error == 25) {
		$db->add_parameter("message", "Access to that functionality not allowed by planet owner.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
