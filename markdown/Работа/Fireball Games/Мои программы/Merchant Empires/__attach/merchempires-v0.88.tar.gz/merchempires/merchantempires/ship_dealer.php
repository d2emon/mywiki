<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/sector.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$s1 = new ME_Sector;
$s1->get_sector($player_id);
$sector_id = $s1->f("sector_id");
?>

<html><head><title>Merchant Empires: Ship Dealer</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5><?php
$db = new ME_DB;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Shipdealer'");
$db->next_record();

if ( $db->nf() == 0 ) {
	echo "The current sector does not contain a ship dealer.";
} else {
	echo $db->f("name");
}
?>
								</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$options = $db->f("options");	
$ships = array();
$ships = explode(",", $options);

?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Name</center>
	        </font>
					</td>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Cost</center>
	        </font>
					</td>
					<td bgColor=#000033>
					<font color=#ffffff  face=arial,helvetica,swiss size=3>
					<center>Action</center>
	        </font>
					</td>
				</tr><?php

while (list($key, $val) = each($ships)) {
	$val = (int) $val;
	$db = new ME_DB;
	$db->query("select ship_type_id, name, cost from ship_types where ship_type_id = '$val'");
	$db->next_record();

	echo "<tr>";
	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3><center>";
	echo $db->f("name");
	echo "</center></font></td>";
	
	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3><center>";
	echo $db->f("cost");
	echo "</center></font></td>";

	echo "<td bgColor=#000000><font color=#cccccc  face=arial,helvetica,swiss size=3><center>";
	echo "<a href=";
	echo $sess->url(URL . "ship_dealer_examine.php?id=");
	echo $val . ">Examine</a>";
	echo "</center></font></td>";

	echo "</tr>";
}
?>
				<tr>
					<td colspan=3 bgColor=#000000>
          	<br><center><a href=<?php

echo $sess->url(URL . "local_map.php");
echo ">Leave Ship Dealer</a></center><br>";
?>

					</td>
				</tr>
			</table>
		<td>
  </tr>
</table><br><?php

if ( $dt > 0 ) {
?>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#cccccc face=arial,helvetica,swiss size=3><?php

echo "Your ship is scheduled to be delivered at " . date ("H:i:s", $dt) . ".";
?>
								</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
