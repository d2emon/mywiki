<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function display_error($subject, $message) {
	echo "<table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=#993300><table border=0 cellPadding=5 cellSpacing=1 width=500>";
	echo "<tr><td class=clsHedTxt id=red1>" . $subject . "<br></td></tr><tr><td class=clsNrmTxt width=500 valign=middle><br>";
	echo $message;
	echo "<br><br></td></tr></table></td></tr></table><br>";
}

function display_merchant($id, $sess, $display_protection, $imperial_protection, $newbie_protection) {
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td class=clsNrmTxt valign=top width=225>
									<font color=#3333FF face=arial,helvetica,swiss size=4><b>Merchant</font></b><br><?php

$db = new ME_DB;
$query = sprintf("SELECT player_id, rank, public_player_id, name, race, alliance_name from players where player_id = '%s'", $id);
$db->query($query);
$db->next_record();

echo "&nbsp;" . $db->f("rank") . "<br>";
echo "&nbsp;<a href=";
echo $sess->purl(URL . "merchant_search_results.php?action=merchant_id&criteria=" . $db->f("public_player_id")) . ">";
echo $db->f("name") . "</a>";
echo " (" . $db->f("public_player_id") . ")";

$db_a = new ME_DB;
$query = sprintf("SELECT * from active_sessions where player_id = '%s'", $db->f("player_id"));
$db_a->query($query);

if ( $db_a->nf() > 0 ) {
	echo " (online)<br>";
} else {
	echo " (offline)<br>";
}

echo "&nbsp;Race: " . $db->f("race") . "<br>";
echo "&nbsp;Alliance: " . $db->f("alliance_name") . "<br>";

echo "<br><font color=#3333FF face=arial,helvetica,swiss size=4><b>Ship</font></b><br>";

$query = sprintf("SELECT ships.*, ship_weapons.*, ship_technology.*	from ships, ship_weapons, ship_technology where ships.player_id = '%s' and ship_weapons.player_id = ships.player_id and ship_technology.player_id = ships.player_id", $id);

$db->query($query);
$db->next_record();

if ( $db->f("illusion") and $db->f("illusion_active") == 't' ) {
	echo "&nbsp;" . $db->f("illusion_type") . " ";
	$offense = $db->f("illusion_attack");
	$defense = $db->f("illusion_defense");
	echo "<br>&nbsp;Attack rating: " . $offense;
	echo "<br>&nbsp;Defense rating: " . $defense;
} else {
	echo "&nbsp;" . $db->f("type") . " ";

	$combined_damage = get_combined_damage($db);

	if ( (int) (($combined_damage / 40) + ($db->f("combatcurrent") / 50)) < 1 ) {
		$offense = 1;
	} else {
		$offense = (int) (($combined_damage / 40) + ($db->f("combatcurrent") / 50));
	}

	if ( (int) (($db->f("shieldcurrent") + $db->f("armorcurrent") + ($db->f("combatcurrent") * 3)) / 100)  < 1 ) {
		$defense = 1;
	} else {
		$defense = (int) (($db->f("shieldcurrent") + $db->f("armorcurrent") + ($db->f("combatcurrent") * 3)) / 100);
	}

	echo "<br>&nbsp;Attack rating: " . $offense;
	echo "<br>&nbsp;Defense rating: " . $defense;
}

if ( $display_protection ) {
	if ( $imperial_protection or $newbie_protection ) {
		echo "<br><br><font color=#3333FF face=arial,helvetica,swiss size=4>Protection</font></b><br>";

		if ( $newbie_protection ) {
			echo "&nbsp;<font  color=#cccccc face=arial,helvetica,swiss size=3>Newbie";	
		}

		if ( $imperial_protection ) {
			if ( $newbie_protection ) {	
				echo "<br>";
			}		
			echo "&nbsp;<font  color=#cccccc face=arial,helvetica,swiss size=3>Imperial</font>";	
		}
	}
}
?>									
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php
	
}

function display_planet($id) {
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td class=clsNrmTxt valign=top width=225>
									<font color=#3333FF face=arial,helvetica,swiss size=4><b>Planet</font></b><br><?php

$db = new ME_DB;
$query = sprintf("SELECT * from planets where planet_id = '%s'", $id);
$db->query($query);
$db->next_record();

echo "&nbsp;Planet: " . $db->f("name") . "<br>";

echo "&nbsp;Owned by: " . $db->f("owner_name") . "<br>";

if ( $db->f("alliance_name") <> "" ) {
	echo "&nbsp;Alliance: " . $db->f("alliance_name") . "<br><br>";
}

?>									
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php
}

function display_force_combat($id) {
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td class=clsNrmTxt valign=top width=225>
									<font color=#3333FF face=arial,helvetica,swiss size=4><b>Forces</font></b><br><?php

$db = new ME_DB;
$query = sprintf("SELECT * from forces where forces_id = '%s'", $id);
$db->query($query);
$db->next_record();

echo "&nbsp;Owned by: " . $db->f("player_name") . "<br>";

echo "&nbsp;Alliance: " . $db->f("alliance_name") . "<br><br>";

if ( $db->f("combat") <> 0 ) {
	echo "&nbsp;Combat Drones: " . $db->f("combat") . "<br>";
}

?>									
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php
}

function display_force($id) {
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td class=clsNrmTxt valign=top width=225>
									<font color=#3333FF face=arial,helvetica,swiss size=4><b>Forces</font></b><br><?php

$db = new ME_DB;
$query = sprintf("SELECT * from forces where forces_id = '%s'", $id);
$db->query($query);
$db->next_record();

echo "&nbsp;Owned by: " . $db->f("player_name") . "<br>";

echo "&nbsp;Alliance: " . $db->f("alliance_name") . "<br><br>";

if ( $db->f("mine") <> 0 ) {
	echo "&nbsp;Mines: " . $db->f("mine") . "<br>";
}

if ( $db->f("combat") <> 0 ) {
	echo "&nbsp;Combat Drones: " . $db->f("combat") . "<br>";
}

if ( $db->f("scout") <> 0 ) {
	echo "&nbsp;Scout Drones: " . $db->f("scout") . "<br>";
}
?>									
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php
}
?>

<html><head><title>Merchant Empires: Attack Results</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5>ATTACK MERCHANT</font>
								</td>
							</tr>							
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$id = (int) $id;

#retrieve the attack record
$db = new ME_DB;
$db->query("SELECT * from attacks where attack_id = '$id'");
$db->next_record();

if ( $db->nf() > 0 ) {
	$attackers = array();
	$defenders = array();

	$attackers_protected = 0;
	$defenders_protected = 0;

	$attacker_types = array();
	$attacker_types = explode(",", $db->f("attacker_types"));
  $attacker_ids = array();
	$attacker_ids = explode(",", $db->f("attacker_ids"));
	$attacker_imperial_protections = array();
	$attacker_imperial_protections = explode(",", $db->f("attacker_imperial_protections"));
	$attacker_newbie_protections = array();
	$attacker_newbie_protections = explode(",", $db->f("attacker_newbie_protections"));

	$defender_types = array();
	$defender_types = explode(",", $db->f("defender_types"));
  $defender_ids = array();
	$defender_ids = explode(",", $db->f("defender_ids"));
	$defender_imperial_protections = array();
	$defender_imperial_protections = explode(",", $db->f("defender_imperial_protections"));
	$defender_newbie_protections = array();
	$defender_newbie_protections = explode(",", $db->f("defender_newbie_protections"));

	# if a ship is involved in combat, then forces are displayed differently
	# with only the combat drones appearing
	$attacker_ship_involved_in_combat = 0;
	$defender_ship_involved_in_combat = 0;

	for ($i = 0; $i <= count($attacker_ids) - 1; $i++) {
		$attackers[$i][0] = $attacker_types[$i];

		if ( $attacker_types[$i] == 's' ) {
			$attacker_ship_involved_in_combat = 1;
		}

		$attackers[$i][1] = $attacker_ids[$i];
		$attackers[$i][2] = $attacker_imperial_protections[$i];
		$attackers[$i][3] = $attacker_newbie_protections[$i];
	}
	
	for ($i = 0; $i <= count($defender_ids) - 1; $i++) {
		$defenders[$i][0] = $defender_types[$i];

		if ( $defender_types[$i] == 's' ) {
			$defender_ship_involved_in_combat = 1;
		}

		$defenders[$i][1] = $defender_ids[$i];
		$defenders[$i][2] = $defender_imperial_protections[$i];
		$defenders[$i][3] = $defender_newbie_protections[$i];
	}

	#delete the attack record
	$db_d = new ME_DB_Tran;
	$db_d->begin_transaction();
	$db_d->query("delete from attacks where attack_id = '$id'");
	$db_d->end_transaction();

	$attacker_type = $attackers[0][0];
	$attacker_id = $attackers[0][1];
	$attacker_imperial_protection = $attackers[0][2];
	$attacker_newbie_protection = $attackers[0][3];
	$defender_type = $defenders[0][0];
	$defender_id = $defenders[0][1];
	$defender_imperial_protection = $defenders[0][2];
	$defender_newbie_protection = $defenders[0][3];

	if ( $defender_type == 's' ) {
		$db->query("SELECT * from ships where player_id = '$defender_id'");
		$db->next_record();

		if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
			$error = 1;
		}
	}

	if ( $defender_type == 'f' ) {
		$db->query("SELECT * from forces where forces_id = '$defender_id'");
		$db->next_record();

		if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
			$error = 1;
		}
	}

	if ( $error <> 1 ) {
?>
<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td valign=top>
			<center><font color=#3333FF face=arial,helvetica,swiss size=4>Attacker(s)</font></center><br><?php

		for ($i = 0; $i <= count($attacker_ids) - 1; $i++) {
			$attacker_type = $attackers[$i][0];
			$attacker_id = $attackers[$i][1];

			if ( $attacker_type == 's' ) {
				display_merchant($attackers[$i][1], $sess, 1, $attackers[$i][2], $attackers[$i][3]);
				echo "<br>";
			} elseif ( $attacker_type == 'f' and $attacker_ship_involved_in_combat ) {
				display_force_combat($attacker_id, $sess);
			} elseif ( $attacker_type == 'f' ) {
				display_force($attacker_id, $sess);
			}
		
			if ( $attackers[$i][2] == 1 or $attackers[$i][3] == 1 ) {
				$attackers_protected = $attackers_protected + 1;
			}
		}
?>
		</td><td valign=top>

		<center><font color=#3333FF face=arial,helvetica,swiss size=4>Defender(s)</font></center><br><?php

		for ($i = 0; $i <= count($defender_ids) - 1; $i++) {			
			$defender_type = $defenders[$i][0];
			$defender_id = $defenders[$i][1];

			if ( $defender_type == 's' ) {
				display_merchant($defenders[$i][1], $sess, 1, $defenders[$i][2], $defenders[$i][3]);
				echo "<br>";
			} elseif ( $defender_type == 'p' ) {
				display_planet($defender_id);
			} elseif ( $defender_type == 'f' and $defender_ship_involved_in_combat or $attacker_ship_involved_in_combat ) {
				display_force_combat($defender_id, $sess);
			} elseif ( $defender_type == 'f' ) {
				display_force($defender_id, $sess);
			}

			if ( $defenders[$i][2] == 1 or $defenders[$i][3] == 1 ) {
				$defenders_protected = $defenders_protected + 1;
			}
		}
?>											
		</td>
	</tr>
</table><br>
<table border=0 cellPadding=0 cellSpacing=0 width=500
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width="100%">
				<tr><?php

		if ( $attackers_protected == count($attacker_ids) or $defenders_protected == count($defender_ids) or $player->f("newturnsleft") > 0 ) {
			echo "<form name=form_abort action=";
			echo $sess->url(URL . "current_sector.php");
			echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

			echo "<td class=clsNrmTxt align=center>";

			echo "<input type=hidden name=abort value=Abort>";
			echo "<a href='javascript:document.form_abort.submit()'><img border=0 height=20 width=100 src='./images/form/abort-off.png'></a><br>";
		} else {
	    echo "<form name=form_attack action=";
			echo $sess->url(URL . "attack.php");
			echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";
			echo "<td class=clsNrmTxt align=center>";
			echo "<input type=hidden name=attack value=Attack>";
			echo "<a href='javascript:document.form_attack.submit()'><img border=0 height=20 width=100 src='./images/form/attack-off.png'></a><br>";

			echo "<input type=hidden name=type ";
			echo " value=" . $defenders[0][0] . ">";
?>
						<input type=hidden name=refer value=preattack>
						<input type=hidden name=id <?php

			echo " value=" . $defenders[0][1] . ">";
		}
?>						
							</td>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php
		
	} else {
		display_error("Warning", "The ship or forces that you intended to attack cannot be found in the current sector.  It is probable that he/she fled, cloaked, or was destroyed in a different engagement.");
	}
} else {
	display_error("Warning", "Attack not entered or continued properly.  To continue an attack you must select continue from the attack results screen.");	
}		
?>					

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
