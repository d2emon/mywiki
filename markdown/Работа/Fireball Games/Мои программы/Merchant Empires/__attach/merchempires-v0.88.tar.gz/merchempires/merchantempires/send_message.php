<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

## Get a database connection
$db = new ME_DB;

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "send_message":
			if (empty($toplayer) || empty($message) and $action <> "allmerchants") {
				$error = 1;
				#"Please fill out all of the fields.";
				break;
			}

			if (strlen($message) > 1000) {
				$error = 2;
				#"Message length is limited to 1000 characters.";
				$message = substr ($message, 0, 1200);
				$db = new ME_DB;
				$db->query("update player_config set long_message = '$message' where player_id = '$player_id'");

				break;
			}

			if (strpos ("." . strtolower($message), 'fuck') or strpos ("." . strtolower($message), 'cock'))  {		
				$error = 6;
				break;
			}

			# protect against hacking the game_id
			if ($game_id <> $player->f("game_id"))  {
      	$error = 3;
				#"You can't send messages to players in other games.";
				break;
			}

			$message = str_replace(';', ':', $message);			

			$fromplayername = addslashes($player->f("name"));
      $date = date("m/d/y H:i");
			$date_integer = time();

			if ( $action <> "merchant_id" and $action <> "allmerchants" and $action <> "alliance" and $action <> "council" ) {
				# find the to player's id				
				$db = new ME_DB;
				$db->query("select player_id, game_id, public_player_id, name from players where name = '$toplayer' and game_id = '$game_id'");
				$db->next_record();

				if ($db->nf() == 0)  {
					$error = 4;
					#"There is no merchant with that name.";
					break;
      	} else {
					$toplayer_id = $db->f("player_id");
							
					$query = "insert into messages (player_id, message, fromplayer_id, fromplayer, toplayer, date, date_integer)
						values ('$toplayer_id', '$message', '$public_player_id', '$fromplayername', '$toplayer', '$date', '$date_integer')";
					$db->query($query);

					$query = "select player_id, sent_message_id from sent_messages where player_id = '$player_id' order by sent_message_id";
					$db->query($query);
					$db->next_record();
					if ( $db->nf() > 10 ) {
          	$sent_message_id = $db->f("sent_message_id");

						$query = "delete from sent_messages where sent_message_id = '$sent_message_id'";
						$db->query($query);
					}

					$query = "insert into sent_messages (player_id, message, toplayer, date, date_integer)
						values ('$player_id', '$message', '$toplayer', '$date', '$date_integer')";
					$db->query($query);
					break;
				}
			} elseif ( $action == "merchant_id" ) {
				$toplayer = (int) $toplayer;

				# find the to player's name
				$db = new ME_DB;
				$db->query("select player_id, game_id, public_player_id, name from players where public_player_id = '$toplayer' and game_id = '$game_id'");
				$db->next_record();

				if ($db->nf() == 0)  {
					$error = 5;
					#"There is no merchant with that ID.";
					break;
      	} else {
					$toplayername = addslashes($db->f("name"));
          $toplayer_id = $db->f("player_id");
					$fromplayer_public_id = $player->f("public_player_id");
				
					$query = "insert into messages (player_id, message, fromplayer_id, fromplayer, toplayer, date, date_integer)
						values ('$toplayer_id', '$message', '$fromplayer_public_id', '$fromplayername', '$toplayername', '$date', '$date_integer')";
					$db->query($query);

					$query = "select player_id, sent_message_id from sent_messages where player_id = '$player_id' order by sent_message_id";
					$db->query($query);
					$db->next_record();
					if ( $db->nf() > 10 ) {
          	$sent_message_id = $db->f("sent_message_id");

						$query = "delete from sent_messages where sent_message_id = '$sent_message_id'";
						$db->query($query);
					}

					$query = "insert into sent_messages (player_id, message, toplayer, date, date_integer)
						values ('$player_id', '$message', '$toplayername', '$date', '$date_integer')";
					$db->query($query);

					break;
				}
			} elseif ( $action == "allmerchants" )  {		
				$db = new ME_DB;
				$db->query("select active_sessions.player_id, active_sessions.game_id, players.player_id, players.name,
					players.race, players.experience, players.alliance_name, players.public_player_id, players.ignore_global from active_sessions, players
					where active_sessions.player_id > 0 and active_sessions.game_id = '$game_id' and players.player_id = active_sessions.player_id");

				# this array holds unique player names; there could be multiple entries for 1 player				

				$db_4 = new ME_DB;
				while ($db->next_record()) {

					$active_player_id = $db->f("player_id");

  				if ( $active_player_id > 0 and $active_player_id <> $player->f("player_id") ) {	
						$str = $active_player_id;						
						
						if ( $db->nf() > 0 )  {
							if ( $db->f("ignore_global") == 'f' ) {
 	       				$toplayer = $db->f("public_player_id");
              	 	
								$str = $db->f("player_id");   						      	
								$toplayername = "All Online Merchants";
								$toplayer_id = $str;
								$fromplayer_public_id = $player->f("public_player_id");

								$query = "insert into messages (player_id, message, fromplayer_id, fromplayer, toplayer, date, date_integer)
									values ('$toplayer_id', '$message', '$fromplayer_public_id', '$fromplayername', '$toplayername', '$date', '$date_integer')";
								$db_4->query($query);
							}
						}
          }
				}
						
				$query = "select player_id, sent_message_id from sent_messages where player_id = '$player_id' order by sent_message_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 10 ) {
         	$sent_message_id = $db->f("sent_message_id");

					$query = "delete from sent_messages where sent_message_id = '$sent_message_id'";
					$db->query($query);
				}

				$query = "insert into sent_messages (player_id, message, toplayer, date, date_integer)
					values ('$player_id', '$message', '$toplayername', '$date', '$date_integer')";
				$db->query($query);
	
        break;
			} elseif ( $action == "alliance" )  {
					$alliance_id = (int) $alliance_id;

        	$db_2 = new ME_DB;
					$db_2->query("select player_id, game_id, public_player_id, name, alliance_id, alliance_name from players where alliance_id = '$alliance_id'");
					
					while ( $db_2->next_record() )  {
						$toplayer = $db_2->f("player_id");
			
						$toplayername = $db_2->f("alliance_name");
	         	$toplayer_id = $db_2->f("player_id");
						$fromplayer_public_id = $player->f("public_player_id");

						$db_4 = new ME_DB;
						$query = "insert into messages (player_id, message, fromplayer_id, fromplayer, toplayer, date, date_integer)
							values ('$toplayer_id', '$message', '$fromplayer_public_id', '$fromplayername', '$toplayername', '$date', '$date_integer')";
						$db_4->query($query);
					}
	
					$db = new ME_DB;
					$query = "select player_id, sent_message_id from sent_messages where player_id = '$player_id' order by sent_message_id";
					$db->query($query);
					$db->next_record();
					if ( $db->nf() > 10 ) {
          	$sent_message_id = $db->f("sent_message_id");

						$query = "delete from sent_messages where sent_message_id = '$sent_message_id'";
						$db->query($query);
					}

					$query = "insert into sent_messages (player_id, message, toplayer, date, date_integer)
						values ('$player_id', '$message', '$toplayername', '$date', '$date_integer')";
					$db->query($query);
			} elseif ( $action == "council" )  {
				$council_id = (int) $council_id;

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, name, experience, game_id, race, rank, alliance_id, alliance_name from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);				

				while ( $db->next_record() ) {
					$toplayer = $db->f("player_id");
			
					$toplayername = $race . " Council";
         	$toplayer_id = $db->f("player_id");
					$fromplayer_public_id = $player->f("public_player_id");

					$db_4 = new ME_DB;
					$query = "insert into messages (player_id, message, fromplayer_id, fromplayer, toplayer, date, date_integer)
						values ('$toplayer_id', '$message', '$fromplayer_public_id', '$fromplayername', '$toplayername', '$date', '$date_integer')";
					$db_4->query($query);						
				}
					
				$query = "select player_id, sent_message_id from sent_messages where player_id = '$player_id' order by sent_message_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 10 ) {
         	$sent_message_id = $db->f("sent_message_id");

					$query = "delete from sent_messages where sent_message_id = '$sent_message_id'";
					$db->query($query);
				}

				$query = "insert into sent_messages (player_id, message, toplayer, date, date_integer)
					values ('$player_id', '$message', '$toplayername', '$date', '$date_integer')";
				$db->query($query);
			}
	}
}

if ( $error ) {
	$newurl = $sess->url(URL . "send_messages.php?error=$error");
 	header("Location: $newurl");	
} else {
	$newurl = $sess->url(URL . "send_messages.php");
	header("Location: $newurl");	
}

page_close();
?>