<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "jettison":						
			$amount = (int) $amount;
		
			if ( $amount < 0 ) {
				$error = 2;
				break;
			}

			$returnto = "ship_cargo";
			
			if ( $ship->f("last_jettison_date") >= time() - 1000 and $ship->f("last_jettison_date") <> 0 ) {
				$error = 4;
				break;				
			} else {
				if ( $amount > 0 ) {
						$db = new ME_DB;
						$query = sprintf("update ships set last_jettison_date = '%s' where ship_id = '%s'", time(), $ship->f("ship_id"));
						$db->query($query);
				}
			}
  		
			if ( $player->f("turns") == 0 ) {
				$error = 3;
				break;
			}

			if ( $amount > 0 ) {
				if ( $amount > $cargo->Current_cargo[$good_type]['amount'] ) {
	      	$error = 1;
					break;
      	}
			
				$new_good = $cargo->Current_cargo[$good_type]['amount'] - $amount;
				$cargo->set_good($good_type, 1, $new_good);
				$cargo->save();
			}
			
			$new_experience = $player->f("experience") - $player->f("success_experience");
			$new_turns = $player->f("turns") - 2;

			if ( $new_turns > 0 ) {
				$player->set_turns($new_turns);				
			} else {
				$player->set_turns(0);				
			}
			
			if ( $new_experience > 0 ) {
				$player->set_experience($new_experience);
			} else {
  			$player->set_experience(0);
			}
			$player->save();

			break;
	}
}

if ( $error ) {
	if ($returnto == "ship_cargo")  {
		$newurl = $sess->url(URL . "ship_cargo.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "ship_cargo")  {
		$newurl = $sess->url(URL . "ship_cargo.php");
		header("Location: $newurl");	
	}
}

page_close();
?>