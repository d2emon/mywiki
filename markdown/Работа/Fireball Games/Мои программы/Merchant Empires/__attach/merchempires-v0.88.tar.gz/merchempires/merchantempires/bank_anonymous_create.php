<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$s1 = new ME_Sector;
$s1->get_sector($player_id);
$sector_id = $s1->f("sector_id");
?>

<html><head><title>Merchant Empires: Update Alliance</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$game_id = $player->f("game_id");
$alliance_id = $player->f("alliance_id");

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
$db->add_parameter("current_screen", "bank_anonymous");
echo $db->get_transform("./xslt/menu_top_bank.xslt", $db->get_xml());

$error = 0;

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "anonymous_create":
			if (empty($password) || empty($verify)) {
				$error = "Please fill out all of the fields.";
				break;
			}
	
			if (!strcmp($password,$verify) == 0) {
				$error = "Your password was not successfully verified.";
				break;
			}

			if ( stristr($password, ';') ) {
				$error = "Illegal character in alliance name.";
				break;			
			}

			if ( strlen($password) > 10 ) {
				$error = "The length of the password is limited to 10 characters";
				break;
			}

			$db = new ME_DB;
			$query = "insert into accounts (game_id, alliance_id, balance, password,
				public_account_id) values('$game_id', 0, 0, '$password', nextval('public_account_id_game_" . $game_id . "'))";
			$db->query($query);

			# get public player id
			$db = new ME_DB;
			$db->query("select * from public_account_id_game_" . $game_id);
			$db->next_record();
	  	$public_id = $db->f("last_value");

			$msg = "Please record your account number and password." . "<br><br>";
			$msg = $msg . "Account : " . $public_id . "<br>";
			$msg = $msg . "Password : " . $password . "<br>";
			break;
	}
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	$db->add_parameter("message", $error);
	echo $db->get_transform("./xslt/message_box.xslt", "");			
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Account Created");
	$db->add_parameter("message", $msg);
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
