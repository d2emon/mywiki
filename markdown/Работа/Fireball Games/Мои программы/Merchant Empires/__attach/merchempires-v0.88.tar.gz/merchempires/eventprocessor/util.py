
""" This file is part of Merchant Empires
    Copyright (C) 2000 Bryan Brunton (bryan@dunsinane.net)

    This is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this library; see the file COPYING If not, write to
    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
    Boston, MA 02111-1307, USA.
"""

import string
import signal, os, time
from pg import DB
from Defines import *

if __name__ == '__main__':

	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)
	qrystr = "SELECT player_id, game_id, race_number from players"
	q = pgcnx.query(qrystr)
	res = q.getresult()
	
	# loop through all the players
	for value in range(len(res)):
		game_id = res[value][q.fieldnum('game_id')]
		race_id = res[value][q.fieldnum('race_number')]
		player_id = res[value][q.fieldnum('player_id')]
				
		qrystr = "update council_votes set game_id = %d, race_id = %d where player_id = %d" % (game_id, race_id, player_id)
		pgcnx.query(qrystr)
			
		
