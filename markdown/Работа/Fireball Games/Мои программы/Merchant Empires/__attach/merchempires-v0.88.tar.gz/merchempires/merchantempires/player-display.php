<?php

$db = new ME_DB;
$db->query("select player_id, read, battle, scout, planetary from messages where player_id = '$player_id' and read = 'f'");

$battle_exists = 0;
$scout_exists = 0;
$planetary_exists = 0;
$message_exists = 0;

while ( $db->next_record() ) {
	if ( $db->f("battle") == 't' ) {
		$battle_exists = 1;
	} elseif ( $db->f("scout") == 't' ) {
		$scout_exists = 1;
	} elseif ( $db->f("planetary") == 't' ) {
		$planetary_exists = 1;
	} elseif ( $db->f("battle") == 'f' and $db->f("scout") == 'f' and $db->f("planetary") == 'f' ) {
		$message_exists = 1;
	}
}

if ( $db->nf() > 0 ) {
	echo "<table border=0 cellPadding=0 cellSpacing=0 width=145 valign=top><tr><td vAlign=top width=100%>";
	echo "<table border=0 cellPadding=0 cellSpacing=0 width=100%><tr><td bgColor=#993300>";
	echo "<table border=0 cellPadding=3 cellSpacing=1 width=100%><tr><td class=clsHedTxt id=redsml1>";

	if ( $battle_exists ) {
		echo "<a href=";
		echo $sess->url(URL . "view_messages_battle.php");
		echo ">Battle Report</a><br>";
	}

	if ( $player->f("ignore_scout") == 'f' ) {
		if ( $scout_exists ) {
			echo "<a href=";
			echo $sess->url(URL . "view_messages_scout.php");
			echo ">Forces Report</a><br>";
		}
	}

	if ( $player->f("ignore_planetary") == 'f' ) {
		if ( $planetary_exists ) {
			echo "<a href=";
			echo $sess->url(URL . "view_messages_planet.php");
			echo ">Planetary Report</a><br>";
		}
	}

	if ( $message_exists ) {
  	echo "<a href=";
		echo $sess->url(URL . "view_messages.php");
		echo ">Incoming Messages</a>";
	}	

	echo "</td></tr></table></td></tr></table><br></td></tr></table>";
}

echo "<table border=0 cellPadding=0 cellSpacing=0 width=145 valign=top><tr>";
echo "<td vAlign=top width=100%><table border=0 cellPadding=0 cellSpacing=0 width=100%>";
echo "<tr><td bgColor=#003399><table border=0 cellPadding=5 cellSpacing=1 width=100%>";
echo "<tr><td class=clsHedTxt id=blu1><span class=clsNrmTxt>";

echo $player->f("rank");
echo "</span><br><a href=";
echo $sess->url(URL . "merchant_search_results.php"). "?action=merchant_id&criteria=" . $player->f("public_player_id") . ">";
echo $player->f("name");

echo "</a><br><span class=clsNrmTxt>";
echo "(" . $player->f("public_player_id") . ")";
echo "</span><br></td></tr><tr><td class=clsNrmTxtWht><span class=clsNrmTxt>Race: </span>";
echo $player->f("race");
echo "<br><span class=clsNrmTxt>Turns: </span>";
echo $player->f("turns");
echo "<br><span class=clsNrmTxt>Credits: </span>";
echo $player->f("credits");
echo "<br><span class=clsNrmTxt>Experience: </span>";
echo $player->f("experience");
echo "<br><span class=clsNrmTxt>Alignment: </span>";
echo $player->f("alignment");
echo "<br><span class=clsNrmTxt>";
echo "Alliance: </span>" . $player->f("alliance_name") . "<br>";

if ($player->f("newturnsleft") > 0) {
	echo "<br><span class=clsNrmTxt>";
	echo "Newbie Turns: </span>" . $player->f("newturnsleft");	
}

echo "<br></td></tr></table></td></tr></table></td></tr></table><br>";
