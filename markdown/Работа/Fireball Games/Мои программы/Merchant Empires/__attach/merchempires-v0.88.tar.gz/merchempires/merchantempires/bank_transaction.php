<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$s1 = new ME_Sector;
$s1->get_sector($player_id);
$sector_id = $s1->f("sector_id");
?>

<html><head><title>Merchant Empires: Bank Transaction</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table border=0 width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
$db->add_parameter("current_screen", "");
echo $db->get_transform("./xslt/menu_top_bank.xslt", $db->get_xml());

$game_id = $player->f("game_id");
$alliance_id = $player->f("alliance_id");
$error = 0;

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {
	
	switch ($key) {
		case "deposit_personal":
			$amount = (int) $amount;

			if (empty($amount)) {
				$error = "Please fill out all of the fields.";
				break;
			}						

			if ( $player->f("newturnsleft") > 100 ) {
				$error = "Bank access is not allowed if you have more than 100 newbie turns.";
				break;
			}
			
			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = "Your ship is not in a sector that contains a bank.";
				break;
			}

			if ( $amount < 0 )  {
      	$error = "Please only use positive amounts.";
				break;
			}

			$db_t = new ME_DB_Tran;
			$db_t->begin_transaction();

			$query = "select player_id, credits, bank_account from players where player_id = '$player_id' for update";
			$db_t->query($query);
			$db_t->next_record();

			if ( $amount > $db_t->f("credits") )  {
      	$error = "You do not have that many credits available to deposit.";
				$db_t->end_transaction();
				break;
			} else {
				$new_balance = $db_t->f("bank_account") + $amount;
        $current_credits = $db_t->f("credits") - $amount;
				
				$query = "update players set bank_account = '$new_balance', credits = '$current_credits' where player_id = '$player_id'";
				$db_t->query($query);
				$db_t->end_transaction();

				$msg = "Your deposit has been completed.<br>Account balance: " . $new_balance . "<br><br>Thank you for your business.";
				break;
      }

			break;

    case "withdraw_personal":
			$amount = (int) $amount;

			if (empty($amount)) {
				$error = "Please fill out all of the fields.";
				break;
			}						

			if ( $player->f("newturnsleft") > 100 ) {
				$error = "Bank access is not allowed if you have more than 100 newbie turns.";
				break;
			}

			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = "Your ship is not in a sector that contains a bank.";
				break;
			}

			if ( $amount < 0 )  {
      	$error = "Please only use positive amounts.";
				break;
			}

			$db_t = new ME_DB_Tran;
			$db_t->begin_transaction();

			$query = "select player_id, credits, bank_account from players where player_id = '$player_id' for update";
			$db_t->query($query);
			$db_t->next_record();

			if ( $amount > $db_t->f("bank_account") )  {
      	$error = "You do not have that many credits available to withdraw.";
				$db_t->end_transaction();
				break;
			} else {
				$new_balance = $db_t->f("bank_account") - $amount;
        $current_credits = $db_t->f("credits") + $amount;
				
				$query = "update players set bank_account = '$new_balance', credits = '$current_credits' where player_id = '$player_id'";
				$db_t->query($query);
				$db_t->end_transaction();

				$msg = "Your withdraw has been completed.<br>Account balance: " . $new_balance . "<br><br>Thank you for your business.";
				break;
      }
			
			break;

		case "deposit_anonymous":
			$amount = (int) $amount;
			$account_id = (int) $account_id;			

			if (empty($amount)) {
				$error = "Please fill out all of the fields.";
				break;
			}			

			if ( $player->f("newturnsleft") > 100 ) {
				$error = "Bank access is not allowed if you have more than 100 newbie turns.";
				break;
			}

			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = "Your ship is not in a sector that contains a bank.";
				break;
			}

			if ( $amount < 0 )  {
      	$error = "Please only use positive amounts.";
				break;
			}

			$db_t = new ME_DB_Tran;
			$db_t->begin_transaction();

			$query = "select player_id, credits, bank_account from players where player_id = '$player_id' for update";
			$db_t->query($query);
			$db_t->next_record();

			if ( $amount > $db_t->f("credits") )  {
      	$error = "You do not have that many credits available to deposit.";
				$db_t->end_transaction();
				break;
			} else {				
				$current_credits = $db_t->f("credits") - $amount;

				$query = "select * from accounts where public_account_id = '$account_id' and game_id = '$game_id' for update";
				$db_t->query($query);
        $db_t->next_record();				

				if ( $db_t->nf() > 0 ) {
					if ( $password <> $db_t->f("password") ) {					
    		 		$error = "Incorrect password.";
						$db_t->end_transaction();
						break;
					}

					$new_balance = $db_t->f("balance") + $amount;      	

					$transactions = array();
					$transactions = explode(",", $db_t->f("transactions"));

					if ( count($transactions) >= 10 ) {	
						array_splice($transactions, 0, 1);		
						$transactions[10] = "Deposit of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));
					} else {
						$transactions = array();
						$transactions = explode(",", $db_t->f("transactions"));
						$transactions[count($transactions) + 1] = "Deposit of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));		
					}
					
					$query = "update accounts set balance = '$new_balance', transactions = '$str_transactions' where public_account_id = '$account_id' and game_id = '$game_id'";
					$db_t->query($query);
					
					$query = "update players set credits = '$current_credits' where player_id = '$player_id'";
					$db_t->query($query);

					$db_t->end_transaction();
					$msg = "Your deposit has been completed.<br>Account balance: " . $new_balance . "<br><br>Thank you for your business.";
					break;
				} else {
					$db_t->end_transaction();
				}
      }

			break;

		case "withdraw_anonymous":
			$amount = (int) $amount;
			$account_id = (int) $account_id;			

			if (empty($amount)) {
				$error = "Please fill out all of the fields.";
				break;
			}
			
			if ( $player->f("newturnsleft") > 100 ) {
				$error = "Bank access is not allowed if you have more than 100 newbie turns.";
				break;
			}

			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = "Your ship is not in a sector that contains a bank.";
				break;
			}

			$db_t = new ME_DB_Tran;
			$db_t->begin_transaction();

			$query = "select player_id, credits, bank_account from players where player_id = '$player_id' for update";
			$db_t->query($query);
			$db_t->next_record();

			$current_credits = $db_t->f("credits") + $amount;

			$query = "select * from accounts where public_account_id = '$account_id' and game_id = '$game_id' for update";
			$db_t->query($query);
			$db_t->next_record();			
			
			if ( $db_t->nf() > 0 ) {
				if ( $amount < 0 )  {
    	  	$error = "Please only use positive amounts.";
					$db_t->end_transaction();
					break;
				}

				if ( $amount > $db_t->f("balance") )  {
    	  	$error = "You do not have that many credits available to withdraw.";
					$db_t->end_transaction();
					break;
				} else {
					if ( $password <> $db_t->f("password") )  {
      			$error = "Incorrect password.";
						$db_t->end_transaction();
						break;
					}

					$new_balance = $db_t->f("balance") - $amount;      	

					$transactions = array();
					$transactions = explode(",", $db_t->f("transactions"));

					if ( count($transactions) >= 10 ) {	
						array_splice($transactions, 0, 1);		
						$transactions[10] = "Withdraw of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));
					} else {
						$transactions = array();
						$transactions = explode(",", $db_t->f("transactions"));
						$transactions[count($transactions) + 1] = "Withdraw of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));		
					}
				
					$query = "update accounts set balance = '$new_balance', transactions = '$str_transactions' where public_account_id = '$account_id' and game_id = '$game_id'";
					$db_t->query($query);
						
					$query = "update players set credits = '$current_credits' where player_id = '$player_id'";
					$db_t->query($query);
					$db_t->end_transaction();

					$msg = "Your withdraw has been completed.<br>Account balance: " . $new_balance . "<br><br>Thank you for your business.";
					break;
	      }
			} else {
				$db_t->end_transaction();
			}
			
			break;

		case "deposit_alliance":
			$amount = (int) $amount;
			$account_id = (int) $account_id;			

			if (empty($amount)) {
				$error = "Please fill out all of the fields.";
				break;
			}
			
			if ( $player->f("newturnsleft") > 100 ) {
				$error = "Bank access is not allowed if you have more than 100 newbie turns.";
				break;
			}

			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = "Your ship is not in a sector that contains a bank.";
				break;
			}

			if ( $amount < 0 )  {
      	$error = "Please only use positive amounts.";
				break;
			}

			$db_t = new ME_DB_Tran;
			$db_t->begin_transaction();

			$query = "select player_id, credits, bank_account from players where player_id = '$player_id' for update";
			$db_t->query($query);
			$db_t->next_record();

			$current_credits = $db_t->f("credits") - $amount;

			if ( $amount > $db_t->f("credits") )  {
      	$error = "You do not have that many credits available to deposit.";
				$db_t->end_transaction();
				break;
			} else {				
				$query = "select * from accounts where public_account_id = '$account_id' and game_id = '$game_id' for update";
				$db_t->query($query);
        $db_t->next_record();

				if ( $db_t->nf() > 0 ) {
					if ( $player->f("alliance_id") <> $db_t->f("alliance_id") )  {
	  	   		$error = "You are not a member of this alliance.";
						$db_t->end_transaction();
						break;
					}

					$new_balance = $db_t->f("balance") + $amount;      	

					$transactions = array();
					$transactions = explode(",", $db_t->f("transactions"));

					if ( count($transactions) >= 10 ) {	
						array_splice($transactions, 0, 1);		
						$transactions[10] = "Deposit of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));
					} else {
						$transactions = array();
						$transactions = explode(",", $db_t->f("transactions"));
						$transactions[count($transactions) + 1] = "Deposit of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));		
					}
					
					$query = "update accounts set balance = '$new_balance', transactions = '$str_transactions' where public_account_id = '$account_id' and game_id = '$game_id'";
					$db_t->query($query);
					
					$query = "update players set credits = '$current_credits' where player_id = '$player_id'";
					$db_t->query($query);

					$db_t->end_transaction();

					$msg = "Your deposit has been completed.<br>Account balance: " . $new_balance . "<br><br>Thank you for your business.";
					break;
	      } else {
					$db_t->end_transaction();
				}
			}

			break;

		case "withdraw_alliance":
			$amount = (int) $amount;
			$account_id = (int) $account_id;			

			if (empty($amount)) {
				$error = "Please fill out all of the fields.";
				break;
			}

			if ( $player->f("newturnsleft") > 100 ) {
				$error = "Bank access is not allowed if you have more than 100 newbie turns.";
				break;
			}

			$db = new ME_DB;
			$db->query("SELECT * from locations where sector_id = '$sector_id' and type='Bank'");
			$db->next_record();

			if ( $db->nf() == 0 ) {
				$error = "Your ship is not in a sector that contains a bank.";
				break;
			}

			$db_t = new ME_DB_Tran;
			$db_t->begin_transaction();

			$query = "select player_id, credits, bank_account from players where player_id = '$player_id' for update";
			$db_t->query($query);
			$db_t->next_record();

			$current_credits = $db_t->f("credits") + $amount;

			$query = "select * from accounts where public_account_id = '$account_id' and game_id = '$game_id' for update";
			$db_t->query($query);
			$db_t->next_record();			

			if ( $db_t->nf() > 0 ) {
				if ( $amount < 0 )  {
    	  	$error = "Please only use positive amounts.";
					$db_t->end_transaction();
					break;
				}

				if ( $amount > $db_t->f("balance") )  {
    	  	$error = "You do not have that many credits available to withdraw.";
					$db_t->end_transaction();
					break;
				} else {
					if ( $player->f("alliance_id") <> $db_t->f("alliance_id") )  {
    	  		$error = "You are not a member of this alliance.";
						$db_t->end_transaction();
						break;
					}

					$new_balance = $db_t->f("balance") - $amount;	
			
					$transactions = array();
					$transactions = explode(",", $db_t->f("transactions"));

					if ( count($transactions) >= 10 ) {	
						array_splice($transactions, 0, 1);		
						$transactions[10] = "Withdraw of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));
					} else {
						$transactions = array();
						$transactions = explode(",", $db_t->f("transactions"));
						$transactions[count($transactions) + 1] = "Withdraw of " . $amount . " by " .  addslashes($player->f("name")) . " at " . date ("m/d H:i:s") . ".";
						$str_transactions = addslashes(implode(",", $transactions));		
					}			
					
					$query = "update accounts set balance = '$new_balance', transactions = '$str_transactions' where public_account_id = '$account_id' and game_id = '$game_id'";
					$db_t->query($query);
					
					$query = "update players set credits = '$current_credits' where player_id = '$player_id'";
					$db_t->query($query);
					$db_t->end_transaction();

					$msg = "Your withdraw has been completed.<br>Account balance: " . $new_balance . "<br><br>Thank you for your business.";
					break;
	      }
			} else {
				$db_t->end_transaction();
			}

			break;
	}
}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	$db->add_parameter("message", $error);
	echo $db->get_transform("./xslt/message_box.xslt", "");		
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Transaction Completed");
	$db->add_parameter("message", $msg);
	echo $db->get_transform("./xslt/message_box.xslt", "");		
}
?>

</td>
<td valign=top align=right width=100%><?php

$player->get_player($player_id);
include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
