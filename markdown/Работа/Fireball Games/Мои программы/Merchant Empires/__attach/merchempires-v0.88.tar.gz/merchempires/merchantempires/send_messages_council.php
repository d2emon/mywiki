<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Send Messages</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "sendmessages");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=1 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 valign=middle>
						<br>
						<font color=#3333FF face=arial,helvetica,swiss size=5><center>SEND MESSAGES</center></font>
						<br>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<form name=form_send_message action=<?php

echo $sess->url(URL . "send_message.php");
?>
					method=post>
				<tr>
					<td width=500 class=clsNrmTxt valign=middle>
						<font color=#3333FF face=arial,helvetica,swiss size=3>&nbsp;To:&nbsp;</font><?php

$id = (int) $id;
$db = new ME_DB;
$game_id = $player->f("game_id");
$db->query("select * from games where game_id = '$game_id'");
$db->next_record();
echo "<font color=#ccccc  face=arial,helvetica,swiss size=3>" . $db->f("namerace_" . $id) . "&nbsp;Council</font>";
echo "<INPUT TYPE=hidden name=action value=council>";	
echo "<INPUT TYPE=hidden name=toplayer value=council>";
echo "<INPUT TYPE=hidden name=race value=" . $db->f("namerace_" . $id) . ">";
echo "<INPUT TYPE=hidden name=council_id value='$id'>";
	
?>
						<INPUT TYPE="hidden" name="player_id" value=<?php

printf("%s", $player_id);
?>
						>						
						<INPUT TYPE="hidden" name="public_player_id" value=<?php

echo $player->f("public_player_id");
?>
						>
					</td>
				</tr>
				<tr>
						<td class=clsNrmTxt>
							<font color=#cccccc face=arial,helvetica,swiss size=3>
							<center><p><?php

echo "<textarea name=message rows=8 cols=48 size1000>";

if ( $error == 2 ) {
	$db = new ME_DB;
	$db->query("select long_message from player_config where player_id = '$player_id'");
	$db->next_record();

	echo $db->f("long_message");
}

echo "</textarea>";
?>
							</p></center>							
						</td>
				</tr>
				<tr>
						<td align=center class=clsNrmTxt><?php

echo "<input type=hidden name=send_message value=Send>";
echo "<a href='javascript:document.form_send_message.submit()'><img border=0 src='./images/form/send-off.png'></a><br>";

?>
						</td>
				</tr>
				</form>
			</table>
		</td>
	</tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");		
		
	if ($error == 1) {
		$db->add_parameter("message", "The message body or address field contained no value.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Message length is limited to 1000 characters.");
	} elseif ($error == 3) {
		$db->add_parameter("message", "You can't send messages to players in other games.");
	} elseif ($error == 4) {
		$db->add_parameter("message", "There is no merchant with that name.");
	} elseif ($error == 5) {
		$db->add_parameter("message", "There is no merchant with that ID.");
	} elseif ($error == 6) {
		$db->add_parameter("message", "Your message contains potentially offensive language.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
