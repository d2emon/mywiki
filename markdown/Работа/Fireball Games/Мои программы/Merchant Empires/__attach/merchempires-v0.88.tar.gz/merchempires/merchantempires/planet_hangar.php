<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./lib/cargo.php");
include("./lib/weapons.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function get_planetary_tech($db_p) {
	$tech_temp = explode(",", $db_p->f("ship_technology"));

	for ($i = 0; $i <= count($tech_temp) - 1; $i = $i + 2) {
		$planetary_tech[$tech_temp[$i]] = $tech_temp[$i + 1];
	}		

	return $planetary_tech;
}

function get_planetary_weapons($db_p) {
	$weapons_temp = explode(",", $db_p->f("ship_weapons"));

	for ($i = 0; $i <= count($weapons_temp) - 1; $i = $i + 2) {
		$planetary_weapons[$weapons_temp[$i]] = $weapons_temp[$i + 1];
	}		

	return $planetary_weapons;
}

?>

<html><head><title>Merchant Empires: Planetary Hangar</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$planet_id = $ship->f("planet_id");
$weapons = new ME_Weapons;
$weapons->get_weapons($ship->f("ship_id"));

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "planet");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
	
$db_pl = new ME_DB;
$db_pl->query("select players.rank, players.experience, players.player_id, ships.planet_id, ships.player_id from players, ships where ships.planet_id = '$planet_id' and players.player_id = ships.player_id order by players.experience desc limit 1");
$db_pl->next_record();

$db_p = new ME_DB_Xml;
$db_p->query("select * from planets where planet_id = '$planet_id'");
$db_p->next_record();

$sector_id = $db_p->f("sector_id");

$db_s = new ME_DB;
$db_s->query("select * from sectors where sector_id = '$sector_id'");
$db_s->next_record();

$sector = new ME_Sector;
$sector->get_offset_sector($db_s->f("map_id"), $db_s->f("xpos"), $db_s->f("ypos"));

$db = new ME_DB;
$db->query("select * from weapons order by weapon_id");

while ( $db->next_record() ) {
	$all_weapons[$db->f("weapon_id")] = $db->f("name");
}
	
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

if ( $planet_id <> 0 ) {
	$db_p->add_parameter("current_screen", "planet_hangar");	
	echo $db_p->get_transform("./xslt/menu_top_planet.xslt", $db_p->get_xml());
?>
<script>
	function verify() {
		msg = "Are you absolutely sure that you want to destroy that ship?";
		return confirm(msg);
	}
</script> 

<table border=0 cellPadding=0 cellSpacing=0 width=490>
	<tr>
  	<td bgColor=#003399>
    	<table border=0 cellPadding=5 cellSpacing=1 width=490>
        <tr>
        	<td class=clsNrmTxt>
						<font color=#3333FF face=arial,helvetica,swiss size=3><b>Planetary Hangar</font></b><br><?php

$current_time = time();						
$db->query("select * from ships_storage where planet_id = '$planet_id' and player_id = '$player_id' and delivery_time <= '$current_time'");

if ( $db->nf() == 0 ) {
	echo "<br>&nbsp;No ships in storage.";
}

echo "<table width=400 cols=2 cellpadding=3 cellspacing=3>";

if ( $db->nf() > 0 ) {
	while ( $db->next_record() ) {
		echo "<tr>";
		
		echo "<td width=30% valign=middle class=clsNrmTxt>";				
		echo "&nbsp;" . $db->f("type");
		echo "</td><td align=left valign=middle class=clsNrmTxt>";
		
		if ( $db->f("board_time") + 400 < time() ) {
			
			echo "<form action=";
			echo $sess->url(URL . "planet_update.php");
			echo " method=post>";
			
			echo "<table border=0><tr>";
			
			echo "<td><input border=0 type=image src='./images/form/board-off.png' name=board>";
			echo "&nbsp;&nbsp;<input type=hidden name=id value=" . $db->f("ship_storage_id") . ">";
			echo "</td>";
			
			echo "</form><form action=";
			echo $sess->url(URL . "planet_update.php");
			echo " method=post onsubmit='return verify()'>";
		
			echo "<td>&nbsp;&nbsp;<input border=0 type=image src='./images/form/scuttle-off.png' name=scuttle>";
			echo "&nbsp;&nbsp;<input type=hidden name=id value=" . $db->f("ship_storage_id") . "></td>";
				
			echo "</tr></form></table>";						
		} else {
			echo "&nbsp;Prepared for boarding in " . (string) ($db->f("board_time") + 400 - time()) . " seconds.";
		}		
		
		echo "</tr></td>";
	}	
}

echo "</table>";
?>
	       	</td>
		  	</tr>
			</table>
		</td>
	</tr>
</table><br><?php

$planet_tech = array();
$tech_temp = explode(",", $db_p->f("ship_technology"));		

for ($i = 0; $i <= count($tech_temp) - 1; $i = $i + 2) {	
	$planet_tech[$tech_temp[$i]] = $tech_temp[$i + 1];	
}
?>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=red1><center>
					<br>Hangar Technology (Shared)<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=red1>				
					<center>Item</center>
					</td>	
					<td class=clsHedTxt id=red1>
					<center>Amount on Planet</center>
					</td>								
					<td class=clsHedTxt id=red1>
					<center>Option</center>
					</td>
				</tr><?php

while (list($key, $val) = each($planet_tech)) {
	if ( $val > 0 ) {
		$val = (int) $val;		

		echo "<tr><form action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td class=clsNrmTxt><center>";
		echo $key;
		echo "</center></td>";		
		
		echo "<td class=clsNrmTxt><center>";
		echo "<input type=textbox name=amount value=" . $val . " size=5>";
		echo "</center></td>";

		echo "<td class=clsNrmTxt valign=middle align=center>";
		echo "<input type=hidden name=source value=shared>";
		echo "<input type=hidden name=tech_type value='" . $key . "'>";
		
		echo "<input border=0 type=image src='./images/form/store-off.png' name=store_tech>";
		echo "<input border=0 type=image src='./images/form/install-off.png' name=install_tech>";	
		echo "</td></form></tr>";
	}
}
?>					
			</table>
		<td>
  </tr>
</table><br><?php

$planet_tech_personal = array();
$planet_weapons_personal = array();

$db = new ME_DB;
$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
$db->next_record();

if ( $db->nf() == 0 ) {
	$db->query("insert into planet_merchant_storage (planet_id, player_id) values ('$planet_id', '$player_id')");
	$db->query("select * from planet_merchant_storage where planet_id = '$planet_id' and player_id = '$player_id'");
	$db->next_record();
}

$planet_tech_personal = get_planetary_tech($db);
$planet_weapons_personal = get_planetary_weapons($db);

?>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=blu1><center>
					<br>Hangar Technology (Personal)<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Item</center>
					</td>	
					<td class=clsHedTxt id=blu1>
					<center>Amount on Planet</center>
					</td>								
					<td class=clsHedTxt id=blu1>
					<center>Option</center>
					</td>
				</tr><?php

while (list($key, $val) = each($planet_tech_personal)) {
	if ( $val > 0 ) {
		$val = (int) $val;		

		echo "<tr>";
		echo "<form action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td class=clsNrmTxt><center>";
		echo $key;
		echo "</center></td>";
		
		echo "<td class=clsNrmTxt><center>";
		echo "<input type=textbox name=amount value=" . $val . " size=5>";
		echo "</center></td>";

		echo "<td class=clsNrmTxt valign=middle align=center>";
		echo "<input type=hidden name=source value=personal>";
		echo "<input type=hidden name=tech_type value='" . $key . "'>";

		echo "<input border=0 type=image src='./images/form/store-off.png' name=store_tech>";
		echo "<input border=0 type=image src='./images/form/install-off.png' name=install_tech>";	
		
		echo "</td></form></tr>";
	}
}
?>					
			</table>
		<td>
  </tr>
</table><br><?php

$planet_weapons = array();
$weapons_temp = explode(",", $db_p->f("ship_weapons"));

for ($i = 0; $i <= count($weapons_temp) - 1; $i = $i + 2) {
	$planet_weapons[$weapons_temp[$i]] = $weapons_temp[$i + 1];
}
?>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=red1><center>
					<br>Hangar Weapons (Shared)<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=red1>				
					<center>Weapon</center>
					</td>	
					<td class=clsHedTxt id=red1>
					<center>Amount on Planet</center>
					</td>								
					<td class=clsHedTxt id=red1>
					<center>Option</center>
					</td>
				</tr><?php

while (list($key, $val) = each($planet_weapons)) {
	if ( $val > 0 ) {
		$val = (int) $val;		

		echo "<tr><form action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td class=clsNrmTxt><center>";
		echo $key;
		echo "</center></td>";		
		
		echo "<td class=clsNrmTxt><center>";
		echo "<input type=textbox name=amount value=" . $val . " size=5>";
		echo "</center></td>";

		echo "<td class=clsNrmTxt valign=middle align=center>";
		echo "<input type=hidden name=source value=shared>";
		echo "<input type=hidden name=weapon_type value='" . $key . "'>";

		echo "<input border=0 type=image src='./images/form/store-off.png' name=store_weapon>";
		echo "<input border=0 type=image src='./images/form/install-off.png' name=install_weapon>";	

		echo "</td></form></tr>";
	}
}
?>					
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=blu1><center>
					<br>Hangar Weapons (Personal)<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Weapon</center>
					</td>	
					<td class=clsHedTxt id=blu1>
					<center>Amount on Planet</center>
					</td>								
					<td class=clsHedTxt id=blu1>
					<center>Option</center>
					</td>
				</tr><?php

while (list($key, $val) = each($planet_weapons_personal)) {
	if ( $val > 0 ) {
		$val = (int) $val;		

		echo "<tr><form action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td class=clsNrmTxt><center>";
		echo $key;
		echo "</center></td>";
		
		echo "<td class=clsNrmTxt><center>";
		echo "<input type=textbox name=amount value=" . $val . " size=5>";
		echo "</center></td>";

		echo "<td class=clsNrmTxt valign=middle align=center>";
		echo "<input type=hidden name=source value=personal>";
		echo "<input type=hidden name=weapon_type value='" . $key . "'>";

		echo "<input border=0 type=image src='./images/form/store-off.png' name=store_weapon>";
		echo "<input border=0 type=image src='./images/form/install-off.png' name=install_weapon>";	

		echo "</td></form></tr>";
	}
}
?>					
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=red1><center>
					<br>Installed Technology<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=red1>				
					<center>Item</center>
					</td>		
					<td class=clsHedTxt id=red1>
					<center>Amount on Ship</center>
					</td>								
					<td class=clsHedTxt id=red1>
					<center>Transfer to</center>
					</td>
				</tr><?php

$current_techs = array();

if ( $ship->f("cloak") ) {	
	$current_techs["Cloaking Device"] = $ship->f("cloak");
}

if ( $ship->f("illusion") ) {	
	$current_techs["Illusion Generator"] = $ship->f("illusion");
}

if ( $ship->f("jump") ) {	
	$current_techs["Jump Drive"] = $ship->f("jump");
}

if ( $ship->f("scanner") ) {
	$current_techs["Scanners"] = $ship->f("scanner");
}

if ( $ship->f("tracking") ) {	
	$current_techs["Tracking Device"] = $ship->f("tracking");
}

if ( $ship->f("deep_scanner") ) {	
	$current_techs["Deep Space Scanner"] = $ship->f("deep_scanner");
}

if ( $ship->f("targeting_computer") ) {	
	$current_techs["Targeting Computer"] = $ship->f("targeting_computer");
}

if ( $ship->f("plasma_booster") ) {	
	$current_techs["Plasma Booster"] = $ship->f("plasma_booster");
}

if ( $ship->f("active_screens") ) {	
	$current_techs["Active Screens"] = $ship->f("active_screens");
}

if ( $ship->f("trifocus_plasma") ) {
	$current_techs["Tri-Focus Plasma"] = $ship->f("trifocus_plasma");
}

if ( $ship->f("tractor_beam") ) {	
	$current_techs["Tractor Beam"] = $ship->f("tractor_beam");
}

if ( $ship->f("battle_systems_computer") ) {
	$current_techs["Battle Systems Computer"] = $ship->f("battle_systems_computer");
}

if ( $ship->f("scoutcurrent") > 0 ) {
	$current_techs["Scout Drones"] = $ship->f("scoutcurrent");
}

if ( $ship->f("combatcurrent") > 0 ) {
	$current_techs["Combat Drones"] = $ship->f("combatcurrent");
}

if ( $ship->f("minescurrent") > 0 ) {
	$current_techs["Mines"] = $ship->f("minescurrent");
}

if ( $ship->f("shieldcurrent") > 0 ) {
	$current_techs["Shields"] = $ship->f("shieldcurrent");
}

if ( $ship->f("armorcurrent") > 0 ) {
	$current_techs["Armor"] = $ship->f("armorcurrent");
}

if ( $ship->f("powercurrent") > 0 ) {
	$current_techs["Power Plant"] = $ship->f("powercurrent");
}

if ( $ship->f("cargocurrent") > 0 ) {
	$current_techs["Cargo Holds"] = $ship->f("cargocurrent");
}

while (list($key, $val) = each($current_techs)) {
	$val = (int) $val;

	echo "<tr><form action=";
	echo $sess->url(URL . "planet_update.php");
	echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";
	echo "<td class=clsNrmTxt><center>";
	echo $key;
	echo "</center></td>";		
		
	echo "<td class=clsNrmTxt><center>";
	echo "<input type=textbox name=amount value=" . $val . " size=5>";
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";	
	echo "<input type=hidden name=tech_type value='" . $key . "'>";

	echo "<input border=0 type=image src='./images/form/shared-off.png' name=unload_installed_tech>";
	echo "<input border=0 type=image src='./images/form/personal-off.png' name=unload_installed_tech_personal>";

	echo "</center></td></form></tr>";
}
?>				
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=blu1><center>
					<br>Stored Technology<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Item</center>
					</td>					
					<td class=clsHedTxt id=blu1>
					<center>Amount on Ship</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Transfer to</center>
					</td>
				</tr><?php

$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

while (list($key, $val) = each($cargo->Current_cargo)) {
	if ( $val['type'] == 2 ) {
		echo "<tr><form action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td class=clsNrmTxt><center>";
		echo $key;
		echo "</center></td>";		

		echo "<td class=clsNrmTxt><center>";
		echo "<input type=textbox name=amount value=" . $val['amount'] . " size=5>";
		echo "</center></td>";
		
		echo "<td class=clsNrmTxt><center>";
		echo "<input type=hidden name=tech_type value='" . $key . "'>";

		echo "<input border=0 type=image src='./images/form/shared-off.png' name=unload_stored_tech>";
		echo "<input border=0 type=image src='./images/form/personal-off.png' name=unload_stored_tech_personal>";
		
		echo "</center></td></form></tr>";
	}
}

?>									
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
  <tr>
    <td bgColor=#993300>
      <table cols=2 border=0 cellpadding=2 cellspacing=1 width=500>
        <tr>
					<td align=center colspan=2 class=clsHedTxt id=red1>
					<br>Installed Weapons<br><br>
					</td>
				</tr>				
       	<tr>
					<td width=60% class=clsHedTxt id=red1>				
					<center>Weapon</center>
					</td>										
					<td class=clsHedTxt id=red1>
					<center>Transfer to</center>
					</td>
				</tr><?php

while (list($key, $val) = each($weapons->Current_weapons)) {
  echo "<tr><td align=center class=clsNrmTxt>";
  echo $all_weapons[$val];
  echo "</td>";

	echo "<form action=";
  echo $sess->url(URL . "planet_update.php");
  echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

	echo "<td align=center class=clsNrmTxt><center>";				
	echo "<input type=hidden name=id value='" . $key . "'>";
	echo "<input type=hidden name=weapon_id value='" . $val . "'>";
	echo "<input type=hidden name=weapon_type value='" . $all_weapons[$val] . "'>";

	echo "<input type=hidden name=unload_installed_weapon>";
	echo "<input border=0 type=image src='./images/form/shared-off.png' name=unload_installed_weapon_shared value=Shared>";
	echo "<input border=0 type=image src='./images/form/personal-off.png' name=unload_installed_weapon_personal value=Personal>";
	
	echo "</td></form></tr>";
}
?>
      </table>
    <td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td colspan=3 class=clsHedTxt id=blu1><center>
					<br>Stored Weapons<br><br>
					</center></td></tr>
				<tr>
					<td class=clsHedTxt id=blu1>				
					<center>Weapons</center>
					</td>					
					<td class=clsHedTxt id=blu1>
					<center>Amount on Ship</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Transfer to</center>
					</td>
				</tr><?php

$cargo = new ME_Cargo;
$cargo->get_cargo($player_id);

while (list($key, $val) = each($cargo->Current_cargo)) {
	if ( $val['type'] == 3 ) {		
		echo "<tr><form action=";
		echo $sess->url(URL . "planet_update.php");
		echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";

		echo "<td valign=middle align=center class=clsNrmTxt>";
		echo $key . "</td>";

		echo "<td align=center class=clsNrmTxt>";
		echo "<input type=textbox name=amount value=" . $val['amount'] . " size=5>" . "</td>";		
		
		echo "<td align=center class=clsNrmTxt>";
		echo "<input type=hidden name=weapon_type value='" . $key . "'>";
		
		echo "<input type=hidden name=unload_stored_weapon>";
		echo "<input border=0 type=image src='./images/form/shared-off.png' name=unload_stored_weapon_shared value=Shared>";
		echo "<input border=0 type=image src='./images/form/personal-off.png' name=unload_stored_weapon_personal value=Personal>";
	
		echo "</td></form></tr>";
	}
}

?>									
			</table>
		<td>
  </tr>
</table><br><?php

} else {
	$error = 4;
}

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Password not entered.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "Incorrect password.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "Each player is allowed to own only one planet.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "Your merchant is currently not landed on a planet.");			
	} elseif ($error == 5) {
		$db->add_parameter("message", "Stored ship not found.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "There will be a short delay before that ship is prepared for boarding.");			
	} elseif ($error == 7) {
		$db->add_parameter("message", "Command not processed due to insufficient technology on planet.");			
	} elseif ($error == 8) {
		$db->add_parameter("message", "Command not processed due to insufficient cargo capacity.");			
	} elseif ($error == 9) {
		$db->add_parameter("message", "Command not processed due to invalid amount entered.");			
	} elseif ($error == 10) {
		$db->add_parameter("message", "Command not processed due to insufficient capacity.");			
	} elseif ($error == 11) {
		$db->add_parameter("message", "Command not processed due to technology already installed.");			
	} elseif ($error == 12) {
		$db->add_parameter("message", "Current ship type does not support that technology.");			
	} elseif ($error == 13) {
		$db->add_parameter("message", "Command not processed due to insufficient technology on ship.");			
	} elseif ($error == 14) {
		$db->add_parameter("message", "Technology not found on ship.");			
	} elseif ($error == 15) {
		$db->add_parameter("message", "The planetary hangar capacity for that technology type is 500 units.");			
	} elseif ($error == 16) {
		$db->add_parameter("message", "Only four modules of one technology type can be installed.");			
	} elseif ($error == 17) {
		$db->add_parameter("message", "That weapon cannot be used while your merchant is under newbie protection.");			
	} elseif ($error == 18) {
		$db->add_parameter("message", "Command not processed due to insufficient weapons on planet.");			
	} elseif ($error == 19) {
		$db->add_parameter("message", "The planetary hangar capacity for that weapon type is 10 units.");			
	} elseif ($error == 20) {
		$db->add_parameter("message", "Your alignment prevents you from installing that weapon.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>