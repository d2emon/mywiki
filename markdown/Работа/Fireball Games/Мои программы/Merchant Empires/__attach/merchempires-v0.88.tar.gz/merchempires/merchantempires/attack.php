<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/ship.php");
include("./lib/player.php");
include("./lib/sector.php");
include("./lib/player_alliance.php");
include("./lib/player_redirect.php");

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

if ( $player_id > 0 )  {
	if ( $refer == "current" ) {
		$returnto = "current";
	} elseif ( $refer == "preattack" ) {
		$returnto = "results";
	} elseif ( $refer == "results" ) {
		$returnto = "results";
	} elseif ( $refer == "planet" ) {
		$returnto = "results";
	} elseif ( $refer == "moveto" ) {
		$returnto = "results";
	}

	$db = new ME_DB;
	$imperial_protection = 0;
	$db->query("SELECT * from locations where sector_id = '$sector_id' and type = 'Authority'");
	if ( $db->nf() > 0 ) {
		$imperial_beacon = 1;
		$defender_ship = new ME_Ship;
		$attacker_ship = new ME_Ship;
	}

	$query = sprintf("select * from sectors where sector_id = '%s'", $ship->f("sector_id"));
	$db->query($query);	
	$db->next_record();
	$map_id = $db->f("map_id");
	
	$attackers = array();
	$defenders = array();

	$attacker_alliance_id = $player->f("alliance_id");
	$attacker_sector_id = $ship->f("sector_id");
	
	$db_ps = new ME_DB;
	$db_pf = new ME_DB;

	if ( $type == 's' ) {					
		$db_ps->query("select players.player_id, players.alliance_id, players.alignment, players.newturnsleft, ships.player_id, ships.sector_id, ships.planet_id from players, ships
			where players.player_id = '$id' and players.player_id = ships.player_id");
		$db_ps->next_record();
	
		$defender_alliance_id = $db_ps->f("alliance_id");
		$defender_sector_id = $db_ps->f("sector_id");
		$defender_planet_id = $db_ps->f("planet_id");
	}
			
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_sql = get_alliance_sql($player->f("alliance_id"), get_treaties($player->f("alliance_id"), 'Mutual Assistance'));
		
		if ( $type == 's' ) {
			$alliance_sql = $alliance_sql . " and players.alliance_id <> '" . $defender_alliance_id . "'";
		}
				
		if ( $type == 'p' ) {
			$db_ps->query("select players.player_id, players.alliance_id, players.alignment, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
				where (" . $alliance_sql . ") and ships.player_id = players.player_id and ships.sector_id = '$attacker_sector_id' and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id and players.newturnsleft = 0 limit 10");
		} else {
			$db_ps->query("select players.player_id, players.alliance_id, players.alignment, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
				where (" . $alliance_sql . ") and ships.player_id = players.player_id and ships.sector_id = '$attacker_sector_id' and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id");
		}
	} else {
		$db_ps->query("select players.player_id, players.alliance_id, players.alignment, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
			where players.player_id = '$player_id' and ships.player_id = players.player_id and ships.sector_id = '$attacker_sector_id' and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id");
	}
	
	$x = 0;
	
	while ( $db_ps->next_record() ) {
		$process_merchant = 1;

		if ( $attacker_sector_id <> 0 ) {
			if ( $db_ps->f("player_id") <> $player->f("player_id") and $type == 'f' and $db_ps->f("group_combat_forces") == 'f' ) {
				$process_merchant = 0;
			} elseif ( $db_ps->f("player_id") <> $player->f("player_id") and $type == 'p' and $db_ps->f("group_combat_planets") == 'f' ) {
				$process_merchant = 0;
			} elseif ( $db_ps->f("player_id") <> $player->f("player_id") and $type == 's' and $db_ps->f("group_combat_ships") == 'f' ) {
				$process_merchant = 0;
			}
		}

		if ( $process_merchant ) {
			$attackers[$x][0] = "s";	
			$attackers[$x][1] = $db_ps->f("player_id");
	
			$attacker_type = $attackers[$x][0];
			$attacker_id = $attackers[$x][1];

			if ( $attacker_type = 's' ) {			
				if ( $imperial_beacon ) {
					$attacker_ship->get_ship($attacker_id);
    	
					if ( (int) (($attacker_ship->combined_damage / 40) + ($attacker_ship->f("combatcurrent") / 50)) < 1 ) {
						$offense = 1;
					} else {
						$offense = (int) (($attacker_ship->combined_damage / 40) + ($attacker_ship->f("combatcurrent") / 50));
					}

					$protected = 3;
				
					if ( $db_ps->f("alignment") >= 150 and $db_ps->f("alignment") < 300 ) {
						$protected = 4;
					} elseif( $db_ps->f("alignment") >= 300 ) {
						$protected = 5;
					} elseif( $db_ps->f("alignment") <= -150 and $db_ps->f("alignment") > -300 ) {
						$protected = 2;
					} elseif( $db_ps->f("alignment") < -300 ) {
						$protected = 1;
					}

					if ( $offense > $protected ) {
						$attackers[$x][2] = 0;
					} else {
						$attackers[$x][2] = 1;	
					}
				} else {
					$attackers[$x][2] = 0;	
				}

				$query = sprintf("SELECT player_id, newturnsleft from players where player_id = '%s'", $attacker_id);
				$db->query($query);
				$db->next_record();
		
				if ( $db->f("newturnsleft") > 0 ) {
					$attackers[$x][3] = 1;	
				} else {
					$attackers[$x][3] = 0;
				}			
			} else {
				$attackers[$x][2] = 0;		
				$attackers[$x][3] = 0;		
			}	

			$x = $x + 1;
		}
	}

	if ( $type <> 'p' ) {
		if ( $attacker_sector_id <> 0 ) {
			if ( $attacker_alliance_id == 0 ) {			
				$db_pf->query("select * from forces where player_id = '$attacker_id' and sector_id = '$sector_id' and combat > 0");
				$db_pf->next_record();

				if ( $db_pf->nf() > 0 ) {				
					$attackers[$x][0] = "f";
					$attackers[$x][1] = $db_pf->f("forces_id");
					$attackers[$x][2] = 0;
					$attackers[$x][3] = 0;
					$x = $x + 1;
				}
			} else {
				$db_pf->query("select * from forces where alliance_id = '$attacker_alliance_id' and sector_id = '$sector_id' and combat > 0");			
			
				while ( $db_pf->next_record() ) {								
					$attackers[$x][0] = "f";
					$attackers[$x][1] = $db_pf->f("forces_id");
					$attackers[$x][2] = 0;
					$attackers[$x][3] = 0;	
					$x = $x + 1;			
				}
			}		
		}
	}

	$id = (int) $id;

	# check here for a ship under attack that has landed on a planet
	if ( $type == 's' ) {			
		$db_ps = new ME_DB;
		$db_ps->query("select players.player_id, players.alliance_id, players.alignment, ships.player_id, ships.sector_id, ships.planet_id from players, ships
			where players.player_id = '$id' and players.player_id = ships.player_id");
		$db_ps->next_record();
						
		$defender_planet_id = $db_ps->f("planet_id");
		
		if ( $defender_planet_id > 0 ) {
			$query = sprintf("select * from planets where planet_id = '%s'", $defender_planet_id);
			$db->query($query);
			$db->next_record();
		
			if ( $db->f("generatorcurrent") > 0 or $db->f("hangarcurrent") > 0 ) {
				$type = '';
				$id = '';
			}
		}
	}

	if ( $type == 'p' and $player->f("newturnsleft") == 0 ) {
		$query = sprintf("SELECT * from planets where planet_id = '%s'", $id);
		$db->query($query);
		$db->next_record();

		$defender_alliance_id = $db->f("alliance_id");
		
		if ( $attacker_sector_id == $db->f("sector_id") ) {
			if ( $db->f("generatorcurrent") > 0 or $db->f("hangarcurrent") > 0 ) {			
				$defenders[0][0] = $type;
				$defenders[0][1] = $id;
				$defenders[0][2] = 0;
				$defenders[0][3] = 0;   		
			} else {
				$query = sprintf("SELECT ships.player_id, ships.planet_id, players.player_id, players.newturnsleft from ships, players where planet_id = '%s' and ships.player_id = players.player_id", $id);
				$db->query($query);			
		
				$non_newbie_found = 0;
				while ( $db->next_record() ) {
					if ( $db->f("newturnsleft") == 0 ) {
						$non_newbie_found = 1;					
					}
				}
			
				if ( $non_newbie_found ) {
					$db->query($query);				
					
					if ( $db->nf() > 0 ) {
						$x = 0;
						$returnto = "results";
						
						while ( $db->next_record() ) {														
							$defenders[$x][0] = 's';
							$defenders[$x][1] = $db->f("player_id");
							$defenders[$x][2] = 0;

							if ( $db->f("newturnsleft") > 0 ) {
								$defenders[$x][3] = 1;	
							} else {
								$defenders[$x][3] = 0;
							}
							$x = $x + 1;						
						}
					} else {			
						$db->query("update planets set password = '', owner_id = 0, owner_name = '',
							alliance_id = 0 where planet_id = '$id'");

						$returnto = "planet_land";
					}
				} else {
					$query = sprintf("SELECT ships.player_id, ships.planet_id, ships.ship_id, players.player_id, players.newturnsleft from ships, players where planet_id = '%s' and ships.player_id = players.player_id", $id);
					$db->query($query);		

					$db_p_u = new ME_DB;
					$db_2 = new ME_DB;

					while ( $db->next_record() ) {
						$db_2->query("SELECT planet_id, sector_id, public_sector_id from planets where planet_id = '$id'");		
						$db_2->next_record();
						$this_sector_id = $db_2->f("sector_id");
						$this_public_sector_id = $db_2->f("public_sector_id");
						$this_ship_id = $db->f("ship_id");
				
						$db_p_u->query("update ships set planet_id = 0, sector_id = '$this_sector_id', public_sector_id = '$this_public_sector_id' where ship_id = '$this_ship_id'");
					}

					$db->query("update planets set password = '', owner_id = 0, owner_name = '',
						alliance_id = 0 where planet_id = '$id'");

					$returnto = "planet_land";
				}
			}
		} else {
			$defenders[0][0] = $type;
			$defenders[0][1] = 0;
			$defenders[0][2] = 0;
			$defenders[0][3] = 0;
		}
	}

	if ( $type == 'm' ) {
		$defenders[0][0] = $type;
		$defenders[0][1] = $id;
		$defenders[0][2] = 0;
		$defenders[0][3] = 0;

		$db_pf->query("select * from forces where forces_id = '$id' and sector_id = '$sector_id'");
		$db_pf->next_record();
		$defender_alliance_id = $db_pf->f("alliance_id");
	}

	if ( $type == 'f' ) {
		$db_pf->query("select * from forces where forces_id = '$id' and sector_id = '$sector_id'");
		$db_pf->next_record();
		$defender_alliance_id = $db_pf->f("alliance_id");
		$this_player_id = $db_pf->f("player_id");

		if ( $db_pf->nf() > 0 ) {
			if ( $db_pf->f("alliance_id") <> 0 ) {
				$alliance_sql = get_alliance_sql($db_pf->f("alliance_id"), get_treaties($db_pf->f("alliance_id"), 'Mutual Assistance'));				
				$alliance_sql = $alliance_sql . " and players.alliance_id <> '" . $attacker_alliance_id . "'";
						
				$db_ps->query("select players.player_id, players.alliance_id, players.alignment, players.newturnsleft, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
					where (" . $alliance_sql . ") and ships.player_id = players.player_id and ships.sector_id = '$sector_id' and players.newturnsleft = 0 and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id");
			} else {
				$db_ps->query("select players.player_id, players.alliance_id, players.alignment, players.newturnsleft, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
					where players.player_id = '$this_player_id' and ships.player_id = players.player_id and ships.sector_id = '$sector_id' and players.newturnsleft = 0 and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id");
			}
			
			if ( $db_ps->nf() > 0 ) {				
				while ( $db_ps->next_record() ) {
					if ( $db_ps->f("group_combat_forces") == 'f' ) {
						// nothing						
					} else {
						$id = $db_ps->f("player_id");
						$type = 's';					
					}
				}				

				// if no uncloaked combat merchant found
				if ( $type == 'f' ) {
					if ( $db_pf->f("alliance_id") <> 0 ) {
						$db_pf->query("select * from forces where sector_id = '$sector_id' and alliance_id = '$defender_alliance_id'");
				
						$x = 0;
						while ( $db_pf->next_record() ) {
							$defenders[$x][0] = 'f';
							$defenders[$x][1] = $db_pf->f("forces_id");
							$defenders[$x][2] = 0;
							$defenders[$x][3] = 0;
							$x = $x + 1;
						}
					} else {
						$defenders[0][0] = $type;
						$defenders[0][1] = $id;
						$defenders[0][2] = 0;
						$defenders[0][3] = 0;
					}
				}				
			} else {
				if ( $db_pf->f("alliance_id") <> 0 ) {
					$db_pf->query("select * from forces where sector_id = '$sector_id' and alliance_id = '$defender_alliance_id'");
				
					$x = 0;
					while ( $db_pf->next_record() ) {
						$defenders[$x][0] = 'f';
						$defenders[$x][1] = $db_pf->f("forces_id");
						$defenders[$x][2] = 0;
						$defenders[$x][3] = 0;
						$x = $x + 1;
					}
				} else {
					$defenders[0][0] = $type;
					$defenders[0][1] = $id;
					$defenders[0][2] = 0;
					$defenders[0][3] = 0;
				}
			}
		}		
	}	
	
	if ( $type == 's' ) {
		if ( $defender_alliance_id <> 0 ) {
			$alliance_sql = get_alliance_sql($defender_alliance_id, get_treaties($defender_alliance_id, 'Mutual Assistance'));
			$alliance_sql = $alliance_sql . " and players.alliance_id <> '" . $attacker_alliance_id . "'";
				
			if ( $defender_sector_id == 0 and $defender_planet_id <> 0 ) {
				$db_ps->query("select players.player_id, players.alliance_id, players.alignment, players.newturnsleft, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
					where (" . $alliance_sql . ") and ships.player_id = players.player_id and ships.planet_id = '$defender_planet_id' and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id");
			} elseif ( $defender_sector_id <> 0 ) {
				$db_ps->query("select players.player_id, players.alliance_id, players.alignment, players.newturnsleft, ships.sector_id, ship_technology.player_id, ship_technology.cloak_active, player_config.player_id, player_config.group_combat_forces, player_config.group_combat_ships, player_config.group_combat_planets from players, ships, player_config, ship_technology
					where (" . $alliance_sql . ") and ships.player_id = players.player_id and ships.sector_id = '$defender_sector_id' and players.player_id = player_config.player_id and players.player_id = ship_technology.player_id");
			}
	
			$x = 0;
			
			while ( $db_ps->next_record() ) {
				$process_merchant = 1;

				if ( $defender_sector_id <> 0 ) {
					if ( $db_ps->f("group_combat_ships") == 'f' and $db_ps->f("player_id") <> $id ) {
						$process_merchant = 0;
					}
				}

				if ( $process_merchant ) {				
					$defenders[$x][0] = "s";
					$defenders[$x][1] = $db_ps->f("player_id");
					$defender_type = $defenders[$x][0];
					$defender_id = $defenders[$x][1];
				
					if ( $imperial_beacon ) {
						$defender_ship->get_ship($defender_id);

						if ( (int) (($defender_ship->combined_damage / 40) + ($defender_ship->f("combatcurrent") / 50)) < 1 ) {
							$offense = 1;
						} else {
							$offense = (int) (($defender_ship->combined_damage / 40) + ($defender_ship->f("combatcurrent") / 50));
						}

						$protected = 3;
				
						if ( $db_ps->f("alignment") >= 150 and $db_ps->f("alignment") < 300 ) {
							$protected = 4;
						} elseif( $db_ps->f("alignment") >= 300 ) {
							$protected = 5;
						} elseif( $db_ps->f("alignment") <= -150 and $db_ps->f("alignment") > -300 ) {
							$protected = 2;
						} elseif( $db_ps->f("alignment") < -300 ) {
							$protected = 1;
						}

						if ( $offense > $protected ) {
							$defenders[$x][2] = 0;
						} else {
							$defenders[$x][2] = 1;
						}				
					} else {
						$defenders[$x][2] = 0;
					}					
		
					if ( $db_ps->f("newturnsleft") > 0 ) {
						$defenders[$x][3] = 1;
					} else {
						$defenders[$x][3] = 0;
					}

					$x = $x + 1;
				}
			}
			
			if ( $defender_sector_id <> 0 ) {
				$db_pf->query("select * from forces where alliance_id = '$defender_alliance_id' and sector_id = '$sector_id' and combat > 0");

				while ( $db_pf->next_record() ) {
					$defenders[$x][0] = "f";
					$defenders[$x][1] = $db_pf->f("forces_id");
					$defenders[$x][2] = 0;
					$defenders[$x][3] = 0;
					$x = $x + 1;
				}
			}
		} else {
			$x = 0;
			
			$defenders[$x][0] = "s";
			$defenders[$x][1] = $id;			
			$defender_type = "s";
			$defender_id = $id;

			$db_ps->query("select players.player_id, players.alliance_id, players.alignment, players.newturnsleft, ships.sector_id from players, ships
				where players.player_id = '$defender_id' and ships.player_id = players.player_id and ships.sector_id = '$defender_sector_id'");

			if ( $db_ps->nf() > 0 ) {		
				if ( $imperial_beacon ) {
					$defender_ship->get_ship($defender_id);

					if ( (int) (($defender_ship->combined_damage / 40) + ($defender_ship->f("combatcurrent") / 50)) < 1 ) {
						$offense = 1;
					} else {
						$offense = (int) (($defender_ship->combined_damage / 40) + ($defender_ship->f("combatcurrent") / 50));
					}

					$protected = 3;
			
					if ( $db_ps->f("alignment") >= 150 and $db_ps->f("alignment") < 300 ) {
						$protected = 4;
					} elseif( $db_ps->f("alignment") >= 300 ) {
						$protected = 5;
					} elseif( $db_ps->f("alignment") <= -150 and $db_ps->f("alignment") > -300 ) {
						$protected = 2;
					} elseif( $db_ps->f("alignment") < -300 ) {
						$protected = 1;
					}

					if ( $offense > $protected ) {
						$defenders[$x][2] = 0;
					} else {
						$defenders[$x][2] = 1;
					}				
				} else {
					$defenders[$x][2] = 0;
				}				
	
				if ( $db_ps->f("newturnsleft") > 0 ) {
					$defenders[$x][3] = 1;
				} else {
					$defenders[$x][3] = 0;
				}

				$x = $x + 1;

				if ( $defender_sector_id <> 0 ) {				
					$db_pf->query("select * from forces where player_id = '$defender_id' and sector_id = '$sector_id' and combat > 0");
					$db_pf->next_record();

					if ( $db_pf->nf() > 0 ) {						
						$defenders[$x][0] = "f";
						$defenders[$x][1] = $db_pf->f("forces_id");
						$defenders[$x][2] = 0;
						$defenders[$x][3] = 0;
						$x = $x + 1;
					}
				}
			} else {	
				array_splice($defenders, 0, 1, 0);				
			}
		}
	}

	#implode here
	for ($i = 0; $i <= count($attackers) - 1; $i++) {
		if ( $i > 0 ) {
			$comma = ',';
		} else {
			$comma = '';
		}

		$attacker_types = $attacker_types . $comma . $attackers[$i][0];
		$attacker_ids = $attacker_ids . $comma . $attackers[$i][1];
		$attacker_imperial_protections = $attacker_imperial_protections . $comma . $attackers[$i][2];
		$attacker_newbie_protections = $attacker_newbie_protections . $comma . $attackers[$i][3];
	}
	
	#implode here
	for ($i = 0; $i <= count($defenders) - 1; $i++) {
		if ( $i > 0 ) {
			$comma = ',';
		} else {
			$comma = '';
		}

		$defender_types = $defender_types . $comma . $defenders[$i][0];
		$defender_ids = $defender_ids . $comma . $defenders[$i][1];
		$defender_imperial_protections = $defender_imperial_protections . $comma . $defenders[$i][2];
		$defender_newbie_protections = $defender_newbie_protections . $comma . $defenders[$i][3];
	}

	if ( $player->f("newturnsleft") > 0 and $type == 'p' ) {
		$returnto = "planet_orbit";
	} elseif ( $player->f("turns") <= 4 ) {
		$returnto = "current";	
	} else {
		$date = time();
		$query = "insert into attacks (attacker_types, attacker_ids, attacker_imperial_protections, attacker_newbie_protections, defender_types, defender_ids, defender_imperial_protections, defender_newbie_protections, sector_id, date, defender_alliance_id, map_id)
			values('$attacker_types', '$attacker_ids', '$attacker_imperial_protections', '$attacker_newbie_protections', '$defender_types', '$defender_ids', '$defender_imperial_protections', '$defender_newbie_protections', '$sector_id', '$date', '$defender_alliance_id', '$map_id')";

		$db->record_oid();	
		$db->query($query);

		$query = sprintf("select attack_id from attacks where oid = '%s'", $db->Last_OID);
		$db->query($query);
		$db->next_record();
		
		$attack_id = $db->f("attack_id");
	}
	
	if ($returnto == "results")  {
		if ( $type == 's' ) {
			$newurl = $sess->url(URL . "attack_delay.php?id=" . $attack_id);
			header("Location: $newurl");	
		} else {
			$newurl = $sess->url(URL . "current_sector_attack_results.php?id=" . $attack_id);
			header("Location: $newurl");	
		}
	} elseif ($returnto == "preattack")  {
		$newurl = $sess->url(URL . "current_sector_attack_results.php?id=" . $attack_id);
		header("Location: $newurl");	
	} elseif ($returnto == "current")  {
		$newurl = $sess->url(URL . "current_sector_attack.php?id=" . $attack_id);
		header("Location: $newurl");	
	} elseif ($returnto == "planet_land")  {
		$newurl = $sess->url(URL . "planet_land.php");
		header("Location: $newurl");	
	} elseif ($returnto == "planet_orbit")  {
		$newurl = $sess->url(URL . "planet_orbit.php?error=1");
		header("Location: $newurl");	
	}
}

page_close();
?>