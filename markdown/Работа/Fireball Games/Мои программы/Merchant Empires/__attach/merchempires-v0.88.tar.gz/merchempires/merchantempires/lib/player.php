<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Player extends ME_DB_Xml {
  var $id = 0;
	var $dirty_fields = array();	

  function get_player($id) {
		$this->connect();
		$query = sprintf("select * from players where player_id = '%s'", $id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();		
		$this->id = $this->f("player_id");		
				
    return $this->Query_ID;
  }

  function get_new_player($user_id, $game_id, $race) {
  	$this->connect();
  	$query = "insert into players (user_id, game_id, race, public_player_id) values ('$user_id', '$game_id', '$race', nextval('public_player_id_game_" . $game_id . "'))";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   	
		# get the player id so the save method will know what to save to
   	$db = new ME_DB;
		$db->query("select * from player_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;
	  $this->set_game_id($game_id);
	  $this->set_race($race);

		# get public player id
		$db->query("select * from public_player_id_game_" . $game_id);
		$db->next_record();
	  $this->set_public_player_id($db->f("last_value"));

	  $query = sprintf("select * from players where player_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
   	# find the new player's starting sector
		$db->query("select * from games where game_id = '$game_id'");
		$db->next_record();
		
		if ($race == $db->f("namerace_1")) {
			$sector_id = $db->f("startsectrace_1");
			$this->set_race_number(1);
		} elseif ($race == $db->f("namerace_2")) {
			$sector_id = $db->f("startsectrace_2");
			$this->set_race_number(2);
		} elseif ($race == $db->f("namerace_3")) {
			$sector_id = $db->f("startsectrace_3");
			$this->set_race_number(3);
		} elseif ($race == $db->f("namerace_4")) {
			$sector_id = $db->f("startsectrace_4");
			$this->set_race_number(4);
		} elseif ($race == $db->f("namerace_5")) {
			$sector_id = $db->f("startsectrace_5");
			$this->set_race_number(5);
		} elseif ($race == $db->f("namerace_6")) {
			$sector_id = $db->f("startsectrace_6");
			$this->set_race_number(6);
		} elseif ($race == $db->f("namerace_7")) {
			$sector_id = $db->f("startsectrace_7");
			$this->set_race_number(7);
		}

		# get map id
		$db->query("select * from sectors where sector_id = '$sector_id'");
		$db->next_record();
		$map_id = $db->f("map_id");

		# get map id
		$db->query("select * from maps where map_id = '$map_id'");
		$db->next_record();
		$map_rank = $db->f("map_rank");

		if ( $map_rank == 1 ) {
			$query = "insert into player_maps (player_id, map_1, map_1_id) values ('$str', '$sector_id', '$map_id')";
		} elseif ( $map_rank == 2 ) {
			$query = "insert into player_maps (player_id, map_2, map_2_id) values ('$str', '$sector_id', '$map_id')";
		} elseif ( $map_rank == 3 ) {
			$query = "insert into player_maps (player_id, map_3, map_3_id) values ('$str', '$sector_id', '$map_id')";
		} elseif ( $map_rank == 4 ) {
			$query = "insert into player_maps (player_id, map_4, map_4_id) values ('$str', '$sector_id', '$map_id')";
		} elseif ( $map_rank == 5 ) {
			$query = "insert into player_maps (player_id, map_5, map_5_id) values ('$str', '$sector_id', '$map_id')";
		} elseif ( $map_rank == 6 ) {
			$query = "insert into player_maps (player_id, map_6, map_6_id) values ('$str', '$sector_id', '$map_id')";
		} elseif ( $map_rank == 7 ) {
			$query = "insert into player_maps (player_id, map_7, map_7_id) values ('$str', '$sector_id', '$map_id')";
		}

		$db->query($query);

		$race_id = $this->Race_number;
		$query = "insert into council_votes (player_id, game_id, race_id) values ('$str', '$game_id', '$race_id')";
		$db->query($query);

		# set some default values
   	$ship = new ME_Ship;
		$ship->get_new_ship($this->id, $sector_id);
		$ship->set_type("Merchant Tug");
		$ship->set_shieldmax(250);
		$ship->set_shieldcurrent(150);
		$ship->set_armormax(325);
		$ship->set_armorcurrent(75);
		$ship->set_minesmax(5);
		$ship->set_minescurrent(0);
		$ship->set_combatmax(15);
		$ship->set_combatcurrent(0);
		$ship->set_scoutmax(0);
		$ship->set_scoutcurrent(0);
		$ship->set_cargocurrent(40);
		$ship->set_cargomax(120);
		$ship->set_powermax(40);
		$ship->set_powercurrent(15);
		$ship->set_type_id(1);		
		$ship->set_turns_per_sector(2);
		$ship->set_hardpoints(2);
		$ship->set_last_move_date(time());
		$ship->save();
		
		$weapons = new ME_Weapons;
		$weapons->get_new_weapons($ship->id);
		$weapons->set_player_id($this->id);
		$weapons->set_weapon_1_id(6);
		$weapons->set_weapon_1_name("Laser");
		$weapons->set_weapon_1_shield_damage(25);
		$weapons->set_weapon_1_armor_damage(25);
		$weapons->save();

		$technology = new ME_Technology;
		$technology->get_new_technology($ship->id);
		$technology->set_player_id($this->id);		
		$technology->save();

		$player_config = new ME_Player_config;
		$player_config->get_new_player_config($this->id);
		$player_config->save();

		$player_score = new ME_Player_score;
		$player_score->get_new_player_score($this->id);
		$player_score->save();

		$this->next_record();	
   	return $this->Query_ID;
  }

  function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update players set ";		
			$i = 1;			

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}

				$i++;
			}
					
			$str = $str . " where player_id = '$this->id'";
			$db->query($str);
			
			$this->dirty_fields = array();			
		}
  }

	function set_public_player_id($n) {		
		$this->dirty_fields["public_player_id"] = $n;
  }

  function set_name($n) {		
		$this->dirty_fields["name"] = $n;
  }

  function set_race($n) {
		$this->dirty_fields["race"] = $n;
  }

  function set_game_id($n) {
		$this->dirty_fields["game_id"] = $n;
  }

  function set_turns($n) {				
		$this->dirty_fields["turns"] = $n;
  }

  function set_new_turns_left($n) {				
		$this->dirty_fields["newturnsleft"] = $n;		
  }

  function set_credits($n) {
		$this->dirty_fields["credits"] = $n;
  }

  function set_experience($n) {
		$this->dirty_fields["experience"] = $n;
  }

  function set_alignment($n) {
		if ( $n < -500 ) {
			$this->dirty_fields["alignment"] = -500;
		} elseif ( $n > 500 ) {
			$this->dirty_fields["alignment"] = 500;
		} else {
			$this->dirty_fields["alignment"] = $n;
		}
  }

  function set_rank($n) {
		$this->dirty_fields["rank"] = $n;
  }

	function set_level($n) {
		$this->dirty_fields["level"] = $n;
  }

	function set_alliance_id($n) {
		$this->dirty_fields["alliance_id"] = $n;
  }

	function set_alliance_name($n) {
		$this->dirty_fields["alliance_name"] = $n;
  }

	function set_relationrace_1($n) {
		$this->dirty_fields["relationrace_1"] = $n;
  }
	
	function set_relationrace_2($n) {
		$this->dirty_fields["relationrace_2"] = $n;
  }

	function set_relationrace_3($n) {
		$this->dirty_fields["relationrace_3"] = $n;
  }

	function set_relationrace_4($n) {
		$this->dirty_fields["relationrace_4"] = $n;
  }

	function set_relationrace_5($n) {
		$this->dirty_fields["relationrace_5"] = $n;
  }

	function set_relationrace_6($n) {
		$this->dirty_fields["relationrace_6"] = $n;
  }

	function set_relationrace_7($n) {
		$this->dirty_fields["relationrace_7"] = $n;
  }

	function set_race_number($n) {
		$this->dirty_fields["race_number"] = $n;
  }
	
	function set_bank_account($n) {
		$this->dirty_fields["bank_account"] = $n;
  }

	function set_unclaimed_bounties($n) {
		$this->dirty_fields["unclaimed_bounties"] = $n;
  }

	function set_unclaimed_ug_bounties($n) {
		$this->dirty_fields["unclaimed_ug_bounties"] = $n;
  }

	function set_unclaimed_military_bounties($n) {
		$this->dirty_fields["unclaimed_military_bounties"] = $n;
  }

	function set_success_experience($n) {
		$this->dirty_fields["success_experience"] = $n;
  }
	
	function set_dead($n) {	
		$this->dirty_fields["dead"] = $n;
  }
 }
?>