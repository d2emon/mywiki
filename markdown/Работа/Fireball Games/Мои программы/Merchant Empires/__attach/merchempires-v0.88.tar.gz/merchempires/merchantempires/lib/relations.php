<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Relations extends ME_DB {
  var $Player_id = 0;
	var $Game_id = 0;
  var $Race_number = 0;

	var $Relationsrace_1 = array();
	var $Relationsrace_2 = array();
	var $Relationsrace_3 = array();
	var $Relationsrace_4 = array();
	var $Relationsrace_5 = array();
	var $Relationsrace_6 = array();
	var $Relationsrace_7 = array();
	
	function initialize($game_id, $race_number) {
		$this->connect();
		$query = sprintf("select * from games where game_id = '%s'", $game_id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
			$this->halt("Invalid SQL: ".$Query_String);
    }
			
		$this->next_record();

		$this->Game_id = $game_id;
		$this->Race_number = $race_number;
		
		$this->Relationsrace_1 = explode(",", $this->f("relationsrace_1"));		
		$this->Relationsrace_2 = explode(",", $this->f("relationsrace_2"));
		$this->Relationsrace_3 = explode(",", $this->f("relationsrace_3"));
		$this->Relationsrace_4 = explode(",", $this->f("relationsrace_4"));
		$this->Relationsrace_5 = explode(",", $this->f("relationsrace_5"));
		$this->Relationsrace_6 = explode(",", $this->f("relationsrace_6"));
		$this->Relationsrace_7 = explode(",", $this->f("relationsrace_7"));

   	return $this->Query_ID;
  }
	
	function save() {

		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_1) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_1 = $relrace_1 . $comma . $this->Relationsrace_1[$i];
		}

		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_2) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_2 = $relrace_2 . $comma . $this->Relationsrace_2[$i];
		}

		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_3) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_3 = $relrace_3 . $comma . $this->Relationsrace_3[$i];
		}
	
		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_4) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_4 = $relrace_4 . $comma . $this->Relationsrace_4[$i];
		}

		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_5) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_5 = $relrace_5 . $comma . $this->Relationsrace_5[$i];
		}

		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_6) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_6 = $relrace_6 . $comma . $this->Relationsrace_6[$i];
		}

		#implode here
		for ($i = 0; $i <= count($this->Relationsrace_7) - 1; $i++) {
			if ( $i > 0 ) {
				$comma = ',';
			} else {
				$comma = '';
			}

			$relrace_7 = $relrace_7 . $comma . $this->Relationsrace_7[$i];
		}

 		$db = new ME_DB;
		$query = sprintf("update games set relationsrace_1 = '%s', relationsrace_2 = '%s', relationsrace_3 = '%s',
			relationsrace_4 = '%s', relationsrace_5 = '%s', relationsrace_6 = '%s', relationsrace_7 = '%s'
			where game_id = '%s'",
			$relrace_1, $relrace_2, $relrace_3, $relrace_4, $relrace_5, $relrace_6, $relrace_7, $this->Game_id);

		$db->query($query);
  }

	function get_relations_1() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[0];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[0];
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[0];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[0];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[0];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[0];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[0];
		}
  }

	function set_relations_1($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[0] = $n;				
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[0] = $n;
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[0] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[0] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[0] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[0] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[0] = $n;
		}
  }

	function get_relations_2() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[1];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[1];			
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[1];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[1];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[1];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[1];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[1];
		}
  }

	function set_relations_2($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[1] = $n;
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[1] = $n;						
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[1] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[1] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[1] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[1] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[1] = $n;
		}
  }		

		function get_relations_3() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[2];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[2];			
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[2];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[2];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[2];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[2];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[2];
		}
  }

	function set_relations_3($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[2] = $n;
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[2] = $n;						
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[2] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[2] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[2] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[2] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[2] = $n;
		}
  }		

		function get_relations_4() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[3];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[3];			
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[3];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[3];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[3];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[3];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[3];
		}
  }

	function set_relations_4($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[3] = $n;
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[3] = $n;						
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[3] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[3] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[3] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[3] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[3] = $n;
		}
  }		

		function get_relations_5() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[4];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[4];			
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[4];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[4];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[4];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[4];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[4];
		}
  }

	function set_relations_5($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[4] = $n;
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[4] = $n;						
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[4] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[4] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[4] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[4] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[4] = $n;
		}
  }		

		function get_relations_6() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[5];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[5];			
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[5];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[5];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[5];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[5];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[5];
		}
  }

	function set_relations_6($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[5] = $n;
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[5] = $n;						
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[5] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[5] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[5] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[5] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[5] = $n;
		}
  }		

	function get_relations_7() {
		if ( $this->Race_number == 1 ) {
			return $this->Relationsrace_1[6];
		} elseif ( $this->Race_number == 2 ) {
			return $this->Relationsrace_2[6];			
		} elseif ( $this->Race_number == 3 ) {
			return $this->Relationsrace_3[6];
		} elseif ( $this->Race_number == 4 ) {
			return $this->Relationsrace_4[6];
		} elseif ( $this->Race_number == 5 ) {
			return $this->Relationsrace_5[6];
		} elseif ( $this->Race_number == 6 ) {
			return $this->Relationsrace_6[6];
		} elseif ( $this->Race_number == 7 ) {
			return $this->Relationsrace_7[6];
		}
  }

	function set_relations_7($n) {
		if ( $this->Race_number == 1 ) {
			$this->Relationsrace_1[6] = $n;
		} elseif ( $this->Race_number == 2 ) {
			$this->Relationsrace_2[6] = $n;						
		} elseif ( $this->Race_number == 3 ) {
			$this->Relationsrace_3[6] = $n;
		} elseif ( $this->Race_number == 4 ) {
			$this->Relationsrace_4[6] = $n;
		} elseif ( $this->Race_number == 5 ) {
			$this->Relationsrace_5[6] = $n;
		} elseif ( $this->Race_number == 6 ) {
			$this->Relationsrace_6[6] = $n;
		} elseif ( $this->Race_number == 7 ) {
			$this->Relationsrace_7[6] = $n;
		}
  }		
}
?>
