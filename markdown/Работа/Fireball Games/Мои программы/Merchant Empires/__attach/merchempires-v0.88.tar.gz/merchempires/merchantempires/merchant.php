<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/player_score.php");
include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Merchant Status</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "merchant");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "merchant");	
echo $db->get_transform("./xslt/menu_top_merchant.xslt", "");

$db = new ME_DB;
$query = sprintf("select * from auth_user where user_id = '%s'", $user->id);
$db->query($query);
$db->next_record();
$ranking = $db->f("ranking");

?>
<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td class=clsNrmTxt valign=top width=230>
									<font color=#3333FF face=arial,helvetica,swiss size=3><b>Ship Type</font></b><br>
									&nbsp;<?php
                  echo $ship->f("type");
									echo "<br>" . "&nbsp;Turns per sector: " . $ship->f("turns_per_sector");
									echo "<br>" . "&nbsp;Tactical Defense: " . get_tactical_defense($ship, $player->f("level"));

?>
									<br>&nbsp;Technology:<br><?php

$query = sprintf("select * from ship_types where ship_type_id = '%s'", $ship->f("type_id"));
$db->query($query);
$db->next_record();
echo "<table BORDER=0 cellpadding=1 cellspacing=1>";
echo "<tr><td class=clsNrmTxt>";
if ( $db->f("scanner") == 't' ) {
	$str = "Yes";
} else {
  $str =  "No";
};
echo "<td class=clsNrmTxt>&nbsp;&nbsp;Scanner:</td><td class=clsNrmTxt>&nbsp;" . $str . "</td>";
echo "</tr><tr><td class=clsNrmTxt>";
if ( $db->f("illusion") == 't' ) {
	$str = "Yes";
} else {
  $str =  "No";
};
echo "<td class=clsNrmTxt>&nbsp;&nbsp;Illusion generator:</td><td class=clsNrmTxt>&nbsp;" . $str . "</td>";
echo "</tr><tr><td class=clsNrmTxt>";
if ( $db->f("jump") == 't' ) {
	$str = "Yes";
} else {
  $str =  "No";
};
echo "<td class=clsNrmTxt>&nbsp;&nbsp;Jump drive:</td><td class=clsNrmTxt>&nbsp;" . $str . "</td>";
echo "</tr><tr><td class=clsNrmTxt>";
if ( $db->f("galaxy_jump") == 't' ) {
	$str = "Yes";
} else {
  $str =  "No";
};
echo "<td class=clsNrmTxt>&nbsp;&nbsp;Galaxy jump:</td><td class=clsNrmTxt>&nbsp;" . $str . "</td>";
echo "</tr><tr><td class=clsNrmTxt>";
if ( $db->f("cloak") == 't' ) {
	$str = "Yes";
} else {
  $str =  "No";
};
echo "<td class=clsNrmTxt>&nbsp;&nbsp;Cloak:</td><td class=clsNrmTxt>&nbsp;" . $str . "</td>";
echo "</tr></table>";

echo "<br><font color=#3333FF face=arial,helvetica,swiss size=3><b>Finances</font></b><br>&nbsp;Personal account: " . $player->f("bank_account");

if ( $player->f("alliance_id") <> 0 ) {
	$db_2 = new ME_DB;
	$query = sprintf("select * from accounts where alliance_id = '%s'", $player->f("alliance_id"));
	$db_2->query($query);
	$db_2->next_record();

	if ( $db_2->nf() > 0 ) {			
		echo "<br>&nbsp;Alliance account: ";
		echo $db_2->f("balance") . "<br><br>";
	} else {
		echo "<br>";
	}
} else {
	echo "<br>";
}

$sector_id = $ship->f("sector_id");

$imperial_beacon = 0;
$db->query("SELECT * from locations where sector_id = '$sector_id' and type = 'Authority'");
if ( $db->nf() > 0 ) {
	$imperial_beacon = 1;
}

if ( (int) (($ship->combined_damage / 40) + ($ship->f("combatcurrent") / 50)) < 1 ) {
	$offense = 1;
} else {
	$offense = (int) (($ship->combined_damage / 40) + ($ship->f("combatcurrent") / 50));
}
	
$protected = 3;
$alignment = $player->f("alignment");
				
if ( $alignment >= 150 and $alignment < 300 ) {
	$protected = 4;
} elseif( $alignment >= 300 ) {
	$protected = 5;
} elseif( $alignment <= -150 and $alignment > -300 ) {
	$protected = 2;
} elseif( $alignment < -300 ) {
	$protected = 1;
}

if ( $player->f("newturnsleft") > 0 or ($offense <= $protected and $imperial_beacon) ) {
	echo "<font color=#3333FF face=arial,helvetica,swiss size=3><br><b>Protection</font></b><br>";

	if ( $offense <= $protected and $imperial_beacon ) {
		echo "&nbsp;Imperial Protection<br>";
	}

	if ( $player->f("newturnsleft") > 0 ) {
		echo "&nbsp;Newbie Protection";
		echo "&nbsp;(" . "<a href=";
		echo $sess->url(URL . "merchant_protection_leave.php");
		echo ">Leave</a>)";
	}
}
?>
								</td>
								<td class=clsNrmTxt valign=top width=230>
									<font color=#3333FF face=arial,helvetica,swiss size=3>
									<b>Relations</b></font><br><?php
$db_g = new ME_DB;
$db_g->query("select * from games where game_id = '$game_id'");
$db_g->next_record();

echo "<table BORDER=0 cellpadding=0 cellspacing=0>";

$active_races = array();
$active_races = explode(",", $db_g->f("active_races"));

for ($i = 0; $i <= count($active_races) - 1; $i++) {
	echo "<tr>";
	echo "<td class=clsNrmTxt>&nbsp;" . $db_g->f("namerace_" . $active_races[$i]) . "  </td><td>&nbsp;" . $player->f("relationrace_" . $active_races[$i]) . "</td>";
	echo "</tr>";
}


echo "</table><br>";

$race = $player->f("race");
$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
$db->query($query);

$council_member = 0;

while ( $db->next_record() ) {
	if ( $db->f("player_id") == $player->f("player_id") ) {
		$council_member = 1;
	}	
}
?>
									<font color=#3333FF face=arial,helvetica,swiss size=3><b>Politics</b></font><br>
									&nbsp;You are<?php

if ( ! ($council_member) ) {
	echo " not ";
}
?>
									a member of the <a href=<?php
echo $sess->url(URL . "rankings_council.php");
?>
									>ruling council</a>.<br><br>
									<font color=#3333FF face=arial,helvetica,swiss size=3><b>User Ranking</b></font><br>
									&nbsp;You are ranked as a <?php

echo $ranking . ".";
?>
									<br><br>									
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<br>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td class=clsNrmTxt>

					<table width=100%><tr><td valign=top class=clsNrmTxt width=50%>
						<font color=#3333FF face=arial,helvetica,swiss size=3><b>Economic Stats:</b></font><?php
						
$player_score = new ME_Player_score;
$player_score->get_player_score($player_id);

echo "<br>" . "&nbsp;Credits from goods sold: " . $player_score->f("credits_from_sales");
echo "<br>" . "&nbsp;Credits spent on goods: " . $player_score->f("credits_from_buys");
echo "<br>" . "&nbsp;Total trades: " . $player_score->f("total_trades");

echo "<br><br>" . "&nbsp;Goods traded:";

while (list($key, $val) = each($player_score->goods_traded)) {
	if ( $val > 0 ) {
		echo "<br>" . "&nbsp;&nbsp;" . $key . ": " . $val;				
	}
}				 	

?>
							<br>
					</td>
					<td valign=top width=50% class=clsNrmTxt>
						<font color=#3333FF face=arial,helvetica,swiss size=3><b>Combat Stats:</b></font><?php						

echo "<br>" . "&nbsp;Credits captured: " . $player_score->f("credits_from_kills");
echo "<br>" . "&nbsp;Credits from bounties: " . $player_score->f("credits_from_bounties");
echo "<br>" . "&nbsp;Credits from military bounties: " . $player_score->f("credits_from_bounties_military");
echo "<br>" . "&nbsp;Total kills: " . $player_score->f("total_kills");

echo "<br><br>" . "&nbsp;Kills by level:";

while (list($key, $val) = each($player_score->kills_by_level)) {
	if ( $val > 0 ) {
		echo "<br>" . "&nbsp;&nbsp;" . $key . ": " . $val;				
	}
}	

?>
							<br>
					</td></tr></table>

					</td>
				</tr>	
			</table>
		<td>
  </tr>
</table><br>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td class=clsNrmTxt><form name=update_log action=<?php

echo $sess->url(URL . "merchant_update.php");
?>
					method=post>
						<br><br><?php

$db = new ME_DB;
$query = sprintf("select player_id, log from players where player_id = '%s'", $player->f("player_id"));
$db->query($query);
$db->next_record();

echo "<center><textarea size=600 NAME=log rows=5 cols=48>";
echo $db->f("log") . "</textarea>";

echo "<br><br><input type=hidden name=update_log value=Update>";
echo "<a href='javascript:document.update_log.submit()'><img border=0 src='./images/form/update-off.png'></a></center>";

?>
							<br>
						</form>
					</td>
				</tr>	
			</table>
		<td>
  </tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "There will be a short delay before your merchant is prepared to leave newbie protection.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "The merchant log is limited to 2000 characters.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>