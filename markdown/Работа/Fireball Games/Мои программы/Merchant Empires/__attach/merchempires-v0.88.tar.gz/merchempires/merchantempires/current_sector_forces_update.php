<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");
$public_sector_id = $ship->f("public_sector_id");
$id = (int) $id;
$amount = (int) $amount;
	
switch ($action) {
	case "sub":
		switch ($type) {
			case "1":
				$returnto = "current_sector";
  		
				if ( $ship->f("minescurrent") + $amount > $ship->f("minesmax") ) {
     		 	$error = 1;
					break;	
     		}

				if ( $amount < 0 ) {
					$error = 11;
					break;
				}

				$db = new ME_DB;
				$query = "select * from forces where forces_id = '$id' and sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();				
				
				if ( $db->f("mine") == 0 ) {
					$error = 2;
					break;
				}

				if ( $db->f("mine") < $amount ) {
					$error = 10;
					break;
				}

				if ( $db->f("alliance_id") <> $player->f("alliance_id") or ($player->f("alliance_id") == 0 and $db->f("player_id") <> $player->f("player_id")) ) {
					$error = 3;
					break;
				}

				$new_mines = $ship->f("minescurrent") + $amount;
				$ship->set_minescurrent($new_mines);
				$ship->save();

				$mines = $db->f("mine") - $amount;
				$scout = $db->f("scout");
				$combat = $db->f("combat");
				$forces_id = $db->f("forces_id");

				if ( $scout == 0 and $combat == 0 and $mines == 0 ) {
					$query = "delete from forces where forces_id = '$forces_id'";
					$db->query($query);
				} else {
					$query = "update forces set scout = '$scout', combat = '$combat',
						mine = '$mines' where forces_id = '$forces_id'";
					$db->query($query);
				}

				break;				

			case "2":
				$returnto = "current_sector";
  		
				if ( $ship->f("combatcurrent") + $amount > $ship->f("combatmax") ) {
     		 	$error = 1;
					break;	
     		}

				if ( $amount < 0 ) {
					$error = 11;
					break;
				}

				$db = new ME_DB;
				$query = "select * from forces where forces_id = '$id' and sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();

				if ( $db->f("combat") == 0 ) {
					$error = 2;
					break;
				}

				if ( $db->f("combat") < $amount ) {
					$error = 10;
					break;
				}

				if ( $db->f("alliance_id") <> $player->f("alliance_id") or ($player->f("alliance_id") == 0 and $db->f("player_id") <> $player->f("player_id")) ) {
					$error = 3;
					break;
				}

				$new_combat = $ship->f("combatcurrent") + $amount;
				$ship->set_combatcurrent($new_combat);
				$ship->save();
				
				$combat = $db->f("combat") - $amount;
				$scout = $db->f("scout");
				$mines = $db->f("mine");
				$forces_id = $db->f("forces_id");

				if ( $scout == 0 and $combat == 0 and $mines == 0 ) {
					$query = "delete from forces where forces_id = '$forces_id'";
					$db->query($query);
				} else {
					$query = "update forces set scout = '$scout', combat = '$combat',
						mine = '$mines' where forces_id = '$forces_id'";
					$db->query($query);
				}

				break;			
	
			case "3":
				$returnto = "current_sector";
				
				if ( $ship->f("scoutcurrent") + $amount > $ship->f("scoutmax") ) {
     		 	$error = 1;
					break;	
     		}

				if ( $amount < 0 ) {
					$error = 11;
					break;
				}
  		
				$db = new ME_DB;
				$query = "select * from forces where forces_id = '$id' and sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();

				if ( $db->f("scout") == 0 ) {
					$error = 2;
					break;
				}

				if ( $db->f("scout") < $amount ) {
					$error = 10;
					break;
				}

				if ( $db->f("alliance_id") <> $player->f("alliance_id") or ($player->f("alliance_id") == 0 and $db->f("player_id") <> $player->f("player_id")) ) {
					$error = 3;
					break;
				}

				$new_scout = $ship->f("scoutcurrent") + $amount;
				$ship->set_scoutcurrent($new_scout);
				$ship->save();
				
				$scout = $db->f("scout") - $amount;
				$mines = $db->f("mine");
				$combat = $db->f("combat");
				$forces_id = $db->f("forces_id");

				if ( $scout == 0 and $combat == 0 and $mines == 0 ) {
					$query = "delete from forces where forces_id = '$forces_id'";
					$db->query($query);
				} else {
					$query = "update forces set scout = '$scout', combat = '$combat',
						mine = '$mines' where forces_id = '$forces_id'";
					$db->query($query);
				}

				break;
		}

		break;

  case "add":
		switch ($type) {
			case "1":
				$returnto = "current_sector";
  		
				if ( $ship->f("minescurrent") - $amount < 0 ) {
     		 	$error = 21;
					break;	
     		}

				if ( $amount < 0 ) {
					$error = 11;
					break;
				}

				$db = new ME_DB;
				$query = "select * from forces where forces_id = '$id' and sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();
				$new_sector_mines = $db->f("mine") + $amount;

				if ( $new_sector_mines > 50 ) {
					$error = 9;
					break;	
				}

				$new_mines = $ship->f("minescurrent") - $amount;
				$ship->set_minescurrent($new_mines);
				$ship->save();

				$query = "update forces set mine = '$new_sector_mines' where forces_id = '$id'";
				$db->query($query);
				break;				

			case "2":
				$returnto = "current_sector";
  		
				if ( $ship->f("combatcurrent") - $amount < 0 ) {
     		 	$error = 21;
					break;	
     		}

				if ( $amount < 0 ) {
					$error = 11;
					break;
				}

				$db = new ME_DB;
				$query = "select * from forces where forces_id = '$id' and sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();
				$new_sector_combat = $db->f("combat") + $amount;

				if ( $new_sector_combat > 50 ) {
					$error = 9;
					break;	
				}

				$new_combat = $ship->f("combatcurrent") - $amount;
				$ship->set_combatcurrent($new_combat);
				$ship->save();

				$query = "update forces set combat = '$new_sector_combat' where forces_id = '$id'";
				$db->query($query);
				break;			
	
			case "3":
				$returnto = "current_sector";
				
				if ( $ship->f("scoutcurrent") - $amount < 0 ) {
     		 	$error = 21;
					break;	
     		}

				if ( $amount < 0 ) {
					$error = 11;
					break;
				}

				$db = new ME_DB;
				$query = "select * from forces where forces_id = '$id' and sector_id = '$sector_id'";
				$db->query($query);
        $db->next_record();
				$new_sector_scout = $db->f("scout") + $amount;
  		
				if ( $new_sector_scout > 10 ) {
					$error = 9;
					break;	
				}

				$new_scout = $ship->f("scoutcurrent") - $amount;
				$ship->set_scoutcurrent($new_scout);
				$ship->save();
				
				$query = "update forces set scout = '$new_sector_scout' where forces_id = '$id'";
				$db->query($query);
				break;
		}

		break;
}

if ( $error ) {
	if ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "current_sector")  {
		$newurl = $sess->url(URL . "current_sector.php");
		header("Location: $newurl");	
	}
}

page_close();
?>
