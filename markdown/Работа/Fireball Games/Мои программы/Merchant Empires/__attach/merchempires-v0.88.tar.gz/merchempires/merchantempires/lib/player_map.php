<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

function save_player_map($map_id, $player, $sector_id) {
	$player_id = $player->f("player_id");
	$alliance_id = $player->f("alliance_id");

	if ( $player->f("alliance_id") <> 0 ) {
		$db = new ME_DB;
		$query = sprintf("SELECT * from maps where map_id = '%s'", $map_id);
		$db->query($query);	
	 	$db->next_record();
		$map_rank = $db->f("map_rank");
	
		$query = sprintf("SELECT * from alliance_maps where alliance_id = '%s'", $alliance_id);
		$db->query($query);	
	  $db->next_record();

		switch ($map_rank) {
			case "1":
				$sectors = $db->f("map_1");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_1 = '%s', map_1_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}
	
				break;
			case "2":
				$sectors = $db->f("map_2");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_2 = '%s', map_2_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
			  	return 1;		
				} else {
					return 0;
				}

				break;
			case "3":
				$sectors = $db->f("map_3");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_3 = '%s', map_3_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "4":
				$sectors = $db->f("map_4");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_4 = '%s', map_4_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "5":
				$sectors = $db->f("map_5");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_5 = '%s', map_5_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "6":
				$sectors = $db->f("map_6");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_6 = '%s', map_6_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "7":
				$sectors = $db->f("map_7");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_7 = '%s', map_7_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "8":
				$sectors = $db->f("map_8");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_8 = '%s', map_8_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "9":
				$sectors = $db->f("map_9");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_9 = '%s', map_9_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "10":
				$sectors = $db->f("map_10");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update alliance_maps set map_10 = '%s', map_10_id = '%s' where alliance_id = '%s'", $new_sectors, $map_id, $alliance_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
		}
	} else {
		$db = new ME_DB;
		$query = sprintf("SELECT * from maps where map_id = '%s'", $map_id);
		$db->query($query);	
	 	$db->next_record();
		$map_rank = $db->f("map_rank");
	
		$query = sprintf("SELECT * from player_maps where player_id = '%s'", $player_id);
		$db->query($query);	
	  $db->next_record();

		switch ($map_rank) {
			case "1":
				$sectors = $db->f("map_1");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_1 = '%s', map_1_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}
	
				break;
			case "2":
				$sectors = $db->f("map_2");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_2 = '%s', map_2_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
			  	return 1;		
				} else {
					return 0;
				}

				break;
			case "3":
				$sectors = $db->f("map_3");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_3 = '%s', map_3_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "4":
				$sectors = $db->f("map_4");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_4 = '%s', map_4_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "5":
				$sectors = $db->f("map_5");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_5 = '%s', map_5_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "6":
				$sectors = $db->f("map_6");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_6 = '%s', map_6_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "7":
				$sectors = $db->f("map_7");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_7 = '%s', map_7_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "8":
				$sectors = $db->f("map_8");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_8 = '%s', map_8_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "9":
				$sectors = $db->f("map_9");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_9 = '%s', map_9_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
			case "10":
				$sectors = $db->f("map_10");
				$visible_sectors = array();
				$visible_sectors = explode(",", $sectors);

				if ( ! (in_array($sector_id, $visible_sectors)) )  {
					$new_sectors = $sectors . ',' . $sector_id;
					$query = sprintf("update player_maps set map_10 = '%s', map_10_id = '%s' where player_id = '%s'", $new_sectors, $map_id, $player_id);
					$db->query($query);		
					return 1;		
				} else {
					return 0;
				}

				break;
		}
	}	
}

?>