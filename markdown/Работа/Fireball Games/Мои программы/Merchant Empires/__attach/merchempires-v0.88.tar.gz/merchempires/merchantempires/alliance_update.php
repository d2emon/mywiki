<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$ship = new ME_Ship;
$ship->get_ship($player_id);
$game_id = $player->f("game_id");
$alliance_id = $player->f("alliance_id");

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "leave_alliance":			
			$returnto = "alliance";

			$db_a = new ME_DB;
			$query = sprintf("select players.player_id, players.alliance_id, alliances.leader_id, alliances.alliance_id, alliances.name
				from players, alliances	where players.alliance_id = '%s' and players.alliance_id = alliances.alliance_id", $alliance_id);
			$db_a->query($query);
			$db_a->next_record();
			$leader_id = $db_a->f("leader_id");			

			# leader not allowed to leave if other members exist
			if ( $db_a->nf() > 1 and $player_id == $leader_id )  {					
				$returnto = "alliance_options";
       	$error = 1;
				break;
			} elseif ( $db_a->nf() == 1 and $player_id == $leader_id ) {
      # delete the alliance
      	$db = new ME_DB;
				$query = sprintf("delete from alliances where alliance_id = '%s'", $alliance_id);
				$db->query($query);

				$query = sprintf("delete from alliance_maps where alliance_id = '%s'", $alliance_id);
				$db->query($query);		

				$query = sprintf("delete from treaties where primary_alliance_id = '%s' or secondary_alliance_id = '%s'", $alliance_id, $alliance_id);
				$db->query($query);	
			}

			$db = new ME_DB;
			$query = sprintf("update players set alliance_id = '%s', alliance_name = '%s' where player_id = '%s'", 0, 'None', $player_id);
			$db->query($query);

			# reset the player's forces to no alliance
			$query = sprintf("update forces set alliance_id = 0, alliance_name = 'None' where player_id = '%s'", $player_id);
			$db->query($query);

			# reset the player's planet to no alliance
			$query = sprintf("update planets set alliance_id = 0 where owner_id = '%s'", $player_id);
			$db->query($query);
		
			if ( $player_id <> $leader_id )  {	
				$date = date("H:i m/d/y");
				$date_integer = time();
				$message = addslashes($player->f("name")) . " has left your alliance.";
				$query = "insert into messages (player_id, message, date, toplayer, fromplayer, date_integer)
					values ('$leader_id', '$message', '$date', 'Alliance Leader', 'Alliance Management', '$date_integer')";
				$db->query($query);
			}
			
			break;
		case "merge_maps":
			$returnto = "alliance_options";

			$db = new ME_DB;
			$query = sprintf("select * from alliance_maps where alliance_id = '%s'", $player->f("alliance_id"));
			$db->query($query);	
			$db->next_record();

			$query = sprintf("update player_maps set map_1 = '%s', map_2 = '%s', map_3 = '%s', map_4 = '%s', map_5 = '%s', map_6 = '%s', map_7 = '%s', map_8 = '%s', map_9 = '%s', map_10 = '%s',
				map_1_id = '%s', map_2_id = '%s', map_3_id = '%s', map_4_id = '%s', map_5_id = '%s', map_6_id = '%s', map_7_id = '%s', map_8_id = '%s', map_9_id = '%s', map_10_id = '%s' where player_id = '%s'",
				$db->f("map_1"), $db->f("map_2"), $db->f("map_3"), $db->f("map_4"), $db->f("map_5"), $db->f("map_6"), $db->f("map_7"), $db->f("map_8"), $db->f("map_9"), $db->f("map_10"),
				$db->f("map_1_id"), $db->f("map_2_id"), $db->f("map_3_id"), $db->f("map_4_id"), $db->f("map_5_id"), $db->f("map_6_id"), $db->f("map_7_id"), $db->f("map_8_id"), $db->f("map_9_id"), $db->f("map_10_id"),
				$player->f("player_id"));

			$db->query($query);			
								
			break;
	}

	$db = new ME_DB;
	$query = sprintf("SELECT * from alliances where leader_id = '%s' and alliance_id = '%s'", $player_id, $alliance_id);
	$db->query($query);	

	if ( $db->nf() > 0 ) {
  	switch ($key) {
			case "change_password":				
				$returnto = "alliance_options";

				if ( $password == $verify )  {
					if ( strlen($password) > 10 ) {
						$error = 2;
						break;
					}

        	$db_2 = new ME_DB;
					$query = sprintf("update alliances set password = '%s' where leader_id = '%s' and alliance_id = '%s'", $password, $player_id, $alliance_id);
					$db_2->query($query);								
				} else {
        	$error = 3;
					break;
				}
				break;
			case "change_description":
				$returnto = "alliance_options";

				if (strpos ("." . $description, ";"))  {
					$error = 4;
					break;					
				}

				if ( strlen($description) > 255 ) {
					$error = 5;
					break;
				}

				$leader_id = (int) $leader_id;

				$db_2 = new ME_DB;
				$query = sprintf("update alliances set description = '%s' where leader_id = '%s' and alliance_id = '%s'", $description, $player_id, $alliance_id);
				$db_2->query($query);							

				break;
			case "change_log":
				$returnto = "alliance_options";

				if ( strlen($log) > 2000 ) {
					$error = 6;
					break;
				}

				if (strpos ("." . $log, ";"))  {
					$error = 4;
					break;					
				}

				$db_2 = new ME_DB;
				$query = sprintf("update alliances set log = '%s' where leader_id = '%s' and alliance_id = '%s'", $log, $player_id, $alliance_id);
				$db_2->query($query);							

				break;
			case "change_leadership":
				$returnto = "alliance_options";

				$leader_id = (int) $leader_id;

				$db_2 = new ME_DB;
				$query = sprintf("select * from players where player_id = '%s'", $leader_id);
				$db_2->query($query);
				$db_2->next_record();
				$leader_name = $db_2->f("name");

				$query = sprintf("update alliances set leader_id = '%s' where leader_id = '%s' and alliance_id = '%s'", $leader_id, $player_id, $alliance_id);
				$db_2->query($query);

				$query = sprintf("update treaties set primary_leader_id = '%s', primary_leader_name = '%s' where primary_leader_id = '%s'", $leader_id, $leader_name, $player_id);
				$db_2->query($query);

				$query = sprintf("update treaties set secondary_leader_id = '%s', secondary_leader_name = '%s' where secondary_leader_id = '%s'", $leader_id, $leader_name, $player_id);
				$db_2->query($query);							

				break;
			case "remove_member":
				$returnto = "alliance_options";

				$member_id = (int) $member_id;

				#anti cheat in case alliance leaders attempt to hack the member/alliance removal
				$db = new ME_DB;
				$query = sprintf("select player_id, alliance_id from players where alliance_id = '%s' and player_id = '%s'", $alliance_id, $member_id);
				$db->query($query);
	
				if ( $db->nf() > 0 )  {
					$db_2 = new ME_DB;
					$db_3 = new ME_DB;
					$query = sprintf("update players set alliance_id = 0, alliance_name = 'None' where player_id = '%s'", $member_id);
					$db_2->query($query);

					$query = sprintf("update forces set alliance_id = 0, alliance_name = 'None' where player_id = '%s'", $member_id);
					$db_2->query($query);

					# reset the player's planet to no alliance
					$query = sprintf("select * from planets where owner_id = '%s'", $member_id);
					$db_2->query($query);
					$db_2->next_record();				

					if ( $db_2->nf() > 0 ) {
						#move all players on the player's planet into the planet's sector
						$query = sprintf("select ship_id, planet_id, sector_id, player_id from ships where planet_id = '%s' and player_id <> '%s'", $db_2->f("planet_id"), $member_id);
						$db->query($query);												
						
						while ( $db->next_record() ) {
							$query = sprintf("update ships set planet_id = 0, sector_id = '%s' where ship_id = '%s'", $db_2->f("sector_id"), $db->f("ship_id"));
							$db_3->query($query);
						}						
								
						# reset the player's planet to no alliance
						$query = sprintf("update planets set alliance_id = 0 where owner_id = '%s'", $member_id);
						$db_2->query($query);																									
					}
			
					# if the player is on an alliance planet, move him into space
					$query = sprintf("select ship_id, planet_id, sector_id, player_id from ships where player_id = '%s' and planet_id <> 0", $member_id);
					$db->query($query);						
					$db->next_record();
								
					if ( $db->nf() > 0 ) {						
						# if the player is on an alliance planet, move him into space
						$query = sprintf("select * from planets where planet_id = '%s' and alliance_id = '%s'", $db->f("planet_id"), $alliance_id);
						$db->query($query);	
						$db->next_record();

						if ( $db->nf() > 0 ) {	
							$query = sprintf("update ships set planet_id = 0, sector_id = '%s' where player_id = '%s'", $db->f("sector_id"), $member_id);
							$db_3->query($query);
						}
					}									
        }

				break;
			case "register_account":
				$returnto = "alliance_options";

				$account_id = (int) $account_id;

				if ( $account_id == 0 )  {
					$db = new ME_DB;
					$db->query("update accounts set alliance_id = 0 where alliance_id = '$alliance_id'");					
					break;
				}

				$db = new ME_DB;
				$db->query("select * from accounts where alliance_id = '$alliance_id'");
				$db->next_record();		

				if ( $db->nf() > 0 ) {
        	$error = 9;
					break;
				}
				
				$db->query("select * from accounts where public_account_id = '$account_id' and game_id = '$game_id'");
				$db->next_record();			
			
				if ( $db->nf() == 0 ) {
        	$error = 7;
					break;
				}
				
				if ( $password <> $db->f("password") )  {
      		$error = 8;
					break;
				}
  							
				$db->query("update accounts set alliance_id = '$alliance_id' where public_account_id = '$account_id' and game_id = '$game_id'");				

				break;

			case "cancel_treaty":
				$returnto = "alliance_politics";

				$treaty_id = (int) $treaty_id;

				$db = new ME_DB;
				$db_2 = new ME_DB;

				$query = sprintf("select * from treaties where treaty_id = '%s'", $treaty_id);
				$db->query($query);
				$db->next_record();

				if ( $db->f("primary_alliance_id") <> $player->f("alliance_id") and $db->f("secondary_alliance_id") <> $player->f("alliance_id") ) {
					$error = 1;
					break;
				}

				$query = sprintf("delete from treaties where treaty_id = '%s'", $treaty_id);
				$db->query($query);				
				
				break;

			case "withdraw_treaty":
				$returnto = "alliance_politics";

				$treaty_id = (int) $treaty_id;

				$db = new ME_DB;				

				$query = sprintf("select * from treaties where treaty_id = '%s'", $treaty_id);
				$db->query($query);
				$db->next_record();

				if ( $db->f("primary_alliance_id") <> $player->f("alliance_id") and $db->f("secondary_alliance_id") <> $player->f("alliance_id") ) {
					$error = 1;
					break;
				}

				$query = sprintf("delete from treaties where treaty_id = '%s'", $treaty_id);
				$db->query($query);				
				
				break;

			case "accept_treaty":
				$returnto = "alliance_politics";

				$treaty_id = (int) $treaty_id;

				$db = new ME_DB;
				$db_2 = new ME_DB;

				$query = sprintf("select * from treaties where treaty_id = '%s'", $treaty_id);
				$db->query($query);
				$db->next_record();

				if ( $db->f("primary_alliance_id") <> $player->f("alliance_id") and $db->f("secondary_alliance_id") <> $player->f("alliance_id") ) {
					$error = 1;
					break;
				}

				if ( $db->f("secondary_alliance_id") <> $player->f("alliance_id") ) {
					$error = 2;
					break;
				}

				$query = sprintf("update treaties set accepted = 't' where treaty_id = '%s'", $treaty_id);
				$db->query($query);				
				
				break;

			case "offer_treaty":
				$returnto = "alliance_politics";

				$db = new ME_DB;
				$db_2 = new ME_DB;

				$query = sprintf("select * from alliances where name = '%s' and game_id = '%s'", $alliance_name, $game_id);
				$db->query($query);
				$db->next_record();

				if ( $db->nf() == 0 ) {
					$error = 3;
					break;
				}

				if ( $player->f("alliance_id") == $db->f("alliance_id") ) {
					$error = 4;
					break;
				}				

				$secondary_alliance_id = $db->f("alliance_id");
				$secondary_alliance_name = $db->f("name");
				$secondary_leader_id = $db->f("leader_id");			

				$query = sprintf("select * from players where player_id = '%s'", $secondary_leader_id);
				$db_2->query($query);
				$db_2->next_record();

				$secondary_leader_name = $db_2->f("name");

				$query = sprintf("select * from treaty_types where name = '%s'", $treaty_type);
				$db->query($query);
				$db->next_record();

				if ( $db->nf() == 0 ) {
					$error = 5;
					break;
				}

				$treaty_type_id = $db->f("treaty_type_id");

				$accepted = 'f';
				
				$query = sprintf("select * from treaties where (primary_alliance_id = '%s' and secondary_alliance_id = '%s') or (secondary_alliance_id = '%s' and primary_alliance_id = '%s') and type = '$treaty_type'", $player->f("alliance_id"), $secondary_alliance_id, $secondary_alliance_id, $player->f("alliance_id"));
				$db->query($query);
				$db->next_record();
				
				if ( $db->nf() > 0 ) {
					$error = 6;
					break;
				}										
				
				if ( $treaty_type == 'War' ) {
					$query = sprintf("select * from treaties where (primary_alliance_id = '%s' and secondary_alliance_id = '%s') or (secondary_alliance_id = '%s' and primary_alliance_id = '%s')", $player->f("alliance_id"), $secondary_alliance_id, $secondary_alliance_id, $player->f("alliance_id"));
					$db->query($query);
					$db->next_record();
				
					if ( $db->nf() > 0 ) {
						$error = 6;
						break;
					}
					
					$accepted = 't';
				}								
				
				$query = sprintf("insert into treaties (primary_alliance_id, secondary_alliance_id, primary_alliance_name, secondary_alliance_name, primary_leader_id, secondary_leader_id, primary_leader_name, secondary_leader_name, date_offered, type_id, type, accepted)
					values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')", $player->f("alliance_id"), $secondary_alliance_id, addslashes($player->f("alliance_name")), addslashes($secondary_alliance_name), $player->f("player_id"), $secondary_leader_id, addslashes($player->f("name")), addslashes($secondary_leader_name), time(), $treaty_type_id, $treaty_type, $accepted);
				$db->query($query);								

				break;
		}
	}
}

if ( $error ) {
	if ($returnto == "alliance_options")  {
		$newurl = $sess->url(URL . "alliance_options.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "alliance")  {
		$newurl = $sess->url(URL . "alliance.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "alliance_politics")  {
		$newurl = $sess->url(URL . "alliance_politics.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "alliance_options")  {
		$newurl = $sess->url(URL . "alliance_options.php");
		header("Location: $newurl");	
	} elseif ($returnto == "alliance")  {
		$newurl = $sess->url(URL . "alliance.php");
 		header("Location: $newurl");	
	} elseif ($returnto == "alliance_politics")  {
		$newurl = $sess->url(URL . "alliance_politics.php");
 		header("Location: $newurl");	
	}
}

page_close();
?>
