<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Place Bounty</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$sector_id = $ship->f("sector_id");
$db = new ME_DB_Xml;
$db->query("select * from locations where sector_id = '$sector_id' and type='Government'");
$db->next_record();

$db_2 = new ME_DB;
$db_2->query("select * from games where game_id = '$game_id'");
$db_2->next_record();

switch ($db->f("options")) {
	case "1":
		$race_name = $db_2->f("namerace_1");
		break;
	case "2":
		$race_name = $db_2->f("namerace_2");
		break;
	case "3":
		$race_name = $db_2->f("namerace_3");
		break;
	case "4":
		$race_name = $db_2->f("namerace_4");
		break;
	case "5":
		$race_name = $db_2->f("namerace_5");
		break;
	case "6":
		$race_name = $db_2->f("namerace_6");
		break;
	case "7":
		$race_name = $db_2->f("namerace_7");
		break;
}

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

if ( $player->f("alignment") > -100 ) {	
	$db->add_parameter("current_screen", "government_place");
	echo $db->get_transform("./xslt/menu_top_government.xslt", $db->get_xml());		
?>

<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top>
									<font  color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;<?php

	echo "<form action=";
	echo $sess->url(URL . "government_update.php");
	echo " method=post>";
	echo "<table cellspacing=5>";
	echo "<tr>";
	echo "<td>Enter Merchant ID</td>";
	echo "<td><input type=textbox name=merchant_id size=15></td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>Enter Amount</td>";
	echo "<td><input type=textbox name=amount size=15></td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td colspan=2><br><font  color=#cccccc face=arial,helvetica,swiss size=2>The Imperial Government will contribute toward the creation of a bounty if the criminal is of sufficient noteriety.<br><br>
		This form allows you to contribute to an existing bounty.</font><td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td colspan=2><br><center><input type=submit name=place_bounty value='Place Bounty'></center><td>";
	echo "</tr>";
	echo "</table>";
	echo "</form>";
?>
									</font>
								</td>
							</tr>
						</table><?php
	echo "<tr>";
	echo "<td colspan=2 bgColor=#000000>";
	echo "<center><a href=";
	echo $sess->url(URL . "local_map.php");
	echo ">Leave Capitol</a>&nbsp;&nbsp;";
	echo "<a href=";
	echo $sess->url(URL . "merchant_search.php");
	echo ">Search for Merchant</a></center>";
	echo "</td>";
	echo "</tr>";
?>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $error ) {
		$db = new ME_DB_Xml;
		$db->add_parameter("title", "Error");
	
		$db->add_parameter("message", $error);
		
		if ($error == 1) {
			$db->add_parameter("message", "No merchant was found with that ID.");
		} elseif ($error == 2) {
			$db->add_parameter("message", "10,000 credits is the minimum amount to create a bounty.");
		} elseif ($error == 3) {
			$db->add_parameter("message", "10,000,000 credits is the maximum amount that may be placed on a bounty.");
		} elseif ($error == 4) {
			$db->add_parameter("message", "You can not place a bounty on yourself.");
		} elseif ($error == 5) {
			$db->add_parameter("message", "The target merchant does not have sufficient experience to have a bounty placed.");
		}
			
		echo $db->get_transform("./xslt/message_box.xslt", "");
	}
} else {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Warning");
	$db->add_parameter("message", "Your alignment prevents you from accessing this location.");
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>