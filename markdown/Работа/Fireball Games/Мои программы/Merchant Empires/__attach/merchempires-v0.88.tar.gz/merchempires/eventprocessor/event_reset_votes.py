
def reset_votes():
	from pg import DB
	from Defines import *

	pgcnx = DB(postmerchdb, postmerchhost, user=postmerchuser, passwd=postmerchpass)
	qrystr = "update council_votes set has_voted_1 = 0, has_voted_2 = 0, has_voted_3 = 0, has_voted_4 = 0, has_voted_5 = 0, has_voted_6 = 0, has_voted_7 = 0,	\
		vote_1 = 0, vote_2 = 0, vote_3 = 0, vote_4 = 0, vote_5 = 0, vote_6 = 0, vote_7 = 0"
	q = pgcnx.query(qrystr)
 
