<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/relations.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);

if ( $action == "self_destruct" ) {
	$id = (int) $id;
	$returnto = "merchant_forces";

	$db = new ME_DB;
	$query = sprintf("select * from forces where forces_id = '%s' and player_id = '%s'", $id, $player->f("player_id"));
	$db->query($query);

	if ( $db->nf() > 0 ) {
		$query = sprintf("delete from forces where forces_id = '%s'", $id);
		$db->query($query);				
	}
} elseif ( $action == "repulsion" ) {
	$id = (int) $id;
	$returnto = "merchant_forces";

	$db = new ME_DB;
	$query = sprintf("select * from forces where forces_id = '%s' and player_id = '%s'", $id, $player->f("player_id"));
	$db->query($query);
	$db->next_record();

	if ( $db->nf() > 0 ) {		
		if ( $toggle == 't' ) {
			if ( $db->f("mine") > 19 ) {
				$query = sprintf("update forces set repulsion = 't' where forces_id = '%s'", $id);
				$db->query($query);
			}
		} elseif ( $toggle == 'f' ) {
			$query = sprintf("update forces set repulsion = 'f' where forces_id = '%s'", $id);
			$db->query($query);		
		}					
	}
}

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {				
			case "update_log":
				$returnto = "merchant";

				if ( strlen($log) > 2000 ) {
					$error = 2;
					break;
				}

				$db = new ME_DB;
				$query = sprintf("update players set log = '%s' where player_id = '%s'", $log, $player->f("player_id"));
				$db->query($query);				

				break;	

			case "leave_protection":
				$returnto = "merchant";

				if ( $player->f("last_dead_date") >= time() - 1200 and $player->f("last_dead_date") <> 0 ) {
					$error = 1;
					break;
				} else {
					$db = new ME_DB;
					$query = sprintf("update players set last_dead_date = '%s' where player_id = '%s'", time(), $player->f("player_id"));
					$db->query($query);
				}

				$db = new ME_DB;
				$query = sprintf("update players set newturnsleft = '%s' where player_id = '%s'", 0, $player->f("player_id"));
				$db->query($query);				

				break;						

			case "target_alliance":
				$id = (int) $id;
				$returnto = "merchant_forces";				

				$db = new ME_DB;
				$query = sprintf("select * from forces where forces_id = '%s' and player_id = '%s'", $id, $player->f("player_id"));
				$db->query($query);

				if ( $db->nf() > 0 ) {
					$query = sprintf("select * from alliances where name = '%s' and game_id = '%s'", $alliance_name, $player->f("game_id"));
					$db->query($query);
					$db->next_record();

					if ( $db->f("alliance_id") == $player->f("alliance_id") and $db->f("alliance_id") <> 0 ) {
						$returnto = "merchant_forces_target";
						$error = 2;
						break;		
					}

					if ( $db->nf() > 0 ) {					
						$query = sprintf("update forces set focused_alliance_id = '%s', focused_player_id = '%s', focused_alliance_name = '%s', focused_player_name = '%s' where forces_id = '%s'", $db->f("alliance_id"), 0, $alliance_name, "", $id);
						$db->query($query);	
					} else {
						if ( $alliance_name == "00" ) {
							$query = sprintf("update forces set focused_alliance_id = '%s', focused_player_id = '%s', focused_alliance_name = '%s', focused_player_name = '%s' where forces_id = '%s'", 0, 0, "", "", $id);
							$db->query($query);	
						} else {
							$returnto = "merchant_forces_target";
							$error = 1;
							break;							
						}
					}
				}
				
				break;

			case "target_merchant":
				$id = (int) $id;
				$returnto = "merchant_forces";				

				$db = new ME_DB;
				$query = sprintf("select * from forces where forces_id = '%s' and player_id = '%s'", $id, $player->f("player_id"));
				$db->query($query);

				if ( $db->nf() > 0 ) {
					$query = sprintf("select player_id, name, game_id from players where name = '%s' and game_id = '%s'", $player_name, $player->f("game_id"));
					$db->query($query);
					$db->next_record();

					if ( $db->f("player_id") == $player->f("player_id") ) {
						$returnto = "merchant_forces_target";
						$error = 3;
						break;		
					}

					if ( $db->nf() > 0 ) {					
						$this_player_id = $db->f("player_id");
						$query = sprintf("update forces set focused_player_id = '%s', focused_alliance_id = '%s', focused_player_name = '%s', focused_alliance_name = '%s' where forces_id = '%s'", $this_player_id, 0, $player_name, "", $id);
						$db->query($query);										
					} else {
						if ( $player_name == "00" ) {
							$query = sprintf("update forces set focused_alliance_id = '%s', focused_player_id = '%s', focused_alliance_name = '%s', focused_player_name = '%s' where forces_id = '%s'", 0, 0, "", "", $id);
							$db->query($query);	
						} else {
							$returnto = "merchant_forces_target";
							$error = 3;
							break;							
						}
					}
				}
				
				break;

			case "decrease_1":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_1") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_1();

					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_1(-500);
					} else {
						$relations->set_relations_1($this_relations - 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_1 = 1, vote_1 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}			
				
				break;

			case "decrease_2":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_2") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_2();

					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_2(-500);
					} else {
						$relations->set_relations_2($this_relations - 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_2 = 1, vote_2 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}

				break;

			case "decrease_3":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_3") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_3();

					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_3(-500);
					} else {
						$relations->set_relations_3($this_relations - 10);
					}
				
					$relations->save();
					$query = sprintf("update council_votes set has_voted_3 = 1, vote_3 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}

				break;

			case "decrease_4":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_4") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_4();

					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_4(-500);
					} else {
						$relations->set_relations_4($this_relations - 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_4 = 1, vote_4 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}				

				break;

			case "decrease_5":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_5") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_5();
	
					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_5(-500);
					} else {						
						$relations->set_relations_5($this_relations - 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_5 = 1, vote_5 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}						

				break;

			case "decrease_6":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_6") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_6();

					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_6(-500);
					} else {
						$relations->set_relations_6($this_relations - 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_6 = 1, vote_6 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}					

				break;

			case "decrease_7":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_7") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_7();

					if ( $this_relations - 10 < -500 ) {
						$relations->set_relations_7(-500);
					} else {
						$relations->set_relations_7($this_relations - 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_7 = 1, vote_7 = 0 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}	

				break;

			case "increase_1":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_1") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_1();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_1(500);
					} else {
						$relations->set_relations_1($this_relations + 10);
					}
					
					$relations->save();
					$query = sprintf("update council_votes set has_voted_1 = 1, vote_1 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}				

				break;

			case "increase_2":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_2") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_2();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_2(500);
					} else {
						$relations->set_relations_2($this_relations + 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_2 = 1, vote_2 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}				
	
				break;

			case "increase_3":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_3") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_3();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_3(500);
					} else {
						$relations->set_relations_3($this_relations + 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_3 = 1, vote_3 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}				

				break;

			case "increase_4":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_4") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_4();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_4(500);
					} else {
						$relations->set_relations_4($this_relations + 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_4 = 1, vote_4 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}				

				break;

			case "increase_5":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_5") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_5();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_5(500);
					} else {
						$relations->set_relations_5($this_relations + 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_5 = 1, vote_5 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}					

				break;

			case "increase_6":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_6") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_6();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_6(500);
					} else {
						$relations->set_relations_6($this_relations + 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_6 = 1, vote_6 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}					

				break;

			case "increase_7":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");

				$db = new ME_DB;
				$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
				$db->query($query);	
        $db->next_record();

				if ( $db->f("has_voted_7") <> 1 ) {
					$relations = new ME_Relations;
					$relations->initialize($game_id, $player->f("race_number"));
    	    $this_relations = $relations->get_relations_7();

					if ( $this_relations + 10 > 500 ) {
						$relations->set_relations_7(500);
					} else {
						$relations->set_relations_7($this_relations + 10);
					}

					$relations->save();
					$query = sprintf("update council_votes set has_voted_7 = 1, vote_7 = 1 where player_id = '%s'", $player->f("player_id"));
					$db->query($query);	
				} else {
					$error = 1;
				}				

				break;

			case "war_1":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_1() > -300 ) {
						if ( $db_g->f("overlord_has_voted_1") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_1 = 1, overlord_vote_1 = 1, overlord_vote_1_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);							
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "war_2":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_2() > -300 ) {
						if ( $db_g->f("overlord_has_voted_2") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_2 = 1, overlord_vote_2 = 1, overlord_vote_2_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "war_3":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_3() > -300 ) {
						if ( $db_g->f("overlord_has_voted_3") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_3 = 1, overlord_vote_3 = 1, overlord_vote_3_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);							
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "war_4":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_4() > -300 ) {
						if ( $db_g->f("overlord_has_voted_4") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_4 = 1, overlord_vote_4 = 1, overlord_vote_4_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);							
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "war_5":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_5() > -300 ) {
						if ( $db_g->f("overlord_has_voted_5") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_5 = 1, overlord_vote_5 = 1, overlord_vote_5_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);							
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "war_6":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_6() > -300 ) {
						if ( $db_g->f("overlord_has_voted_6") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_6 = 1, overlord_vote_6 = 1, overlord_vote_6_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);							
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "war_7":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
						
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
				
					$db_g->next_record();					

					if ( $relations->get_relations_7() > -300 ) {
						if ( $db_g->f("overlord_has_voted_7") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_7 = 1, overlord_vote_7 = 1, overlord_vote_7_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);
							$db->query($query);							
						} else {
							$error = 3;
							break;
						}
					} else {
						$error = 2;
						break;						
					}
				}

				break;

			case "peace_1":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_1() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_1") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_1 = 1, overlord_vote_1 = 2, overlord_vote_1_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

			case "peace_2":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_2() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_2") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_2 = 1, overlord_vote_2 = 2, overlord_vote_2_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

			case "peace_3":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_3() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_3") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_3 = 1, overlord_vote_3 = 2, overlord_vote_3_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

			case "peace_4":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_4() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_4") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_4 = 1, overlord_vote_4 = 2, overlord_vote_4_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

		case "peace_5":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_5() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_5") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_5 = 1, overlord_vote_5 = 2, overlord_vote_5_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

		case "peace_6":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_6() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_6") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_6 = 1, overlord_vote_6 = 2, overlord_vote_6_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

		case "peace_7":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 1", $game_id);
				$db->query($query);

				$db->next_record();
				if ( $db->f("player_id") == $player->f("player_id") ) {
					$is_overlord = 1;
				}										
				
				if ( $is_overlord ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();					

					if ( $relations->get_relations_7() <= -300 ) {
						if ( $db_g->f("overlord_has_voted_7") == 0 ) {							
							$query = sprintf("update overlord_votes set overlord_has_voted_7 = 1, overlord_vote_7 = 2, overlord_vote_7_date = %d where game_id = '%s' and race_id = '%s'", time() + 259200, $game_id, $race_id);									
							$db->query($query);							
						} else {
							$error = 4;
							break;
						}
					} else {
						$error = 7;
						break;						
					}
				}

				break;

		case "for_1":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_1") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_1 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_1"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_1")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_1 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "for_2":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_2") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_2 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_2"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_2")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_2 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "for_3":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_3") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_3 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_3"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_3")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_3 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "for_4":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_4") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_4 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_4"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_4")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_4 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "for_5":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_5") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_5 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_5"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_5")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_5 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "for_6":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_6") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_6 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_6"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_6")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_6 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "for_7":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_7") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_7 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_7"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_7")) == 0 ) {
								$votes[0] = "1";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "1";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_7 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_1":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_1") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_1 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_1"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_1")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_1 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_2":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_2") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_2 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_2"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_2")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_2 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_3":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_3") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_3 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_3"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_3")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_3 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_4":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_4") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_4 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_4"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_4")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_4 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_5":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_5") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_5 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_5"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_5")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_5 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_6":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_6") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_6 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_6"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_6")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_6 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

		case "against_7":
				$returnto = "merchant_politics";
				$game_id = $player->f("game_id");
				$race = $player->f("race");

				$relations = new ME_Relations;
				$relations->initialize($game_id, $player->f("race_number"));

				$db = new ME_DB;
				$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
				$db->query($query);

				$council_member = 0;

				while ( $db->next_record() ) {			
					if ( $db->f("player_id") == $player->f("player_id") ) {
						$council_member = 1;
					}	
				}											
				
				if ( $council_member ) {
					$race_id = $player->f("race_number");
					$db_g = new ME_DB;
					$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");					
					$db_g->next_record();												

					$db_c = new ME_DB;
					$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
					$db_c->query($query);	
				  $db_c->next_record();
				
					if ( $db_c->f("overlord_has_voted_7") != 1 ) {
						$query = sprintf("update council_votes set overlord_has_voted_7 = 1 where player_id = '%s'", $player->f("player_id"));
						$db->query($query);							

						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_7"));
							
						if ( count($votes) >= 9 ) {	
							$error = 6;
							break;								
						} else {				
							if ( strlen($db_g->f("overlord_council_votes_7")) == 0 ) {
								$votes[0] = "0";
								$str_votes = implode(",", $votes);
							} else {
								$votes[count($votes)] = "0";
								$str_votes = implode(",", $votes);
							}

							$query = sprintf("update overlord_votes set overlord_council_votes_7 = '$str_votes' where game_id = '$game_id' and race_id = '$race_id'");
							$db->query($query);	
						}
					} else {
						$error = 5;
						break;
					}
				}

				break;

	}
}

if ( $error ) {
	if ($returnto == "merchant")  {
		$newurl = $sess->url(URL . "merchant.php?error=$error");
		header("Location: $newurl");	
	} elseif ($returnto == "merchant_politics")  {
		$newurl = $sess->url(URL . "merchant_politics.php?error=$error");
		header("Location: $newurl");	
	} elseif ($returnto == "merchant_forces")  {
		$newurl = $sess->url(URL . "merchant_forces.php?error=$error");
		header("Location: $newurl");	
	} elseif ($returnto == "merchant_forces_target")  {
		$newurl = $sess->url(URL . "merchant_forces_target.php?error=$error&id=" . $id);
		header("Location: $newurl");	
	}
} else {
	if ($returnto == "merchant")  {
		$newurl = $sess->url(URL . "merchant.php");
		header("Location: $newurl");	
	} elseif ($returnto == "merchant_politics")  {
		$newurl = $sess->url(URL . "merchant_politics.php");
		header("Location: $newurl");	
	} elseif ($returnto == "merchant_forces")  {
		$newurl = $sess->url(URL . "merchant_forces.php");
		header("Location: $newurl");	
	} elseif ($returnto == "merchant_forces_target")  {
		$newurl = $sess->url(URL . "merchant_forces_target.php?id=" . $id);
		header("Location: $newurl");	
	}
}

page_close();
?>