<?php 
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

include("./merchantempiresdefines.php");
?>

<html><head><title>Merchant Empires: New User</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table BORDER=0 WIDTH='100%' NOSAVE >
	<tr>
 		<td width=100 vAlign=top>
   	</td>
   	<td width=350 align=left vAlign=top>
			<table border=0 cellPadding=0 cellSpacing=0 width=450>
  	    <tr>
    	    <td bgColor=#993300>
      	    <table border=0 cellPadding=5 cellSpacing=1 width=450>
        	    <tr>
          	    <td bgColor=#330000><FONT color=#ffffff  face=arial,helvetica,swiss size=4><B>Create a New User
                  </B></FONT><BR clear=all>
            	  </td>
	    				</tr>
            	<tr>
              	<td bgColor=#000000><FONT  color=#cccccc face=arial,helvetica,swiss size=2>
									<form METHOD="POST" ACTION="<?php printf("%s", URL); ?>create_user.php">
									<table>
 		  							<tr>
  		  							<td>Username:</td>
  		  							<td><INPUT TYPE="textbox" NAME="username"></td>
 		  							</tr>
 		  							<tr>
  		  							<td>Password:</td>
  		  							<td><INPUT TYPE="password" maxlength=32 NAME="password"></td>
		  							</tr>
		  							<tr>
		  								<td>Verify:</td>
  		 	 							<td><INPUT TYPE="password" maxlength=32 NAME="verify"></td>
		  							</tr>
		  							<tr>
		  								<td>Email Address:</td>
  		  							<td><INPUT TYPE="textbox" maxlength=32 NAME="email" size=45></td>
  		  						</tr>
		  							<tr>
		  								<td></td>
 		  								<td><INPUT TYPE="submit" NAME="create" VALUE="Create"></td>
		  							</tr>
		 	 							<tr>
		  								<td></td>
 		  								<td><FONT color=#cccccc face=arial,helvetica,swiss size=3>You are allowed to create
 		  								only one user.  Creating multiple users is considered cheating.  Anyone
		  								found to have multiple users will be banned from the game.<br><br>
											Creating a user and participating in the Merchants Empires universe for any other
											purpose aside from simply playing the game is not allowed.</font></td>
		  							</tr>
									</table>
									</form>
	      				</td>
	    				</tr>
	  				</table>
					</td>
      	</tr>
    	</table>
    <td>
 		</td>
	</tr>
</table>

</body></html>

