<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");
include("./lib/relations.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Alliance Status</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
}

$alliance_id = (int) $alliance_id;
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "alliance");	
$db->add_parameter("alliance_id", $alliance_id);
echo $db->get_transform("./xslt/menu_top_alliance.xslt", "");

if ( $alliance_id <> -1 )  {
	$db = new ME_DB;
	$query = sprintf("SELECT player_id, alliance_id, experience from players where alliance_id = '%s' order by experience desc", $alliance_id);
	$db->query($query);

	# calculate some totals
	$total_experience = 0;
	$average_experience = 0;
	$total_members = 0;

	while ( $db->next_record() )  {
		$total_experience = $total_experience + $db->f("experience");
		$total_members = $total_members + 1;
	}

	if ( $total_experience > 0 ) {
		$average_experience = $total_experience / $total_members;
	} else {
		$average_experience = 0;
	}

	$game_id = $player->f("game_id");
	$db = new ME_DB;
	$query = sprintf("SELECT * from alliances where alliance_id = '%s' and game_id = '%s'", $alliance_id, $game_id);
	$db->query($query);
	$db->next_record();
	$leader_id = $db->f("leader_id");

	if ( $db->nf() > 0 ) {
?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td width=150 class=clsHedTxt id=blu1><center>Alliance Name</center></td>
					<td class=clsHedTxt id=blu1><center>Total Experience</center></td>
					<td class=clsHedTxt id=blu1><center>Average Experience</center></td>
					<td class=clsHedTxt id=blu1><center>Merchants</center></td>
				</tr>
  			<tr>
        	<td class=clsNrmTxt><?php
	echo $db->f("name");
?>
					</td>
					<td class=clsNrmTxt><?php
	echo $total_experience;
?>
					</td>
					<td class=clsNrmTxt><?php
	echo (int) $average_experience;
?>
					</td>
					<td class=clsNrmTxt><?php
	echo $total_members;
?>
					</td>
				</tr>
			</table>
		<td>
  </tr>
</table>

<br>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td class=clsNrmTxt><b>
						Description:</b><br><br><?php

echo nl2br(htmlentities($db->f("description")));

if ( $alliance_id == $player->f("alliance_id") ) {
	echo "<br><br><b>Log:</b><br><br>";
	echo nl2br(htmlentities($db->f("log")));

	$db_2 = new ME_DB;
	$query = sprintf("select * from accounts where alliance_id = '%s'", $player->f("alliance_id"));
	$db_2->query($query);
	$db_2->next_record();

	if ( $db_2->nf() > 0 ) {			
		echo "<br><br><b>Finances:</b><br>";
		echo "<FONT color=#cccccc face=arial,helvetica,swiss size=2><br>&nbsp;Alliance account: </font>";
		echo $db_2->f("balance") . "<br><br>";
	} else {
		echo "<br>";
	}
}
?>
				</tr>	
			</table>
		</td>
  </tr>
</table><?php

	$db = new ME_DB;
	$query = sprintf("SELECT player_id, alliance_id, name, race, alignment, experience from players where alliance_id = '%s' order by experience desc", $alliance_id);
	$db->query($query);

?>
<br>
<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellpadding=5 cellspacing=1 width=100%>
				<tr>
					<td width=90 class=clsHedTxt id=red1><center>Merchant Name</center></td>
					<td class=clsHedTxt id=red1><center>Race</center></td>
					<td class=clsHedTxt id=red1><center>Alignment</center></td>
					<td class=clsHedTxt id=red1><center>Experience</center></td>
				</tr><?php

	while ($db->next_record())  {
		echo "<tr>";
		echo "<td class=clsNrmTxt>" . $db->f("name");

		if ( $db->f("player_id") == $leader_id ) {
			echo " (Alliance Leader)";
		}

		echo "</td>";
		echo "<td class=clsNrmTxt>" . $db->f("race") . "</td>";
		echo "<td class=clsNrmTxt>" . $db->f("alignment") . "</td>";
		echo "<td class=clsNrmTxt>" . $db->f("experience") . "</td>";
	}
?>
					
				</tr>
			</table>
		<td>
  </tr>
</table><?php
	} else {
		$db = new ME_DB_Xml;
		$db->add_parameter("title", "Error");
		$db->add_parameter("message", "That alliance does not exist in the current game.");
		echo $db->get_transform("./xslt/message_box.xslt", "");
	}
}

if ( $player->f("alliance_id") == 0 and $alliance_id == -1 )  {

?>
<br>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=7 cellSpacing=1 width=500>
				<tr>
					<td class=clsNrmTxt width=500 align=left valign=middle noWrap>
						You have not joined an alliance.<br><br>

						You can:<br><br>
						(1) Join an alliance by entering an alliance password at the bottom of the view alliance screen.
						<br><br>(2) <a href=<?php
echo  $sess->url(URL . "alliance_get_new.php");
?>
					>FORM</a> your own alliance.  To appear in the alliance list, an alliance must have a minimum of 300 total experience.</font>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}

if ( $player->f("alliance_id") == 0 and $alliance_id <> -1 )  {

?>
<br>
<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=7 cellSpacing=1 width=500>
				<tr>
					<td class=clsNrmTxt width=500 align=left valign=middle>
						Join this alliance<br><br>
						<form action=<?php

echo $sess->url(URL . "alliance_join.php");
?>
						method=post>
						&nbsp;Password:&nbsp;
						<input type=password name=password>
						<input type=hidden name=alliance_id value=<?php
echo $alliance_id;
?>
						>
						&nbsp;&nbsp;<input type="submit" NAME="join" VALUE="Join">
        		</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	
	$db->add_parameter("message", $error);
		
	if ($error == 1) {
		$db->add_parameter("message", "You are the leader of an alliance with more than one member.  You must first transfer leadership before leaving the alliance.");
	} elseif ($error == 2) {
		$db->add_parameter("message", "Command not processed due to insufficient credits.");
	}
			
	echo $db->get_transform("./xslt/message_box.xslt", "");					
}

?>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>