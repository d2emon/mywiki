<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function get_planetary_cargo($db_p) {
	$planetary_cargo = array();

	$cargo_temp = explode(",", $db_p->f("cargo"));

	for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 2) {
		$planetary_cargo[$cargo_temp[$i]] = $cargo_temp[$i + 1];
	}		

	return $planetary_cargo;
}
?>

<html><head><title>Merchant Empires: Merchant Planet</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "merchant");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$db_p = new ME_DB;
$db_p->query("select * from planets where owner_id = '$player_id'");

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "merchant_planet");	
echo $db->get_transform("./xslt/menu_top_merchant.xslt", "");

if ( $db_p->nf() > 0 )  {
?>
<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0 cellspacing=2 cellpadding=2><?php

while ( $db_p->next_record() ) {

echo "<tr><td valign=top>";
echo "<font color=#3333FF face=arial,helvetica,swiss size=3><b>";
echo htmlentities($db_p->f("name")) . "</font><br>";
echo "<font color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;Sector: " . $db_p->f("public_sector_id") . "</font><br>";
?>
									<br><font color=#3333FF face=arial,helvetica,swiss size=3><b>Defenses</font></b><br>
									<table cellPadding=2 cellSpacing=1>
										<tr>
											<td><font  color=#cccccc face=arial,helvetica,swiss size=3>Type</td><td><font  color=#cccccc face=arial,helvetica,swiss size=3>Max</td><td><font  color=#cccccc face=arial,helvetica,swiss size=3>Current</td>
										</tr>
										<tr><?php

echo "<td class=clsNrmTxt>Hangar</td><td>" . $db_p->f("hangarmax") . "</td><td>" . $db_p->f("hangarcurrent") . "</td>";
echo "</tr>";
echo "<tr>";
echo "<td class=clsNrmTxt>Generator</td><td>" . $db_p->f("generatormax") . "</td><td>" . $db_p->f("generatorcurrent") . "</td>";
echo "</tr>";
echo "<tr>";
echo "<td class=clsNrmTxt>Turrets</td><td>" . $db_p->f("turretsmax") . "</td><td>" . $db_p->f("turretscurrent") . "</td>";
?>
										</tr>
									</table><?php

echo "<br>&nbsp;<font color=#cccccc face=arial,helvetica,swiss size=3>Drones: </font><font color=#FFFFFF face=arial,helvetica,swiss size=3>" . $db_p->f("combatcurrent") . "</font><br>";
echo "&nbsp;<font color=#cccccc face=arial,helvetica,swiss size=3>Shields: </font><font color=#FFFFFF face=arial,helvetica,swiss size=3>" . $db_p->f("shieldcurrent") . "</font>";
?>
								</td>
								<td valign=top width=250><font color=#3333FF face=arial,helvetica,swiss size=3>
									<b>Construction</b><br></font><?php

if ( $db_p->f("structure_type_id") <> 0 )  {
	$db = new ME_DB;
	$str = $db_p->f("structure_type_id");
	$db->query("select * from planet_structure_types where planet_structure_type_id = '$str'");
	$db->next_record();
	echo "<table><tr>";
	echo "<td width=100%><font color=#cccccc  face=arial,helvetica,swiss size=3>";

	echo "Building: " . $db->f("type") . "<br>";
	$comptime = $db_p->f("structure_completion_time");
	$currenttime = time();
	$d = ($comptime - $currenttime) / 3600;
	$g = ceil($d) - (($comptime - $currenttime) / 3600);

	if ( $comptime - $currenttime <= 0 ) {
		echo "Structure will be completed momentarily.";
	} else {
		if ($g == 0) {
			$minutes = "0";
		} else {
			$minutes = ((1 - $g) * 60) / 100;
			$minutes = substr($minutes, 2, 2);

	  	if ( strlen($minutes) == 1) {
  			$minutes = $minutes . "0";
			}
		}

		echo "Completion time: " . floor($d) . " hours and " . $minutes . " minutes";
	}

	echo "</font></td>";
	echo "</tr></table>";
} else {
	echo "<font color=#cccccc  face=arial,helvetica,swiss size=3>&nbsp;Building: Nothing.</font>";
}

$planetary_cargo = get_planetary_cargo($db_p);

echo "<font color=#3333FF face=arial,helvetica,swiss size=3>";
echo "<br><br><b>Stockpile</b></font><table border=0 cellspacing=0 cellpadding=0>";

while (list($key, $val) = each($planetary_cargo)) {
	if ( strlen($val) > 0 ) {
		echo "<tr><td class=clsNrmTxt>&nbsp;" . $key . ":</td><td>&nbsp;" . $val . "</td></tr>";
	} else {
		echo "<tr><td class=clsNrmTxt>&nbsp;" . $key . "</td><td>&nbsp;" . $val . "</td></tr>";	
	}
}

echo "</table><br><br>";

echo "</td></tr>";

}

?>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

} else {

?>
<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td valign=top width=230>
									<font color=#cccccc face=arial,helvetica,swiss size=3>
									You control no planets.
								</td>
								<td valign=top width=230>
									<font color=#3333FF face=arial,helvetica,swiss size=3>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>