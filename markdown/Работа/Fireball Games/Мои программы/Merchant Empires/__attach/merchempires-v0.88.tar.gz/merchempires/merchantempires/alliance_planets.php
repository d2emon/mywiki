<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function get_planetary_cargo($db_p) {
	$cargo_temp = explode(",", $db_p->f("cargo"));

	for ($i = 0; $i <= count($cargo_temp) - 1; $i = $i + 2) {
		$planetary_cargo[$cargo_temp[$i]] = $cargo_temp[$i + 1];
	}		

	return $planetary_cargo;
}
?>

<html><head><title>Merchant Empires: Alliance Planets</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "alliance");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

if (!isset($alliance_id))  {
	if ( $player->f("alliance_id") <> 0 ) {
		$alliance_id = $player->f("alliance_id");
	} else {
		$alliance_id = -1;
	}
} else {
	$alliance_id = -1;
}

$alliance_id = (int) $alliance_id;

if ( $alliance_id <> -1 )  {

?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=490><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "alliance_planets");	
$db->add_parameter("alliance_id", $alliance_id);
echo $db->get_transform("./xslt/menu_top_alliance.xslt", "");
}

$sector_id = $ship->f("sector_id");
$alliance_id = $player->f("alliance_id");
$db = new ME_DB;
$db->query("SELECT * from planets where alliance_id = '$alliance_id' order by sector_id");

?>

<table border=0 cellPadding=0 cellSpacing=0 width=500>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellpadding=2 cellspacing=1 width=500>
				<tr>
					<td class=clsHedTxt id=blu1>
					<center>Planet</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Sector</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Owner</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>G</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>H</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>T</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Building</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Shields</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Drones</center>
					</td>
					<td class=clsHedTxt id=blu1>
					<center>Supplies</center>
					</td>
				</tr><?php

while ( $db->next_record() ) {
	echo "<tr>";
	echo "<td class=clsNrmTxt><center>";
	echo htmlentities($db->f("name"));
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo $db->f("public_sector_id");
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo htmlentities($db->f("owner_name"));
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo $db->f("generatorcurrent");
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo $db->f("hangarcurrent");
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo $db->f("turretscurrent");
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";

	if ( $db->f("structure_type_id") <> 0 )  {
		$db_st = new ME_DB;
		$str = $db->f("structure_type_id");
		$db_st->query("select * from planet_structure_types where planet_structure_type_id = '$str'");
		$db_st->next_record();
		echo "<table><tr>";
		echo "<td width=50%><font color=#cccccc  face=arial,helvetica,swiss size=2>";

		echo $db_st->f("type") . "<br><br>";
		$comptime = $db->f("structure_completion_time");
		$currenttime = time();
		$d = ($comptime - $currenttime) / 3600;
		$g = ceil($d) - (($comptime - $currenttime) / 3600);

		if ( $comptime - $currenttime <= 0 ) {
			echo "Structure will be completed momentarily.";
		} else {
			if ($g == 0) {
				$minutes = "0";
			} else {
				$minutes = ((1 - $g) * 60) / 100;
				$minutes = substr($minutes, 2, 2);

		  	if ( strlen($minutes) == 1) {
	  			$minutes = $minutes . "0";
				}
			}

			echo "Completion time: " . floor($d) . " hours and " . $minutes . " minutes";
		}
		
		echo "</td>";
		echo "</tr></table>";
	} else {
		echo "Building: Nothing.</font>";
	}	

	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo $db->f("shieldcurrent");
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo $db->f("combatcurrent");
	echo "</center></td>";

	echo "<td class=clsNrmTxt><center>";
	echo "<table cellpadding=0 cellspacing=0>";

	$planetary_cargo = get_planetary_cargo($db);

	while (list($key, $val) = each($planetary_cargo)) {
		echo "<tr><td class=clsNrmTxt>" . $key . ":</td><td class=clsNrmTxt>" . $val . "</td></tr>";
	}
	
	echo "</table>";
	echo "</center></font></td>";
	echo "</tr>";
}
?>
			</table>
		<td>
  </tr>
</table>
<br>
</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>