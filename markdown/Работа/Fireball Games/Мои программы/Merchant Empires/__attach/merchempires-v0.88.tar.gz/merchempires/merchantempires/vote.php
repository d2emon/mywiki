<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));
include("./merchantempiresdefines.php");
$sess->register("player_id");

include("./lib/player.php");

$error = 0;

$db = new ME_DB;
$query = sprintf("SELECT * from votes where vote_id = 2");
$db->query($query);	
$db->next_record();

$vote_id = $db->f("vote_id");
$selection_one = $db->f("selection_one");
$selection_two = $db->f("selection_two");
$selection_three = $db->f("selection_three");

if ( $feature == 1 ) {
	$selection_one = $selection_one + 1;
} elseif ( $feature == 2 ) {
	$selection_two = $selection_two + 1;
} elseif ( $feature == 3 ) {
	$selection_three = $selection_three + 1;
}

$query = "update votes set selection_one = '$selection_one', selection_two = '$selection_two',
	selection_three = '$selection_three' where vote_id = '$vote_id'";
$db->query($query);

$newurl = $sess->url(URL . "merchant.php");
header("Location: $newurl");


page_close();
?>