<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/cargo.php");
include("./merchantempiresdefines.php");

#if player dead, send to post-death screen
if ( $player_dead == 't' ) {	
	$newurl = $sess->url(URL . "death.php");
	header("Location: $newurl");
	exit;
}

# send player to select a game if no player id
if (!$player_id>0)  {
	$newurl = $sess->url(URL . "select_game.php");
	header("Location: $newurl");
	exit;
}

function get_visible_sectors($map_id, $player)  {
	$db = new ME_DB;
	$query = sprintf("SELECT * from maps where map_id = '%s'", $map_id);
	$db->query($query);	
  $db->next_record();
	$map_rank = $db->f("map_rank");

	if ( $player->f("alliance_id") <> 0 ) {	
		$query = sprintf("SELECT * from alliance_maps where alliance_id = '%s'", $player->f("alliance_id"));
	} else {
		$query = sprintf("SELECT * from player_maps where player_id = '%s'", $player->f("player_id"));
	}

	$db->query($query);	
  $db->next_record();

	switch ($map_rank) {
		case "1":
			$sectors = $db->f("map_1");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);			

			return $visible_sectors;

			break;
		case "2":
			$sectors = $db->f("map_2");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);
		
			return $visible_sectors;			

			break;
		case "3":
			$sectors = $db->f("map_3");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;			

			break;
		case "4":
			$sectors = $db->f("map_4");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;
			
			break;
		case "5":
			$sectors = $db->f("map_5");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;			

			break;
		case "6":
			$sectors = $db->f("map_6");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;		

			break;
		case "7":
			$sectors = $db->f("map_7");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;		

			break;
		case "8":
			$sectors = $db->f("map_8");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;		

			break;
		case "9":
			$sectors = $db->f("map_9");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;		

			break;
		case "10":
			$sectors = $db->f("map_10");
			$visible_sectors = array();
			$visible_sectors = explode(",", $sectors);

			return $visible_sectors;		

			break;
	}	
}

?>

<html><head><title>Merchant Empires: Galaxy Mini Map</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "galaxymap");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5><?php

$id = (int) $id;

$db = new ME_DB;
$query = sprintf("select map_id, description from maps where map_id = '%s'", $id);
$db->query($query);
$db->next_record();

echo $db->f("description");
?>
								</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$query = sprintf("select * from maps where map_id = '%s'", $id);
$db->query($query);
$db->next_record();

$db_2 = new ME_DB;

$query = "select * from sectors where map_id = '$id'";
$db_2->query($query);
$galaxy = array();

$visible_sectors = array();
$visible_sectors = get_visible_sectors($id, $player);

while ( $db_2->next_record() ) {	
	$galaxy[$db_2->f("xpos") . "," . $db_2->f("ypos")] = $db_2->f("sector_id") . "," . $db_2->f("public_sector_id");
}

?>
<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1><?php

$y = $db->f("ysize") - 1;
$x = 0;
for ($i = 1; $i <= $db->f("xsize"); $i++) {
	echo "<tr>";
	for ($j = 1; $j <= $db->f("ysize"); $j++) {
		echo "<td width=500 ";

		if ( ! (in_array(substr( $galaxy[$x . "," . $y], 0, strpos($galaxy[$x . "," . $y], ",") ), $visible_sectors)) )  {
			echo "bgColor=#666666";
		} else {
			echo "bgColor=#000000";
		}

		echo " align=left valign=middle>";	
		echo "<small><small>&nbsp;";
		echo "<a href=";
		$sess->purl(URL . "galaxy_map.php");
		# using the index (the x,y value), output the comma separated sector and public sector values
		echo "?id=" . substr( $galaxy[$x . "," . $y], 0, strpos($galaxy[$x . "," . $y], ",") ) . ">";	
		echo substr( $galaxy[$x . "," . $y], strpos($galaxy[$x . "," . $y], ",") + 1 );
		echo "</a>";		
		echo "</small></small>";		
		echo "</td>";
		$x = $x + 1;
	}
	echo "</tr>";
	$y = $y - 1;
	$x = 0;
}
?>
			</table>
		</td>
	</tr>
</table>

</td>
<td valign=top align=right width=100%>

</td></tr></table>
</body></html><?php

page_close();
?>