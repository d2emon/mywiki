<?php

$db = new ME_DB_Xml;
$db->query("select player_id, read, battle, scout, planetary from messages where player_id = '$player_id' and read = 'f'");

if ( $db->nf() > 0 ) {
	echo $db->get_transform("./xslt/messages.xslt", $db->get_xml());
}

?>
