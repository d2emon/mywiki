<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));

include("./merchantempiresdefines.php");
include("./lib/player.php");
include("./lib/player_config.php");
include("./lib/player_score.php");
include("./lib/weapons.php");
include("./lib/technology.php");
include("./lib/ship.php");
?>

<html><head><title>Merchant Empires: New Player</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white bgcolor="#000000" BACKGROUND="./images/createbg.gif"><?php

include("./templates/header.html");
$error = 0;

## Get a database connection
$db = new ME_DB;

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {

	switch ($key) {
		case "create": // Create a new player
			if (empty($game_id) || empty($race) || empty($name)) {
				$error = "Please fill out all of the fields.";
				break;
			}

			$game_id = (int) $game_id;

			if ( stristr($name, ';') ) {
				$error = "Illegal character in name.";
				break;			
			}

			if ( stristr($race, ';') ) {
				$error = "Illegal character in race.";
				break;			
			}

			if ( strlen($name) > 20 ) {
	  		$error = "Merchant names are limited to 20 characters.";
	  		break;
	  	}

			if ( strlen(trim($name)) < 3 ) {
	  		$error = "Merchant names must be at least 3 characters.";
	  		break;
	  	}

			$db->query("select player_id, name, game_id from players where name = '$name' and game_id = '$game_id'");
	  	$db->next_record();

	  	if ($db->nf()>0) {
	  		$error = "A merchant with that name already exists.";
	  		break;
	  	}

			if ( stristr (strtolower($name), 'fuck') ) {
				$error = "Invalid name.";
				break;
			}

			if ( stristr (strtolower($name), 'shareplay') ) {
				$error = "Invalid name.";
				break;
			}

			if ( stristr (strtolower($name), 'spacemerchant') ) {
				$error = "Invalid name.";
				break;
			}

			if ( stristr (strtolower($name), 'space merchant') ) {
				$error = "Invalid name.";
				break;			
			}

			$db->query("select game_id, user_id from players where user_id = '$user->id' and game_id = '$game_id'");
	  	$db->next_record();

	  	if ($db->nf()>0) {
	  		$error = "You have already joined that game.";
	  		break;
	  	}
			
			$player = new ME_Player;
			$player->get_new_player($user->id, $game_id, $race);
		  $player->set_name($name);
		  $player->set_race($race);
		  $player->set_turns(400);
		  $player->set_new_turns_left(950);
 	   	$player->set_credits(5000);
 	   	$player->set_experience(0);
 	   	$player->set_alignment(0);
 	   	$player->set_rank("Recruit");
			$player->set_alliance_id(0);
			$player->set_alliance_name("None");
			$player->set_relationrace_1(0);
			$player->set_relationrace_2(0);
			$player->set_relationrace_3(0);
			$player->set_relationrace_4(0);
			$player->set_relationrace_5(0);
			$player->set_relationrace_6(0);
			$player->set_relationrace_7(0);
		  $player->save();
	
		  $sess->register("player_id");
			$player_id = $player->f("player_id");
			
			$db = new ME_DB;
			$query = sprintf("update players set date_created = '%s' where player_id = '%s'", time(), $player_id);
			$db->query($query);	

			break;
	}
}
?>

<table BORDER=0 WIDTH='100%' NOSAVE >
  <tr>
   <td width=100 vAlign=top><?php

if ( !$error ) {
  $player = new ME_Player;
	$player->get_player($player_id);

	$ship = new ME_Ship;
	$ship->get_ship($player_id);

	$ship->add_parameter("time", date ("Y H:i:s"));
	echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
}

?>
   </td>
   <td width=350 align=left vAlign=top><?php

if ( $error ) {
	$db = new ME_DB_Xml;
	$db->add_parameter("title", "Error");
	$db->add_parameter("message", $error);
	echo $db->get_transform("./xslt/message_box.xslt", "");	
} else {

$qrystr = "update active_sessions set player_id = '$player_id', game_id = '$game_id' where sid = '$sess->id'";
$db->query($qrystr);

?>
<table border=0 cellPadding=0 cellSpacing=0 width=450
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width="100%">
  			<tr>
   				<td bgColor=#330000><FONT color=#ffffff  face=arial,helvetica,swiss size=4>
	    			Success
         		</FONT><br clear=all>
       		</td>
     		</tr>
     		<tr>
     			<td bgColor=#000000><br>
						<FONT  color=#cccccc face=arial,helvetica,swiss size=3>
						Your Merchant Empires player was successfully created.<br><br>
	    			</font>
	    		</td>
	    	</tr>
	  	</table>
	  </td>
	</tr>
</table><?php

}

?>

</td></tr></table>
</body></html><?php

page_close();
?>