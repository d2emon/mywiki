<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: View Messages Battle</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "viewmessages");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>
<form name="form_delete_messages" action="messages_update.php" method="post"><?php

$db = new ME_DB_Xml;
$db->add_parameter("current_screen", "view_messages_battle");
echo $db->get_transform("./xslt/menu_top_view_messages.xslt", "");

$db = new ME_DB;
$db->query("select * from messages where player_id = '$player_id' and read = 'f' and battle = 't' order by date_integer desc");

if ( $db->nf() == 0 ) {
	$query = sprintf("SELECT * from messages where player_id = '%s' and battle = 't' order by date_integer desc", $player_id);
	$db->query($query);
} else {
	$db_2 = new ME_DB;
	$db_2->query("update messages set read = 't' where player_id = '$player_id' and battle = 't'");
}

# counter variable for the marked messages array that is posted in the following form
$x = 0;

$color_3 = "#993300";
$color_4 = "#330000";
$color_1 = "#003399";
$color_2 = "#000033";
$fcolor_1 = "#3333FF";
$fcolor_2 = "#993300";
$toggle = 1;

if ($db->nf()>0) {
	while($db->next_record()) {
?>

	<table border=0 cellPadding=0 cellSpacing=0>
		<tr>
			<td bgColor=<?php

if ($toggle == 1) {
echo $color_1;
} else {
echo $color_3;
}
?>

				>
				<table border=0 cellPadding=1 cellSpacing=1 width=500>
					<tr>
						<td width=50% bgColor=<?php

if ($toggle == 1) {
echo $color_2;
} else {
echo $color_4;
}
?> 						
							width=150>
							<font color=<?php

if ($toggle == 1) {
echo $fcolor_1;
} else {
echo $fcolor_2;
}
?> 						
							face=arial,helvetica,swiss size=3>&nbsp;To:&nbsp;</font>
							<font color=#ccccc face=arial,helvetica,swiss size=3><?php

echo $db->f("toplayer");
?>
							</font>
						</td>
						<td width=50% bgColor=<?php

if ($toggle == 1) {
echo $color_2;
} else {
echo $color_4;
}
?> 						width=135>
							<font color=<?php

if ($toggle == 1) {
echo $fcolor_1;
} else {
echo $fcolor_2;
}

?>
							face=arial,helvetica,swiss size=3>&nbsp;Date:&nbsp;</font>
						 	<font color=#ccccc face=arial,helvetica,swiss size=2><?php

echo date ("H:i:s m/d/y",  $db->f("date_integer"));
?>
							</font>
						</td>
						<td align=right bgColor=<?php

if ($toggle == 1) {
echo $color_2;
} else {
echo $color_4;
}
?> 				
							>
							<input name=delete[<?php echo $x ?>] type=checkbox value=<?php

echo $db->f("message_id");
?>
						>
						</td>
					</tr>
					<tr>
						<td class=clsNrmTxt colSpan=3>
							<br><?php

echo $db->f("message");
?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table><br><?php
	
		$x = $x + 1;
		if ( $toggle == 1 ) {
			$toggle = 2;
  	} else {
  		$toggle = 1;
		}
	}
	
}
echo "<INPUT TYPE=hidden NAME=total_messages VALUE=" . $x . ">";
?>

</form>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
