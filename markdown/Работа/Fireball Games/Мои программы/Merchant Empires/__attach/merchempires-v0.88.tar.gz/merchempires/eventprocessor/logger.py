# -*- Mode: Python; tab-width: 4 -*-

import socket
import string

class file_logger:
			
	# pass this either a path or a file object.
	def __init__ (self, file, flush=1, mode='a'):
		if type(file) == type(''):
			if (file == '-'):
				import sys
				self.file = sys.stdout
			else:
				self.file = open (file, mode)
		else:
			self.file = file
		self.do_flush = flush

	def __repr__ (self):
		return '<file logger: %s>' % self.file

	def write (self, data):
		self.file.write (data)
		self.maybe_flush()
		
	def writeline (self, line):
		self.file.writeline (line)
		self.maybe_flush()
		
	def writelines (self, lines):
		self.file.writelines (lines)
		self.maybe_flush()

	def maybe_flush (self):
		if self.do_flush:
			self.file.flush()

	def flush (self):
		self.file.flush()

	def softspace (self, *args):
		pass

	def log (self, message):
		if message[-1] not in ('\r', '\n'):
			self.write (message + '\n')
		else:
			self.write (message)


