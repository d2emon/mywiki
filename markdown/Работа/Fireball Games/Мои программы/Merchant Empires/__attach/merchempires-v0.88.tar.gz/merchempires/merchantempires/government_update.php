<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");

include("./lib/player.php");
include("./lib/player_score.php");
include("./lib/ship.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

$error = 0;

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);
$sector_id = $ship->f("sector_id");

$db_g = new ME_DB;
$db_g->query("SELECT * from locations where sector_id = '$sector_id' and type='Government'");
$db_g->next_record();

// Check if there was a submission
while (is_array($HTTP_POST_VARS)
  && list($key, $val) = each($HTTP_POST_VARS)) {	

		switch ($key) {
			case "deputize":
				$returnto = "government";

				if ( $player->f("deputy_or_underground") == 't' or $player->f("alignment") <= -100 ) {
 		     	$error = 1;
					break;	
				}

				if ( $db_g->nf() == 0 ) {
					$error = 6;
					break;
				}

				$db = new ME_DB;
				$query = "update players set deputy_or_underground = 't', alignment = 150 where
					player_id = '$player_id'";
				$db->query($query);
			
				break;

			case "place_bounty":
				$merchant_id = (int) $merchant_id;
				$amount = (int) $amount;

				$returnto = "government";

				if ( $player->f("credits") < $amount ) {
 		     	$error = 2;
					break;	
				}
				
				if ( $db_g->nf() == 0 ) {
					$error = 6;
					break;
				}

				$db_p = new ME_DB;
				$db_p->query("select player_id, public_player_id, game_id, experience, name from players where public_player_id = '$merchant_id' and game_id = '$game_id'");
				$db_p->next_record();

				if ( $db_p->nf() == 0 ) {
					$returnto = "government_place";
					$error = 1;
					break;	
				}

				if ( $db_p->f("experience") < 1000 ) {
					$returnto = "government_place";
					$error = 5;
					break;
				}

				if ( $amount < 10000 ) {
					$returnto = "government_place";
 		     	$error = 2;
					break;	
				}
			
				if ( $amount > 10000000 ) {
					$returnto = "government_place";
 		     	$error = 3;
					break;	
				}

				$new_credits = $player->f("credits") - $amount;

				$db = new ME_DB;
				$player_place_id = $player->f("player_id");
				$player_place_name = addslashes($player->f("name"));

				
				if ( $db_p->f("experience") > 10000 and $db_p->f("experience") < 100000) {
					$amount = $amount + ($amount * .2);
				}

				if ( $db_p->f("experience") >= 100000 ) {
					$amount = $amount + ($amount * .5);
				}

				$player_target_id = $db_p->f("player_id");
				$player_target_name = addslashes($db_p->f("name"));

				if ( $player_target_id == $player_place_id ) {
					$returnto = "government_place";
 		     	$error = 4;
					break;	
				}

				$query = "select * from bounties where player_target_id = '$player_target_id'";
				$db->query($query);
				$db->next_record();

				if ( $db->nf() > 0 ) {
					$new_amount = $db->f("amount") + $amount;
					$bounty_id = $db->f("bounty_id");
					
					$query = "update bounties set amount = '$new_amount' where bounty_id = '$bounty_id'";
					$db->query($query);
				} else {
					$query = "insert into bounties (game_id, player_place_id, player_place_name, amount,
						player_target_id, player_target_name) values ('$game_id', '$player_place_id',
						'$player_place_name', '$amount', '$player_target_id', '$player_target_name')";
					$db->query($query);
				}				
				
				$player->set_credits($new_credits);
				$player->save();
			
				break;

			case "claim_bounty":
				$returnto = "government";

				if ( $db_g->nf() == 0 ) {
					$error = 6;
					break;
				}

				$bounties = array();
				$bounties = explode(",", $player->f("unclaimed_bounties"));

				if ( ! $bounties[0] > 0 ) {
					$returnto = "government";
 		     	$error = 4;
					break;	
				} else {

					while (list($key, $val) = each($bounties)) {
						$val = (int) $val;

						$db = new ME_DB;
						$db->query("select * from bounties where bounty_id = '$val'");

						while ( $db->next_record() ) {
							$new_credits = $new_credits + $db->f("amount");
					
							$db_2 = new ME_DB;
							$db_2->query("delete from bounties where bounty_id = '$val'");		
						}
					}

					$player_score = new ME_Player_score;
					$player_score->get_player_score($player->f("player_id"));
					$player_score->set_credits_from_bounties($player_score->f("credits_from_bounties") + $new_credits);
					$player_score->save();
					
					$new_credits = $new_credits + $player->f("credits");
					$player->set_credits($new_credits);
					$player->set_unclaimed_bounties('');
					$player->save();
				}

				break;

			case "claim_military_bounty":
				$returnto = "government";

				if ( $db_g->nf() == 0 ) {
					$error = 6;
					break;
				}

				$bounties = array();
				$bounties = explode(",", $player->f("unclaimed_military_bounties"));

				if ( ! $bounties[0] > 0 ) {
		    	$returnto = "government";
 		     	$error = 4;
					break;
				} else {
					$new_credits = 0;

					while (list($key, $val) = each($bounties)) {
						$val = (int) $val;

						$db = new ME_DB;
						$db->query("select * from ship_types where ship_type_id = '$val'");

						while ( $db->next_record() ) {
								$amount = (int) ($db->f("cost") * .15);
								if ( $amount < 50000 ) {
									$amount = 50000;
								}
						
							$new_credits = $new_credits + $amount;
						}
					}

					$player_score = new ME_Player_score;
					$player_score->get_player_score($player->f("player_id"));
					$player_score->set_credits_from_bounties_military($player_score->f("credits_from_bounties_military") + $new_credits);
					$player_score->save();

					$new_credits = $new_credits + $player->f("credits");
					$player->set_credits($new_credits);
					$player->set_unclaimed_military_bounties('');
					$player->save();
				}

				break;

			case "post_bulletin":
				$returnto = "government_bulletin";

				if ( $db_g->nf() == 0 ) {
					$error = 6;
					break;
				}
	
				if (strlen($bulletin) > 800) {
					$error = 2;
					break;
				}

				if ( stristr($bulletin, ';') ) {
					$error = 3;
					break;			
				}

				if ( stristr($bulletin, 'fuck') ) {
					$error = 3;
					break;			
				}

				$db = new ME_DB;
				$db->query("select * from bulletins where player_id = '$player_id' and sector_id = '$sector_id'");
						
				if ( $db->nf() > 0 ) {
					$error = 4;
					break;
				}

				$query = "select * from bulletins where sector_id = '$sector_id' order by bulletin_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 10 ) {
         	$bulletin_id = $db->f("bulletin_id");
			
					$query = "delete from bulletins where bulletin_id = '$bulletin_id'";
					$db->query($query);
				}

				$public_player_id = $player->f("public_player_id");
				$player_name = addslashes($player->f("name"));
				$bulletin = addslashes($bulletin);
				
				$db->query("insert into bulletins (player_id, public_player_id, player_name, sector_id, bulletin)
					values ('$player_id', '$public_player_id', '$player_name', '$sector_id', '$bulletin')");									
						
				break;
		}	
}

if ( $error ) {
	if ($returnto == "government")  {
		$newurl = $sess->url(URL . "government.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "government_place")  {
		$newurl = $sess->url(URL . "government_place.php?error=$error");
 		header("Location: $newurl");	
	} elseif ($returnto == "government_bulletin")  {
		$newurl = $sess->url(URL . "government_bulletins.php?error=$error");
 		header("Location: $newurl");	
	}
} else {
	if ($returnto == "government")  {
		$newurl = $sess->url(URL . "government.php");
		header("Location: $newurl");	
	}	elseif ($returnto == "government_place")  {
		$newurl = $sess->url(URL . "government_place.php");
		header("Location: $newurl");	
	} elseif ($returnto == "government_bulletin")  {
		$newurl = $sess->url(URL . "government_bulletins.php");
 		header("Location: $newurl");
	}
}

page_close();
?>