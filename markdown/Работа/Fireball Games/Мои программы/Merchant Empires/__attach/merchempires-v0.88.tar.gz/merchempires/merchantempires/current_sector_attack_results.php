<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/player_score.php");
include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./lib/ship_combat.php");
include("./lib/weapons.php");
include("./lib/relations.php");
include("./lib/cargo.php");
include("./lib/technology.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");

function display_error($subject, $message) {
	echo "<table border=0 cellPadding=0 cellSpacing=0><tr><td bgColor=#993300><table border=0 cellPadding=5 cellSpacing=1 width=500>";
	echo "<tr><td class=clsHedTxt id=red1>" . $subject . "<br></td></tr><tr><td class=clsNrmTxt width=500 valign=middle><br>";
	echo $message;
	echo "<br><br></td></tr></table></td></tr></table><br>";
}

function attack_forces($attacker_id, $defender_id, $wa) {	
	$db_df = new ME_DB;
	$query = sprintf("SELECT * from forces where forces_id = '%s'", $defender_id);
	$db_df->query($query);
	$db_df->next_record();

	$db_as = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.rank, players.level, players.experience, players.turns, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.combatcurrent, ships.type, ship_technology.player_id, ship_technology.targeting_computer, ship_technology.plasma_booster, ship_technology.cloak, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_as->query($query);
	$db_as->next_record();

	$targeting_bonus = 0;
	$damage_bonus = 0;

	if ( $db_as->f("targeting_computer") ) {
		$targeting_bonus = get_targeting_bonus($db_as->f("targeting_computer"));
	}

	if ( $db_as->f("plasma_booster") ) {
		$damage_bonus = get_damage_bonus($db_as->f("plasma_booster"));
	}

	$defender_name = "Forces<br>";

	if ( $db_df->f("mine") > 0 ) {
		$defender_name = $defender_name . "&nbsp;Mines: " . $db_df->f("mine") . "<br>";
	}

	if ( $db_df->f("combat") > 0 ) {
		$defender_name = $defender_name . "&nbsp;Combat Drones: " . $db_df->f("combat") . "<br>";
	}

	if ( $db_df->f("scout") > 0 ) {
		$defender_name = $defender_name . "&nbsp;Scout Drones: " . $db_df->f("scout") . "<br>";
	}		

	$combat = $db_df->f("combat");
	$mine = $db_df->f("mine");
	$scout = $db_df->f("scout");
	
	$combat_killed = 0;
	$mine_killed = 0;
	$scout_killed = 0;
		
	$attacker_name = htmlentities($db_as->f("name")) . "<br>&nbsp;" . $db_as->f("type") . "<br>";
	
	$w_a = new ME_Weapons;
	$w_a->get_weapons($db_as->f("ship_id"));	
?>

<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><td class=clsNrmTxt width=55% valign=top><?php
										
echo $attacker_name . "</td><td class=clsNrmTxt valign=top>" . $defender_name;

?>
										</td></tr>
									</table>
				        	<table>
                  <table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php

	for ($i = 1; $i <= 8; $i++) {
		if ( ($scout_killed + $mine_killed + $combat_killed) < ($db_df->f("scout") + $db_df->f("mine") + $db_df->f("combat")) ) {
			if ( $w_a->f("weapon_" . $i . "_id") > 0 ) {
				echo "<tr><td class=clsNrmTxt>" . $w_a->f("weapon_" . $i . "_name") . "</td><td class=clsNrmTxt align=center>";
    	
				$num = rand(1,100);	

				if ( (($num - $attacker_level) - $targeting_bonus) <= $wa[$w_a->f("weapon_" . $i . "_id")] and $w_a->f("weapon_" . $i . "_armor_damage") > 0 ) {
					$num = rand(-5,5) + $damage_bonus;	
					echo "<font color=CC0000>hit</font>";
					$damage = $w_a->f("weapon_" . $i . "_armor_damage");
					$damage = $damage + $num;

					if ( $damage <= 0 ) {
						$damage = 1;
					}

					$damage_type = $damage . " - kill";
					
					if ( $combat_killed < $combat ) {
						$combat_killed = $combat_killed + 1;
						$combat = $combat - 1;
					} elseif ( $scout_killed < $scout ) {
						$scout_killed = $scout_killed + 1;
						$scout = $scout - 1;
					}	elseif ( $mine_killed < $mine ) {
						$mine_killed = $mine_killed + 1;
						$mine = $mine - 1;
					}
											
				} elseif ( $w_a->f("weapon_" . $i . "_armor_damage") == 0 ) {
					echo "n/a";
					$damage_type = "--";
				} else {
					echo "<font color=33CC00>miss</font>";
					$damage_type = "--";
				}
	
				echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
			}
		}
	}
	
	if ( $db_as->f("combatcurrent") >= 30 ) {
		$attacking_drones = floor($db_as->f("combatcurrent") / 30);
		
		for ($i = 1; $i <= $attacking_drones; $i++) {
			if ( ($scout_killed + $mine_killed + $combat_killed) < ($db_df->f("scout") + $db_df->f("mine") + $db_df->f("combat")) ) {			
				echo "<tr><td class=clsNrmTxt>Combat Drones</td><td class=clsNrmTxt align=center>";    														
				echo "<font color=CC0000>hit</font>";					

				$damage_type = "kill";
					
				if ( $combat_killed < $combat ) {
					$combat_killed = $combat_killed + 1;
					$combat = $combat - 1;
				} elseif ( $scout_killed < $scout ) {
					$scout_killed = $scout_killed + 1;
					$scout = $scout - 1;
				}	elseif ( $mine_killed < $mine ) {
					$mine_killed = $mine_killed + 1;
					$mine = $mine - 1;	
				}															
			
				echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
			}
		}				
	}
?>
									</table>												
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php	
	
	if ( $db_as->f("turns") - 5 < 0 ) {
		$new_turns = 0;
	} else {
		$new_turns = $db_as->f("turns") - 5;
	}

	if ( $total_forces_killed > 0 ) {
		$new_experience = $db_as->f("experience") + ($total_forces_killed * 3);
		$num = rand(2,5);
		
		$new_experience = $new_experience + $num;
	} else {
		$new_experience = $db_as->f("experience");
	}
	
	if ( $db_as->f("cloak_active") == 't' ) {
		$ship_id = $db_as->f("ship_id");
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_as->query($query);
	}

	$query = sprintf("update players set turns = '$new_turns', experience = '$new_experience' where player_id = '%s'", $attacker_id);
	$db_as->query($query);
	
	$this_forces = array();
	$this_forces['player_name'] = $db_df->f("player_name");
	$this_forces['killed'] = 0;
	
	if ( ($scout_killed + $mine_killed + $combat_killed) >= ($db_df->f("scout") + $db_df->f("mine") + $db_df->f("combat")) ) {
		$db_as->query("delete from forces where forces_id = '$defender_id'");
		$this_forces['killed'] = 1;
	} else {		
		$db_as->query("update forces set scout = '$scout', mine = '$mine', combat = '$combat' where forces_id = '$defender_id'");		
	}				

	return $this_forces;
}

function attack_merchant_with_forces($defender_id, $attacker_id, $wa) {
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.level, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.type, ships.combatcurrent, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $defender_id);
	$db_ds->query($query);
	$db_ds->next_record();

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;

	$db_af = new ME_DB;
	$query = sprintf("SELECT * from forces where forces_id = '%s'", $attacker_id);
	$db_af->query($query);
	$db_af->next_record();

	$combat = $db_af->f("combat");
	$mine = $db_af->f("mine");
	$scout = $db_af->f("scout");
	
	$combat_killed = 0;
	$mine_killed = 0;
	$scout_killed = 0;
	$merchant_killed = 0;
			
	$attacker_name = "Forces<br>";

	if ( $db_af->f("mine") > 0 ) {
		$attacker_name = $attacker_name . "&nbsp;Mines: " . $db_af->f("mine") . "<br>";
	}

	if ( $db_af->f("combat") > 0 ) {
		$attacker_name = $attacker_name . "&nbsp;Combat Drones: " . $db_af->f("combat") . "<br>";
	}

	if ( $db_af->f("scout") > 0 ) {
		$attacker_name = $attacker_name . "&nbsp;Scout Drones: " . $db_af->f("scout") . "<br>";
	}

	$defender_name = htmlentities($db_ds->f("name")) . "<br>&nbsp;" . $db_ds->f("type") . "<br>";
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><td width=55% class=clsNrmTxt><?php
										
echo $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name;

?>
										</td></tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>
										</tr><?php

	if ( $combat ) {
		$attacking_drones = $combat;	

		$num = rand(20,55);
		$attacking_drones = (int) ($attacking_drones * ($num / 100));	

		if ( $attacking_drones < 1 ) {
			$attacking_drones = 1;
		}
		
		echo "<tr><td class=clsNrmTxt>Combat Drones</td><td class=clsNrmTxt align=center>";	
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;

			if ( $target_armor - $damage < 0 ) {
	 			$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent") + 1;
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
			}	
			$damage_type = $damage . " - arm";
		}
					
		echo "</td><td class=clsNrmTxtalign=center>" . $damage_type . "</td></tr>";	
	}	

	if ( $scout and !$combat and !$mine ) {
		echo "<tr><td class=clsNrmTxt>Scout Drone(s)</td><td class=clsNrmTxt align=center>";
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>explodes</font>";
			$exploding_scouts = ceil($scout / 2);
			$scout_killed = ceil($scout / 2);
			$scout = $scout - $scout_killed;
			$damage = 10 * $exploding_scouts;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>explodes</font>";
			$exploding_scouts = ceil($scout / 2);	
			$scout_killed = ceil($scout / 2);
			$scout = $scout - $scout_killed;
				
			$damage = 10 * $exploding_scouts;

			if ( $target_armor - $damage < 0 ) {
	 			$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent") + 1;
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
			}	
			$damage_type = $damage . " - arm";
		}
					
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";	
	}	
	
	if ( $mine and !$combat ) {
		$tactical_defense = get_tactical_defense($db_ds, $db_ds->f("level"));

		for ($i = 1; $i <= $mine; $i++) {
			if ( $tactical_defense >=15 and $tactical_defense < 25 ) {
				$num = rand(1,5);
			} elseif ( $tactical_defense >= 25 ) {
				$num = rand(1,6);
			} else {
				$num = rand(1,4);
			}			

			if ( $num == 1 ) {
      	$attacking_mines = $attacking_mines + 1;
			}
		}

		if ( $attacking_mines < 1 ) {
			$attacking_mines = 1;
		}

		$mine = $mine - $attacking_mines;
		$mine_killed = $attacking_mines;
		
		echo "<tr><td class=clsNrmTxt>";

		if ( $attacking_mines == 1 ) {
			echo $attacking_mines . " Mine";
		} else {
  		echo $attacking_mines . " Mines";
		}

		echo "</td><td class=clsNrmTxt align=center>";	
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>collides</font>";
			$damage = $attacking_mines * 15;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>collides</font>";
			$damage = $attacking_mines * 15;

			if ( $target_armor - $damage < 0 ) {
	 			$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent") + 1;
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
			}	
			$damage_type = $damage . " - arm";
		}
					
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
	}

	$ship_id = $db_ds->f("ship_id");
	
	if ( $shield_damage > 0 or $armor_damage > 0 ) {	
		$total_damage = $shield_damage + $armor_damage;
		echo "<tr><td class=clsNrmTxt colspan=3>";
		$total_damage = $shield_damage + $armor_damage;
		echo "<br>Total damage: " . $total_damage;
		echo "</td></tr>";

		$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		$new_armor = $db_ds->f("armorcurrent") - $armor_damage;		
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";
		$db_af->query($query);		
	}

	if ( $db_ds->f("cloak_active") == 't' ) {
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_af->query($query);
	}
?>
									</table>												
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( ($scout_killed + $mine_killed + $combat_killed) >= ($scout + $mine + $combat) ) {
		$db_ds->query("delete from forces where forces_id = '$attacker_id'");
	} else {
		$db_ds->query("update forces set scout = '$scout', mine = '$mine', combat = '$combat' where forces_id = '$attacker_id'");
	}	
		
	return $merchant_killed;
}

function attack_merchant_with_forces_mines($defender_id, $attacker_id, $wa) {
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.level, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.type, ships.combatcurrent, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $defender_id);
	$db_ds->query($query);
	$db_ds->next_record();

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;

	$db_af = new ME_DB;
	$query = sprintf("SELECT * from forces where forces_id = '%s'", $attacker_id);
	$db_af->query($query);
	$db_af->next_record();

	$sector_forces = array();

	$total_mines = $db_af->f("mine");
	$attacker_name = "Forces<br>";

	if ( $db_af->f("mine") > 0 ) {
		$attacker_name = $attacker_name . "&nbsp;Mines: " . $db_af->f("mine") . "<br>";
	}	

	$defender_name = htmlentities($db_ds->f("name")) . "<br>&nbsp;" . $db_ds->f("type") . "<br>";
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><td class=clsNrmTxt width=55%><?php
echo $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name . "</td>";

?>
										</tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php
	
	if ( $db_af->f("mine") > 0 ) {
		$tactical_defense = get_tactical_defense($db_ds, $db_ds->f("level"));
		
		for ($i = 1; $i <= $db_af->f("mine"); $i++) {
			if ( $tactical_defense >=15 and $tactical_defense < 25 ) {
				$num = rand(1,5);
			} elseif ( $tactical_defense >= 25 ) {
				$num = rand(1,6);
			} else {
				$num = rand(1,4);
			}
			
			if ( $num == 1 ) {
      	$attacking_mines = $attacking_mines + 1;
			}
		}		
		
		if ( $attacking_mines < 1 ) {
			$attacking_mines = 1;
		}

		echo "<tr><td class=clsNrmTxt>";

		if ( $attacking_mines == 1 ) {
			echo $attacking_mines . " Mine";
		} else {
  		echo $attacking_mines . " Mines";
		}

		echo "</td><td class=clsNrmTxt align=center>";	
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>collides</font>";
			$damage = $attacking_mines * 15;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>collides</font>";
			$damage = $attacking_mines * 15;

			if ( $target_armor - $damage < 0 ) {
	 			$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent") + 1;
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
			}	
			$damage_type = $damage . " - arm";
		}
					
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
	}	

	$ship_id = $db_ds->f("ship_id");

	if ( $shield_damage > 0 or $armor_damage > 0 ) {	
		$total_damage = $shield_damage + $armor_damage;
		echo "<tr><td colspan=3 class=clsNrmTxt>";
		$total_damage = $shield_damage + $armor_damage;
		echo "<br>Total damage: " . $total_damage;
		echo "</td></tr>";

		$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		$new_armor = $db_ds->f("armorcurrent") - $armor_damage;		
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";
		$db_af->query($query);		
	}

	if ( $db_ds->f("cloak_active") == 't' ) {
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_af->query($query);
	}
?>
									</table>												
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	$sector_forces[0] = $merchant_killed;
	$sector_forces[1] = $attacking_mines;
	$sector_forces[3] = $total_damage;
	return $sector_forces;	
}

function attack_merchant_with_planet_turret($attacker_id, $defender_id, $wa) {	
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.shieldmax, ships.armorcurrent, ships.armormax, ships.type, ships.combatcurrent, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_ds->query($query);
	$db_ds->next_record();

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;

	$w_a = new ME_Weapons;
	$w_a->get_weapons($db_ds->f("ship_id"));

  $db_ap = new ME_DB;
	$query = sprintf("SELECT * from planets where planet_id = '%s'", $defender_id);
	$db_ap->query($query);
	$db_ap->next_record();
	
	$attacker_name = "Planet<br>";
	$attacker_name = $attacker_name . "&nbsp;" . $db_ap->f("name") . "<br>";
	$defender_name = htmlentities($db_ds->f("name")) . "<br>&nbsp;" . $db_ds->f("type") . "<br>";

?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><td class=clsNrmTxt width=55%><?php
echo $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name . "</td>";

?>
										</tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;
  $planet_weapon_damage = 225;
	$merchant_killed = 0;

	$merchant_and_forces = array();
	$merchant_and_forces[0] = 0;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = 0;
	$merchant_and_forces[3] = 0;
	$merchant_and_forces[4] = 0;
	$merchant_and_forces[5] = $db_ds->f("name");
	$merchant_and_forces[6] = $db_ds->f("type");

	$new_shields = $db_ds->f("shieldcurrent");
	$new_armor = $db_ds->f("armorcurrent");

	if ( $db_ap->f("turretscurrent") > 0 ) {		
		echo "<tr><td class=clsNrmTxt>Heavy Ion Cannon</td><td class=clsNrmTxt align=center>";

		$num = rand(1,100);	

		if ( $num <= 55 ) {
			$num = rand(-5,5);	
			if ( $target_shields > 0 ) {
				echo "<font color=CC0000>hit</font>";
				$damage = $planet_weapon_damage;
				$damage = $damage + $num;
			
				if ( $target_shields - $damage < 0 ) {
	  			$target_shields = 0;
					$shield_damage = $db_ds->f("shieldcurrent");
				} else {
					$target_shields = $target_shields - $damage;
					$shield_damage = $shield_damage + $damage;
				}
				$damage_type = $damage . " - shd";
			} else {
				echo "<font color=CC0000>hit</font>";
				$damage = $planet_weapon_damage;
				$damage = $damage + $num;

				if ( $target_armor - $damage < 0 ) {
	  			$target_armor = 0;
					$armor_damage = $db_ds->f("armorcurrent");
					$merchant_killed = 1;
				} else {
					$target_armor = $target_armor - $damage;
					$armor_damage = $armor_damage + $damage;
				}	
				$damage_type = $damage . " - arm";
			}
		} else {
			echo "<font color=33CC00>miss</font>";
			$damage_type = "--";
		}
	
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";		
	}
	
	$ship_id = $db_ds->f("ship_id");

	if ( $shield_damage > 0 or $armor_damage > 0 ) {
		echo "<tr><td class=clsNrmTxt colspan=3>";
		$total_damage = $shield_damage + $armor_damage;
		echo "<br>Total damage: "		. $total_damage;
		echo "</td></tr>";

		if ( $db_ds->f("shieldcurrent") - $shield_damage <= 0 ) {
			$new_shields = 0;			
		} else {
			$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		}

		if ( $db_ds->f("armorcurrent") - $armor_damage <= 0 ) {
			$new_armor = 0;
		} else {
			$new_armor = $db_ds->f("armorcurrent") - $armor_damage;
		}
				
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";
		$db_ap->query($query);		
	}

	if ( $db_ds->f("cloak_active") == 't' ) {
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_ap->query($query);
	}
?>
									</table>																						
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	$merchant_and_forces[0] = $merchant_killed;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = $total_damage;
	$temp = $new_shields / $db_ds->f("shieldmax");

	if ( $temp == 1 ) {
		$merchant_and_forces[3] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[3] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[3] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[3] = 0;
			} else {
  			$merchant_and_forces[3] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[3] = (int) ($temp * 100);
		}
	}

	$temp = $new_armor / $db_ds->f("armormax");

	if ( $temp == 1 ) {
		$merchant_and_forces[4] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[4] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[4] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[4] = 0;
			} else {
  			$merchant_and_forces[4] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[4] = (int) ($temp * 100);
		}
	}

	return $merchant_and_forces;
}

function attack_merchant_with_planet_drones($attacker_id, $defender_id, $wa, $squadrons) {
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.shieldmax, ships.armorcurrent, ships.armormax, ships.type, ships.combatcurrent, ship_technology.cloak, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_ds->query($query);
	$db_ds->next_record();

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;

	$w_a = new ME_Weapons;
	$w_a->get_weapons($db_ds->f("ship_id"));

  $db_ap = new ME_DB;
	$query = sprintf("SELECT * from planets where planet_id = '%s'", $defender_id);
	$db_ap->query($query);
	$db_ap->next_record();
	
	$attacker_name = "Planet<br>";
	$attacker_name = $attacker_name . "&nbsp;" . $db_ap->f("name") . "<br>";
	$defender_name = htmlentities($db_ds->f("name")) . "<br>&nbsp;" . $db_ds->f("type") . "<br>";

?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><td class=clsNrmTxt width=55%><?php
echo $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name . "</td>";

?>
										</tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;
	$merchant_killed = 0;

	$merchant_and_forces = array();
	$merchant_and_forces[0] = 0;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = 0;
	$merchant_and_forces[3] = 0;
	$merchant_and_forces[4] = 0;
	$merchant_and_forces[5] = $db_ds->f("name");
	$merchant_and_forces[6] = $db_ds->f("type");

	$new_shields = $db_ds->f("shieldcurrent");
	$new_armor = $db_ds->f("armorcurrent");

	if ( $db_ap->f("combatcurrent") > 0 ) {
		$attacking_drones = $db_ap->f("combatcurrent");

		$num = rand(20,60);
		$attacking_drones = (int) (($attacking_drones / $squadrons) * ($num / 100));

		if ( $attacking_drones < 1 ) {
			$attacking_drones = 1;
		}

		echo "<tr><td class=clsNrmTxt>Combat Drones</td><td class=clsNrmTxt align=center>";	
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;

			if ( $target_armor - $damage < 0 ) {
	 			$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent") + 1;
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
			}	
			$damage_type = $damage . " - arm";
		}
					
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";	
	}

	$ship_id = $db_ds->f("ship_id");

	if ( $shield_damage > 0 or $armor_damage > 0 ) {
		echo "<tr><td class=clsNrmTxt colspan=3>";
		$total_damage = $shield_damage + $armor_damage;
		echo "<br>Total damage: "		. $total_damage;
		echo "</td></tr>";

		if ( $db_ds->f("shieldcurrent") - $shield_damage <= 0 ) {
			$new_shields = 0;			
		} else {
			$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		}

		if ( $db_ds->f("armorcurrent") - $armor_damage <= 0 ) {
			$new_armor = 0;
		} else {
			$new_armor = $db_ds->f("armorcurrent") - $armor_damage;
		}
				
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";
		$db_ap->query($query);				
	}

	if ( $db_ds->f("cloak_active") == 't' ) {
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_ap->query($query);
	}
?>
									</table>																						
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	$merchant_and_forces[0] = $merchant_killed;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = $total_damage;
	$temp = $new_shields / $db_ds->f("shieldmax");

	if ( $temp == 1 ) {
		$merchant_and_forces[3] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[3] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[3] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[3] = 0;
			} else {
  			$merchant_and_forces[3] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[3] = (int) ($temp * 100);
		}
	}

	$temp = $new_armor / $db_ds->f("armormax");

	if ( $temp == 1 ) {
		$merchant_and_forces[4] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[4] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[4] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[4] = 0;
			} else {
  			$merchant_and_forces[4] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[4] = (int) ($temp * 100);
		}
	}

	return $merchant_and_forces;
}

function attack_merchant_with_planet($attacker_id, $defender_id, $wa) {
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.shieldmax, ships.armorcurrent, ships.armormax, ships.type, ships.combatcurrent, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_ds->query($query);
	$db_ds->next_record();

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;

  $db_ap = new ME_DB;
	$query = sprintf("SELECT * from planets where planet_id = '%s'", $defender_id);
	$db_ap->query($query);
	$db_ap->next_record();
	
	$attacker_name = "Planet<br>";
	$attacker_name = $attacker_name . "&nbsp;" . $db_ap->f("name") . "<br>";
	$defender_name = htmlentities($db_ds->f("name")) . "<br>&nbsp;" . $db_ds->f("type") . "<br>";

?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><?php
echo "<td class=clsNrmTxt width=55%>" . $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name . "</td>";

?>
										</tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");
	$shield_damage = 0;
	$armor_damage = 0;
  $planet_weapon_damage = 225;
	$merchant_killed = 0;

	$merchant_and_forces = array();
	$merchant_and_forces[0] = 0;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = 0;
	$merchant_and_forces[3] = 0;
	$merchant_and_forces[4] = 0;

	$new_shields = $db_ds->f("shieldcurrent");
	$new_armor = $db_ds->f("armorcurrent");

	if ( $db_ap->f("turretscurrent") > 0 ) {
		for ($i = 1; $i <= $db_ap->f("turretscurrent"); $i++) {
			echo "<tr><td class=clsNrmTxt>Heavy Ion Cannon</td><td class=clsNrmTxt align=center>";

			$num = rand(1,100);	

			if ( $num <= 55 ) {
				$num = rand(-5,5);	
				if ( $target_shields > 0 ) {
					echo "<font color=CC0000>hit</font>";
					$damage = $planet_weapon_damage;
					$damage = $damage + $num;
			
					if ( $target_shields - $damage < 0 ) {
		  			$target_shields = 0;
						$shield_damage = $db_ds->f("shieldcurrent");
					} else {
						$target_shields = $target_shields - $damage;
						$shield_damage = $shield_damage + $damage;
					}
					$damage_type = $damage . " - shd";
				} else {
					echo "<font color=CC0000>hit</font>";
					$damage = $planet_weapon_damage;
					$damage = $damage + $num;

					if ( $target_armor - $damage < 0 ) {
		  			$target_armor = 0;
						$armor_damage = $db_ds->f("armorcurrent");
						$merchant_killed = 1;
					} else {
						$target_armor = $target_armor - $damage;
						$armor_damage = $armor_damage + $damage;
					}	
					$damage_type = $damage . " - arm";
				}
			} else {
				echo "<font color=33CC00>miss</font>";
				$damage_type = "--";
			}
	
			echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
		}
	}

	if ( $db_ap->f("combatcurrent") > 0 ) {
		$attacking_drones = $db_ap->f("combatcurrent");

		$num = rand(20,60);
		$attacking_drones = (int) ($attacking_drones * ($num / 100));

		if ( $attacking_drones < 1 ) {
			$attacking_drones = 1;
		}

		echo "<tr><td class=clsNrmTxt>Combat Drones</td><td class=clsNrmTxt align=center>";	
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;

			if ( $target_armor - $damage < 0 ) {
	 			$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent") + 1;
				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
			}	
			$damage_type = $damage . " - arm";
		}
					
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";	
	}

	$ship_id = $db_ds->f("ship_id");

	if ( $shield_damage > 0 or $armor_damage > 0 ) {
		echo "<tr><td class=clsNrmTxt colspan=3>";
		$total_damage = $shield_damage + $armor_damage;
		echo "<br>Total damage: "		. $total_damage;
		echo "</td></tr>";

		if ( $db_ds->f("shieldcurrent") - $shield_damage <= 0 ) {
			$new_shields = 0;			
		} else {
			$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		}

		if ( $db_ds->f("armorcurrent") - $armor_damage <= 0 ) {
			$new_armor = 0;
		} else {
			$new_armor = $db_ds->f("armorcurrent") - $armor_damage;
		}
				
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";
		$db_ap->query($query);		
	}

	if ( $db_ds->f("cloak_active") == 't' ) {
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_ap->query($query);
	}
?>
									</table>																						
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

	$merchant_and_forces[0] = $merchant_killed;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = $total_damage;
	$temp = $new_shields / $db_ds->f("shieldmax");

	if ( $temp == 1 ) {
		$merchant_and_forces[3] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[3] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[3] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[3] = 0;
			} else {
  			$merchant_and_forces[3] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[3] = (int) ($temp * 100);
		}
	}

	$temp = $new_armor / $db_ds->f("armormax");

	if ( $temp == 1 ) {
		$merchant_and_forces[4] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[4] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[4] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[4] = 0;
			} else {
  			$merchant_and_forces[4] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[4] = (int) ($temp * 100);
		}
	}

	return $merchant_and_forces;
}

function attack_planet_with_merchant($attacker_id, $defender_id, $wa) {	
	$db_as = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.rank, players.level, players.turns, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.combatcurrent, ships.type, ship_technology.player_id, ship_technology.targeting_computer, ship_technology.plasma_booster from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_as->query($query);
	$db_as->next_record();

	$targeting_bonus = 0;
	$damage_bonus = 0;

	if ( $db_as->f("targeting_computer") ) {
		$targeting_bonus = get_targeting_bonus($db_as->f("targeting_computer"));
	}

	if ( $db_as->f("plasma_booster") ) {
		$damage_bonus = get_damage_bonus($db_as->f("plasma_booster"));
	}	
	
	$attacker_level = $db_as->f("level");	

	$db_dp = new ME_DB;
	$query = sprintf("SELECT * from planets where planet_id = '%s'", $defender_id);
	$db_dp->query($query);
	$db_dp->next_record();
	
	$w_a = new ME_Weapons;
	$w_a->get_weapons($db_as->f("ship_id"));

	$total_forces = $db_dp->f("combatcurrent");
	$total_forces_killed = 0;

	$defender_name = "Planet<br>";
	$defender_name = $defender_name . "&nbsp;" . $db_dp->f("name") . "<br>";
	$attacker_name = htmlentities($db_as->f("name")) . "<br>&nbsp;" . $db_as->f("type") . "<br>";
?>
<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><?php
	echo "<td class=clsNrmTxt width=55%>" . $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name . "</td>";

?>
										</tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php

	$target_generators = $db_dp->f("generatorcurrent");
	$target_shields = $db_dp->f("shieldcurrent");
	$target_hangars = $db_dp->f("hangarcurrent");
	$target_combat = $db_dp->f("combatcurrent");
	$shield_damage = 0;
	$hangar_damage = 0;

	$planet_killed = 0;
	$planet_and_forces = array();
	$planet_and_forces[0] = 0;
	$planet_and_forces[1] = 0;

	for ($i = 1; $i <= 8; $i++) {
		if ( $w_a->f("weapon_" . $i . "_id") > 0 ) {
			echo "<tr><td class=clsNrmTxt>" . $w_a->f("weapon_" . $i . "_name") . "</td><td class=clsNrmTxt align=center>";

			$num = rand(1,100);	

			$next_hit_kills_generator = 0;
			if ( ($target_shields / 100 - 1 < 0) and $target_generators > 1 ) {
				$next_hit_kills_generator = 1;
			}
		
			if ( $target_shields <= 0 and $target_generators == 1 ) {
				$next_hit_kills_generator = 1;
			}

			$next_hit_kills_hangar = 0;
			if ( $target_shields <= 0 and $target_hangars > 0 ) {
				$next_hit_kills_hangar = 1;
			}	
   	
			if ( (($num - $attacker_level) - $targeting_bonus) <= $wa[$w_a->f("weapon_" . $i . "_id")] ) {
				$num = rand(-5,5);	
				if ( $next_hit_kills_generator and $w_a->f("weapon_" . $i . "_armor_damage") > 0 ) {
					echo "<font color=CC0000>hit</font>";
					$damage_type = "1 - g";
					$target_generators = $target_generators - 1;	
				} elseif ( $w_a->f("weapon_" . $i . "_shield_damage") > 0 and $target_shields > 0 ) {
					echo "<font color=CC0000>hit</font>";
					$damage = (int) (($w_a->f("weapon_" . $i . "_shield_damage") + $damage_bonus) / 4.5);
					$damage = $damage + $num;

					if ( $damage <= 0 ) {
						$damage = 1;
					}
			
					if ( $target_shields - $damage < 0 ) {
		  			$target_shields = 0;
						$shield_damage = $db_dp->f("shieldcurrent");
						$damage = $shield_damage;
					} else {
						$target_shields = $target_shields - $damage;
						$shield_damage = $shield_damage + $damage;
					}
					$damage_type = $damage . " - shd";				
				} elseif ( $next_hit_kills_hangar ) {
					echo "<font color=CC0000>hit</font>";
					$damage_type = "1 - h";
					$target_hangars = $target_hangars - 1;	
				} elseif ( $w_a->f("weapon_" . $i . "_armor_damage") > 0 and $target_combat > 0 ) {
					echo "<font color=CC0000>hit</font>";	
					$damage_type = "1 - kill CD";
					$target_combat = $target_combat - 1;
				} elseif ( $w_a->f("weapon_" . $i . "_armor_damage") > 0 and $target_combat == 0 and $w_a->f("weapon_" . $i . "_shield_damage") == 0 ) {
					echo "shielded";
					$damage_type = "--";
				}
			} else {
				if ( $w_a->f("weapon_" . $i . "_shield_damage") > 0 and $target_shields <= 0 and $w_a->f("weapon_" . $i . "_armor_damage") == 0 ) {
					echo "n/a";
					$damage_type = "--";			
				} else {
					echo "<font color=33CC00>miss</font>";
					$damage_type = "--";
				}
			}
	
			echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
		}
	}
	
	if ( $shield_damage > 0 or $target_generators <> $db_dp->f("generatorcurrent") or $target_hangars <> $db_dp->f("hangarcurrent") or $target_combat <> $db_dp->f("combatcurrent") ) {
		echo "<tr><td class=clsNrmTxt colspan=3>";

		if ( $target_generators <> $db_dp->f("generatorcurrent") ) {
			$generators_destroyed = $db_dp->f("generatorcurrent") - $target_generators;
			echo "<br>" . $generators_destroyed . " shield generator(s) destroyed.";
		}

		if ( $target_hangars <> $db_dp->f("hangarcurrent") ) {
			$hangars_destroyed = $db_dp->f("hangarcurrent") - $target_hangars;
			echo "<br>" . $hangars_destroyed . " combat drone hangar(s) destroyed.";
		}

		if ( $target_combat <> $db_dp->f("combatcurrent") ) {
			$combat_destroyed = $db_dp->f("combatcurrent") - $target_combat;
			echo "<br>" . $combat_destroyed . " combat drone(s) destroyed.";
		}

		$total_damage = $shield_damage + $generators_destroyed + $hangars_destroyed + $combat_destroyed;
		echo "<br><br>Total damage: "		. $total_damage;
		echo "</td></tr>";

		if ( $db_dp->f("shieldcurrent") - $shield_damage <= 0 ) {
  		$new_shields = 0;
		} else {
			$new_shields = $db_dp->f("shieldcurrent") - $shield_damage;
		}

		$planet_id = $db_dp->f("planet_id");
		$query = "update planets set shieldcurrent = '$new_shields', generatorcurrent = '$target_generators', hangarcurrent = '$target_hangars'
			where planet_id = '$planet_id'";
		$db_as->query($query);		

		if ( $target_generators == 0 and $target_hangars == 0 ) {
			$planet_killed = 1;
		}
	}
?>
									</table>																				
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $db_as->f("turns") - 5 < 0 ) {
		$new_turns = 0;
	} else {
		$new_turns = $db_as->f("turns") - 5;
	}

	$query = sprintf("update players set turns = '$new_turns' where player_id = '%s'", $attacker_id);
	$db_as->query($query);	

	$planet_and_forces[0] = $planet_killed;
	$total_forces_killed = $db_dp->f("combatcurrent") - $target_combat;
	$planet_and_forces[1] = $total_forces_killed;

	return $planet_and_forces;
}

function attack_merchant_with_merchant($attacker_id, $defender_id, $wa, $use_turns) {	
	$db_ds = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.rank, players.level, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.shieldmax, ships.armorcurrent, ships.armormax, ships.combatcurrent, ships.type, ships.turns_per_sector, ships.cargocurrent, ships.hardpoints, ships.scoutcurrent, ships.combatcurrent, ships.minescurrent, ship_technology.player_id, ship_technology.active_screens, ship_technology.screenscurrent, ship_technology.cloak_active from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $defender_id);
	$db_ds->query($query);
	$db_ds->next_record();	

	$db_as = new ME_DB;
	$query = sprintf("SELECT players.player_id, players.name, players.rank, players.level, players.turns, ships.ship_id, ships.player_id, ships.shieldcurrent, ships.armorcurrent, ships.combatcurrent, ships.type, ship_technology.player_id, ship_technology.targeting_computer, ship_technology.plasma_booster from players, ships, ship_technology where players.player_id = '%s' and ships.player_id = players.player_id and ship_technology.player_id = players.player_id", $attacker_id);
	$db_as->query($query);
	$db_as->next_record();

	$targeting_bonus = 0;
	$damage_bonus = 0;
	$tactical_defense = get_tactical_defense($db_ds, $db_ds->f("level"));

	if ( $db_as->f("targeting_computer") ) {
		$targeting_bonus = get_targeting_bonus($db_as->f("targeting_computer"));
	}

	if ( $db_as->f("plasma_booster") ) {
		$damage_bonus = get_damage_bonus($db_as->f("plasma_booster"));
	}	
	
	$attacker_level = $db_as->f("level");	
	
	$defender_name = htmlentities($db_ds->f("name")) . "<br>&nbsp;" . $db_ds->f("type") . "<br>";
	$attacker_name = htmlentities($db_as->f("name")) . "<br>&nbsp;" . $db_as->f("type") . "<br>";

	$w_a = new ME_Weapons;
	$w_a->get_weapons($db_as->f("ship_id"));	

	$total_forces = $db_ds->f("combatcurrent");
	$total_forces_killed = 0;
	$total_damage = 0;

	$merchant_and_forces = array();
	$merchant_and_forces[0] = 0;
	$merchant_and_forces[1] = 0;
	$merchant_and_forces[2] = 0;
	$merchant_and_forces[3] = 0;
	$merchant_and_forces[4] = 0;
?>

<table width=225 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=225 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
							<tr>
								<td valign=top width=225>
									<table width=225>
										<tr><td class=clsNrmTxt width=55%><?php
	echo $attacker_name . "</td><td class=clsNrmTxt>" . $defender_name . "</td>";

?>
										</tr>
									</table>
				        	<table>
										<tr>
											<td width=60%>
												<font color=#3333FF face=arial size=3>Weapon</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Result</font>
											</td>
											<td width=20% align=right>
												<font color=#3333FF face=arial size=3>Damage</font>
											</td>						
										</tr><?php

	$target_shields = $db_ds->f("shieldcurrent");
	$target_armor = $db_ds->f("armorcurrent");

	if ( $db_ds->f("active_screens") ) {
		$target_screens = $db_ds->f("screenscurrent");
	} else {
		$target_screens = 0;
	}

	$shield_damage = 0;
	$armor_damage = 0;
	$screens_damage = 0;

	$merchant_killed = 0;

	for ($i = 1; $i <= 8; $i++) {
		if ( $w_a->f("weapon_" . $i . "_id") > 0 ) {
			echo "<tr><td class=clsNrmTxt>" . $w_a->f("weapon_" . $i . "_name") . "</td><td class=clsNrmTxt align=center>";

			$num = rand(1,100);	

			if ( ((($num - $attacker_level) - $targeting_bonus) + $tactical_defense) <= $wa[$w_a->f("weapon_" . $i . "_id")] ) {
				$num = rand(-5,5) + $damage_bonus;
				if ( $w_a->f("weapon_" . $i . "_shield_damage") > 0 and $target_shields + $target_screens > 0 ) {
					echo "<font color=CC0000>hit</font>";
					$damage = $w_a->f("weapon_" . $i . "_shield_damage");
					$damage = $damage + $num;

					if ( $damage <= 0 ) {
						$damage = 1;
					}
			
					if ( $target_screens > 0 and $target_screens - $damage < 0 ) {
						$target_screens = 0;
						$screens_damage = $db_ds->f("screenscurrent");
						$damage_type = $damage . " - scn";
					} elseif ( $target_screens > 0 ) {
						$target_screens = $target_screens - $damage;
						$screens_damage = $screens_damage + $damage;
						$damage_type = $damage . " - scn";
					} elseif ( $target_shields > 0 and $target_shields - $damage < 0 ) {
		  			$target_shields = 0;
						$shield_damage = $db_ds->f("shieldcurrent");
						$damage_type = $damage . " - shd";
					} elseif ( $target_shields > 0 ) {
						$target_shields = $target_shields - $damage;
						$shield_damage = $shield_damage + $damage;
						$damage_type = $damage . " - shd";
					}				
				} elseif ( $w_a->f("weapon_" . $i . "_armor_damage") > 0 and $target_shields <= 0 and $target_screens <= 0 ) {
					echo "<font color=CC0000>hit</font>";				
	
					if ( $total_forces_killed < $total_forces and $num == 1 ) {					
						$damage = $w_a->f("weapon_" . $i . "_armor_damage");
						$damage = $damage + $num;
						$damage_type = $damage . " - kill CD";
						$total_forces_killed = $total_forces_killed + 1;
					} else {	
						$damage = $w_a->f("weapon_" . $i . "_armor_damage");
						$damage = $damage + $num;

						if ( $damage <= 0 ) {
							$damage = 1;
						}

						if ( $target_armor - $damage < 0 ) {
		  				$target_armor = 0;
							$armor_damage = $db_ds->f("armorcurrent");

							if ( !($merchant_killed) ) {			
								$damage_type = $damage . " - kill";
							} else {
								$damage_type = "---";
							}

							$merchant_killed = 1;
						} else {
							$target_armor = $target_armor - $damage;
							$armor_damage = $armor_damage + $damage;
							$damage_type = $damage . " - arm";
						}	
					}
				} elseif ( $w_a->f("weapon_" . $i . "_shield_damage") > 0 and $target_shields + $target_screens <= 0 and $w_a->f("weapon_" . $i . "_armor_damage") == 0 ) {
					echo "n/a";
					$damage_type = "--";
				} elseif ( $w_a->f("weapon_" . $i . "_armor_damage") > 0 and $target_shields + $target_screens > 0 and $w_a->f("weapon_" . $i . "_shield_damage") == 0 ) {
					echo "shielded";
					$damage_type = "--";
				}
			} else {
				if ( $w_a->f("weapon_" . $i . "_shield_damage") > 0 and $target_shields + $target_screens <= 0 and $w_a->f("weapon_" . $i . "_armor_damage") == 0 ) {
					echo "n/a";
					$damage_type = "--";
				} elseif ( $w_a->f("weapon_" . $i . "_armor_damage") > 0 and $target_shields + $target_screens > 0 and $w_a->f("weapon_" . $i . "_shield_damage") == 0 ) {
					echo "shielded";
					$damage_type = "--";
				} else {
					echo "<font color=33CC00>miss</font>";
					$damage_type = "--";
				}
			}
	
			echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";
		}	
	}
		
	if ( $db_as->f("combatcurrent") > 0 ) {
		$attacking_drones = $db_as->f("combatcurrent");

		$max_drones = (55 + $attacker_level) - $tactical_defense;
		$num = rand(5,$max_drones);
		$attacking_drones = (int) ($attacking_drones * ($num / 100));

		if ( $attacking_drones < 1 ) {
			$attacking_drones = 1;
		}

		echo "<tr><td class=clsNrmTxt>Combat Drones</td><td class=clsNrmTxt align=center>";	
		if ( $target_shields > 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;
			
			if ( $target_shields - $damage < 0 ) {
  			$target_shields = 0;
				$shield_damage = $db_ds->f("shieldcurrent");
			} else {
				$target_shields = $target_shields - $damage;
				$shield_damage = $shield_damage + $damage;
			}
			$damage_type = $damage . " - shd";
		} elseif ( $target_shields <= 0 ) {
			echo "<font color=CC0000>hit</font>";
			$damage = $attacking_drones * 3;

			if ( $target_armor - $damage < 0 ) {
	  		$target_armor = 0;
				$armor_damage = $db_ds->f("armorcurrent");

				if ( !($merchant_killed) ) {			
					$damage_type = $damage . " - kill";
				} else {
					$damage_type = "---";
				}

				$merchant_killed = 1;
			} else {
				$target_armor = $target_armor - $damage;
				$armor_damage = $armor_damage + $damage;
				$damage_type = $damage . " - arm";
			}	
		}
					
		echo "</td><td class=clsNrmTxt align=center>" . $damage_type . "</td></tr>";	
	}

	$ship_id = $db_ds->f("ship_id");

	if ( $shield_damage > 0 or $armor_damage > 0 or $screens_damage > 0 ) {
		echo "<tr><td class=clsNrmTxt colspan=3>";
		$total_damage = $shield_damage + $armor_damage + $screens_damage;
		echo "<br>Total damage: "		. $total_damage;
		echo "</td></tr>";

		if ( $db_ds->f("screenscurrent") - $screens_damage <= 0 ) {
			$new_screens = 0;			
		} else {
			$new_screens = $db_ds->f("screenscurrent") - $screens_damage;
		}

		if ( $db_ds->f("shieldcurrent") - $shield_damage <= 0 ) {
			$new_shields = 0;			
		} else {
			$new_shields = $db_ds->f("shieldcurrent") - $shield_damage;
		}

		if ( $db_ds->f("armorcurrent") - $armor_damage <= 0 ) {
			$new_armor = 0;
		} else {
			$new_armor = $db_ds->f("armorcurrent") - $armor_damage;
		}
		
		$query = "update ships set shieldcurrent = '$new_shields', armorcurrent = '$new_armor' where ship_id = '$ship_id'";
		$db_as->query($query);
		
		if ( $screens_damage > 0 ) {
			$query = "update ship_technology set screenscurrent = '$new_screens' where ship_id = '$ship_id'";
			$db_as->query($query);
		}				
	}

	if ( $db_ds->f("cloak_active") == 't' ) {
		$query = "update ship_technology set cloak_active = 'f' where ship_id = '$ship_id'";
		$db_as->query($query);
	}
?>
									</table>												
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

	if ( $use_turns ) {
		if ( $db_as->f("turns") - 5 < 0 ) {
			$new_turns = 0;
		} else {
			$new_turns = $db_as->f("turns") - 5;
		}

		$query = sprintf("update players set turns = '$new_turns' where player_id = '%s'", $attacker_id);
		$db_as->query($query);	
	}

	$merchant_and_forces[0] = $merchant_killed;
	$merchant_and_forces[1] = $total_forces_killed;
	$merchant_and_forces[2] = $total_damage;
	$temp = $new_shields / $db_ds->f("shieldmax");

	if ( $temp == 1 ) {
		$merchant_and_forces[3] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[3] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);	
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[3] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[3] = 0;
			} else {
  			$merchant_and_forces[3] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[3] = (int) ($temp * 100);
		}
	}

	$temp = $new_armor / $db_ds->f("armormax");

	if ( $temp == 1 ) {
		$merchant_and_forces[4] = 100;
	} elseif ( $temp == 0 ) {
		$merchant_and_forces[4] = 0;
	} else {
		$temp_2 = (string) $temp;

		if ( strlen($temp_2) > 4 ) {
			$temp_3 = substr($temp_2, 0, 4);
			$temp_3 = (int) ($temp_3 * 100);
			$num = rand(-5,5);
			if ( $temp_3 + $num > 100 ) {
				$merchant_and_forces[4] = 100;
			} elseif ( $temp_3 + $num < 0 ) {
				$merchant_and_forces[4] = 0;
			} else {
  			$merchant_and_forces[4] = $temp_3 + num;
			}
		} else {
			$merchant_and_forces[4] = (int) ($temp * 100);
		}
	}

	return $merchant_and_forces;
}

function merchant_been_killed($killed, $merchant_id) {
	$in_killed_array = 0;

	for ($i = 0; $i <= count($killed) - 1; $i++) {
		if ( $killed[$i][1] == $merchant_id ) {
			$in_killed_array = 1;
		}
	}

	return $in_killed_array;
}

function condense_force($array) {
	$new_array = array();

	$x = 0;

	for ($i = 0; $i <= count($array) - 1; $i++) {
		if ( $array[$i][1] > 0 ) {
			$new_array[$x][0] = $array[$i][0];
			$new_array[$x][1] = $array[$i][1];
			$new_array[$x][2] = $array[$i][2];
			$new_array[$x][3] = $array[$i][3];
			$x = $x + 1;
		}
	}

	return $new_array;
}

function condense_attackers($array) {
	$new_array = array();

	$x = 0;

	for ($i = 0; $i <= count($array) - 1; $i++) {
		if ( $array[$i][0] == 's' ) {
			$new_array[$x][0] = $array[$i][0];
			$new_array[$x][1] = $array[$i][1];
			$new_array[$x][2] = $array[$i][2];
			$new_array[$x][3] = $array[$i][3];
			$x = $x + 1;
		}
	}

	return $new_array;
}

function get_floatsam($dead_player_id) {
	$floatsam = array();	

	$db = new ME_DB;	
	$db->query("select ship_technology.*, ship_weapons.* from ship_technology, ship_weapons where ship_weapons.player_id = '$dead_player_id' and ship_technology.player_id = ship_weapons.player_id");
	$db->next_record();

	if ( $db->f("jump") ) {
		$floatsam['Jump Drive']['amount'] = 1;
		$floatsam['Jump Drive']['type'] = 2;
	}	

	if ( $db->f("cloak") ) {
		$floatsam['Cloaking Device']['amount'] = 1;
		$floatsam['Cloaking Device']['type'] = 2;
	}

	if ( $db->f("illusion") ) {
		$floatsam['Illusion Generator']['amount'] = 1;
		$floatsam['Illusion Generator']['type'] = 2;
	}

	if ( $db->f("scanner") ) {
		$floatsam['Scanners']['amount'] = 1;
		$floatsam['Scanners']['type'] = 2;
	}

	if ( $db->f("tracking") ) {
		$floatsam['Tracking Device']['amount'] = 1;
		$floatsam['Tracking Device']['type'] = 2;
	}

	if ( $db->f("tractor_beam") ) {
		$floatsam['Tractor Beam']['amount'] = 1;
		$floatsam['Tractor Beam']['type'] = 2;
	}

	if ( $db->f("deep_scanner") ) {
		$floatsam['Deep Space Scanner']['amount'] = 1;
		$floatsam['Deep Space Scanner']['type'] = 2;
	}

	if ( $db->f("targeting_computer") ) {
		$floatsam['Targeting Computer']['amount'] = 1;
		$floatsam['Targeting Computer']['type'] = 2;
	}

	if ( $db->f("active_screens") ) {
		$floatsam['Active Screens']['amount'] = 1;
		$floatsam['Active Screens']['type'] = 2;
	}

	if ( $db->f("trifocus_plasma") ) {
		$floatsam['Tri-Focus Plasma']['amount'] = 1;
		$floatsam['Tri-Focus Plasma']['type'] = 2;
	}

	if ( $db->f("plasma_booster") ) {
		$floatsam['Plasma Booster']['amount'] = 1;
		$floatsam['Plasma Booster']['type'] = 2;
	}	
	
	if ( $db->f("battle_systems_computer") ) {
		$floatsam['Battle Systems Computer']['amount'] = 1;
		$floatsam['Battle Systems Computer']['type'] = 2;
	}

	if ( $db->f("weapon_1_id") <> 0 ) {
		$floatsam[$db->f("weapon_1_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_1_name")]['type'] = 3;
	}

	if ( $db->f("weapon_2_id") <> 0 ) {
		$floatsam[$db->f("weapon_2_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_2_name")]['type'] = 3;
	}

	if ( $db->f("weapon_3_id") <> 0 ) {
		$floatsam[$db->f("weapon_3_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_3_name")]['type'] = 3;
	}

	if ( $db->f("weapon_4_id") <> 0 ) {
		$floatsam[$db->f("weapon_4_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_4_name")]['type'] = 3;
	}

	if ( $db->f("weapon_5_id") <> 0 ) {
		$floatsam[$db->f("weapon_5_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_5_name")]['type'] = 3;
	}

	if ( $db->f("weapon_6_id") <> 0 ) {
		$floatsam[$db->f("weapon_6_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_6_name")]['type'] = 3;
	}

	if ( $db->f("weapon_7_id") <> 0 ) {
		$floatsam[$db->f("weapon_7_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_7_name")]['type'] = 3;
	}

	if ( $db->f("weapon_8_id") <> 0 ) {
		$floatsam[$db->f("weapon_8_name")]['amount'] = 1;
		$floatsam[$db->f("weapon_8_name")]['type'] = 3;
	}

	return $floatsam;
}

function assign_floatsam($dead_player_id, $killer_id) {
	$floatsam = get_floatsam($dead_player_id);
	
	if ( count($floatsam) > 0 ) {		
		$cargo = new ME_Cargo;
		$cargo->get_cargo($killer_id);

		$open_holds = $cargo->Open_holds;
	
		while (list($key, $val) = each($floatsam)) {								
			$num = rand(1,2);	

			if ( $num == 2 and $open_holds > 0 ) {
				$cargo->set_good($key, $val['type'], $cargo->Current_cargo[$key]['amount'] + 1);

				$open_holds--;
			}
		}
		
		$cargo->save();
	}
}

function merchant_dead($dead_player_id, $killer_id, $sector_id, $killer_type) {
	$dead_player = new ME_Player;
	$dead_player->get_player($dead_player_id);
	
	if ( $dead_player->f("dead") <> 't' ) {
		$victor_credits = $dead_player->f("credits");
		$dead_player->set_credits(3000);
		$dead_player->set_new_turns_left(100);	

		$dead_player_alignment = $dead_player->f("alignment");
		$dead_player_experience = $dead_player->f("experience");
		$dead_player_level = $dead_player->f("level");
		$dead_player_race_id = $dead_player->f("race_number");
		$dead_player_alliance_id = $dead_player->f("alliance_id");
		$new_experience = (int) ($dead_player->f("experience") * .85);
		$dead_player->set_experience($new_experience);

		$db = new ME_DB;
		$query = "select * from levels where experience <= '$new_experience' order by experience desc limit 1";
		$db->query($query);
		$db->next_record();

		$dead_player->set_rank($db->f("rank"));
		$dead_player->set_dead("t");
		$dead_player->save();

		$game_id = $dead_player->f("game_id");
		$race = $dead_player->f("race");
		# find the player's starting sector	
		$db->query("select * from games where game_id = '$game_id'");
		$db->next_record();
			
		if ($race == $db->f("namerace_1")) {
			$sector_id = $db->f("startsectrace_1");
		} elseif ($race == $db->f("namerace_2")) {
			$sector_id = $db->f("startsectrace_2");
		} elseif ($race == $db->f("namerace_3")) {
			$sector_id = $db->f("startsectrace_3");
		} elseif ($race == $db->f("namerace_4")) {
			$sector_id = $db->f("startsectrace_4");
		} elseif ($race == $db->f("namerace_5")) {
			$sector_id = $db->f("startsectrace_5");
		} elseif ($race == $db->f("namerace_6")) {
			$sector_id = $db->f("startsectrace_6");
		} elseif ($race == $db->f("namerace_7")) {
			$sector_id = $db->f("startsectrace_7");
		}

		if ( $killer_type == 's' ) {
			assign_floatsam($dead_player_id, $killer_id);
		}

		$db->query("select player_id, type_id from ships where player_id = '$dead_player_id'");
		$db->next_record();
		$dead_ship_type_id = $db->f("type_id");
	
		$db_d = new ME_DB_Tran;
		$db_d->begin_transaction();
		$db_d->query("delete from ships where player_id = '$dead_player_id'");

		$delete_success = $db_d->affected_rows();

		if ( $delete_success ) {
		  $db_d->query("delete from ship_weapons where player_id = '$dead_player_id'");
			$db_d->query("delete from ship_technology where player_id = '$dead_player_id'");
		}

		$delete_success = $db_d->affected_rows();
		$db_d->end_transaction();

		if ( $delete_success ) {
			# set some default values
			$ship = new ME_Ship;
			$ship->get_new_ship($dead_player_id, $sector_id);
			$ship->set_type("Light Freighter");
			$ship->set_shieldmax(250);
			$ship->set_shieldcurrent(150);
			$ship->set_armormax(200);
			$ship->set_armorcurrent(75);
			$ship->set_powermax(50);
			$ship->set_powercurrent(15);
			$ship->set_minesmax(0);
			$ship->set_minescurrent(0);
			$ship->set_combatmax(0);
			$ship->set_combatcurrent(0);
			$ship->set_scoutmax(0);
			$ship->set_scoutcurrent(0);
			$ship->set_cargocurrent(40);
			$ship->set_cargomax(100);
			$ship->set_type_id(53);		
			$ship->set_turns_per_sector(2.5);
			$ship->set_hardpoints(1);
			$ship->set_last_move_date(time());	
			$ship->save();		
	
			$weapons = new ME_Weapons;
			$weapons->get_new_weapons($ship->id);
			$weapons->set_player_id($dead_player_id);
			$weapons->save();

			$technology = new ME_Technology;
			$technology->get_new_technology($ship->id);
			$technology->set_player_id($dead_player_id);		
			$technology->save();
		}
	
		$date = time();

		if ( $killer_type == 'f' or $killer_type == 'm' ) {			
			$db->query("select forces_id, player_name, public_sector_id from forces where forces_id = '$killer_id'");

			$db->next_record();
			$public_sector_id = $db->f("public_sector_id");	
			$killer_name = $db->f("player_name");
					
			$message = addslashes($dead_player->f("name")) . " was killed by forces belonging to " . addslashes($killer_name) . " in sector " . $db->f("public_sector_id") . ".";
			$query = "insert into news (date, item, game_id) values ('$date', '$message', '$game_id')";
			$db->query($query);		
		}

		if ( $killer_type == 's' ) {						
			$db->query("select * from bounties where player_target_id = '$dead_player_id'");
			$db->next_record();

			if ( $db->nf() > 0 ) {
				$new_bounties = $db->f("bounty_id");
			}

			$db->query("select * from underground_bounties where player_target_id = '$dead_player_id'");
			$db->next_record();

			if ( $db->nf() > 0 ) {
				$new_ug_bounties = $db->f("underground_bounty_id");
			}

			$db->query("select players.player_id, players.name, players.alignment, players.race, players.credits, players.race_number, players.alliance_name, players.alliance_id,
				players.experience, players.unclaimed_bounties, players.unclaimed_ug_bounties, players.unclaimed_military_bounties, ships.player_id,
				ships.sector_id, ships.public_sector_id from players, ships where players.player_id = '$killer_id'
				and players.player_id = ships.player_id");

			$db->next_record();
		
			$killer_name = $db->f("name");
			$killer_alliance_id = $db->f("alliance_id");

			$relations = new ME_Relations;
			$relations->initialize($game_id, $db->f("race_number"));

			if ( $dead_player_race_id == 1 ) {
				$this_relations = $relations->get_relations_1();
			} elseif ( $dead_player_race_id == 2 ) {
				$this_relations = $relations->get_relations_2();
			} elseif ( $dead_player_race_id == 3 ) {
				$this_relations = $relations->get_relations_3();
			} elseif ( $dead_player_race_id == 4 ) {
				$this_relations = $relations->get_relations_4();
			} elseif ( $dead_player_race_id == 5 ) {
				$this_relations = $relations->get_relations_5();
			} elseif ( $dead_player_race_id == 6 ) {
				$this_relations = $relations->get_relations_6();
			} elseif ( $dead_player_race_id == 7 ) {
				$this_relations = $relations->get_relations_7();
			}

			$new_military_bounties = $db->f("unclaimed_military_bounties");

			if ( $dead_player_experience > 100 ) {
				if ( $this_relations <= -300 ) {
					if ( strlen($new_military_bounties) > 0 ) {
						$new_military_bounties = $new_military_bounties . "," . $dead_ship_type_id;
					} else {
						$new_military_bounties = $dead_ship_type_id;
					}
				}
			}

			if ( strlen($new_bounties) > 0 ) {
				if ( strlen($db->f("unclaimed_bounties")) > 0 ) {

					$bounties = array();
					$bounties = explode(",", $db->f("unclaimed_bounties"));	

					$bounty_found = 0;
					while (list($key, $val) = each($bounties)) {
						if ( $val == $new_bounties ) {
							$bounty_found = 1;
						}		
					}	

					if ( !(bounty_found) ) {
						$new_bounties = $db->f("unclaimed_bounties") . "," . $new_bounties;
					} else {
						$new_bounties = $db->f("unclaimed_bounties");
					}
				}
			} else {
				$new_bounties = $db->f("unclaimed_bounties");
			}

			if ( strlen($new_ug_bounties) > 0 ) {
				if ( strlen($db->f("unclaimed_ug_bounties")) > 0 ) {

					$bounties = array();
					$bounties = explode(",", $db->f("unclaimed_ug_bounties"));	

					$bounty_found = 0;
					while (list($key, $val) = each($bounties)) {
						if ( $val == $new_ug_bounties ) {
							$bounty_found = 1;
						}		
					}	

					if ( !(bounty_found) ) {
						$new_ug_bounties = $db->f("unclaimed_ug_bounties") . "," . $new_ug_bounties;					
					} else {
						$new_ug_bounties = $db->f("unclaimed_ug_bounties");
					}				
				}
			} else {
				$new_ug_bounties = $db->f("unclaimed_ug_bounties");
			}
		
			$public_sector_id = $db->f("public_sector_id");

			if ( $db->f("alliance_name") <> 'None' ) {
				$killer_alliance = ' (' . $db->f("alliance_name") . ') ';
			} else {
				$killer_alliance = '';
			}

			if ( $dead_player->f("alliance_name") <> 'None' ) {
				$dead_player_alliance = ' (' . $dead_player->f("alliance_name") . ') ';
			} else {
				$dead_player_alliance = '';
			}

			$message = addslashes($db->f("name")) . addslashes($killer_alliance) . " killed " . addslashes($dead_player->f("name")) . addslashes($dead_player_alliance) . " in sector " . $db->f("public_sector_id") . ".";			
			$new_credits = $db->f("credits") + $victor_credits;

			$new_experience = ($dead_player_experience / 1000) * 50;
			if ( $new_experience < 50 ) {
				$new_experience = $db->f("experience") + 50;			
			} else {
				$new_experience = (int) ($db->f("experience") + $new_experience);	
			}

			$new_alignment = $db->f("alignment");

			$query = sprintf("select * from treaties where (primary_alliance_id = '%s' and secondary_alliance_id = '%s' and type = 'War') or (secondary_alliance_id = '%s' and primary_alliance_id = '%s' and type = 'War')", $killer_alliance_id, $dead_player_alliance_id, $dead_player_alliance_id, $killer_alliance_id);
			$db->query($query);
			$db->next_record();

			if ( $db->nf() == 0 ) {
				if ( $dead_player_experience > 300 ) {
					if ( $dead_player_alignment > 200 ) {
						$new_alignment = $new_alignment - 70;
					} elseif ( $dead_player_alignment > 150 ) {
		 				$new_alignment = $new_alignment - 50;
					} elseif ( $dead_player_alignment > 100 ) {
						$new_alignment = $new_alignment - 30;
					} elseif ( $dead_player_alignment > 50 ) {
						$new_alignment = $new_alignment - 10;
					} elseif ( $dead_player_alignment < -200 ) {
						$new_alignment = $new_alignment + 70;
					} elseif ( $dead_player_alignment < -150 ) {
						$new_alignment = $new_alignment + 40;
					} elseif ( $dead_player_alignment < -100 ) {
						$new_alignment = $new_alignment + 20;
					}	elseif ( $dead_player_alignment < -50 ) {
						$new_alignment = $new_alignment + 10;
					}			

					if ( $new_alignment > 500 ) {
						$new_alignment = 500;
					} elseif ( $new_alignment < -500 ) {
						$new_alignment = -500;
					}
				}
			}
			
			$query = "insert into news (date, item, game_id) values ('$date', '$message', '$game_id')";
			$db->query($query);

			$query = "update players set credits = '$new_credits', experience = '$new_experience', alignment = '$new_alignment', unclaimed_bounties = '$new_bounties', unclaimed_ug_bounties = '$new_ug_bounties', unclaimed_military_bounties = '$new_military_bounties' where player_id = '$killer_id'";
			$db->query($query);
			
			$player_score = new ME_Player_score;
			$player_score->get_player_score($killer_id);
			$player_score->set_credits_from_kills($player_score->f("credits_from_kills") + $victor_credits);
			$player_score->set_total_kills($player_score->f("total_kills") + 1);
			$player_score->set_kills_by_level($dead_player_level, $player_score->kills_by_level[$dead_player_level] + 1);
			$player_score->save();

			$message = addslashes($killer_name) . " destroyed you in sector " . $public_sector_id;
			$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
				values ('$dead_player_id', '$message', 'Bridge', 't', '$date')";
			$db->query($query);
		}

		if ( $killer_type == 'p' ) {			
			$db->query("select * from planets where planet_id = '$killer_id'");

			$db->next_record();
			$public_sector_id = $db->f("public_sector_id");
			$killer_name = $db->f("name");
			$message = addslashes($dead_player->f("name")) . " was killed by the planet " . addslashes($db->f("name")) . " in sector " . $db->f("public_sector_id") . ".";
			$query = "insert into news (date, item, game_id) values ('$date', '$message', '$game_id')";
			$db->query($query);	
			
			$message = "The planet " . addslashes($killer_name) . " destroyed you in sector " . $public_sector_id;
			$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
				values ('$dead_player_id', '$message', 'Bridge', 't', '$date')";
			$db->query($query);
		}
	}
}

?>

<html><head><title>Merchant Empires: Attack Merchant</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table BORDER=0 WIDTH='100%' NOSAVE ><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$db = new ME_DB;
$db_2 = new ME_DB;

$wa = array();
$db->query("SELECT * from weapons order by weapon_id");

while ( $db->next_record() ) {
	$wa[$db->f("weapon_id")] = $db->f("accuracy");
}
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left>
									<font color=#3333FF face=helvetica size=5>ATTACK RESULTS</font>
								</td>
							</tr>							
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br><?php

$id = (int) $id;

# retrieve the attack record
$db->query("SELECT * from attacks where attack_id = '$id'");
$db->next_record();

if ( $db->nf() > 0 and $db->f("sector_id") == $ship->f("sector_id") ) {
	$query = sprintf("insert into attack_logs (attacker_types, attacker_ids, attacker_imperial_protections, attacker_newbie_protections, defender_types, defender_ids, defender_imperial_protections, defender_newbie_protections, date, defender_alliance_id, map_id, public_sector_id, attacker_name)
	values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
	$db->f("attacker_types"),
	$db->f("attacker_ids"),
  $db->f("attacker_imperial_protections"),
  $db->f("attacker_newbie_protections"),
	$db->f("defender_types"),
	$db->f("defender_ids"),
  $db->f("defender_imperial_protections"),
  $db->f("defender_newbie_protections"),
	$db->f("date"),
	$db->f("defender_alliance_id"),
	$db->f("map_id"),
	$ship->f("public_sector_id"),
	addslashes($player->f("name")));
	$db_2->query($query);

	$db_2->query("select * from attack_log_id");
	$db_2->next_record();
	$attack_log_id = $db_2->f("last_value");
	
	$date = time();
	$attackers = array();
	$defenders = array();
	$killed = array();
	$killed_ship_forces = array();
	$killed_sector_forces = array();

	$attacker_types = array();
	$attacker_types = explode(",", $db->f("attacker_types"));
  $attacker_ids = array();
	$attacker_ids = explode(",", $db->f("attacker_ids"));
	$attacker_imperial_protections = array();
	$attacker_imperial_protections = explode(",", $db->f("attacker_imperial_protections"));
	$attacker_newbie_protections = array();
	$attacker_newbie_protections = explode(",", $db->f("attacker_newbie_protections"));

	$defender_types = array();
	$defender_types = explode(",", $db->f("defender_types"));
  $defender_ids = array();
	$defender_ids = explode(",", $db->f("defender_ids"));
	$defender_imperial_protections = array();
	$defender_imperial_protections = explode(",", $db->f("defender_imperial_protections"));
	$defender_newbie_protections = array();
	$defender_newbie_protections = explode(",", $db->f("defender_newbie_protections"));
		
	for ($i = 0; $i <= count($attacker_ids) - 1; $i++) {
		$attackers[$i][0] = $attacker_types[$i];		
		$attackers[$i][1] = $attacker_ids[$i];
		$attackers[$i][2] = $attacker_imperial_protections[$i];
		$attackers[$i][3] = $attacker_newbie_protections[$i];
	}

	for ($i = 0; $i <= count($defender_ids) - 1; $i++) {
		$defenders[$i][0] = $defender_types[$i];		
		$defenders[$i][1] = $defender_ids[$i];
		$defenders[$i][2] = $defender_imperial_protections[$i];
		$defenders[$i][3] = $defender_newbie_protections[$i];
	}
	
	#delete the attack record
	$db_d = new ME_DB_Tran;
	$db_d->begin_transaction();
	$db_d->query("delete from attacks where attack_id = '$id'");
	$db_d->end_transaction();

	for ($i = 0; $i <= count($attackers) - 1; $i++) {
		$attacker_type = $attackers[$i][0];
		$attacker_id = $attackers[$i][1];
		$attacker_imperial_protection = $attackers[$i][2];
		$attacker_newbie_protection = $attackers[$i][3];

		if ( $attacker_newbie_protection or $attacker_imperial_protection ) {
			array_splice($attackers, $i, 1, 0);
		} else {
			if ( $attacker_type == 's' ) {
				$db->query("SELECT player_id, sector_id, planet_id from ships where player_id = '$attacker_id'");
				$db->next_record();

				if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
					array_splice($attackers, $i, 1, 0);
				}
			}		
		}
	}

	$db_ap = new ME_DB;
	$db_p_u = new ME_DB;
	$db_af = new ME_DB;	

	for ($i = 0; $i <= count($defenders) - 1; $i++) {
		$defender_type = $defenders[$i][0];
		$defender_id = $defenders[$i][1];
		$defender_imperial_protection = $defenders[$i][2];
		$defender_newbie_protection = $defenders[$i][3];
	
		if ( $defender_newbie_protection or $defender_imperial_protection ) {			
			$db->query("SELECT player_id, sector_id, planet_id from ships where player_id = '$defender_id'");
			$db->next_record();			
			
			if ( $db->f("planet_id") > 0 ) {
				$query = sprintf("SELECT ships.player_id, ships.planet_id, ships.ship_id, players.player_id, players.newturnsleft from ships, players where ships.planet_id = '%s' and players.player_id = '$defender_id' and ships.player_id = players.player_id", $db->f("planet_id"));
				$db->query($query);		
      	$db->next_record();				
				
				$query = sprintf("SELECT planet_id, sector_id, public_sector_id from planets where planet_id = '%s'", $db->f("planet_id"));
				$db_2->query($query);		
				$db_2->next_record();

				$this_sector_id = $db_2->f("sector_id");
        $this_public_sector_id = $db_2->f("public_sector_id");
				$this_ship_id = $db->f("ship_id");
				
				$db_p_u->query("update ships set planet_id = 0, sector_id = '$this_sector_id', public_sector_id = '$this_public_sector_id' where ship_id = '$this_ship_id'");
			}
				
			array_splice($defenders, $i, 1, 0);		
		} else {
			if ( $defender_type == 's' ) {
				$db->query("SELECT player_id, sector_id, planet_id from ships where player_id = '$defender_id'");
				$db->next_record();

				if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
					if ( $db->f("sector_id") == 0 ) {
						$planet_id = $db->f("planet_id");
						$db->query("SELECT * from planets where planet_id = '$planet_id'");
						$db->next_record();
						
						if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
							array_splice($defenders, $i, 1, 0);								
						}
					} else {	
						array_splice($defenders, $i, 1, 0);					
					}
				}
			}

			if ( $defender_type == 'f' ) {
				$db->query("SELECT * from forces where forces_id = '$defender_id'");
				$db->next_record();

				$owner_id = $db->f("player_id");
				$total_forces = $db->f("mine") + $db->f("combat") + $db->f("scout");
				if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
					array_splice($defenders, $i, 1, 0);							
				}
			}

			if ( $defender_type == 'm' ) {
				$db->query("SELECT * from forces where forces_id = '$defender_id'");
				$db->next_record();

				$owner_id = $db->f("player_id");				
				if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
					array_splice($defenders, $i, 1, 0);							
				}
			}

			if ( $defender_type == 'p' ) {
				$db->query("SELECT * from planets where planet_id = '$defender_id'");
				$db->next_record();

				$owner_id = $db->f("owner_id");
				$total_forces = $db->f("combat") + $db->f("scout");
				if ( $db->f("sector_id") <> $ship->f("sector_id") ) {
					array_splice($defenders, $i, 1, 0);							
				}
			}
		}		
  }
	
	$defenders = condense_force($defenders);
	$attackers = condense_force($attackers);

	if ( count($defenders) > 0 and count($attackers) > 0 ) {
?>

<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td width=50% valign=top>
			<center><font color=#3333FF face=helvetica size=4>Attack Results</font></center><br><?php

		$x = 0;
		$y = 0;
		$z = 0;
		$xy = 0;
		$defender_killed = 0;		
		
		for ($i = 0; $i <= count($attackers) - 1; $i++) {
			$merchant_and_forces = array();
			$this_forces = array();
			$planet_and_forces = array();
			$sector_forces = array();

			$attacker_type = $attackers[$i][0];
			$attacker_id = $attackers[$i][1];

			if ( count($defenders) == 1 ) {
				$defender_type = $defenders[0][0];
				$defender_id = $defenders[0][1];
				$defender_index = 0;
			} elseif ( $defenders[$i][1] > 0 ) {
				$defender_type = $defenders[$i][0];
				$defender_id = $defenders[$i][1];
				$defender_index = $i;
			} else {
				$num = rand(0,count($defenders) - 1);

				$defender_type = $defenders[$num][0];
				$defender_id = $defenders[$num][1];
				$defender_index = $num;
			}
			
			if ( $defender_type == 's' and $attacker_type == 's' ) {
				if ( !(merchant_been_killed($killed, $defender_id)) ) {
					$merchant_and_forces = attack_merchant_with_merchant($attacker_id, $defender_id, $wa, 1);
					
					if ( $merchant_and_forces[0] == 1 ) {
						$killed[$x][0] = "s";
						$killed[$x][1] = $defender_id;
						$killed[$x][2] = "s";
						$killed[$x][3] = $attackers[$i][1];
						$x = $x + 1;
					}

					if ( $merchant_and_forces[1] > 0 ) {
						$killed_ship_forces[$y][0] = "sf";
						$killed_ship_forces[$y][1] = $defender_id;
						$killed_ship_forces[$y][2] = $merchant_and_forces[1];
						$y = $y + 1;
					}
				}					
			} elseif ( $defender_type == 'f' and $attacker_type == 's' ) {
				$this_forces = attack_forces($attacker_id, $defender_id, $wa);				
				
				if ( $this_forces['killed'] ) {
					$killed[$x][0] = "f";
					$killed[$x][1] = $defender_id;
					$killed[$x]['player_name'] = $this_forces['player_name'];
					$x = $x + 1;
				}
			} elseif ( $defender_type == 'm' and $attacker_type == 's' ) {
				$this_forces = attack_forces($attacker_id, $defender_id, $wa);
				
				if ( $this_forces['killed'] ) {
					$killed[$x][0] = "f";
					$killed[$x][1] = $defender_id;
					$killed[$x]['player_name'] = $this_forces['player_name'];
					$x = $x + 1;
				}
			} elseif ( $defender_type == 'p' and $attacker_type == 's' ) {
				$planet_and_forces = attack_planet_with_merchant($attacker_id, $defender_id, $wa);
	
				if ( $planet_and_forces[0] == 1 ) {
					$killed[$x][0] = "p";
					$killed[$x][1] =  $defender_id;
					$killed[$x][2] = "s";
					$killed[$x][3] = $attacker_id;
					$x = $x + 1;
				}

				if ( $planet_and_forces[1] > 0 ) {
					$killed_planet_forces[$z][0] = "pf";
					$killed_planet_forces[$z][1] = $defender_id;
					$killed_planet_forces[$z][2] = $planet_and_forces[1];
					$z = $z + 1;
				}
			} elseif ( $defender_type == 's' and $attacker_type == 'f' ) {
				if ( !(merchant_been_killed($killed, $defender_id)) ) {
					$defender_killed = attack_merchant_with_forces($defender_id, $attacker_id, $wa);
					
					if ( $defender_killed ) {
						$killed[$x][0] = "s";
						$killed[$x][1] = $defender_id;
						$killed[$x][2] = "f";
						$killed[$x][3] = $attacker_id;
						$x = $x + 1;
					}
				}
			}
		}
?>
		</td><td width=50% valign=top>
			<center><font color=#3333FF face=helvetica size=4>Defense Results</font></center><br><?php

		for ($i = 0; $i <= count($defenders) - 1; $i++) {
			$merchant_and_forces = array();
			$planet_and_forces = array();
			$sector_forces = array();

			$defender_type = $defenders[$i][0];
			$defender_id = $defenders[$i][1];			

			if ( count($attackers) == 1 ) {				
				$attacker_type = $attackers[0][0];
				$attacker_id = $attackers[0][1];
			} elseif ( $attackers[$i][1] > 0 ) {
				$attacker_type = $attackers[$i][0];
				$attacker_id = $attackers[$i][1];
			} else {
				$num = rand(0,count($attackers) - 1);

				$attacker_type = $attackers[$num][0];
				$attacker_id = $attackers[$num][1];
			}

			$defender_killed = 0;
  	
			if ( $defender_type == 's' and $attacker_type == 's' ) {
				if ( !(merchant_been_killed($killed, $attacker_id)) ) {
					$merchant_and_forces = attack_merchant_with_merchant($defender_id, $attacker_id, $wa, 0);
					
					if ( $merchant_and_forces[0] == 1 ) {
						$killed[$x][0] = "s";
						$killed[$x][1] = $attacker_id;
						$killed[$x][2] = "s";
						$killed[$x][3] = $defenders[$i][1];
						$x = $x + 1;					
					}

					if ( $merchant_and_forces[1] > 0 ) {
						$killed_ship_forces[$y][0] = "sf";
						$killed_ship_forces[$y][1] = $attacker_id;
						$killed_ship_forces[$y][2] = $merchant_and_forces[1];
						$y = $y + 1;
					}
				}				
			} elseif ( $defender_type == 'f' and $attacker_type == 's' ) {				
				$query = sprintf("SELECT * from forces where forces_id = '%s'", $defenders[$i][1]);
				$db_af->query($query);
				$db_af->next_record();

				if ( $db_af->f("mine") > 0 and $db_af->f("scout") == 0 and $db_af->f("combat") == 0 ) {
					if ( !(merchant_been_killed($killed, $attacker_id)) ) {
						$sector_forces = attack_merchant_with_forces_mines($attacker_id, $defenders[$i][1], $wa);
						
						if ( $sector_forces[0] == 1 ) {
							$killed[$x][0] = "s";
							$killed[$x][1] = $attacker_id;
							$killed[$x][2] = "m";
							$killed[$x][3] = $defenders[$i][1];
							$x = $x + 1;
						}

						if ( $sector_forces[1] > 0 ) {
							$killed_sector_forces[$xy][0] = "ef";
							$killed_sector_forces[$xy][1] = $defender_id;
							$killed_sector_forces[$xy][2] = $sector_forces[1];
							$xy = $xy + 1;
						}
					}						
				} else {
					if ( !(merchant_been_killed($killed, $attacker_id)) ) {
						$defender_killed = attack_merchant_with_forces($attacker_id, $defenders[$i][1], $wa);
						
						if ( $defender_killed ) {
							$killed[$x][0] = "s";
							$killed[$x][1] = $attacker_id;
							$killed[$x][2] = "f";
							$killed[$x][3] = $defenders[$i][1];
							$x = $x + 1;
						}
					}					
				}
			} elseif ( $defender_type == 'p' and $attacker_type == 's' ) {
				if ( count($attackers) > 1 ) {					
					$attackers = condense_attackers($attackers);

					$query = sprintf("SELECT * from planets where planet_id = '%s'", $defenders[$i][1]);
					$db_ap->query($query);
					$db_ap->next_record();

					$attacker_index = 0;
					$total_attacker_damage = 0;
					
					for ($j = 0; $j < $db_ap->f("turretscurrent"); $j++) {
						if ( $attacker_index > count($attackers) - 1 ) {
							$attacker_index = 0;
						}

						$attacker_id = $attackers[$attacker_index][1];						

						if ( !(merchant_been_killed($killed, $attacker_id)) ) {
							$merchant_and_forces = attack_merchant_with_planet_turret($attacker_id, $defenders[$i][1], $wa);
							
							$attackers[$attacker_index][4] = $merchant_and_forces[5];
							$attackers[$attacker_index][5] = $merchant_and_forces[6];
							$attackers[$attacker_index][6] = $merchant_and_forces[3];
							$attackers[$attacker_index][7] = $merchant_and_forces[4];
							$attacker_index = $attacker_index + 1;
							$total_attacker_damage = $total_attacker_damage + $merchant_and_forces[2];

							if ( $merchant_and_forces[0] == 1 ) {
								$killed[$x][0] = "s";
								$killed[$x][1] = $attacker_id;
								$killed[$x][2] = "p";
								$killed[$x][3] = $defenders[0][1];
								$x = $x + 1;
							}
						}								
					}		

					if ( $db_ap->f("combatcurrent") > 0 ) {
						if ( $db_ap->f("combatcurrent") < 5 ) {
							$squadrons = 1;
						} else {
							$squadrons = $db_ap->f("combat_squadrons");
						}

						for ($j = 0; $j < $squadrons; $j++) {						
							if ( count($attackers) > 1 ) {
								$num = rand(0,count($attackers) - 1);
							} else {
								$num = 0;
							}

							$attacker_type = $attackers[$num][0];
							$attacker_id = $attackers[$num][1];
	
							if ( !(merchant_been_killed($killed, $attacker_id)) ) {
								$merchant_and_forces = attack_merchant_with_planet_drones($attacker_id, $defenders[$i][1], $wa, $squadrons);
							
								$total_attacker_damage = $total_attacker_damage + $merchant_and_forces[2];
								$attackers[$num][6] = $attackers[$num][6] + $merchant_and_forces[3];
								$attackers[$num][7] = $attackers[$num][7] + $merchant_and_forces[4];
	
								if ( $merchant_and_forces[0] == 1 ) {
									$killed[$x][0] = "s";
									$killed[$x][1] = $attacker_id;
									$killed[$x][2] = "p";
									$killed[$x][3] = $defenders[0][1];
									$x = $x + 1;
								}
							}								
						}
					}
				} else {
					if ( !(merchant_been_killed($killed, $attacker_id)) ) {
						$merchant_and_forces = attack_merchant_with_planet($attacker_id, $defenders[$i][1], $wa);
						
						if ( $merchant_and_forces[0] == 1 ) {
							$killed[$x][0] = "s";
							$killed[$x][1] = $attacker_id;
							$killed[$x][2] = "p";
							$killed[$x][3] = $defenders[0][1];
							$x = $x + 1;
						}
					}													
				}
			} elseif ( $defender_type == 'm' and $attacker_type == 's' ) {
				if ( !(merchant_been_killed($killed, $attacker_id)) ) {
					$sector_forces = attack_merchant_with_forces_mines($attacker_id, $defenders[$i][1], $wa);
					
					if ( $sector_forces[0] == 1 ) {
						$killed[$x][0] = "s";
						$killed[$x][1] = $attacker_id;
						$killed[$x][2] = "m";
						$killed[$x][3] = $defenders[$i][1];
						$x = $x + 1;
					}

					if ( $sector_forces[1] > 0 ) {
						$killed_sector_forces[$xy][0] = "ef";
						$killed_sector_forces[$xy][1] = $defender_id;
						$killed_sector_forces[$xy][2] = $sector_forces[1];
						$xy = $xy + 1;
					}
				}								
			}

			if ( $defender_type == 's' ) {
				if ( !(merchant_been_killed($killed, $defender_id)) ) {
					$db->query("select ships.player_id, ships.shieldcurrent, ships.armorcurrent from ships where ships.player_id = '$defender_id'");
					$db->next_record();

					$defender_shields = $db->f("shieldcurrent");
					$defender_armor = $db->f("armorcurrent");

					$query = "select player_id, message_id from messages where player_id = '$defender_id' and battle = 't' order by message_id";
					$db->query($query);
					$db->next_record();
					if ( $db->nf() > 50 ) {
		       	$message_id = $db->f("message_id");
	
						$query = "delete from messages where message_id = '$message_id'";
						$db->query($query);
					}	

					$db->query("select players.player_id, players.name, ships.player_id, ships.type from players, ships where players.player_id = '$attacker_id' and ships.player_id = players.player_id");
					$db->next_record();
					$message = addslashes($db->f("name")) . " attacked you in sector " . $ship->f("public_sector_id") . ".";				
					$message = $message . "<br><br>Post-combat ship status:";
					$message = $message . "<br>Shields: " . $defender_shields;
					$message = $message . "<br>Armor: " . $defender_armor;
					$message = $message . "<br>Return fire inflicted " . $merchant_and_forces[2] . " points of damage.";
					$message = $message . "<br><br>Enemy ship type: " . $db->f("type") . ".";
					$message = $message . "<br>Enemy shields estimated at " . $merchant_and_forces[3] . "%";
					$message = $message . "<br>Enemy armor estimated at " . $merchant_and_forces[4] . "%";
					$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
						values ('$defender_id', '$message', 'Bridge', 't', '$date')";
					$db->query($query);
				}
			} elseif ( $defender_type == 'f' ) {
				$query = "select player_id, message_id from messages where player_id = '$owner_id' and battle = 't' order by message_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 50 ) {
         	$message_id = $db->f("message_id");

					$query = "delete from messages where message_id = '$message_id'";
					$db->query($query);
				}

				$message = addslashes($player->f("name")) . " attacked your forces in sector " . $ship->f("public_sector_id") . ".";
				$query = "insert into messages (player_id, message, toplayer, battle, date_integer)
					values ('$owner_id', '$message', 'Bridge', 't', '$date')";
				$db->query($query);
			} elseif ( $defender_type == 'm' ) {
				$query = "select player_id, message_id from messages where player_id = '$owner_id' and scout = 't' order by message_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 50 ) {
         	$message_id = $db->f("message_id");

					$query = "delete from messages where message_id = '$message_id'";
					$db->query($query);
				}

				$message = addslashes($player->f("name")) . " was struck by your mines in sector " . $ship->f("public_sector_id") . ", incurring " . $sector_forces[3] . " points of damage.";
				$query = "insert into messages (player_id, message, toplayer, scout, date_integer)
					values ('$owner_id', '$message', 'Bridge', 't', '$date')";
				$db->query($query);
			} elseif ( $defender_type == 'p' ) {
				if ( count($attackers) == 1 ) {
					$db->query("select players.player_id, players.name, ships.player_id, ships.type from players, ships where players.player_id = '$attacker_id' and ships.player_id = players.player_id");		
					$db->next_record();
					$message = addslashes($db->f("name")) . " attacked your planet in sector " . $ship->f("public_sector_id") . ".";
					$message = $message . "<br><br>Return fire inflicted " . $merchant_and_forces[2] . " points of damage.";
					$message = $message . "<br>Enemy ship type: " . $db->f("type") . ".";
					$message = $message . "<br>Enemy shields estimated at " . $merchant_and_forces[3] . "%";
					$message = $message . "<br>Enemy armor estimated at " . $merchant_and_forces[4] . "%";
				} else {
					$message = "An attack fleet composed of:<br>";
					
					for ($xj = 0; $xj <= count($attackers) - 1; $xj++) {
						$message = $message . "<br>" . addslashes($attackers[$xj][4]) . " -- " . addslashes($attackers[$xj][5]);
						$message = $message . "<br>Estimated shields: " . $attackers[$xj][6] . "%";
						$message = $message . "<br>Estimated armor: " . $attackers[$xj][7] . "%";
					}

					$message = $message . "<br><br>attacked the planet in sector " . $ship->f("public_sector_id") . ".";
					$message = $message . "<br><br>Return fire inflicted " . $total_attacker_damage . " points of damage.";
				}

				$query = "select player_id, message_id from messages where player_id = '$owner_id' and planetary = 't' order by message_id";
				$db->query($query);
				$db->next_record();
				if ( $db->nf() > 50 ) {
         	$message_id = $db->f("message_id");

					$query = "delete from messages where message_id = '$message_id'";
					$db->query($query);
				}

				$query = "insert into messages (player_id, message, toplayer, planetary, date_integer)
					values ('$owner_id', '$message', 'Planet Defense', 't', '$date')";
				$db->query($query);

				$db->query("SELECT player_id, alliance_id from players where player_id = '$owner_id'");
				$db->next_record();

				if ( $db->f("alliance_id") <> 0 ) {
					$alliance_id = $db->f("alliance_id");
					$db->query("SELECT player_id, alliance_id, name from players where alliance_id = '$alliance_id'");

					while ( $db->next_record() ) {
						if ( $db->f("player_id") <> $owner_id ) {
							$this_player_id = $db->f("player_id");							

							$query = "select player_id, message_id from messages where player_id = '$this_player_id' and planetary = 't' order by message_id";
							$db->query($query);
							$db->next_record();
							if ( $db->nf() > 50 ) {
			         	$message_id = $db->f("message_id");

								$query = "delete from messages where message_id = '$message_id'";
								$db->query($query);
							}
					
							$query = "insert into messages (player_id, message, toplayer, planetary, date_integer)
								values ('$this_player_id', '$message', 'Planet Defense', 't', '$date')";
												
							$db_2->query($query);													
						}
					}
				}
			}
		}

?>
		</td>
	</tr>
</table><br><?php		

		for ($i = 0; $i <= count($killed_ship_forces) - 1; $i++) {
			if ( $killed_ship_forces[$i][0] == 'sf' ) {
					$killed_forces_player_id = $killed_ship_forces[$i][1];
					$query = sprintf("SELECT player_id, combatcurrent from ships where player_id = '%s'", $killed_forces_player_id);
					$db->query($query);
					$db->next_record();
					$killed_combat = $killed_ship_forces[$i][2];
					$new_combat = $db->f("combatcurrent") - $killed_combat;					

					$db->query("update ships set combatcurrent = '$new_combat' where player_id = '$killed_forces_player_id'");
				}
		}
	
		for ($i = 0; $i <= count($killed_sector_forces) - 1; $i++) {
			if ( $killed_sector_forces[$i][0] == 'ef' ) {
					$killed_forces_id = $killed_sector_forces[$i][1];
					$query = sprintf("SELECT forces_id, mine, combat, scout from forces where forces_id = '%s'", $killed_forces_id);
					$db->query($query);
					$db->next_record();
					$killed_mine = $killed_sector_forces[$i][2];
					$new_mine = $db->f("mine") - $killed_mine;					

					if ( $new_mine < 0 ) {
						$new_mine = 0;
					}
					
					if ( $new_mine <= 0 and $db->f("scout") == 0 and $db->f("combat") == 0 ) {
						$db->query("delete from forces where forces_id = '$killed_forces_id'");
					} else {				
						$db->query("update forces set mine = '$new_mine' where forces_id = '$killed_forces_id'");
					}
				}
		}

		for ($i = 0; $i <= count($killed_planet_forces) - 1; $i++) {
			if ( $killed_planet_forces[$i][0] == 'pf' ) {
					$killed_forces_planet_id = $killed_planet_forces[$i][1];
					$query = sprintf("SELECT planet_id, combatcurrent from planets where planet_id = '%s'", $killed_forces_planet_id);
					$db->query($query);
					$db->next_record();
					$killed_combat = $killed_planet_forces[$i][2];
					$new_combat = $db->f("combatcurrent") - $killed_combat;					

					$db->query("update planets set combatcurrent = '$new_combat' where planet_id = '$killed_forces_planet_id'");
				}
		}

		if ( $killed[0][1] > 0 ) {
?>

<table border=0 cellPadding=0 cellSpacing=0 width=500
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width="100%">	
				<tr>
        	<td bgColor=#000000>
						<table>
							<tr><td class=clsNrmTxt>
								Battle Report<br><br><?php
              	
			for ($i = 0; $i <= count($killed) - 1; $i++) {	
				if ( $killed[$i][0] == 's' ) {
					$killed_player_id = $killed[$i][1];
					$query = sprintf("SELECT player_id, name from players where player_id = '%s'", $killed_player_id);
					$db->query($query);
					$db->next_record();
					echo "&nbsp;" . $db->f("name") . " was destroyed.<br>";

					merchant_dead($killed[$i][1], $killed[$i][3], $ship->f("sector_id"), $killed[$i][2]);
				}				

				if ( $killed[$i][0] == 'f' ) {					
					echo "&nbsp;Forces owned by " . stripslashes($killed[$i]['player_name']) . " were destroyed.<br>";
				}

				if ( $killed[$i][0] == 'p' ) {
					$planet_id = $killed[$i][1];
					$query = sprintf("update planets set combatcurrent = 0, turretscurrent = 0 where planet_id = '%s'", $planet_id);
					$db->query($query);
					$db->next_record();

					echo "&nbsp;All planetary defenses have been destroyed.<br>";
				}
			}

		$color_1 = "#003399";
?>									
								</td></tr>
							</table>					
						</td>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

		} else {
			$color_1 = "#993300";
		}
?>

<table border=0 cellPadding=0 cellSpacing=0 width=500
	<tr>
		<td bgColor=<?php

		echo $color_1;
?>
			>
			<table border=0 cellPadding=5 cellSpacing=1 width="100%">	
				<tr>
        	<td class=clsNrmTxt align=center>
        		<table>
        			<tr><?php

if ( count($defenders) > count($killed) ) {
	echo "<form name=form_attack action=";
	echo $sess->url(URL . "attack.php");
	echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'>";	
	echo "<td><input type=hidden name=type ";
	echo " value=" . $defender_type . ">";
	echo "<input type=hidden name=refer value=preattack>";
	echo "<input type=hidden name=id ";
	echo " value=" . $defender_id . ">";		
	echo "<input type=hidden name=attack value=Attack>";
	echo "<a href='javascript:document.form_attack.submit()'><img border=0 height=20 width=100 src='./images/form/attack-off.png'></a><br>";
	echo "</td></form>";
} else {
	echo "<form name=form_abort action=";  	
	echo $sess->url(URL . "current_sector.php");
	echo " method=post onsubmit='if(this.submitted) return false; else {this.submitted=true; return true;}'><td>";

	echo "<input type=hidden name=abort value=Abort>";
	echo "<a href='javascript:document.form_abort.submit()'><img border=0 height=20 width=100 src='./images/form/abort-off.png'></a><br></td>";
}
?>												  					
							</tr>				  						  			
						</table>											
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><?php

	} else {
		display_error("Warning", "The merchant that you intended to attack cannot be found in the current sector.  It is probable that he/she fled, cloaked, or was destroyed.");		
	}
} else {
	display_error("Warning", "Attack not entered or continued properly.  To continue an attack you must select continue from the attack results screen.");
}		
?>							
</td>
<td valign=top align=right width=100%><?php

$player->get_player($player_id);
$ship->get_ship($player_id);

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");

echo "<font color=Black>Attack log id: " . $attack_log_id . "</font>";
?>

</td></tr></table>
</body></html><?php

page_close();
?>