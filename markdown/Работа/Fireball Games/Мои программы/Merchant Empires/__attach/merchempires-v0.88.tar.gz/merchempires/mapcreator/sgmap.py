# -*- Mode: Python; tab-width: 4 -*-
#	Author: Bryan Brunton

RCS_ID = '$Id: spacegame.py,v 0.01 2000/03/14'

import string
import sys
from pg import DB
import sgsector
import types

def compute_exits(val, val_2, x, y):
		exits = ''
		#exits.append(val, val_2)

		'top'
		a = val
		b = val_2 + 1

		if b < y:
			exits = exits + str(a) + ':' + str(b)

		'left'
		a = val - 1
		b = val_2

		if a > -1:
			if exits != '':
				exits = exits + ',' + str(a) + ':' + str(b)
			else:
				exits = str(a) + ':' + str(b)
		
		'right'
		a = val + 1
		b = val_2

		if a < x:
			if exits != '':
				exits = exits + ',' + str(a) + ':' + str(b)
			else:
				exits = str(a) + ':' + str(b)
		
		'bottom'
		a = val
		b = val_2 - 1

		if b > -1:
			if exits != '':
				exits = exits + ',' + str(a) + ':' + str(b)
			else:
				exits = str(a) + ':' + str(b)

		return exits

def alloc_map(self, xsize, ysize, public_sector_id):
	x = 0 
	y = 0
	print "Allocating Sectors"
	for value in range (ysize):
		for value_2 in range (xsize):
			x = x + 1
			newsect = self.sector_class (value, value_2)
			self.sectors[str(newsect)] = newsect
			print str(newsect.xpos) + ', ' + str(newsect.ypos)
			exits = compute_exits(value, value_2, xsize, ysize)
			te = self.sectors[str(newsect)]
			te.exits = exits
			te.public_sector_id = public_sector_id
			public_sector_id = public_sector_id + 1
		y = y + 1
		x = 0

class sgmap:
	
	sector_class = sgsector.sgsector

	def __init__ (self, xsize=3, ysize=3, public_sector_id=None):
		self.xsize = xsize
		self.ysize = ysize
		self.public_sector_id = public_sector_id
		self.sectors = {}

		alloc_map(self, xsize, ysize, public_sector_id)

	def save_map (self):
		pgcnx = DB('spacegame','192.168.1.2',user='postgres')
		qrystr = "INSERT INTO maps (map_id, xsize, ysize)"	\
			"VALUES (NEXTVAL('map_id'), '%d', '%d')" % (self.xsize, self.ysize)
		q = pgcnx.query(qrystr)
		
		qrystr = "select last_value from map_id"
		q = pgcnx.query(qrystr)
		list2 = q.getresult()

		next_map_id = list2[0][0]
		for key in self.sectors.keys():
			e = self.sectors[key]

			qrystr = "INSERT INTO sectors (sector_id, map_id, xpos, ypos, exits, public_sector_id)"	\
				" VALUES (NEXTVAL('sector_id'), '%d', '%d', '%d', '%s', '%s')" 	\
				% (next_map_id, e.xpos, e.ypos, e.exits, e.public_sector_id)
			q = pgcnx.query(qrystr)
			








		
