<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/ship_miscellaneous.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Examine Merchant</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5>EXAMINE MERCHANT</font>
								</td>
							</tr>							
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br>
<table width=500 border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td valign=top width=400>
									<font color=#3333FF face=arial,helvetica,swiss size=4><b>Merchant</font></b><br>									
									<font  color=#cccccc face=arial,helvetica,swiss size=3><?php

$id = (int) $id;

$db = new ME_DB;
$query = sprintf("SELECT player_id, rank, public_player_id, name, race, alliance_name, newturnsleft, alignment, experience from players where player_id = '%s'", $id);
$db->query($query);
$db->next_record();
$newturnsleft = $db->f("newturnsleft");
echo "&nbsp;" . $db->f("rank") . "<br>";

echo "&nbsp;<a href=";
echo $sess->purl(URL . "merchant_search_results.php?action=merchant_id&criteria=" . $db->f("public_player_id")) . ">";
echo $db->f("name") . "</a>";
echo " (" . $db->f("public_player_id") . ")";

$db_a = new ME_DB;
$query = sprintf("SELECT * from active_sessions where player_id = '%s'", $db->f("player_id"));
$db_a->query($query);

if ( $db_a->nf() > 0 ) {
	echo " (online)<br>";
} else {
	echo " (offline)<br>";
}

echo "&nbsp;Race: " . $db->f("race") . "<br>";
echo "&nbsp;Alliance: " . $db->f("alliance_name") . "<br>";
$alignment = $db->f("alignment");

if ( ($player->f("experience") * .8) >= $db->f("experience") ) {
	if ( $db->f("alignment") <= -150 ) {
		echo "&nbsp;Alignment: Evil";
	} elseif ( $db->f("alignment") >= 150 ) {
		echo "&nbsp;Alignment: Good";
	} else {
		echo "&nbsp;Alignment: Neutral";
	}
} else {
	 echo "&nbsp;Alignment: Unknown";
}

echo "<br><br><font color=#3333FF face=arial,helvetica,swiss size=4><b>Ship</font></b><br>";
$query = sprintf("SELECT ships.*, ship_weapons.*, ship_technology.* from ships, ship_weapons, ship_technology where ships.player_id = '%s' and ship_weapons.player_id = ships.player_id and ship_technology.player_id = ships.player_id", $id);

$db->query($query);
$db->next_record();

if ( $db->f("illusion") and $db->f("illusion_active") == 't' ) {
	echo "&nbsp;" . $db->f("illusion_type") . " ";
	$offense = $db->f("illusion_attack");
	$defense = $db->f("illusion_defense");
	echo "<br>&nbsp;Attack rating: " . $offense;
	echo "<br>&nbsp;Defense rating: " . $defense;
} else {
	echo "&nbsp;" . $db->f("type") . " ";

	$combined_damage = get_combined_damage($db);

	if ( (int) (($combined_damage / 40) + ($db->f("combatcurrent") / 50)) < 1 ) {
		$offense = 1;
	} else {
		$offense = (int) (($combined_damage / 40) + ($db->f("combatcurrent") / 50));
	}

	if ( (int) (($db->f("shieldcurrent") + $db->f("armorcurrent") + ($db->f("combatcurrent") * 3)) / 100)  < 1 ) {
		$defense = 1;
	} else {
		$defense = (int) (($db->f("shieldcurrent") + $db->f("armorcurrent") + ($db->f("combatcurrent") * 3)) / 100);
	}

	echo "<br>&nbsp;Attack rating: " . $offense;
	echo "<br>&nbsp;Defense rating: " . $defense;
}

$imperial_protection = 0;
$sector_id = $ship->f("sector_id");
$db->query("SELECT * from locations where sector_id = '$sector_id' and type = 'Authority'");
if ( $db->nf() > 0 ) {		
	$protected = 3;
				
	if ( $alignment >= 150 and $alignment < 300 ) {
		$protected = 4;
	} elseif( $alignment >= 300 ) {
		$protected = 5;
	} elseif( $alignment <= -150 and $alignment > -300 ) {
		$protected = 2;
	} elseif( $alignment < -300 ) {
		$protected = 1;
	}

	if ( $offense > $protected ) {
		$imperial_protection = 0;
	} else {
		$imperial_protection = 1;	
	}			
}


if ( $newturnsleft > 0 or $imperial_protection ) {
	echo "<br><br><font color=#3333FF face=arial,helvetica,swiss size=4>Protection</font></b><br>";

	if ( $newturnsleft > 0 ) {
		echo "&nbsp;<font  color=#cccccc face=arial,helvetica,swiss size=3>Newbie";	
	}

	if ( $imperial_protection ) {
		if ( $newturnsleft > 0 ) {	
			echo "<br>";
		}		
		echo "&nbsp;<font  color=#cccccc face=arial,helvetica,swiss size=3>Imperial</font>";	
	}
}

?>									
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>