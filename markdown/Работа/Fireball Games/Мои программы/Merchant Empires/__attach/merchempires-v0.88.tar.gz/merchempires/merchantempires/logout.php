<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth"));

include("./merchantempiresdefines.php");

$sess->unregister("player_id");
$sess->delete();
page_open(array("auth" => "ME_Auth"));
?>

<html><head><title>Merchant Empires: Log Out</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head>
<body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top>

<table border=0 cellPadding=0 cellSpacing=0 width=100>
  <tr align=left vAlign=center>
    <td>
    </td>
  </tr>
</table>

</td>
<td vAlign=top width=650>

<table border=0 cellPadding=0 cellSpacing=0 width=450> 
  <tr> 
    <td bgColor=#993300> 
      <table border=0 cellPadding=5 cellSpacing=1 width="100%"> 
        <tr> 
          <td class=clsHedTxt id=red1>Logged Off<br></td>
				</tr>
        <tr>
          <td class=clsNrmTxt>
	    		 	Merchant <?php print stripslashes($auth->auth["uname"]) ?> has successfully logged off.</b>
						<br><br>You may <a href=<?php

echo URL . "index.php3";
?>
						>log back in</a> at any time.
	    		</td>
	 			</tr>
      </table>
    </td>
  </tr>
</table>

</td></tr></table>
</body></html><?php

$auth->logout();
page_close();
?>