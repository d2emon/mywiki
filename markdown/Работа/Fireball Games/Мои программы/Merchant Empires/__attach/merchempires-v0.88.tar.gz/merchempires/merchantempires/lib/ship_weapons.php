<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

function add_weapon($id, $name, $weapons) {
  $db = new ME_DB;
  $db->query("SELECT * from weapons where weapon_id = '$id'");
  $db->next_record();

  $shield_damage = $db->f("shield_damage");
  $armor_damage = $db->f("armor_damage");

  if ( $weapons->f("weapon_1_id") == 0 ) {
    $weapons->set_weapon_1_id($id);
    $weapons->set_weapon_1_name($name);
    $weapons->set_weapon_1_shield_damage($shield_damage);
    $weapons->set_weapon_1_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_2_id") == 0 ) {
    $weapons->set_weapon_2_id($id);
    $weapons->set_weapon_2_name($name);
    $weapons->set_weapon_2_shield_damage($shield_damage);
    $weapons->set_weapon_2_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_3_id") == 0 ) {
    $weapons->set_weapon_3_id($id);
    $weapons->set_weapon_3_name($name);
    $weapons->set_weapon_3_shield_damage($shield_damage);
    $weapons->set_weapon_3_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_4_id") == 0 ) {
    $weapons->set_weapon_4_id($id);
    $weapons->set_weapon_4_name($name);
    $weapons->set_weapon_4_shield_damage($shield_damage);
    $weapons->set_weapon_4_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_5_id") == 0 ) {
    $weapons->set_weapon_5_id($id);
    $weapons->set_weapon_5_name($name);
    $weapons->set_weapon_5_shield_damage($shield_damage);
    $weapons->set_weapon_5_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_6_id") == 0 ) {
    $weapons->set_weapon_6_id($id);
    $weapons->set_weapon_6_name($name);
    $weapons->set_weapon_6_shield_damage($shield_damage);
    $weapons->set_weapon_6_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_7_id") == 0 ) {
    $weapons->set_weapon_7_id($id);
    $weapons->set_weapon_7_name($name);
    $weapons->set_weapon_7_shield_damage($shield_damage);
    $weapons->set_weapon_7_armor_damage($armor_damage);
    $weapons->save();
  } elseif ( $weapons->f("weapon_8_id") == 0 ) {
    $weapons->set_weapon_8_id($id);
    $weapons->set_weapon_8_name($name);
    $weapons->set_weapon_8_shield_damage($shield_damage);
    $weapons->set_weapon_8_armor_damage($armor_damage);
    $weapons->save();
  }
}

function set_weapon_id_and_name($id, $weapons)  {
  switch ($id) {
    case "1":
      $weapons->set_weapon_1_id(0);
      $weapons->set_weapon_1_name('');
      $weapons->set_weapon_1_shield_damage(0);
      $weapons->set_weapon_1_armor_damage(0);
      $weapons->save();
      break;
     case "2":
      $weapons->set_weapon_2_id(0);
      $weapons->set_weapon_2_name('');
      $weapons->set_weapon_2_shield_damage(0);
      $weapons->set_weapon_2_armor_damage(0);
      $weapons->save();
      break;
    case "3":
      $weapons->set_weapon_3_id(0);
      $weapons->set_weapon_3_name('');
      $weapons->set_weapon_3_shield_damage(0);
      $weapons->set_weapon_3_armor_damage(0);
      $weapons->save();
      break;
    case "4":
      $weapons->set_weapon_4_id(0);
      $weapons->set_weapon_4_name('');
      $weapons->set_weapon_4_shield_damage(0);
      $weapons->set_weapon_4_armor_damage(0);
      $weapons->save();
      break;
    case "5":
      $weapons->set_weapon_5_id(0);
      $weapons->set_weapon_5_name('');
      $weapons->set_weapon_5_shield_damage(0);
      $weapons->set_weapon_5_armor_damage(0);
      $weapons->save();
      break;
    case "6":
      $weapons->set_weapon_6_id(0);
      $weapons->set_weapon_6_name('');
      $weapons->set_weapon_6_shield_damage(0);
      $weapons->set_weapon_6_armor_damage(0);
      $weapons->save();
      break;
    case "7":
      $weapons->set_weapon_7_id(0);
      $weapons->set_weapon_7_name('');
      $weapons->set_weapon_7_shield_damage(0);
      $weapons->set_weapon_7_armor_damage(0);
      $weapons->save();
      break;
    case "8":
      $weapons->set_weapon_8_id(0);
      $weapons->set_weapon_8_name('');
      $weapons->set_weapon_8_shield_damage(0);
      $weapons->set_weapon_8_armor_damage(0);
      $weapons->save();
      break;
  }
}

?>