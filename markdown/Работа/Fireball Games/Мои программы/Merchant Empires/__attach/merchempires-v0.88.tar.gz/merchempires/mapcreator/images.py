# -*- Mode: Python; tab-width: 4 -*-
#	Author: Bryan Brunton

""" This file is part of Merchant Empires
    Copyright (C) 2000 Bryan Brunton (bryan@dunsinane.net)

    This is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this library; see the file COPYING If not, write to
    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
    Boston, MA 02111-1307, USA.
"""

import Image, ImageDraw, ImageFont
from pg import DB
from Defines import *
import whrandom, os, string

def has_bottom_exit(exits, xpos, ypos):
	import re

	qypos = ypos - 1
	strpos = str(xpos) + ':' + str(qypos)

	if re.search(strpos, exits) == None:
		return 0
	else:
		return 1

def has_right_exit(exits, xpos, ypos):
	import re

	qxpos = xpos + 1
	strpos = str(qxpos) + ':' + str(ypos)

	if re.search(strpos, exits) == None:
		return 0
	else:
		return 1

def has_top_exit(exits, xpos, ypos):
	import re

	qypos = ypos + 1
	strpos = str(xpos) + ':' + str(qypos)

	if re.search(strpos, exits) == None:
		return 0
	else:
		return 1

def has_left_exit(exits, xpos, ypos):
	import re

	qxpos = xpos - 1
	strpos = str(qxpos) + ':' + str(ypos)

	if re.search(strpos, exits) == None:
		return 0
	else:
		return 1

def computesellgoods(sector_id, sellgoods):
	qrystr = "SELECT sector_id, type, buyorsell, marketvalue from goods where sector_id = '%d' and buyorsell = 'sell' order by marketvalue" % (sector_id)
	q = pgcnx.query(qrystr)
	res = q.getresult()

	if len(res) > 0:
		for value in range(len(res)):
			if res[value][q.fieldnum('type')] == 'Circuitry':
				sellgoods['circuitry'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Computers':
				sellgoods['computers'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Food':
				sellgoods['food'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Luxury Items':
				sellgoods['luxuryitems'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Machinery':	
				sellgoods['machinery'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Ore':
				sellgoods['ore'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Precious Metals':
				sellgoods['preciousmetals'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Textiles':
				sellgoods['textiles'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Biochemicals':
				sellgoods['biochemicals'] = 'true'

		return 1

	return 0

def computesellgoods_contra(sector_id, sellgoods):
	qrystr = "SELECT sector_id, type, buyorsell, marketvalue from goods where sector_id = '%d' and buyorsell = 'sell' order by marketvalue" % (sector_id)
	q = pgcnx.query(qrystr)
	res = q.getresult()

	contra_found = 0

	if len(res) > 0:
		for value in range(len(res)):
			if res[value][q.fieldnum('type')] == 'Narcotics':
				sellgoods['narcotics'] = 'true'
				contra_found = 1
			elif res[value][q.fieldnum('type')] == 'Slaves':
				sellgoods['slaves'] = 'true'
				contra_found = 1
			elif res[value][q.fieldnum('type')] == 'Weapons':
				sellgoods['weapons'] = 'true'
				contra_found = 1

		if contra_found:
			return 1

	return 0

def sellgoodit(im, sellgoods):
	num_sellgoods = 0
	
	yselltop = 66

	im_2 = Image.open('./goods/buttonsell.png').convert("RGB")
	box = (0,0,5,16)
	region = im_2.crop(box)
	box_2 = (3,yselltop,8,yselltop+16)
	im.paste(region, box_2)

	if sellgoods['biochemicals'] == 'true':
		im_2 = Image.open('./goods/biochemicals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)
		box_2 = (9,yselltop,24,yselltop + 15)
		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['food'] == 'true':
		im_2 = Image.open('./goods/food.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['ore'] == 'true':
		im_2 = Image.open('./goods/ore.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['preciousmetals'] == 'true':
		im_2 = Image.open('./goods/preciousmetals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['textiles'] == 'true':
		im_2 = Image.open('./goods/textiles.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1
	
	if sellgoods['machinery'] == 'true':
		im_2 = Image.open('./goods/machinery.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['circuitry'] == 'true':
		im_2 = Image.open('./goods/circuitry.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['computers'] == 'true':
		im_2 = Image.open('./goods/computers.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['luxuryitems'] == 'true':
		im_2 = Image.open('./goods/luxuryitems.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

def sellgoodit_contra(im, sellgoods):
	num_sellgoods = 0
	
	yselltop = 66

	im_2 = Image.open('./goods/buttonsell.png').convert("RGB")
	box = (0,0,5,16)
	region = im_2.crop(box)
	box_2 = (3,yselltop,8,yselltop+16)
	im.paste(region, box_2)

	if sellgoods['biochemicals'] == 'true':
		im_2 = Image.open('./goods/biochemicals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)
		box_2 = (9,yselltop,24,yselltop + 15)
		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['food'] == 'true':
		im_2 = Image.open('./goods/food.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['ore'] == 'true':
		im_2 = Image.open('./goods/ore.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['preciousmetals'] == 'true':
		im_2 = Image.open('./goods/preciousmetals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['textiles'] == 'true':
		im_2 = Image.open('./goods/textiles.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1
	
	if sellgoods['machinery'] == 'true':
		im_2 = Image.open('./goods/machinery.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['circuitry'] == 'true':
		im_2 = Image.open('./goods/circuitry.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['computers'] == 'true':
		im_2 = Image.open('./goods/computers.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['luxuryitems'] == 'true':
		im_2 = Image.open('./goods/luxuryitems.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['slaves'] == 'true':
		im_2 = Image.open('./goods/slaves.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['weapons'] == 'true':
		im_2 = Image.open('./goods/weapons.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

	if sellgoods['narcotics'] == 'true':
		im_2 = Image.open('./goods/narcotics.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_sellgoods == 0:
			box_2 = (9,yselltop,24,yselltop + 15)
		if num_sellgoods == 1:
			box_2 = (24,yselltop,39,yselltop + 15)
		elif num_sellgoods == 2:
			box_2 = (39,yselltop,54,yselltop + 15)
		elif num_sellgoods == 3:
			box_2 = (53,yselltop,68,yselltop + 15)
		elif num_sellgoods == 4:
			box_2 = (68,yselltop,83,yselltop + 15)

		im.paste(region, box_2)
		num_sellgoods = num_sellgoods + 1

def computebuygoods(sector_id, buygoods):
	qrystr = "SELECT sector_id, type, buyorsell, marketvalue from goods where sector_id = '%d' and buyorsell = 'buy' order by marketvalue" % (sector_id)
	q = pgcnx.query(qrystr)
	res = q.getresult()

	if len(res) > 0:
		for value in range(len(res)):
			if res[value][q.fieldnum('type')] == 'Circuitry':
				buygoods['circuitry'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Computers':
				buygoods['computers'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Food':
				buygoods['food'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Luxury Items':
				buygoods['luxuryitems'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Machinery':	
				buygoods['machinery'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Ore':
				buygoods['ore'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Precious Metals':
				buygoods['preciousmetals'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Textiles':
				buygoods['textiles'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Biochemicals':
				buygoods['biochemicals'] = 'true'

		return 1

	return 0

def computebuygoods_contra(sector_id, buygoods):
	qrystr = "SELECT sector_id, type, buyorsell, marketvalue from goods where sector_id = '%d' and buyorsell = 'buy' order by marketvalue" % (sector_id)
	q = pgcnx.query(qrystr)
	res = q.getresult()

	contra_found = 0

	if len(res) > 0:
		for value in range(len(res)):
			if res[value][q.fieldnum('type')] == 'Narcotics':
				buygoods['narcotics'] = 'true'
				contra_found = 1
			elif res[value][q.fieldnum('type')] == 'Slaves':
				buygoods['slaves'] = 'true'
				contra_found = 1
			elif res[value][q.fieldnum('type')] == 'Weapons':
				buygoods['weapons'] = 'true'
				contra_found = 1

		if contra_found:
			return 1

	return 0

def buygoodit(im, buygoods):
	num_buygoods = 0
	ybuytop = 49

	im_2 = Image.open('./goods/buttonbuy.png').convert("RGB")
	box = (0,0,5,16)
	region = im_2.crop(box)
	box_2 = (3,ybuytop,8,ybuytop + 16)
	im.paste(region, box_2)

	if buygoods['biochemicals'] == 'true':
		im_2 = Image.open('./goods/biochemicals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)
		box_2 = (9,ybuytop,24,ybuytop + 15)
		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['food'] == 'true':
		im_2 = Image.open('./goods/food.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['ore'] == 'true':
		im_2 = Image.open('./goods/ore.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['preciousmetals'] == 'true':
		im_2 = Image.open('./goods/preciousmetals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['textiles'] == 'true':
		im_2 = Image.open('./goods/textiles.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['machinery'] == 'true':
		im_2 = Image.open('./goods/machinery.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['circuitry'] == 'true':
		im_2 = Image.open('./goods/circuitry.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['computers'] == 'true':
		im_2 = Image.open('./goods/computers.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (23,ybuytop,38,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1


	if buygoods['luxuryitems'] == 'true':
		im_2 = Image.open('./goods/luxuryitems.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

def buygoodit_contra(im, buygoods):
	num_buygoods = 0
	ybuytop = 49

	im_2 = Image.open('./goods/buttonbuy.png').convert("RGB")
	box = (0,0,5,16)
	region = im_2.crop(box)
	box_2 = (3,ybuytop,8,ybuytop + 16)
	im.paste(region, box_2)

	if buygoods['biochemicals'] == 'true':
		im_2 = Image.open('./goods/biochemicals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)
		box_2 = (9,ybuytop,24,ybuytop + 15)
		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['food'] == 'true':
		im_2 = Image.open('./goods/food.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['ore'] == 'true':
		im_2 = Image.open('./goods/ore.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['preciousmetals'] == 'true':
		im_2 = Image.open('./goods/preciousmetals.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['textiles'] == 'true':
		im_2 = Image.open('./goods/textiles.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['machinery'] == 'true':
		im_2 = Image.open('./goods/machinery.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['circuitry'] == 'true':
		im_2 = Image.open('./goods/circuitry.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['computers'] == 'true':
		im_2 = Image.open('./goods/computers.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (23,ybuytop,38,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1


	if buygoods['luxuryitems'] == 'true':
		im_2 = Image.open('./goods/luxuryitems.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['slaves'] == 'true':
		im_2 = Image.open('./goods/slaves.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['weapons'] == 'true':
		im_2 = Image.open('./goods/weapons.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

	if buygoods['narcotics'] == 'true':
		im_2 = Image.open('./goods/narcotics.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_buygoods == 0:
			box_2 = (9,ybuytop,24,ybuytop + 15)
		if num_buygoods == 1:
			box_2 = (24,ybuytop,39,ybuytop + 15)
		elif num_buygoods == 2:
			box_2 = (39,ybuytop,54,ybuytop + 15)
		elif num_buygoods == 3:
			box_2 = (53,ybuytop,68,ybuytop + 15)
		elif num_buygoods == 4:
			box_2 = (68,ybuytop,83,ybuytop + 15)

		im.paste(region, box_2)
		num_buygoods = num_buygoods + 1

def computelocations(sector_id, locations):
	qrystr = "SELECT sector_id, type, name, options from locations where sector_id = '%d' order by type" % (sector_id)
	q = pgcnx.query(qrystr)
	res = q.getresult()

	if len(res) > 0:
		for value in range(len(res)):
			if res[value][q.fieldnum('type')] == 'Shipdealer':
				locations['shipdealer'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Technology':
				locations['technology'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Weapons':
				locations['weapons'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Bank':
				locations['bank'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Bar':	
				locations['bar'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Government':
				locations['government'] = 'true'				
				locations['options'] = res[value][q.fieldnum('options')]
			elif res[value][q.fieldnum('type')] == 'Underground':
				locations['underground'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Authority':
				locations['authority'] = 'true'
			elif res[value][q.fieldnum('type')] == 'Starbase':
				locations['starbase'] = 'true'
				
def locationit(im, locations):
	# only 4 locations allowed in one sector

	num_locations = 0

	if locations['shipdealer'] == 'true':
		im_2 = Image.open('./locations/shipdealer.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)
		box_2 = (3,23,18,38)
		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['technology'] == 'true':
		im_2 = Image.open('./locations/hardware.png').convert("RGB")
		box = (0,0,16,16)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,19,39)
		if num_locations == 1:
			box_2 = (18,23,34,39)
		elif num_locations == 2:
			box_2 = (34,23,50,39)
		elif num_locations == 3:
			box_2 = (50,23,66,39)
		elif num_locations == 4:
			box_2 = (66,23,82,39)

		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['bank'] == 'true':
		im_2 = Image.open('./locations/bank.png').convert("RGB")
		box = (0,0,16,16)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,19,39)
		if num_locations == 1:
			box_2 = (18,23,34,39)
		elif num_locations == 2:
			box_2 = (34,23,50,39)
		elif num_locations == 3:
			box_2 = (50,23,66,39)
		elif num_locations == 4:
			box_2 = (66,23,82,39)

		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['government'] == 'true':
		if locations['options'] == '1':
			im_2 = Image.open('./locations/government_1.png').convert("RGB")
		elif locations['options'] == '2':
			im_2 = Image.open('./locations/government_2.png').convert("RGB")		
		elif locations['options'] == '3':
			im_2 = Image.open('./locations/government_3.png').convert("RGB")		
		elif locations['options'] == '4':
			im_2 = Image.open('./locations/government_4.png').convert("RGB")		
		elif locations['options'] == '5':
			im_2 = Image.open('./locations/government_5.png').convert("RGB")		
		elif locations['options'] == '6':
			im_2 = Image.open('./locations/government_6.png').convert("RGB")		
		elif locations['options'] == '7':
			im_2 = Image.open('./locations/government_7.png').convert("RGB")
		elif locations['options'] == '0':
			im_2 = Image.open('./locations/government_1.png').convert("RGB")
				
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,18,38)
		if num_locations == 1:
			box_2 = (18,23,33,38)
		elif num_locations == 2:
			box_2 = (34,23,49,38)
		elif num_locations == 3:
			box_2 = (50,23,65,38)
		elif num_locations == 4:
			box_2 = (66,23,81,38)

		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['bar'] == 'true':
		im_2 = Image.open('./locations/bar.png').convert("RGB")
		box = (0,0,16,16)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,19,39)
		if num_locations == 1:
			box_2 = (18,23,34,39)
		elif num_locations == 2:
			box_2 = (34,23,50,39)
		elif num_locations == 3:
			box_2 = (50,23,66,39)
		elif num_locations == 4:
			box_2 = (66,23,82,39)

		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['underground'] == 'true':
		im_2 = Image.open('./locations/underground.png').convert("RGB")
		box = (0,0,16,16)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,19,39)
		if num_locations == 1:
			box_2 = (18,23,34,39)
		elif num_locations == 2:
			box_2 = (34,23,50,39)
		elif num_locations == 3:
			box_2 = (50,23,66,39)
		elif num_locations == 4:
			box_2 = (66,23,82,39)

		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['weapons'] == 'true':
		im_2 = Image.open('./locations/weapons.png').convert("RGB")
		box = (0,0,16,16)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,19,39)
		if num_locations == 1:
			box_2 = (18,23,34,39)
		elif num_locations == 2:
			box_2 = (34,23,50,39)
		elif num_locations == 3:
			box_2 = (50,23,66,39)
		elif num_locations == 4:
			box_2 = (66,23,82,39)

		im.paste(region, box_2)
		num_locations = num_locations + 1

	if locations['authority'] == 'true':
		im_2 = Image.open('./locations/beacon.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,18,38)
		if num_locations == 1:
			box_2 = (18,23,33,38)
		elif num_locations == 2:
			box_2 = (34,23,49,38)
		elif num_locations == 3:
			box_2 = (50,23,65,38)
		elif num_locations == 4:
			box_2 = (66,23,81,38)

		im.paste(region, box_2)
		num_locations = num_locations + 1
			
	if locations['starbase'] == 'true':
		im_2 = Image.open('./locations/starbase.png').convert("RGB")
		box = (0,0,15,15)
		region = im_2.crop(box)

		if num_locations == 0:
			box_2 = (3,23,18,38)
		if num_locations == 1:
			box_2 = (18,23,33,38)
		elif num_locations == 2:
			box_2 = (34,23,49,38)
		elif num_locations == 3:
			box_2 = (50,23,65,38)
		elif num_locations == 4:
			box_2 = (66,23,81,38)

		im.paste(region, box_2)
		num_locations = num_locations + 1

def topexitit(im):
	im_2 = Image.open('./arrows/arrowdownsmall-blue.png').convert("RGB")
	box = (0,0,7,4)
	region = im_2.crop(box)
	box_2 = (47,3,54,7)
	im.paste(region, box_2)

def bottomexitit(im):
	im_2 = Image.open('./arrows/arrowupsmall-blue.png').convert("RGB")
	box = (0,0,7,4)
	region = im_2.crop(box)
	box_2 = (47,87,54,91)
	im.paste(region, box_2)

def rightexitit(im):
	im_2 = Image.open('./arrows/arrowleftsmall-blue.png').convert("RGB")
	box = (0,0,4,7)
	region = im_2.crop(box)
	box_2 = (88,44,92,51)
	im.paste(region, box_2)

def warpit(im_c):
	im_2 = Image.open('./misc/warp.png').convert("RGB")
	box = (0,0,15,15)
	box_2 = (58,4,73,19)
	region = im_2.crop(box)

	im_c.paste(region, box_2)

def merchantit(im_c):
	im_2 = Image.open('./dynamic/trader.png').convert("RGB")
	box = (0,0,16,16)
	box_2 = (74,4,90,20)
	region = im_2.crop(box)

	im_c.paste(region, box_2)

def mineit(im_c):
	im_2 = Image.open('./dynamic/minedrone.png').convert("RGB")
	box = (0,0,16,16)
	box_2 = (74,24,90,40)
	region = im_2.crop(box)

	im_c.paste(region, box_2)
	
def planetit(im_c, number):
	if number == 1:
		im_2 = Image.open('./planets/planet1.png').convert("RGB")
	elif number == 2:
		im_2 = Image.open('./planets/planet2.png').convert("RGB")
	elif number == 3:
		im_2 = Image.open('./planets/planet3.png').convert("RGB")
	elif number == 4:
		im_2 = Image.open('./planets/planet4.png').convert("RGB")
	elif number == 5:
		im_2 = Image.open('./planets/planet5.png').convert("RGB")

	box = (0,0,16,16)
	box_2 = (41,4,57,20)
	region = im_2.crop(box)

	im_c.paste(region, box_2)

def boxit(im, color):
	if color == 'red':
		im_2 = Image.open('./misc/redbandvertical.png').convert("RGB")
		im_3 = Image.open('./misc/redbandhorizontal.png').convert("RGB")
	else:
		im_2 = Image.open('./misc/yellowbandvertical.png').convert("RGB")
		im_3 = Image.open('./misc/yellowbandhorizontal.png').convert("RGB")

	#left side
	box = (0,0,2,94)
	#right side
	box_2 = (93,0,95,94)
	#top
	box_3 = (0,0,94,2)
	#bottom
	box_4 = (0,92,94,94)

	region = im_2.crop(box)
	region_2 = im_3.crop(box_3)

	im.paste(region, box)
	im.paste(region, box_2)
	im.paste(region_2, box_3)
	im.paste(region_2, box_4)

def create_navigation_box(exits, xpos, ypos, map_id):
	im_move = Image.open('./navmenu/moveblank.png').convert("RGB")
	font = ImageFont.load('./fonts/Arial Bold_8_100.pil')
	draw = ImageDraw.ImageDraw(im_move)
	draw.setfont(font)
	draw.setink(0xff5555)
	draw.text((42,36), str(res[value][q.fieldnum('public_sector_id')]))
	
	im_2 = Image.open('./navmenu/yellowsquare.png').convert("RGB")
	box = (0,0,28,27)
	region = im_2.crop(box)

	if has_right_exit(exits, xpos, ypos):
		box_3 = (69,30,97,57)
		im_move.paste(region, box_3)
		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos + 1, ypos, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((71,36), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	if has_left_exit(exits, xpos, ypos):
		box_2 = (11,30,39,57)
		im_move.paste(region, box_2)

		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos - 1, ypos, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((13,36), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	if has_top_exit(exits, xpos, ypos):
		box_4 = (40,2,68,29)
		im_move.paste(region, box_4)

		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos, ypos + 1, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((42,8), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	if has_bottom_exit(exits, xpos, ypos):
		box_5 = (40,58,68,85)
		im_move.paste(region, box_5)
			
		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos, ypos - 1, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((42,64), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	im_move.save('./createdsectors/navmenu' + str(res[value][q.fieldnum('sector_id')]) + '.png')

def create_scan_box(exits, xpos, ypos, map_id):
	im_move = Image.open('./navmenu/scanblank.png').convert("RGB")
	font = ImageFont.load('./fonts/Arial Bold_8_100.pil')
	draw = ImageDraw.ImageDraw(im_move)
	draw.setfont(font)
	draw.setink(0xff5555)
	draw.text((42,36), str(res[value][q.fieldnum('public_sector_id')]))
	
	im_2 = Image.open('./navmenu/yellowsquare.png').convert("RGB")
	box = (0,0,28,27)
	region = im_2.crop(box)

	if has_right_exit(exits, xpos, ypos):
		box_3 = (69,30,97,57)
		im_move.paste(region, box_3)
		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos + 1, ypos, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((71,36), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	if has_left_exit(exits, xpos, ypos):
		box_2 = (11,30,39,57)
		im_move.paste(region, box_2)

		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos - 1, ypos, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((13,36), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	if has_top_exit(exits, xpos, ypos):
		box_4 = (40,2,68,29)
		im_move.paste(region, box_4)

		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos, ypos + 1, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((42,8), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	if has_bottom_exit(exits, xpos, ypos):
		box_5 = (40,58,68,85)
		im_move.paste(region, box_5)
			
		qrystr = "SELECT sector_id, xpos, ypos, map_id, public_sector_id from sectors where xpos = '%d' and ypos = '%d' and map_id = '%d'" % (xpos, ypos - 1, map_id)
		q_2 = pgcnx.query(qrystr)
		res_2 = q_2.getresult()

		if len(res_2) > 0:
			draw.text((42,64), str(res_2[0][q_2.fieldnum('public_sector_id')]))

	im_move.save('./createdsectors/scanmenu' + str(res[value][q.fieldnum('sector_id')]) + '.png')

if __name__ == '__main__':
	map_id = input("Input map id: ")
	pgcnx = DB(postmerchdb,postmerchhost,user=postmerchuser,passwd=postmerchpass)

	qrystr = "SELECT sector_id, xpos, ypos, exits, public_sector_id, image_version from sectors where map_id = '%d'" % (map_id)
	q = pgcnx.query(qrystr)
	res = q.getresult()
	
	if len(res) > 0:
		for value in range(len(res)):
			num = whrandom.randint(1,5)
			
			if num == 1:
				im = Image.open('./misc/blanksector_1.png').convert("RGB")
			elif num == 2:
				im = Image.open('./misc/blanksector_2.png').convert("RGB")			
			elif num == 3:
				im = Image.open('./misc/blanksector_3.png').convert("RGB")
			elif num == 4:
				im = Image.open('./misc/blanksector_4.png').convert("RGB")
			elif num == 5:
				im = Image.open('./misc/blanksector_5.png').convert("RGB")
											
			print value
			im_exp_y = im.copy()
			font = ImageFont.load('./fonts/Arial Bold_8_100.pil')
			draw = ImageDraw.ImageDraw(im)
			draw.setfont(font)
			draw.setink(0xff5555)
			draw.text((3,2), str(res[value][q.fieldnum('public_sector_id')]))
			
			draw_2 = ImageDraw.ImageDraw(im_exp_y)
			draw_2.setfont(font)
			draw_2.setink(0x888888)
			draw_2.text((3,2), str(res[value][q.fieldnum('public_sector_id')]))

			locations = {'bank': 'false', 'bar': 'false', 'government': 'false', 'technology': 'false',	\
				'shipdealer': 'false', 'underground': 'false', 'weapons': 'false', 'authority': 'false',
				'starbase': 'false', 'options': '0'}
			
			computelocations(res[value][q.fieldnum('sector_id')], locations)
			image_version = res[value][q.fieldnum('image_version')]

			# unexplored map image
			im_exp_y.save('./createdsectors/unexplored' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')
			
			#yellow box
			boxit(im_exp_y, 'yellow')			
			im_exp_y.save('./createdsectors/unexplored-yellow' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# add locations
			locationit(im, locations)
			
			# compute planet
			qrystr = "SELECT warp_id, sector_id from warps where sector_id = '%d'" % (res[value][q.fieldnum('sector_id')])
			q_2 = pgcnx.query(qrystr)
			res_2 = q_2.getresult()

			if len(res_2) > 0:
				warpit(im)

			# add exits
			if has_right_exit(res[value][q.fieldnum('exits')], res[value][q.fieldnum('xpos')], res[value][q.fieldnum('ypos')]):
				rightexitit(im)

			if has_bottom_exit(res[value][q.fieldnum('exits')], res[value][q.fieldnum('xpos')], res[value][q.fieldnum('ypos')]):
				bottomexitit(im)

			buygoods = {'circuitry': 'false', 'computers': 'false', 'food': 'false', 'luxuryitems': 'false',	\
				'machinery': 'false', 'ore': 'false', 'preciousmetals': 'false', 'textiles': 'false',		\
				'biochemicals': 'false', 'narcotics': 'false', 'slaves': 'false', 'weapons': 'false'}

			sellgoods = {'circuitry': 'false', 'computers': 'false', 'food': 'false', 'luxuryitems': 'false',	\
				'machinery': 'false', 'ore': 'false', 'preciousmetals': 'false', 'textiles': 'false',		\
				'biochemicals': 'false', 'narcotics': 'false', 'slaves': 'false', 'weapons': 'false'}	

			contra_exists = 0

			if computesellgoods_contra(res[value][q.fieldnum('sector_id')], sellgoods) or computebuygoods_contra(res[value][q.fieldnum('sector_id')], buygoods):
				contra_exists = 1

			# create a copy for contra good image creation
			im_evil = im.copy()

			# compute buy goods	
			if computebuygoods(res[value][q.fieldnum('sector_id')], buygoods):
				buygoodit(im, buygoods)

			# compute contra buy goods	
			if contra_exists:
				buygoodit_contra(im_evil, buygoods)		

			# compute sell goods
			if computesellgoods(res[value][q.fieldnum('sector_id')], sellgoods):
				sellgoodit(im, sellgoods)		

			# compute sell goods
			if contra_exists:
				sellgoodit_contra(im_evil, sellgoods)	

			# compute planet
			qrystr = "SELECT planet_id, sector_id, image_id from planets where sector_id = '%d'" % (res[value][q.fieldnum('sector_id')])
			q_2 = pgcnx.query(qrystr)
			res_2 = q_2.getresult()
		
			if len(res_2) > 0:
				if res_2[0][q_2.fieldnum('image_id')] == 1:
					planetit(im, 1)
										
					if contra_exists:
						planetit(im_evil, 1)
					
				elif res_2[0][q_2.fieldnum('image_id')] == 2:
					planetit(im, 2)
										
					if contra_exists:
						planetit(im_evil, 2)

				elif res_2[0][q_2.fieldnum('image_id')] == 3:
					planetit(im, 3)
										
					if contra_exists:
						planetit(im_evil, 3)
					
				elif res_2[0][q_2.fieldnum('image_id')] == 4:
					planetit(im, 4)
										
					if contra_exists:
						planetit(im_evil, 4)
					
				elif res_2[0][q_2.fieldnum('image_id')] == 5:
					planetit(im, 5)
										
					if contra_exists:
						planetit(im_evil, 5)
					
					
			# blank map image
			im.save('./createdsectors/blank' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				# blank evil map image
				im_evil.save('./createdsectors/blank-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			#red box
			boxit(im, 'red')			
			im.save('./createdsectors/blankredbox' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				#red evil box
				boxit(im_evil, 'red')			
				im_evil.save('./createdsectors/blankredbox-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# create mines
			im_m = im.copy()
			mineit(im_m)
			im_m.save('./createdsectors/minedrone-nomerchant' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')
			
			if contra_exists:
				# create evil mines
				im_m_evil = im_evil.copy()
				mineit(im_m_evil)
				im_m_evil.save('./createdsectors/minedrone-nomerchant-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# create merchant
			im_c = im.copy()
			merchantit(im_c)
			im_c.save('./createdsectors/merchant' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				# create evil merchant
				im_c_evil = im_evil.copy()
				merchantit(im_c_evil)
				im_c_evil.save('./createdsectors/merchant-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# create mines w/ merchant
			im_m2 = im_c.copy()
			mineit(im_m2)
			im_m2.save('./createdsectors/minedrone-withmerchant' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')
			
			if contra_exists:
				# create evil mines w/ merchant
				im_m2_evil = im_c_evil.copy()
				mineit(im_m2_evil)
				im_m2_evil.save('./createdsectors/minedrone-withmerchant-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			#yellow box
			boxit(im, 'yellow')			
			im.save('./createdsectors/blankyellowbox' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				#yellow evil box
				boxit(im_evil, 'yellow')			
				im_evil.save('./createdsectors/blankyellowbox-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# create mines
			im_ym = im.copy()
			mineit(im_ym)
			im_ym.save('./createdsectors/yellow-minedrone-nomerchant' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				# create evil mines
				im_ym_evil = im_evil.copy()
				mineit(im_ym_evil)
				im_ym_evil.save('./createdsectors/yellow-minedrone-nomerchant-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# create merchant
			im_yc = im.copy()
			merchantit(im_yc)
			im_yc.save('./createdsectors/yellow-merchant' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				# create evil merchant
				im_yc_evil = im_evil.copy()
				merchantit(im_yc_evil)
				im_yc_evil.save('./createdsectors/yellow-merchant-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			# create mines w/ merchant
			im_ym2 = im_yc.copy()
			mineit(im_ym2)
			im_ym2.save('./createdsectors/yellow-minedrone-withmerchant' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			if contra_exists:
				# create evil mines w/ merchant
				im_ym2_evil = im_yc_evil.copy()
				mineit(im_ym2_evil)
				im_ym2_evil.save('./createdsectors/yellow-minedrone-withmerchant-evil' + str(res[value][q.fieldnum('sector_id')]) + '-' + str(image_version) + '.png')

			#nav box
			create_navigation_box(res[value][q.fieldnum('exits')], res[value][q.fieldnum('xpos')], res[value][q.fieldnum('ypos')], map_id)
			
			#scan box
			create_scan_box(res[value][q.fieldnum('exits')], res[value][q.fieldnum('xpos')], res[value][q.fieldnum('ypos')], map_id)
		
		dir_1 = '/usr/local/merchantempires/mapcreator/createdsectors/'	
		dir_2 = '/home/httpd/html/merchantempires/images/map' + str(map_id) + '/'		
		mylist = os.listdir(dir_1)
	
		for value in range(len(mylist)):
			if string.find(mylist[value], '.png') <> -1:
				os.system('./pngcrush -m 113 ' + dir_1 + mylist[value] + ' ' + dir_2 + mylist[value])				
				
		print 'Map images successfully created.'
	else:
		print 'Map not found.'



