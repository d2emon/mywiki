<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/sector.php");
include("./merchantempiresdefines.php");

#if player dead, send to post-death screen
if ( $player_dead == 't' ) {	
	$newurl = $sess->url(URL . "death.php");
	header("Location: $newurl");
	exit;
}

# send player to select a game if no player id
if (!$player_id>0)  {
	$newurl = $sess->url(URL . "select_game.php");
	header("Location: $newurl");
	exit;
}

function get_player_map($map_id, $player)  {
	$player_id = $player->f("player_id");

	$db = new ME_DB;

	if ( $player->f("alliance_id") <> 0 ) {	
		$query = sprintf("SELECT * from alliance_maps where alliance_id = '%s'", $player->f("alliance_id"));
	} else {
		$query = sprintf("SELECT * from player_maps where player_id = '%s'", $player_id);
	}	

	$db->query($query);
	$db->next_record();

	if ( $db->f("map_1_id") == $map_id ) {
		return $db->f("map_1");			
	} elseif ( $db->f("map_2_id") == $map_id ) {
		return $db->f("map_2");				
	} elseif ( $db->f("map_3_id") == $map_id ) {
		return $db->f("map_3");				
	} elseif ( $db->f("map_4_id") == $map_id ) {
		return $db->f("map_4");				
	} elseif ( $db->f("map_5_id") == $map_id ) {
		return $db->f("map_5");				
	} elseif ( $db->f("map_6_id") == $map_id ) {
		return $db->f("map_6");	
	} elseif ( $db->f("map_7_id") == $map_id ) {
		return $db->f("map_7");	
	} elseif ( $db->f("map_8_id") == $map_id ) {
		return $db->f("map_8");	
	} elseif ( $db->f("map_9_id") == $map_id ) {
		return $db->f("map_9");	
	} elseif ( $db->f("map_10_id") == $map_id ) {
		return $db->f("map_10");	
	}			
}
?>

<html><head><title>Merchant Empires: Galaxy Map</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/stars.png"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$game_id = $player->f("game_id");

$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "galaxymap");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());

$id = (int) $id;

$db = new ME_DB;
$db->query("select * from sectors where sector_id = '$id'");
$db->next_record();

$s1 = new ME_Sector;
$s1->get_offset_sector($db->f("map_id"), $db->f("xpos"), $db->f("ypos"));

$s3 = new ME_Sector;
$s3->get_sector($player_id);

$sectors = get_player_map($db->f("map_id"), $player);
$visible_sectors = array();
$visible_sectors = explode(",", $sectors);

$query = sprintf("select * from sectors where map_id = '%s'", $s1->f("map_id"));
$db->query($query);
$galaxy = array();	

while ( $db->next_record() ) {	
	$galaxy[$db->f("xpos") . "," . $db->f("ypos")][0] = $db->f("xpos");
	$galaxy[$db->f("xpos") . "," . $db->f("ypos")][1] = $db->f("ypos");
	$galaxy[$db->f("xpos") . "," . $db->f("ypos")][2] = $db->f("sector_id");
	$galaxy[$db->f("xpos") . "," . $db->f("ypos")][3] = $db->f("public_sector_id");
	$galaxy[$db->f("xpos") . "," . $db->f("ypos")][4] = $db->f("map_id");
	$galaxy[$db->f("xpos") . "," . $db->f("ypos")][5] = $db->f("image_version");
}

$query = sprintf("select map_id, description from maps where map_id = '%s'", $s1->f("map_id"));
$db->query($query);
$db->next_record();
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500>

<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#993300>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle bgColor=#330000>
						<table border=0>
            	<tr>
								<td align=left colspan=6>
									<font color=#3333FF face=arial,helvetica,swiss size=5><?php

echo $db->f("description");
?>
								</font>
								</td>
							</tr>					
						</table>
					</td>
					<td width=90 valign=top align=right bgColor=#000000>
						<img border=0 src='./images/misc/galaxy_map_scroll.png' usemap='#galmenu'><?php

echo "<map name='galmenu'>";

#bottom
$str = ($s1->f("xpos")) . "," . ($s1->f("ypos") - 1);

if ($galaxy[$str][2] != 0)  {
	echo "<area coords=40,58,68,85 href=" . URL . "galaxy_map.php?id=" . $galaxy[$str][2] . ">";
}

#top
$str = ($s1->f("xpos")) . "," . ($s1->f("ypos") + 1);

if ($galaxy[$str][2] != 0)  {
	echo "<area coords=40,2,68,29 href=" . URL . "galaxy_map.php?id=" . $galaxy[$str][2] . ">";
}

#right
$str = ($s1->f("xpos") + 1) . "," . ($s1->f("ypos"));

if ($galaxy[$str][2] != 0)  {
	echo "<area coords=69,30,97,57 href=" . URL . "galaxy_map.php?id=" . $galaxy[$str][2] . ">";
}

#left
$str = ($s1->f("xpos") - 1) . "," . ($s1->f("ypos") + -1);

if ($galaxy[$str][2] != 0)  {
	echo "<area coords=11,30,39,57 href=" . URL . "galaxy_map.php?id=" . $galaxy[$str][2] . ">";
}

echo "</map>";
?>
					</td>				
				</tr>
			</table>
		</td>
	</tr>
</table>
<br></font></center><br>
<table COLS=5 BORDER=0 width=490 cellPadding=1 cellSpacing=0><?php

$db_f = new ME_DB;

$y = 4;
for ($i = 1; $i <= 8; $i++) {
	$x = -4;
	printf("<tr>");
	for ($j = 1; $j <= 8; $j++) {
		$str = ($s1->f("xpos") + $x) . "," . ($s1->f("ypos") + $y);

		printf("<td>");

		# if the table cell contains a map sector, print the contents
		if ($galaxy[$str][2] != 0)  {
			$status = array("redbox" => "false", "yellowbox" => "false");
			
			if ( $player->f("alignment") < -100 ) {
				$query = sprintf("SELECT sector_id, type from goods where sector_id = '%s' and (type='Narcotics' or type='Weapons' or type='Slaves')", $galaxy[$str][2]);
				$db->query($query);

				$contra_found = 0;
	
				if ( $db->nf() > 0 ) {
					$contra_found = 1;
				}
			} else {
				$contra_found = 0;
			}

			# determine if the sector is an exit sector from the current sector, or if the
			# sector is the current sector
			if ( $galaxy[$str][0] == $s3->f("xpos")
			and $galaxy[$str][1] == $s3->f("ypos") )  {
				$status["redbox"] = "true";
			}

			if ( $status["redbox"] == "true" )  {
				if ( in_array($galaxy[$str][2], $visible_sectors) )  {
					if ( $contra_found ) {
  					printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/blankredbox-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
					} else {
						printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
								"/blankredbox" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
					}
				}
			} else {
				if ( in_array($galaxy[$str][2], $visible_sectors) )  {
					if ( $contra_found ) {
						printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
							"/blank-evil" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
					} else {
						printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
							"/blank" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
					}
				} else {
					printf("<img border=0 src='./images/map" . $galaxy[$str][4] .
						"/unexplored" . $galaxy[$str][2] . "-" . $galaxy[$str][5] . ".png'>");
				}
			}
			
		} else {
			printf("<img src='./images/blanksector.png'>");
		}
    echo "\n</td>";
		$x = $x + 1;
	}
	printf("</tr>");
	$y = $y - 1;
}

?>
</table>
</td>
<td valign=top align=right width=100%>
</td></tr></table>
</body></html><?php

page_close();
?>