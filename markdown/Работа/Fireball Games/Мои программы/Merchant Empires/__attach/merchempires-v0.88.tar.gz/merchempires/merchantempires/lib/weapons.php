<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

class ME_Weapons extends ME_DB {	
	var $id = 0;
	var $dirty_fields = array();
	var $Current_weapons = array();

  function get_weapons($id) {
		$this->connect();
		$query = sprintf("select * from ship_weapons where ship_id = '%s'", $id);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
    $this->Row   = 0;

    $this->Error = pg_ErrorMessage($this->Link_ID);
    $this->Errno = ($this->Error == "")?0:1;
    if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
    }
	
		$this->next_record();	

		$this->id = $this->f("ship_weapon_id");
  	$this->set_ship_id($id);		
	
		if ( $this->f("weapon_1_id") <> 0 ) {
			$this->Current_weapons[1] = $this->f("weapon_1_id");			
		}		

		if ( $this->f("weapon_2_id") <> 0 ) {
			$this->Current_weapons[2] = $this->f("weapon_2_id");						
		}		
		
		if ( $this->f("weapon_3_id") <> 0 ) {
			$this->Current_weapons[3] = $this->f("weapon_3_id");				
		}		
	
		if ( $this->f("weapon_4_id") <> 0 ) {
			$this->Current_weapons[4] = $this->f("weapon_4_id");				
		}		

		if ( $this->f("weapon_5_id") <> 0 ) {
			$this->Current_weapons[5] = $this->f("weapon_5_id");				
		}		

		if ( $this->f("weapon_6_id") <> 0 ) {
			$this->Current_weapons[6] = $this->f("weapon_6_id");	
		}		

		if ( $this->f("weapon_7_id") <> 0 ) {
			$this->Current_weapons[7] = $this->f("weapon_7_id");				
		}		

		if ( $this->f("weapon_8_id") <> 0 ) {
			$this->Current_weapons[8] = $this->f("weapon_8_id");			
		}		
		
  	return $this->Query_ID;
  }

	function get_new_weapons($ship_id) {
    $this->connect();
  	$query = "insert into ship_weapons (ship_id) values($ship_id)";
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
   	
   	$db = new ME_DB;
		$db->query("select * from ship_weapon_id");
		$db->next_record();
	  $str = $db->f("last_value");
	  $this->id = $str;
		$this->set_ship_id($ship_id);
	
	  $query = sprintf("select * from ship_weapons where ship_weapon_id = '%s'", $str);
		$this->Query_ID = pg_Exec($this->Link_ID, $query);
   	$this->Row   = 0;

   	$this->Error = pg_ErrorMessage($this->Link_ID);
   	$this->Errno = ($this->Error == "")?0:1;
   	if (!$this->Query_ID) {
     		$this->halt("Invalid SQL: ".$Query_String);
   	}
	
		$this->next_record();
    return $this->Query_ID;
  }

  function save() {
		if ( count($this->dirty_fields) ) {
			$db = new ME_DB;
			$str = "update ship_weapons set ";		
			$i = 1;

			while (list($key, $val) = each($this->dirty_fields)) {
				$str = $str . " " . $key . " = '" . $val . "'";

				if ( $i < count($this->dirty_fields) ) {
					$str = $str . ", ";
				}
			
				$i++;
			}
					
			$str = $str . " where ship_weapon_id = '$this->id'";		
			$db->query($str);
		
			$this->dirty_fields = array();
		}			
	}	

	function set_player_id($n) {
		$this->dirty_fields["player_id"] = $n;	 			
  }

	function set_ship_id($n) {
		$this->dirty_fields["ship_id"] = $n;	 	
  }

	function set_weapon_1_id($n) {
		$this->dirty_fields["weapon_1_id"] = $n;	 			
  }
	
	function set_weapon_1_name($n) {
		$this->dirty_fields["weapon_1_name"] = $n;	 			
  }

	function set_weapon_2_id($n) {
		$this->dirty_fields["weapon_2_id"] = $n;	 			
  }

	function set_weapon_2_name($n) {
		$this->dirty_fields["weapon_2_name"] = $n;	 			
  }

	function set_weapon_3_id($n) {
		$this->dirty_fields["weapon_3_id"] = $n;	 			
  }

	function set_weapon_3_name($n) {
		$this->dirty_fields["weapon_3_name"] = $n;	 			
  }

	function set_weapon_4_id($n) {
		$this->dirty_fields["weapon_4_id"] = $n;	 			
  }

	function set_weapon_4_name($n) {
		$this->dirty_fields["weapon_4_name"] = $n;	 			
  }

	function set_weapon_5_id($n) {
		$this->dirty_fields["weapon_5_id"] = $n;	 			
  }

	function set_weapon_5_name($n) {
		$this->dirty_fields["weapon_5_name"] = $n;	 			
  }

	function set_weapon_6_id($n) {
		$this->dirty_fields["weapon_6_id"] = $n;	 			
  }

	function set_weapon_6_name($n) {
		$this->dirty_fields["weapon_6_name"] = $n;	 			
  }

	function set_weapon_7_id($n) {
		$this->dirty_fields["weapon_7_id"] = $n;	 			
  }

	function set_weapon_7_name($n) {
		$this->dirty_fields["weapon_7_name"] = $n;	 			
  }

	function set_weapon_8_id($n) {
		$this->dirty_fields["weapon_8_id"] = $n;	 			
  }

	function set_weapon_8_name($n) {
		$this->dirty_fields["weapon_8_name"] = $n;	 			
  }
	
	function set_weapon_1_shield_damage($n) {
		$this->dirty_fields["weapon_1_shield_damage"] = $n;	 			
  }

	function set_weapon_2_shield_damage($n) {
		$this->dirty_fields["weapon_2_shield_damage"] = $n;	 			
  }

	function set_weapon_3_shield_damage($n) {
		$this->dirty_fields["weapon_3_shield_damage"] = $n;	 			
  }

	function set_weapon_4_shield_damage($n) {
		$this->dirty_fields["weapon_4_shield_damage"] = $n;	 			
  }

	function set_weapon_5_shield_damage($n) {
		$this->dirty_fields["weapon_5_shield_damage"] = $n;	 			
  }

	function set_weapon_6_shield_damage($n) {
		$this->dirty_fields["weapon_6_shield_damage"] = $n;	 			
  }

	function set_weapon_7_shield_damage($n) {
		$this->dirty_fields["weapon_7_shield_damage"] = $n;	 			
  }

	function set_weapon_8_shield_damage($n) {
		$this->dirty_fields["weapon_8_shield_damage"] = $n;	 			
  }

	function set_weapon_1_armor_damage($n) {
		$this->dirty_fields["weapon_1_armor_damage"] = $n;	 			
  }

	function set_weapon_2_armor_damage($n) {
		$this->dirty_fields["weapon_2_armor_damage"] = $n;	 			
  }

	function set_weapon_3_armor_damage($n) {
		$this->dirty_fields["weapon_3_armor_damage"] = $n;	 			
  }

	function set_weapon_4_armor_damage($n) {
		$this->dirty_fields["weapon_4_armor_damage"] = $n;	 			
  }

	function set_weapon_5_armor_damage($n) {
		$this->dirty_fields["weapon_5_armor_damage"] = $n;	 			
  }

	function set_weapon_6_armor_damage($n) {
		$this->dirty_fields["weapon_6_armor_damage"] = $n;	 			
  }

	function set_weapon_7_armor_damage($n) {
		$this->dirty_fields["weapon_7_armor_damage"] = $n;;	 			
  }

	function set_weapon_8_armor_damage($n) {
		$this->dirty_fields["weapon_8_armor_damage"] = $n;	 			
  }
}
?>
