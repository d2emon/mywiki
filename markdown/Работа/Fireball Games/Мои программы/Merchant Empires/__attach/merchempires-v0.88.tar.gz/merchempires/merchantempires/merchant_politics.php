<?php
/****************************************************************************
*    Copyright (C) 2000 Bryan Brunton
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
****************************************************************************/

page_open(array("sess" => "ME_Session_Uncached", "auth" => "ME_Auth", "user" => "ME_User"));
$sess->register("player_id");
$sess->register("player_dead");

include("./lib/player.php");
include("./lib/ship.php");
include("./lib/relations.php");
include("./merchantempiresdefines.php");
include("./lib/player_redirect.php");
?>

<html><head><title>Merchant Empires: Manage Politics</title>
<link rel=stylesheet href="./merchantempires.css" type=text/css>
</head><body text=white background="./images/createbg.gif"><?php

include("./templates/header.html");
?>

<table width=100%><tr>
<td width=100 vAlign=top><?php

$player = new ME_Player;
$player->get_player($player_id);
$player_dead = $player->f("dead");
$ship = new ME_Ship;
$ship->get_ship($player_id);

$ship->add_parameter("time", date ("Y H:i:s"));
$ship->add_parameter("current_screen", "merchant");
echo $ship->get_transform("./xslt/mainmenu.xslt", $ship->get_xml());
?>

</td>
<td vAlign=top align=left width=0>&nbsp;</td>
<td vAlign=top width=500><?php

$db = new ME_DB_Xml;	
$db->add_parameter("current_screen", "merchant_politics");	
echo $db->get_transform("./xslt/menu_top_merchant.xslt", "");

?>


<table border=0 cellPadding=0 cellSpacing=0>
	<tr>
		<td bgColor=#003399>
			<table border=0 cellPadding=5 cellSpacing=1 width=500>
				<tr>
					<td width=500 bgColor=#000000 align=left valign=middle>
						<table cols=2 width=100% border=0>
            	<tr>
								<td valign=top width=250>
									<font  color=#cccccc face=arial,helvetica,swiss size=3><?php

$race = $player->f("race");
$game_id = $player->f("game_id");

$relations = new ME_Relations;
$relations->initialize($game_id, $player->f("race_number"));

$db = new ME_DB;
$query = sprintf("SELECT player_id, experience, race, game_id from players where race = '$race' and game_id = '%s' order by experience desc limit 10", $game_id);
$db->query($query);

$council_member = 0;
$check_overlord = 1;

while ( $db->next_record() ) {
	if ( $check_overlord == 1 ) {
		if ( $db->f("player_id") == $player->f("player_id") ) {
			$overlord = 1;
		}		
		$check_overlord = 0;
	}

	if ( $db->f("player_id") == $player->f("player_id") ) {
		$council_member = 1;
	
		$db_c = new ME_DB;
		$query = sprintf("select * from council_votes where player_id = '%s'", $player->f("player_id"));
		$db_c->query($query);	
	  $db_c->next_record();
	}	
}

if ( ! ($council_member) ) {
	echo "You are not a member of your race's ruling council.";
}

$race_id = $player->f("race_number");
$db_g = new ME_DB;
$db_g->query("select games.*, overlord_votes.* from games, overlord_votes where games.game_id = '$game_id' and games.game_id = overlord_votes.game_id and overlord_votes.race_id = '$race_id'");
$db_g->next_record();

if ( $council_member ) {
	echo "<b><font color=#3333FF face=arial,helvetica,swiss size=3>Influence Global Relations</b></font>";
  echo "<form action=";
	echo $sess->url(URL . "merchant_update.php");
	echo " method=post>";
	echo "<table cellpadding=0 cellspacing=0>";
	echo "<tr>";
	
	$active_races = array();
	$active_races = explode(",", $db_g->f("active_races"));

	for ($i = 0; $i <= count($active_races) - 1; $i++) {
		if ( $player->f("race_number") <> $active_races[$i] ) {
			if ( $db_c->f("has_voted_" . $active_races[$i]) <> 1 ) {
				echo "<tr>";
				echo "<td><br><table><tr><td><FONT color=#cccccc face=arial,helvetica,swiss size=3>" . $db_g->f("namerace_" . $active_races[$i]) . "  </font></td><td>";

				switch ($active_races[$i]) {				
					case 1:
         		echo $relations->get_relations_1();
						break;
					case 2:
         		echo $relations->get_relations_2();
						break;
					case 3:
         		echo $relations->get_relations_3();
						break;
					case 4:
         		echo $relations->get_relations_4();
						break;
					case 5:
         		echo $relations->get_relations_5();
						break;
					case 6:
         		echo $relations->get_relations_6();
						break;
					case 7:
         		echo $relations->get_relations_7();
						break;
				}		

				echo "</td></tr></table>";			
				echo "</td></tr><tr><td >&nbsp;&nbsp;&nbsp;<small><input type=submit name=increase_" . $active_races[$i] . " value=Increase>";
				echo "&nbsp;<input type=submit name=decrease_" . $active_races[$i]. " value=Decrease></small><br>";
				echo "</td></tr>";
			} else {
				echo "<tr>";
				echo "<td><br><table><tr><td><FONT color=#cccccc face=arial,helvetica,swiss size=3>" . $db_g->f("namerace_" . $active_races[$i]) . "  </font></td><td>";

				switch ($active_races[$i]) {				
					case 1:
         		echo $relations->get_relations_1();
						break;
					case 2:
         		echo $relations->get_relations_2();
						break;
					case 3:
         		echo $relations->get_relations_3();
						break;
					case 4:
         		echo $relations->get_relations_4();
						break;
					case 5:
         		echo $relations->get_relations_5();
						break;
					case 6:
         		echo $relations->get_relations_6();
						break;
					case 7:
         		echo $relations->get_relations_7();
						break;
				}				

				echo "</td></tr></table>";
				echo "</td></tr><tr><td ><FONT color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;&nbsp;You choose to ";
			
				if ( $db_c->f("vote_" . $active_races[$i]) == 0 ) {
					echo "decrease";
				} else {
					echo "increase";
				}

				echo " relations with the " .  $db_g->f("namerace_" . $active_races[$i]) . ".";
				echo "</td></tr>";
			}
		}		
	}	
	
	echo "</table></form><br>";
}

if ( $overlord ) {
	echo "<b><font color=#3333FF face=arial,helvetica,swiss size=3>Declare War/Peace</b></font>";	
  echo "<form action=";
	echo $sess->url(URL . "merchant_update.php");
	echo " method=post>";
	echo "<table BORDER=0 cellpadding=0 cellspacing=0>";			

	for ($i = 0; $i <= count($active_races) - 1; $i++) {
		if ( $player->f("race_number") <> $active_races[$i] ) {
			echo "<tr><td><br><table><tr><td><FONT color=#cccccc face=arial,helvetica,swiss size=3>" . $db_g->f("namerace_" . $active_races[$i]) . "  </font></td><td>";

			switch ($active_races[$i]) {				
				case 1:
       		echo $relations->get_relations_1();
					break;
				case 2:
       		echo $relations->get_relations_2();
					break;
				case 3:
       		echo $relations->get_relations_3();
					break;
				case 4:
       		echo $relations->get_relations_4();
					break;
				case 5:
       		echo $relations->get_relations_5();
					break;
				case 6:
       		echo $relations->get_relations_6();
					break;
				case 7:
       		echo $relations->get_relations_7();
					break;
			}		

			echo "</td></tr></table>";

			if ( $db_g->f("overlord_has_voted_" . $active_races[$i]) == 1 ) {
				if ( $db_g->f("overlord_vote_" . $active_races[$i]) == 1 ) {
					echo "<FONT color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;&nbsp;You called for a council vote declaring war.  The council has not finished their vote for or against your declaration.";
				} elseif ( $db_g->f("overlord_vote_" . $active_races[$i]) == 2 ) {
					echo "<FONT color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;&nbsp;You called for a council vote declaring peace.  The council has not finished their vote for or against your declaration.";
				}				

				$comptime = $db_g->f("overlord_vote_" . $active_races[$i] . "_date");
				$currenttime = time();
				$d = ($comptime - $currenttime) / 3600;
				$g = ceil($d) - (($comptime - $currenttime) / 3600);
			
				if ( $comptime - $currenttime <= 0 ) {
					echo "The vote will be decided momentarily.";
				} else {
					if ($g == 0) {
						$minutes = "0";
					} else {
						$minutes = ((1 - $g) * 60) / 100;
						$minutes = substr($minutes, 2, 2);
    	
		  			if ( strlen($minutes) == 1) {
	  					$minutes = $minutes . "0";
						}
					}

					if ( strlen($db_g->f("overlord_council_votes_" . $active_races[$i])) > 0 ) {
						$votes = array();
						$votes = explode(",", $db_g->f("overlord_council_votes_" . $active_races[$i]));
						echo "<br><br>&nbsp;&nbsp;*** Vote Status ***";

						$for = 0;
						$against = 0;

						while (list($key, $val) = each($votes)) {		
							if ( $val == 0 ) {
								$against = $against + 1;
							} else {
								$for = $for + 1;
							}
						}

						echo "<br>&nbsp;&nbsp;" . $for . " for the declaration.";
						echo "<br>&nbsp;&nbsp;" . $against . " against the declaration.";
					} else {
						echo "<br><br>&nbsp;&nbsp;0 votes have been cast on this issue.";					
					}

					echo "<br><br>&nbsp;&nbsp;Remaining voting time: " . floor($d) . " hours and " . $minutes . " minutes.";		
				}
			} else {

				switch ($active_races[$i]) {				
					case 1:
 	    	 		if ( $relations->get_relations_1() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_1 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_1() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_1 value='Declare Peace'></small><br>";
						}	

						break;	

					case 2:
 	    	 		if ( $relations->get_relations_2() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_2 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_2() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_2 value='Declare Peace'></small><br>";
						}	

						break;	

					case 3:
 	    	 		if ( $relations->get_relations_3() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_3 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_3() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_3 value='Declare Peace'></small><br>";
						}	

						break;	

					case 4:
 	    	 		if ( $relations->get_relations_4() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_4 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_4() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_4 value='Declare Peace'></small><br>";
						}	

						break;	

					case 5:
 	    	 		if ( $relations->get_relations_5() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_5 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_5() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_5 value='Declare Peace'></small><br>";
						}	

						break;	

					case 6:
 	    	 		if ( $relations->get_relations_6() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_6 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_6() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_6 value='Declare Peace'></small><br>";
						}	

						break;	

					case 7:
 	    	 		if ( $relations->get_relations_7() > -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=war_7 value='Declare War'></small><br>";
						}	

						if ( $relations->get_relations_7() <= -300 ) {
							echo "</td></tr><tr><td>&nbsp;<input type=submit name=peace_7 value='Declare Peace'></small><br>";
						}	

						break;								
				}						
			}
		
			echo "</td></tr>";
		}	
	}	
	
	echo "</table></form>";
}	

if ( $council_member && !$overlord ) {
	echo "<b><font color=#3333FF face=arial,helvetica,swiss size=3>Racial Overlord Support</b></font>";
  echo "<form action=";
	echo $sess->url(URL . "merchant_update.php");
	echo " method=post>";
	echo "<table BORDER=0 cellpadding=0 cellspacing=0><tr>";

	if ( $db_g->f("overlord_has_voted_1") == 0 && $db_g->f("overlord_has_voted_2") == 0 && $db_g->f("overlord_has_voted_3") == 0 &&
			$db_g->f("overlord_has_voted_4") == 0 && $db_g->f("overlord_has_voted_5") == 0 && $db_g->f("overlord_has_voted_6") == 0 &&
			$db_g->f("overlord_has_voted_7") == 0) {

		echo "<FONT color=#cccccc face=arial,helvetica,swiss size=3>Your Overlord has not called for a Council vote on any issue.";
	}
	
	for ($i = 0; $i <= count($active_races) - 1; $i++) {			
		if ( $db_g->f("overlord_has_voted_" . $active_races[$i]) == 1 ) {
			if ( $player->f("race_number") <> $active_races[$i] ) {
				echo "<tr>";
				echo "<td><br><table border=1><tr><td><FONT color=#cccccc face=arial,helvetica,swiss size=3>" . $db_g->f("namerace_" . $active_races[$i]) . "  </font></td><td>";

				switch ($active_races[$i]) {				
					case 1:
  	     		echo $relations->get_relations_1();
						break;
					case 2:
  	     		echo $relations->get_relations_2();
						break;
					case 3:
  	     		echo $relations->get_relations_3();
						break;
					case 4:
  	     		echo $relations->get_relations_4();
						break;
					case 5:
  	     		echo $relations->get_relations_5();
						break;
					case 6:
  	     		echo $relations->get_relations_6();
						break;
					case 7:
    	   		echo $relations->get_relations_7();
						break;
				}		

				echo "</td></tr></table>";

				$votes = array();
				$votes = explode(",", $db_g->f("overlord_council_votes_" . $active_races[$i]));
					
				if ( $db_g->f("overlord_vote_" . $active_races[$i]) == 1 ) {
					echo "<FONT color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;&nbsp;Your racial Overlord has called for a declaration of war.<br>";

					if ( $db_c->f("overlord_has_voted_" . $active_races[$i]) == 1 ) {
						echo "<br>&nbsp;&nbsp;Your vote on this issue has already been cast.";
					} else {
						if ( count($votes) >= 9 ) {
							echo "<br>&nbsp;&nbsp;9 votes have been cast.";						
						} else {
							echo "<br>&nbsp;&nbsp;<input type=submit name=for_" . $active_races[$i] . " value=For>";
							echo "&nbsp;&nbsp;<input type=submit name=against_" . $active_races[$i] . " value=Against>";
						}
					}
				} elseif ( $db_g->f("overlord_vote_" . $active_races[$i]) == 2 ) {
					echo "<FONT color=#cccccc face=arial,helvetica,swiss size=3>&nbsp;&nbsp;Your racial Overlord has called for a declaraction of peace.";

					if ( $db_c->f("overlord_has_voted_" . $active_races[$i]) == 1 ) {
						echo "<br>&nbsp;&nbsp;Your vote on this issue has already been cast.";
					} else {
						if ( count($votes) >= 9 ) {
							echo "<br>&nbsp;&nbsp;9 votes have been cast.";						
						} else {
							echo "<br>&nbsp;&nbsp;<input type=submit name=for_" . $active_races[$i] . " value=For>";
							echo "&nbsp;&nbsp;<input type=submit name=against_" . $active_races[$i] . " value=Against>";
						}
					}
				}				

				$comptime = $db_g->f("overlord_vote_" . $active_races[$i] . "_date");
				$currenttime = time();
				$d = ($comptime - $currenttime) / 3600;
				$g = ceil($d) - (($comptime - $currenttime) / 3600);

				if ( $comptime - $currenttime <= 0 ) {
					echo "The vote will be decided momentarily.";
				} else {
					if ($g == 0) {
						$minutes = "0";
					} else {
						$minutes = ((1 - $g) * 60) / 100;
						$minutes = substr($minutes, 2, 2);
    	
		  			if ( strlen($minutes) == 1) {
	  					$minutes = $minutes . "0";
						}
					}

					if ( strlen($db_g->f("overlord_council_votes_" . $active_races[$i])) > 0 ) {					
						echo "<br><br>&nbsp;&nbsp;*** Vote Status ***";

						$for = 0;
						$against = 0;

						while (list($key, $val) = each($votes)) {		
							if ( $val == 0 ) {
								$against = $against + 1;
							} else {
								$for = $for + 1;
							}
						}

						echo "<br>&nbsp;&nbsp;" . $for . " for the declaration.";
						echo "<br>&nbsp;&nbsp;" . $against . " against the declaration.";
					} else {
						echo "<br><br>&nbsp;&nbsp;0 votes have been cast on this issue.";					
					}
								
					echo "<br><br>&nbsp;&nbsp;Remaining voting time: " . floor($d) . " hours and " . $minutes . " minutes.";						
				}		  					
			}							
		}		
	}	
	
	echo "</td></tr></table></form>";
}
?>
										
									</font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table><br><?php

if ( $error ) {
	$db = new ME_DB_Xml;	
	$db->add_parameter("title", "Error");
	
	if ($error == 1) {
		$db->add_parameter("message", "Your merchant has already influenced that issue today.");		
	} elseif ($error == 2) {
		$db->add_parameter("message", "A state of war already exists with that race.");			
	} elseif ($error == 3) {
		$db->add_parameter("message", "You have already called for a vote on that issue.");			
	} elseif ($error == 4) {
		$db->add_parameter("message", "A state of peace already exists with that race.");			
	} elseif ($error == 5) {
		$db->add_parameter("message", "Your vote has already been cast on that issue.");			
	} elseif ($error == 6) {
		$db->add_parameter("message", "10 votes have already been cast on that issue.");			
	} elseif ($error == 7) {
		$db->add_parameter("message", "A state of peace already exists with that race.");			
	}
	
	echo $db->get_transform("./xslt/message_box.xslt", "");
}
?>

</td>
<td valign=top align=right width=100%><?php

include("./messages_display.php");
echo $player->get_transform("./xslt/player.xslt", $player->get_xml());
include("./ship_display.php");
?>

</td></tr></table>
</body></html><?php

page_close();
?>
